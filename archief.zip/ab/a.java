package ab;

import com.google.firebase.perf.v1.NetworkRequestMetric;
import com.google.firebase.perf.v1.f;
import com.google.firebase.perf.v1.i;
import qb.o;

/* compiled from: PerfMetricOrBuilder */
public interface a extends o {
    boolean g();

    f h();

    boolean k();

    i l();

    boolean m();

    NetworkRequestMetric n();
}
