package a9;

import java.lang.Thread;
import java.util.Locale;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;

/* compiled from: ThreadFactoryBuilder */
public final class b implements ThreadFactory {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ ThreadFactory f868p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ String f869q;

    /* renamed from: r  reason: collision with root package name */
    public final /* synthetic */ AtomicLong f870r;

    public b(ThreadFactory threadFactory, String str, AtomicLong atomicLong, Boolean bool, Integer num, Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.f868p = threadFactory;
        this.f869q = str;
        this.f870r = atomicLong;
    }

    public Thread newThread(Runnable runnable) {
        Thread newThread = this.f868p.newThread(runnable);
        String str = this.f869q;
        if (str != null) {
            newThread.setName(String.format(Locale.ROOT, str, new Object[]{Long.valueOf(this.f870r.getAndIncrement())}));
        }
        return newThread;
    }
}
