package ad;

import z1.c;

/* compiled from: AgentCallback */
public interface c<R extends z1.c> {
    void f(R r10);
}
