package ad;

/* compiled from: AgentCallback */
public interface b {
    void g(boolean z10);
}
