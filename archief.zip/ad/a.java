package ad;

import com.tinnotech.penblesdk.Constants$OtaPushError;

/* compiled from: AgentCallback */
public interface a {
    void otaPushError(Constants$OtaPushError constants$OtaPushError);

    void otaPushFinish();

    void otaPushProgress(double d10);

    void otaPushSpeed(double d10, double d11);
}
