package ad;

import fd.a;

/* compiled from: AgentCallback */
public interface d<R extends a> {
    void b(R r10);
}
