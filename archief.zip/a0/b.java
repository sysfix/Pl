package a0;

import ai.plaud.android.plaud.common.util.AppProvider;
import android.content.IntentFilter;

/* compiled from: BroadcastReceiverHelper.kt */
public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static b f660a;

    public b() {
        a aVar = new a();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.bluetooth.adapter.action.STATE_CHANGED");
        AppProvider.a().registerReceiver(aVar, intentFilter);
        e eVar = new e();
        IntentFilter intentFilter2 = new IntentFilter();
        intentFilter2.addAction("android.net.wifi.STATE_CHANGE");
        intentFilter2.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        intentFilter2.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        intentFilter2.addAction("android.net.wifi.supplicant.CONNECTION_CHANGE");
        intentFilter2.addAction("android.net.wifi.supplicant.STATE_CHANGE");
        AppProvider.a().registerReceiver(eVar, intentFilter2);
        c cVar = new c();
        IntentFilter intentFilter3 = new IntentFilter();
        intentFilter3.addAction("android.intent.action.TIMEZONE_CHANGED");
        AppProvider.a().registerReceiver(cVar, intentFilter3);
        d dVar = new d();
        IntentFilter intentFilter4 = new IntentFilter();
        intentFilter4.addAction("android.intent.action.LOCALE_CHANGED");
        AppProvider.a().registerReceiver(dVar, intentFilter4);
    }
}
