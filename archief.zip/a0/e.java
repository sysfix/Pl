package a0;

import a.d;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;
import ci.a;
import com.blankj.utilcode.util.f;
import com.blankj.utilcode.util.i;
import com.google.firebase.perf.v1.NetworkRequestMetric;
import kotlin.NoWhenBranchMatchedException;
import okhttp3.HttpUrl;
import q.b;
import rg.d0;

/* compiled from: WiFiStateReceiver.kt */
public final class e extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        String str;
        boolean z10;
        d0.g(context, "context");
        d0.g(intent, "intent");
        a.C0057a aVar = a.f4931a;
        aVar.a("WiFiStateReceiver", new Object[0]);
        String action = intent.getAction();
        if (action != null) {
            switch (action.hashCode()) {
                case -1875733435:
                    if (action.equals("android.net.wifi.WIFI_STATE_CHANGED")) {
                        aVar.a("WIFI_STATE_CHANGED_ACTION", new Object[0]);
                        return;
                    }
                    return;
                case -1172645946:
                    if (action.equals("android.net.conn.CONNECTIVITY_CHANGE")) {
                        aVar.a("CONNECTIVITY_ACTION", new Object[0]);
                        return;
                    }
                    return;
                case -343630553:
                    if (action.equals("android.net.wifi.STATE_CHANGE")) {
                        aVar.a("NETWORK_STATE_CHANGED_ACTION", new Object[0]);
                        NetworkInfo networkInfo = (NetworkInfo) intent.getParcelableExtra("networkInfo");
                        NetworkInfo.State state = null;
                        aVar.d("wifi 连接状态 " + (networkInfo != null ? networkInfo.getState() : null), new Object[0]);
                        if ((networkInfo != null ? networkInfo.getState() : null) == NetworkInfo.State.CONNECTED) {
                            Object systemService = context.getSystemService("wifi");
                            d0.e(systemService, "null cannot be cast to non-null type android.net.wifi.WifiManager");
                            WifiInfo connectionInfo = ((WifiManager) systemService).getConnectionInfo();
                            d0.f(connectionInfo.getSSID(), "connectionInfo.ssid");
                            String ssid = connectionInfo.getSSID();
                            int i10 = f.f5612a;
                            WifiManager wifiManager = (WifiManager) i.a().getSystemService("wifi");
                            if (wifiManager == null) {
                                str = HttpUrl.FRAGMENT_ENCODE_SET;
                            } else {
                                str = Formatter.formatIpAddress(wifiManager.getDhcpInfo().ipAddress);
                            }
                            aVar.d("connectedSSID " + ssid + " IpAddress " + str, new Object[0]);
                            return;
                        }
                        if (networkInfo != null) {
                            state = networkInfo.getState();
                        }
                        if (state == NetworkInfo.State.CONNECTING) {
                            Object systemService2 = context.getSystemService("wifi");
                            d0.e(systemService2, "null cannot be cast to non-null type android.net.wifi.WifiManager");
                            WifiInfo connectionInfo2 = ((WifiManager) systemService2).getConnectionInfo();
                            d0.f(connectionInfo2.getSSID(), "connectionInfo.ssid");
                            aVar.d(d.a("connectingSSID ", connectionInfo2.getSSID()), new Object[0]);
                            return;
                        }
                        return;
                    }
                    return;
                case 68995823:
                    if (action.equals("android.net.wifi.supplicant.CONNECTION_CHANGE")) {
                        aVar.a("SUPPLICANT_CONNECTION_CHANGE_ACTION", new Object[0]);
                        return;
                    }
                    return;
                case 233521600:
                    if (action.equals("android.net.wifi.supplicant.STATE_CHANGE")) {
                        aVar.a("SUPPLICANT_STATE_CHANGED_ACTION", new Object[0]);
                        SupplicantState supplicantState = (SupplicantState) intent.getParcelableExtra("newState");
                        if (supplicantState == null) {
                            aVar.a("supplicantState 是空", new Object[0]);
                            return;
                        }
                        aVar.a("supplicantState " + supplicantState, new Object[0]);
                        b.b(supplicantState);
                        b.a(supplicantState);
                        SupplicantState supplicantState2 = SupplicantState.SCANNING;
                        boolean z11 = true;
                        boolean z12 = (supplicantState == SupplicantState.UNINITIALIZED || supplicantState == SupplicantState.INVALID) ? false : true;
                        boolean b10 = b.b(supplicantState);
                        boolean a10 = b.a(supplicantState);
                        switch (b.a.f15666a[supplicantState.ordinal()]) {
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                            case 7:
                            case 9:
                            case 10:
                            case 11:
                                z10 = true;
                                break;
                            case 8:
                            case 12:
                            case NetworkRequestMetric.PERF_SESSIONS_FIELD_NUMBER /*13*/:
                                z10 = false;
                                break;
                            default:
                                throw new NoWhenBranchMatchedException();
                        }
                        if (supplicantState != SupplicantState.SCANNING) {
                            z11 = false;
                        }
                        aVar.a("isValidState " + z12 + " isHandshakeState " + b10 + " isConnecting " + a10 + " isDriverActive " + z10 + " isScanning " + z11, new Object[0]);
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }
}
