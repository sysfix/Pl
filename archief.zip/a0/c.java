package a0;

import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import ci.a;
import rg.d0;

/* compiled from: DateTimeReceiver.kt */
public final class c extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        d0.g(intent, "intent");
        if (d0.b("android.intent.action.TIMEZONE_CHANGED", intent.getAction())) {
            a.C0057a aVar = a.f4931a;
            aVar.d("timezone changed", new Object[0]);
            aVar.d("同步时区时间", new Object[0]);
            FlutterDeviceManager.INSTANCE.syncTime();
        }
    }
}
