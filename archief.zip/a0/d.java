package a0;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import ci.a;
import he.b;
import java.util.Locale;
import qe.e;
import rg.d0;
import yf.h;

/* compiled from: LocaleReceiver.kt */
public final class d extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        e eVar;
        d0.g(intent, "intent");
        if (d0.b("android.intent.action.LOCALE_CHANGED", intent.getAction())) {
            a.f4931a.a("ACTION_LOCALE_CHANGED", new Object[0]);
            io.flutter.embedding.engine.a aVar = (io.flutter.embedding.engine.a) b.a().f11704a.get("plaud_flutter_engine_id");
            if (aVar != null && (eVar = aVar.f12229h) != null) {
                eVar.a(h.B(Locale.getDefault()));
            }
        }
    }
}
