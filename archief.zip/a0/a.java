package a0;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import rg.d0;

/* compiled from: BluetoothStateBroadcastReceiver.kt */
public final class a extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        d0.g(context, "context");
        d0.g(intent, "intent");
        String action = intent.getAction();
        if (action != null && action.hashCode() == -1530327060 && action.equals("android.bluetooth.adapter.action.STATE_CHANGED")) {
            int intExtra = intent.getIntExtra("android.bluetooth.adapter.extra.STATE", 0);
            if (intExtra == 10) {
                ci.a.f4931a.d("蓝牙已关闭", new Object[0]);
            } else if (intExtra == 12) {
                ci.a.f4931a.d("蓝牙已开启", new Object[0]);
            }
        }
    }
}
