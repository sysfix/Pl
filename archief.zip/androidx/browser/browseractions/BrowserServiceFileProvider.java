package androidx.browser.browseractions;

import androidx.core.content.FileProvider;

@Deprecated
public final class BrowserServiceFileProvider extends FileProvider {
}
