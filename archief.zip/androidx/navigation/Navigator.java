package androidx.navigation;

import android.os.Bundle;
import h2.l;
import h2.q;
import h2.x;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.List;
import java.util.ListIterator;
import kotlin.sequences.SequencesKt___SequencesKt$filterNotNull$1;
import og.e;
import og.o;
import rg.d0;

/* compiled from: Navigator.kt */
public abstract class Navigator<D extends l> {

    /* renamed from: a  reason: collision with root package name */
    public x f3371a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f3372b;

    /* compiled from: Navigator.kt */
    public interface a {
    }

    @Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE})
    @Retention(RetentionPolicy.RUNTIME)
    /* compiled from: Navigator.kt */
    public @interface b {
        String value();
    }

    public abstract D a();

    public final x b() {
        x xVar = this.f3371a;
        if (xVar != null) {
            return xVar;
        }
        throw new IllegalStateException("You cannot access the Navigator's state until the Navigator is attached".toString());
    }

    public l c(D d10, Bundle bundle, q qVar, a aVar) {
        return d10;
    }

    public void d(List<NavBackStackEntry> list, q qVar, a aVar) {
        d0.g(list, "entries");
        o oVar = new o(yf.l.X(list), new Navigator$navigate$1(this, qVar, aVar));
        SequencesKt___SequencesKt$filterNotNull$1 sequencesKt___SequencesKt$filterNotNull$1 = SequencesKt___SequencesKt$filterNotNull$1.INSTANCE;
        d0.g(sequencesKt___SequencesKt$filterNotNull$1, "predicate");
        e.a aVar2 = new e.a(new e(oVar, false, sequencesKt___SequencesKt$filterNotNull$1));
        while (aVar2.hasNext()) {
            b().c((NavBackStackEntry) aVar2.next());
        }
    }

    public void e(x xVar) {
        this.f3371a = xVar;
        this.f3372b = true;
    }

    public void f(Bundle bundle) {
    }

    public Bundle g() {
        return null;
    }

    public void h(NavBackStackEntry navBackStackEntry, boolean z10) {
        d0.g(navBackStackEntry, "popUpTo");
        List value = b().f11445e.getValue();
        if (value.contains(navBackStackEntry)) {
            ListIterator listIterator = value.listIterator(value.size());
            NavBackStackEntry navBackStackEntry2 = null;
            while (i()) {
                navBackStackEntry2 = (NavBackStackEntry) listIterator.previous();
                if (d0.b(navBackStackEntry2, navBackStackEntry)) {
                    break;
                }
            }
            if (navBackStackEntry2 != null) {
                b().b(navBackStackEntry2, z10);
                return;
            }
            return;
        }
        throw new IllegalStateException(("popBackStack was called with " + navBackStackEntry + " which does not exist in back stack " + value).toString());
    }

    public boolean i() {
        return true;
    }
}
