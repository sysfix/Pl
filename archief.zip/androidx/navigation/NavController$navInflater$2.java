package androidx.navigation;

import gg.a;
import h2.p;
import java.util.Objects;
import kotlin.jvm.internal.Lambda;

/* compiled from: NavController.kt */
public final class NavController$navInflater$2 extends Lambda implements a<p> {
    public final /* synthetic */ NavController this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NavController$navInflater$2(NavController navController) {
        super(0);
        this.this$0 = navController;
    }

    public final p invoke() {
        Objects.requireNonNull(this.this$0);
        NavController navController = this.this$0;
        return new p(navController.f3327a, navController.f3348v);
    }
}
