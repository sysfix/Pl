package androidx.navigation;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import androidx.lifecycle.AbstractSavedStateViewModelFactory;
import androidx.lifecycle.HasDefaultViewModelProviderFactory;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.SavedStateHandleSupport;
import androidx.lifecycle.SavedStateViewModelFactory;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.lifecycle.viewmodel.MutableCreationExtras;
import h2.l;
import h2.u;
import java.util.Set;
import java.util.UUID;
import kotlin.jvm.internal.DefaultConstructorMarker;
import rg.d0;
import xf.d;
import xf.e;

/* compiled from: NavBackStackEntry.kt */
public final class NavBackStackEntry implements LifecycleOwner, ViewModelStoreOwner, HasDefaultViewModelProviderFactory, p2.b {
    public static final a C = new a((DefaultConstructorMarker) null);
    public final d A;
    public Lifecycle.State B;

    /* renamed from: p  reason: collision with root package name */
    public final Context f3311p;

    /* renamed from: q  reason: collision with root package name */
    public l f3312q;

    /* renamed from: r  reason: collision with root package name */
    public final Bundle f3313r;

    /* renamed from: s  reason: collision with root package name */
    public Lifecycle.State f3314s;

    /* renamed from: t  reason: collision with root package name */
    public final u f3315t;

    /* renamed from: u  reason: collision with root package name */
    public final String f3316u;

    /* renamed from: v  reason: collision with root package name */
    public final Bundle f3317v;

    /* renamed from: w  reason: collision with root package name */
    public LifecycleRegistry f3318w = new LifecycleRegistry(this);

    /* renamed from: x  reason: collision with root package name */
    public final p2.a f3319x;

    /* renamed from: y  reason: collision with root package name */
    public boolean f3320y;

    /* renamed from: z  reason: collision with root package name */
    public final d f3321z;

    /* compiled from: NavBackStackEntry.kt */
    public static final class a {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
        }

        public static /* synthetic */ NavBackStackEntry b(a aVar, Context context, l lVar, Bundle bundle, Lifecycle.State state, u uVar, String str, Bundle bundle2, int i10) {
            String str2 = null;
            Bundle bundle3 = (i10 & 4) != 0 ? null : bundle;
            Lifecycle.State state2 = (i10 & 8) != 0 ? Lifecycle.State.CREATED : state;
            u uVar2 = (i10 & 16) != 0 ? null : uVar;
            if ((i10 & 32) != 0) {
                str2 = UUID.randomUUID().toString();
                d0.f(str2, "randomUUID().toString()");
            }
            return aVar.a(context, lVar, bundle3, state2, uVar2, str2, (Bundle) null);
        }

        public final NavBackStackEntry a(Context context, l lVar, Bundle bundle, Lifecycle.State state, u uVar, String str, Bundle bundle2) {
            l lVar2 = lVar;
            d0.g(lVar, "destination");
            Lifecycle.State state2 = state;
            d0.g(state, "hostLifecycleState");
            String str2 = str;
            d0.g(str, "id");
            return new NavBackStackEntry(context, lVar, bundle, state, uVar, str, bundle2);
        }
    }

    /* compiled from: NavBackStackEntry.kt */
    public static final class b extends AbstractSavedStateViewModelFactory {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(p2.b bVar) {
            super(bVar, (Bundle) null);
            d0.g(bVar, "owner");
        }

        public <T extends ViewModel> T create(String str, Class<T> cls, SavedStateHandle savedStateHandle) {
            d0.g(str, "key");
            d0.g(cls, "modelClass");
            d0.g(savedStateHandle, "handle");
            return new c(savedStateHandle);
        }
    }

    /* compiled from: NavBackStackEntry.kt */
    public static final class c extends ViewModel {

        /* renamed from: a  reason: collision with root package name */
        public final SavedStateHandle f3322a;

        public c(SavedStateHandle savedStateHandle) {
            d0.g(savedStateHandle, "handle");
            this.f3322a = savedStateHandle;
        }
    }

    public NavBackStackEntry(Context context, l lVar, Bundle bundle, Lifecycle.State state, u uVar, String str, Bundle bundle2) {
        this.f3311p = context;
        this.f3312q = lVar;
        this.f3313r = bundle;
        this.f3314s = state;
        this.f3315t = uVar;
        this.f3316u = str;
        this.f3317v = bundle2;
        d0.g(this, "owner");
        this.f3319x = new p2.a(this, (DefaultConstructorMarker) null);
        this.f3321z = e.a(new NavBackStackEntry$defaultFactory$2(this));
        this.A = e.a(new NavBackStackEntry$savedStateHandle$2(this));
        this.B = Lifecycle.State.INITIALIZED;
    }

    public final void a(Lifecycle.State state) {
        d0.g(state, "maxState");
        this.B = state;
        b();
    }

    public final void b() {
        if (!this.f3320y) {
            this.f3319x.b();
            this.f3320y = true;
            if (this.f3315t != null) {
                SavedStateHandleSupport.enableSavedStateHandles(this);
            }
            this.f3319x.c(this.f3317v);
        }
        if (this.f3314s.ordinal() < this.B.ordinal()) {
            this.f3318w.setCurrentState(this.f3314s);
        } else {
            this.f3318w.setCurrentState(this.B);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:44:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r7) {
        /*
            r6 = this;
            r0 = 0
            if (r7 == 0) goto L_0x0083
            boolean r1 = r7 instanceof androidx.navigation.NavBackStackEntry
            if (r1 != 0) goto L_0x0009
            goto L_0x0083
        L_0x0009:
            java.lang.String r1 = r6.f3316u
            androidx.navigation.NavBackStackEntry r7 = (androidx.navigation.NavBackStackEntry) r7
            java.lang.String r2 = r7.f3316u
            boolean r1 = rg.d0.b(r1, r2)
            r2 = 1
            if (r1 == 0) goto L_0x0083
            h2.l r1 = r6.f3312q
            h2.l r3 = r7.f3312q
            boolean r1 = rg.d0.b(r1, r3)
            if (r1 == 0) goto L_0x0083
            androidx.lifecycle.LifecycleRegistry r1 = r6.f3318w
            androidx.lifecycle.LifecycleRegistry r3 = r7.f3318w
            boolean r1 = rg.d0.b(r1, r3)
            if (r1 == 0) goto L_0x0083
            p2.a r1 = r6.f3319x
            androidx.savedstate.a r1 = r1.f15365b
            p2.a r3 = r7.f3319x
            androidx.savedstate.a r3 = r3.f15365b
            boolean r1 = rg.d0.b(r1, r3)
            if (r1 == 0) goto L_0x0083
            android.os.Bundle r1 = r6.f3313r
            android.os.Bundle r3 = r7.f3313r
            boolean r1 = rg.d0.b(r1, r3)
            if (r1 != 0) goto L_0x0082
            android.os.Bundle r1 = r6.f3313r
            if (r1 == 0) goto L_0x007f
            java.util.Set r1 = r1.keySet()
            if (r1 == 0) goto L_0x007f
            boolean r3 = r1.isEmpty()
            if (r3 == 0) goto L_0x0054
        L_0x0052:
            r7 = r2
            goto L_0x007b
        L_0x0054:
            java.util.Iterator r1 = r1.iterator()
        L_0x0058:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto L_0x0052
            java.lang.Object r3 = r1.next()
            java.lang.String r3 = (java.lang.String) r3
            android.os.Bundle r4 = r6.f3313r
            java.lang.Object r4 = r4.get(r3)
            android.os.Bundle r5 = r7.f3313r
            if (r5 == 0) goto L_0x0073
            java.lang.Object r3 = r5.get(r3)
            goto L_0x0074
        L_0x0073:
            r3 = 0
        L_0x0074:
            boolean r3 = rg.d0.b(r4, r3)
            if (r3 != 0) goto L_0x0058
            r7 = r0
        L_0x007b:
            if (r7 != r2) goto L_0x007f
            r7 = r2
            goto L_0x0080
        L_0x007f:
            r7 = r0
        L_0x0080:
            if (r7 == 0) goto L_0x0083
        L_0x0082:
            r0 = r2
        L_0x0083:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.NavBackStackEntry.equals(java.lang.Object):boolean");
    }

    public CreationExtras getDefaultViewModelCreationExtras() {
        Application application = null;
        MutableCreationExtras mutableCreationExtras = new MutableCreationExtras((CreationExtras) null, 1, (DefaultConstructorMarker) null);
        Context context = this.f3311p;
        Context applicationContext = context != null ? context.getApplicationContext() : null;
        if (applicationContext instanceof Application) {
            application = (Application) applicationContext;
        }
        if (application != null) {
            mutableCreationExtras.set(ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY, application);
        }
        mutableCreationExtras.set(SavedStateHandleSupport.SAVED_STATE_REGISTRY_OWNER_KEY, this);
        mutableCreationExtras.set(SavedStateHandleSupport.VIEW_MODEL_STORE_OWNER_KEY, this);
        Bundle bundle = this.f3313r;
        if (bundle != null) {
            mutableCreationExtras.set(SavedStateHandleSupport.DEFAULT_ARGS_KEY, bundle);
        }
        return mutableCreationExtras;
    }

    public ViewModelProvider.Factory getDefaultViewModelProviderFactory() {
        return (SavedStateViewModelFactory) this.f3321z.getValue();
    }

    public Lifecycle getLifecycle() {
        return this.f3318w;
    }

    public androidx.savedstate.a getSavedStateRegistry() {
        return this.f3319x.f15365b;
    }

    public ViewModelStore getViewModelStore() {
        if (this.f3320y) {
            if (this.f3318w.getCurrentState() != Lifecycle.State.DESTROYED) {
                u uVar = this.f3315t;
                if (uVar != null) {
                    return uVar.b(this.f3316u);
                }
                throw new IllegalStateException("You must call setViewModelStore() on your NavHostController before accessing the ViewModelStore of a navigation graph.".toString());
            }
            throw new IllegalStateException("You cannot access the NavBackStackEntry's ViewModels after the NavBackStackEntry is destroyed.".toString());
        }
        throw new IllegalStateException("You cannot access the NavBackStackEntry's ViewModels until it is added to the NavController's back stack (i.e., the Lifecycle of the NavBackStackEntry reaches the CREATED state).".toString());
    }

    public int hashCode() {
        Set<String> keySet;
        int hashCode = this.f3312q.hashCode() + (this.f3316u.hashCode() * 31);
        Bundle bundle = this.f3313r;
        if (!(bundle == null || (keySet = bundle.keySet()) == null)) {
            for (String str : keySet) {
                int i10 = hashCode * 31;
                Object obj = this.f3313r.get(str);
                hashCode = i10 + (obj != null ? obj.hashCode() : 0);
            }
        }
        return this.f3319x.f15365b.hashCode() + ((this.f3318w.hashCode() + (hashCode * 31)) * 31);
    }
}
