package androidx.navigation;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.lifecycle.Lifecycle;
import h2.j;
import h2.l;
import rg.d0;

@SuppressLint({"BanParcelableUsage"})
/* compiled from: NavBackStackEntryState.kt */
public final class NavBackStackEntryState implements Parcelable {
    public static final Parcelable.Creator<NavBackStackEntryState> CREATOR = new a();

    /* renamed from: p  reason: collision with root package name */
    public final String f3323p;

    /* renamed from: q  reason: collision with root package name */
    public final int f3324q;

    /* renamed from: r  reason: collision with root package name */
    public final Bundle f3325r;

    /* renamed from: s  reason: collision with root package name */
    public final Bundle f3326s;

    /* compiled from: NavBackStackEntryState.kt */
    public static final class a implements Parcelable.Creator<NavBackStackEntryState> {
        public Object createFromParcel(Parcel parcel) {
            d0.g(parcel, "inParcel");
            return new NavBackStackEntryState(parcel);
        }

        public Object[] newArray(int i10) {
            return new NavBackStackEntryState[i10];
        }
    }

    public NavBackStackEntryState(NavBackStackEntry navBackStackEntry) {
        d0.g(navBackStackEntry, "entry");
        this.f3323p = navBackStackEntry.f3316u;
        this.f3324q = navBackStackEntry.f3312q.f11382w;
        this.f3325r = navBackStackEntry.f3313r;
        Bundle bundle = new Bundle();
        this.f3326s = bundle;
        d0.g(bundle, "outBundle");
        navBackStackEntry.f3319x.d(bundle);
    }

    public final NavBackStackEntry a(Context context, l lVar, Lifecycle.State state, j jVar) {
        d0.g(context, "context");
        d0.g(state, "hostLifecycleState");
        Bundle bundle = this.f3325r;
        if (bundle != null) {
            bundle.setClassLoader(context.getClassLoader());
        } else {
            bundle = null;
        }
        String str = this.f3323p;
        Bundle bundle2 = this.f3326s;
        d0.g(str, "id");
        return new NavBackStackEntry(context, lVar, bundle, state, jVar, str, bundle2);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        d0.g(parcel, "parcel");
        parcel.writeString(this.f3323p);
        parcel.writeInt(this.f3324q);
        parcel.writeBundle(this.f3325r);
        parcel.writeBundle(this.f3326s);
    }

    public NavBackStackEntryState(Parcel parcel) {
        String readString = parcel.readString();
        d0.d(readString);
        this.f3323p = readString;
        this.f3324q = parcel.readInt();
        this.f3325r = parcel.readBundle(NavBackStackEntryState.class.getClassLoader());
        Bundle readBundle = parcel.readBundle(NavBackStackEntryState.class.getClassLoader());
        d0.d(readBundle);
        this.f3326s = readBundle;
    }
}
