package androidx.navigation;

import android.os.Bundle;
import gg.l;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Ref$BooleanRef;
import rg.d0;
import xf.g;

/* compiled from: NavController.kt */
public final class NavController$navigate$4 extends Lambda implements l<NavBackStackEntry, g> {
    public final /* synthetic */ Bundle $finalArgs;
    public final /* synthetic */ Ref$BooleanRef $navigated;
    public final /* synthetic */ h2.l $node;
    public final /* synthetic */ NavController this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NavController$navigate$4(Ref$BooleanRef ref$BooleanRef, NavController navController, h2.l lVar, Bundle bundle) {
        super(1);
        this.$navigated = ref$BooleanRef;
        this.this$0 = navController;
        this.$node = lVar;
        this.$finalArgs = bundle;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((NavBackStackEntry) obj);
        return g.f19030a;
    }

    public final void invoke(NavBackStackEntry navBackStackEntry) {
        d0.g(navBackStackEntry, "it");
        this.$navigated.element = true;
        this.this$0.a(this.$node, this.$finalArgs, navBackStackEntry, EmptyList.INSTANCE);
    }
}
