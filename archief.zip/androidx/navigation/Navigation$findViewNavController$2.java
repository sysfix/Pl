package androidx.navigation;

import ai.plaud.android.plaud.R;
import android.view.View;
import gg.l;
import java.lang.ref.WeakReference;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: Navigation.kt */
public final class Navigation$findViewNavController$2 extends Lambda implements l<View, NavController> {
    public static final Navigation$findViewNavController$2 INSTANCE = new Navigation$findViewNavController$2();

    public Navigation$findViewNavController$2() {
        super(1);
    }

    public final NavController invoke(View view) {
        d0.g(view, "it");
        Object tag = view.getTag(R.id.nav_controller_view_tag);
        if (tag instanceof WeakReference) {
            return (NavController) ((WeakReference) tag).get();
        }
        if (tag instanceof NavController) {
            return (NavController) tag;
        }
        return null;
    }
}
