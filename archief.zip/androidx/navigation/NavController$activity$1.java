package androidx.navigation;

import android.content.Context;
import android.content.ContextWrapper;
import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: NavController.kt */
public final class NavController$activity$1 extends Lambda implements l<Context, Context> {
    public static final NavController$activity$1 INSTANCE = new NavController$activity$1();

    public NavController$activity$1() {
        super(1);
    }

    public final Context invoke(Context context) {
        d0.g(context, "it");
        if (context instanceof ContextWrapper) {
            return ((ContextWrapper) context).getBaseContext();
        }
        return null;
    }
}
