package androidx.navigation;

import android.os.Bundle;
import gg.l;
import java.util.List;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$IntRef;
import rg.d0;
import xf.g;

/* compiled from: NavController.kt */
public final class NavController$restoreStateInternal$4 extends Lambda implements l<NavBackStackEntry, g> {
    public final /* synthetic */ Bundle $args;
    public final /* synthetic */ List<NavBackStackEntry> $entries;
    public final /* synthetic */ Ref$IntRef $lastNavigatedIndex;
    public final /* synthetic */ Ref$BooleanRef $navigated;
    public final /* synthetic */ NavController this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NavController$restoreStateInternal$4(Ref$BooleanRef ref$BooleanRef, List<NavBackStackEntry> list, Ref$IntRef ref$IntRef, NavController navController, Bundle bundle) {
        super(1);
        this.$navigated = ref$BooleanRef;
        this.$entries = list;
        this.$lastNavigatedIndex = ref$IntRef;
        this.this$0 = navController;
        this.$args = bundle;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((NavBackStackEntry) obj);
        return g.f19030a;
    }

    public final void invoke(NavBackStackEntry navBackStackEntry) {
        List<NavBackStackEntry> list;
        d0.g(navBackStackEntry, "entry");
        this.$navigated.element = true;
        int indexOf = this.$entries.indexOf(navBackStackEntry);
        if (indexOf != -1) {
            int i10 = indexOf + 1;
            list = this.$entries.subList(this.$lastNavigatedIndex.element, i10);
            this.$lastNavigatedIndex.element = i10;
        } else {
            list = EmptyList.INSTANCE;
        }
        this.this$0.a(navBackStackEntry.f3312q, this.$args, navBackStackEntry, list);
    }
}
