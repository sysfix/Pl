package androidx.navigation;

import androidx.navigation.Navigator;
import gg.l;
import h2.q;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: Navigator.kt */
public final class Navigator$navigate$1 extends Lambda implements l<NavBackStackEntry, NavBackStackEntry> {
    public final /* synthetic */ q $navOptions;
    public final /* synthetic */ Navigator.a $navigatorExtras;
    public final /* synthetic */ Navigator<D> this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public Navigator$navigate$1(Navigator<D> navigator, q qVar, Navigator.a aVar) {
        super(1);
        this.this$0 = navigator;
        this.$navOptions = qVar;
        this.$navigatorExtras = aVar;
    }

    public final NavBackStackEntry invoke(NavBackStackEntry navBackStackEntry) {
        d0.g(navBackStackEntry, "backStackEntry");
        h2.l lVar = navBackStackEntry.f3312q;
        if (!(lVar instanceof h2.l)) {
            lVar = null;
        }
        if (lVar == null) {
            return null;
        }
        h2.l c10 = this.this$0.c(lVar, navBackStackEntry.f3313r, this.$navOptions, this.$navigatorExtras);
        if (c10 == null) {
            return null;
        }
        return d0.b(c10, lVar) ? navBackStackEntry : this.this$0.b().a(c10, c10.f(navBackStackEntry.f3313r));
    }
}
