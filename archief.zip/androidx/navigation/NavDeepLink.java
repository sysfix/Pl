package androidx.navigation;

import android.net.Uri;
import android.os.Bundle;
import h2.h;
import h2.t;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.collections.EmptyList;
import kotlin.text.Regex;
import pg.j;
import pg.k;
import rg.d0;
import xf.d;
import xf.e;
import yf.l;

/* compiled from: NavDeepLink.kt */
public final class NavDeepLink {
    @Deprecated

    /* renamed from: m  reason: collision with root package name */
    public static final Pattern f3356m = Pattern.compile("^[a-zA-Z]+[+\\w\\-.]*:");

    /* renamed from: a  reason: collision with root package name */
    public final String f3357a;

    /* renamed from: b  reason: collision with root package name */
    public final String f3358b;

    /* renamed from: c  reason: collision with root package name */
    public final String f3359c;

    /* renamed from: d  reason: collision with root package name */
    public final List<String> f3360d = new ArrayList();

    /* renamed from: e  reason: collision with root package name */
    public final Map<String, a> f3361e = new LinkedHashMap();

    /* renamed from: f  reason: collision with root package name */
    public String f3362f;

    /* renamed from: g  reason: collision with root package name */
    public final d f3363g = e.a(new NavDeepLink$pattern$2(this));

    /* renamed from: h  reason: collision with root package name */
    public boolean f3364h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f3365i;

    /* renamed from: j  reason: collision with root package name */
    public String f3366j;

    /* renamed from: k  reason: collision with root package name */
    public final d f3367k = e.a(new NavDeepLink$mimeTypePattern$2(this));

    /* renamed from: l  reason: collision with root package name */
    public boolean f3368l;

    /* compiled from: NavDeepLink.kt */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public String f3369a;

        /* renamed from: b  reason: collision with root package name */
        public final List<String> f3370b = new ArrayList();
    }

    public NavDeepLink(String str, String str2, String str3) {
        int i10;
        List<T> list;
        boolean z10;
        this.f3357a = str;
        this.f3358b = str2;
        this.f3359c = str3;
        boolean z11 = true;
        int i11 = 0;
        if (str != null) {
            Uri parse = Uri.parse(str);
            this.f3364h = parse.getQuery() != null;
            StringBuilder sb2 = new StringBuilder("^");
            if (!f3356m.matcher(str).find()) {
                sb2.append("http[s]?://");
            }
            Pattern compile = Pattern.compile("\\{(.+?)\\}");
            if (this.f3364h) {
                Matcher matcher = Pattern.compile("(\\?)").matcher(str);
                if (matcher.find()) {
                    String substring = str.substring(0, matcher.start());
                    d0.f(substring, "this as java.lang.String…ing(startIndex, endIndex)");
                    d0.f(compile, "fillInPattern");
                    this.f3368l = a(substring, sb2, compile);
                }
                for (String next : parse.getQueryParameterNames()) {
                    StringBuilder sb3 = new StringBuilder();
                    String queryParameter = parse.getQueryParameter(next);
                    if (queryParameter == null) {
                        this.f3365i = z11;
                        queryParameter = next;
                    }
                    Matcher matcher2 = compile.matcher(queryParameter);
                    a aVar = new a();
                    while (matcher2.find()) {
                        String group = matcher2.group(z11 ? 1 : 0);
                        Objects.requireNonNull(group, "null cannot be cast to non-null type kotlin.String");
                        d0.g(group, "name");
                        aVar.f3370b.add(group);
                        d0.f(queryParameter, "queryParam");
                        String substring2 = queryParameter.substring(i11, matcher2.start());
                        d0.f(substring2, "this as java.lang.String…ing(startIndex, endIndex)");
                        sb3.append(Pattern.quote(substring2));
                        sb3.append("(.+?)?");
                        i11 = matcher2.end();
                        z11 = true;
                    }
                    if (i11 < queryParameter.length()) {
                        String substring3 = queryParameter.substring(i11);
                        d0.f(substring3, "this as java.lang.String).substring(startIndex)");
                        sb3.append(Pattern.quote(substring3));
                    }
                    String sb4 = sb3.toString();
                    d0.f(sb4, "argRegex.toString()");
                    aVar.f3369a = j.s(sb4, ".*", "\\E.*\\Q", false, 4);
                    Map<String, a> map = this.f3361e;
                    d0.f(next, "paramName");
                    map.put(next, aVar);
                    z11 = true;
                    i11 = 0;
                }
            } else {
                d0.f(compile, "fillInPattern");
                this.f3368l = a(str, sb2, compile);
            }
            String sb5 = sb2.toString();
            d0.f(sb5, "uriRegex.toString()");
            this.f3362f = j.s(sb5, ".*", "\\E.*\\Q", false, 4);
        }
        if (this.f3359c == null) {
            return;
        }
        if (Pattern.compile("^[\\s\\S]+/[\\s\\S]+$").matcher(this.f3359c).matches()) {
            String str4 = this.f3359c;
            d0.g(str4, "mimeType");
            List<String> split = new Regex("/").split(str4, 0);
            if (!split.isEmpty()) {
                ListIterator<String> listIterator = split.listIterator(split.size());
                while (true) {
                    if (!listIterator.hasPrevious()) {
                        break;
                    }
                    if (listIterator.previous().length() == 0) {
                        z10 = true;
                        continue;
                    } else {
                        z10 = false;
                        continue;
                    }
                    if (!z10) {
                        i10 = 1;
                        list = l.o0(split, listIterator.nextIndex() + 1);
                        break;
                    }
                }
                this.f3366j = j.s(c.a.a("^(", (String) list.get(0), "|[*]+)/(", (String) list.get(i10), "|[*]+)$"), "*|[*]", "[\\s\\S]", false, 4);
                return;
            }
            i10 = 1;
            list = EmptyList.INSTANCE;
            this.f3366j = j.s(c.a.a("^(", (String) list.get(0), "|[*]+)/(", (String) list.get(i10), "|[*]+)$"), "*|[*]", "[\\s\\S]", false, 4);
            return;
        }
        throw new IllegalArgumentException(c.d.a(f.a.a("The given mimeType "), this.f3359c, " does not match to required \"type/subtype\" format").toString());
    }

    public final boolean a(String str, StringBuilder sb2, Pattern pattern) {
        Matcher matcher = pattern.matcher(str);
        boolean z10 = !k.y(str, ".*", false, 2);
        int i10 = 0;
        while (matcher.find()) {
            String group = matcher.group(1);
            Objects.requireNonNull(group, "null cannot be cast to non-null type kotlin.String");
            this.f3360d.add(group);
            String substring = str.substring(i10, matcher.start());
            d0.f(substring, "this as java.lang.String…ing(startIndex, endIndex)");
            sb2.append(Pattern.quote(substring));
            sb2.append("([^/]+?)");
            i10 = matcher.end();
            z10 = false;
        }
        if (i10 < str.length()) {
            String substring2 = str.substring(i10);
            d0.f(substring2, "this as java.lang.String).substring(startIndex)");
            sb2.append(Pattern.quote(substring2));
        }
        sb2.append("($|(\\?(.)*)|(\\#(.)*))");
        return z10;
    }

    public final boolean b(Bundle bundle, String str, String str2, h hVar) {
        if (hVar != null) {
            t<Object> tVar = hVar.f11361a;
            Objects.requireNonNull(tVar);
            d0.g(str, "key");
            tVar.d(bundle, str, tVar.c(str2));
            return false;
        }
        bundle.putString(str, str2);
        return false;
    }

    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof NavDeepLink)) {
            return false;
        }
        NavDeepLink navDeepLink = (NavDeepLink) obj;
        if (!d0.b(this.f3357a, navDeepLink.f3357a) || !d0.b(this.f3358b, navDeepLink.f3358b) || !d0.b(this.f3359c, navDeepLink.f3359c)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        String str = this.f3357a;
        int i10 = 0;
        int hashCode = ((str != null ? str.hashCode() : 0) + 0) * 31;
        String str2 = this.f3358b;
        int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.f3359c;
        if (str3 != null) {
            i10 = str3.hashCode();
        }
        return hashCode2 + i10;
    }
}
