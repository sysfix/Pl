package androidx.navigation;

import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: NavDestination.kt */
public final class NavDestination$Companion$hierarchy$1 extends Lambda implements l<h2.l, h2.l> {
    public static final NavDestination$Companion$hierarchy$1 INSTANCE = new NavDestination$Companion$hierarchy$1();

    public NavDestination$Companion$hierarchy$1() {
        super(1);
    }

    public final h2.l invoke(h2.l lVar) {
        d0.g(lVar, "it");
        return lVar.f11376q;
    }
}
