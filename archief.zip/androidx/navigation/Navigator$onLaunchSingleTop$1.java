package androidx.navigation;

import gg.l;
import h2.r;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import xf.g;

/* compiled from: Navigator.kt */
public final class Navigator$onLaunchSingleTop$1 extends Lambda implements l<r, g> {
    public static final Navigator$onLaunchSingleTop$1 INSTANCE = new Navigator$onLaunchSingleTop$1();

    public Navigator$onLaunchSingleTop$1() {
        super(1);
    }

    public final void invoke(r rVar) {
        d0.g(rVar, "$this$navOptions");
        rVar.f11417b = true;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((r) obj);
        return g.f19030a;
    }
}
