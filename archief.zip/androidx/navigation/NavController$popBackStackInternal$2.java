package androidx.navigation;

import gg.l;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Ref$BooleanRef;
import rg.d0;
import xf.g;
import yf.e;

/* compiled from: NavController.kt */
public final class NavController$popBackStackInternal$2 extends Lambda implements l<NavBackStackEntry, g> {
    public final /* synthetic */ Ref$BooleanRef $popped;
    public final /* synthetic */ Ref$BooleanRef $receivedPop;
    public final /* synthetic */ boolean $saveState;
    public final /* synthetic */ e<NavBackStackEntryState> $savedState;
    public final /* synthetic */ NavController this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NavController$popBackStackInternal$2(Ref$BooleanRef ref$BooleanRef, Ref$BooleanRef ref$BooleanRef2, NavController navController, boolean z10, e<NavBackStackEntryState> eVar) {
        super(1);
        this.$receivedPop = ref$BooleanRef;
        this.$popped = ref$BooleanRef2;
        this.this$0 = navController;
        this.$saveState = z10;
        this.$savedState = eVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((NavBackStackEntry) obj);
        return g.f19030a;
    }

    public final void invoke(NavBackStackEntry navBackStackEntry) {
        d0.g(navBackStackEntry, "entry");
        this.$receivedPop.element = true;
        this.$popped.element = true;
        this.this$0.p(navBackStackEntry, this.$saveState, this.$savedState);
    }
}
