package androidx.navigation;

import gg.l;
import h2.n;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: NavController.kt */
public final class NavController$popBackStackInternal$3 extends Lambda implements l<h2.l, h2.l> {
    public static final NavController$popBackStackInternal$3 INSTANCE = new NavController$popBackStackInternal$3();

    public NavController$popBackStackInternal$3() {
        super(1);
    }

    public final h2.l invoke(h2.l lVar) {
        d0.g(lVar, "destination");
        n nVar = lVar.f11376q;
        boolean z10 = false;
        if (nVar != null && nVar.A == lVar.f11382w) {
            z10 = true;
        }
        if (z10) {
            return nVar;
        }
        return null;
    }
}
