package androidx.navigation.fragment;

import ai.plaud.android.plaud.R;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.i;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.a;
import androidx.lifecycle.ViewModelStore;
import androidx.navigation.NavController;
import h2.o;
import h2.p;
import h2.v;
import h2.w;
import h2.z;
import j2.b;
import j2.c;
import j2.d;
import java.util.Objects;
import rg.d0;

/* compiled from: NavHostFragment.kt */
public class NavHostFragment extends Fragment {

    /* renamed from: p  reason: collision with root package name */
    public o f3374p;

    /* renamed from: q  reason: collision with root package name */
    public Boolean f3375q;

    /* renamed from: r  reason: collision with root package name */
    public View f3376r;

    /* renamed from: s  reason: collision with root package name */
    public int f3377s;

    /* renamed from: t  reason: collision with root package name */
    public boolean f3378t;

    public void onAttach(Context context) {
        d0.g(context, "context");
        super.onAttach(context);
        if (this.f3378t) {
            a aVar = new a(getParentFragmentManager());
            aVar.p(this);
            aVar.e();
        }
    }

    public void onCreate(Bundle bundle) {
        Bundle bundle2;
        Context requireContext = requireContext();
        d0.f(requireContext, "requireContext()");
        o oVar = new o(requireContext);
        this.f3374p = oVar;
        oVar.z(this);
        while (true) {
            if (!(requireContext instanceof ContextWrapper)) {
                break;
            } else if (requireContext instanceof i) {
                o oVar2 = this.f3374p;
                d0.d(oVar2);
                OnBackPressedDispatcher onBackPressedDispatcher = ((i) requireContext).getOnBackPressedDispatcher();
                d0.f(onBackPressedDispatcher, "context as OnBackPressed…).onBackPressedDispatcher");
                oVar2.A(onBackPressedDispatcher);
                break;
            } else {
                requireContext = ((ContextWrapper) requireContext).getBaseContext();
                d0.f(requireContext, "context.baseContext");
            }
        }
        o oVar3 = this.f3374p;
        d0.d(oVar3);
        Boolean bool = this.f3375q;
        int i10 = 0;
        oVar3.f3347u = bool != null && bool.booleanValue();
        oVar3.y();
        Bundle bundle3 = null;
        this.f3375q = null;
        o oVar4 = this.f3374p;
        d0.d(oVar4);
        ViewModelStore viewModelStore = getViewModelStore();
        d0.f(viewModelStore, "viewModelStore");
        oVar4.B(viewModelStore);
        o oVar5 = this.f3374p;
        d0.d(oVar5);
        w wVar = oVar5.f3348v;
        Context requireContext2 = requireContext();
        d0.f(requireContext2, "requireContext()");
        FragmentManager childFragmentManager = getChildFragmentManager();
        d0.f(childFragmentManager, "childFragmentManager");
        wVar.a(new b(requireContext2, childFragmentManager));
        w wVar2 = oVar5.f3348v;
        Context requireContext3 = requireContext();
        d0.f(requireContext3, "requireContext()");
        FragmentManager childFragmentManager2 = getChildFragmentManager();
        d0.f(childFragmentManager2, "childFragmentManager");
        int id2 = getId();
        if (id2 == 0 || id2 == -1) {
            id2 = R.id.nav_host_fragment_container;
        }
        wVar2.a(new c(requireContext3, childFragmentManager2, id2));
        if (bundle != null) {
            bundle2 = bundle.getBundle("android-support-nav:fragment:navControllerState");
            if (bundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
                this.f3378t = true;
                a aVar = new a(getParentFragmentManager());
                aVar.p(this);
                aVar.e();
            }
            this.f3377s = bundle.getInt("android-support-nav:fragment:graphId");
        } else {
            bundle2 = null;
        }
        if (bundle2 != null) {
            o oVar6 = this.f3374p;
            d0.d(oVar6);
            oVar6.s(bundle2);
        }
        if (this.f3377s != 0) {
            o oVar7 = this.f3374p;
            d0.d(oVar7);
            oVar7.v(((p) oVar7.C.getValue()).c(this.f3377s), (Bundle) null);
        } else {
            Bundle arguments = getArguments();
            if (arguments != null) {
                i10 = arguments.getInt("android-support-nav:fragment:graphId");
            }
            if (arguments != null) {
                bundle3 = arguments.getBundle("android-support-nav:fragment:startDestinationArgs");
            }
            if (i10 != 0) {
                o oVar8 = this.f3374p;
                d0.d(oVar8);
                oVar8.v(((p) oVar8.C.getValue()).c(i10), bundle3);
            }
        }
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        d0.g(layoutInflater, "inflater");
        Context context = layoutInflater.getContext();
        d0.f(context, "inflater.context");
        FragmentContainerView fragmentContainerView = new FragmentContainerView(context);
        int id2 = getId();
        if (id2 == 0 || id2 == -1) {
            id2 = R.id.nav_host_fragment_container;
        }
        fragmentContainerView.setId(id2);
        return fragmentContainerView;
    }

    public void onDestroyView() {
        super.onDestroyView();
        View view = this.f3376r;
        if (view != null && v.a(view) == this.f3374p) {
            v.b(view, (NavController) null);
        }
        this.f3376r = null;
    }

    public void onInflate(Context context, AttributeSet attributeSet, Bundle bundle) {
        d0.g(context, "context");
        d0.g(attributeSet, "attrs");
        super.onInflate(context, attributeSet, bundle);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z.f11449b);
        d0.f(obtainStyledAttributes, "context.obtainStyledAttr…yleable.NavHost\n        )");
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            this.f3377s = resourceId;
        }
        obtainStyledAttributes.recycle();
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, d.f13151c);
        d0.f(obtainStyledAttributes2, "context.obtainStyledAttr…tyleable.NavHostFragment)");
        if (obtainStyledAttributes2.getBoolean(0, false)) {
            this.f3378t = true;
        }
        obtainStyledAttributes2.recycle();
    }

    public void onPrimaryNavigationFragmentChanged(boolean z10) {
        o oVar = this.f3374p;
        if (oVar == null) {
            this.f3375q = Boolean.valueOf(z10);
        } else if (oVar != null) {
            oVar.f3347u = z10;
            oVar.y();
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        d0.g(bundle, "outState");
        super.onSaveInstanceState(bundle);
        o oVar = this.f3374p;
        d0.d(oVar);
        Bundle u10 = oVar.u();
        if (u10 != null) {
            bundle.putBundle("android-support-nav:fragment:navControllerState", u10);
        }
        if (this.f3378t) {
            bundle.putBoolean("android-support-nav:fragment:defaultHost", true);
        }
        int i10 = this.f3377s;
        if (i10 != 0) {
            bundle.putInt("android-support-nav:fragment:graphId", i10);
        }
    }

    public void onViewCreated(View view, Bundle bundle) {
        d0.g(view, "view");
        super.onViewCreated(view, bundle);
        if (view instanceof ViewGroup) {
            v.b(view, this.f3374p);
            if (view.getParent() != null) {
                ViewParent parent = view.getParent();
                Objects.requireNonNull(parent, "null cannot be cast to non-null type android.view.View");
                View view2 = (View) parent;
                this.f3376r = view2;
                d0.d(view2);
                if (view2.getId() == getId()) {
                    View view3 = this.f3376r;
                    d0.d(view3);
                    v.b(view3, this.f3374p);
                    return;
                }
                return;
            }
            return;
        }
        throw new IllegalStateException(("created host view " + view + " is not a ViewGroup").toString());
    }
}
