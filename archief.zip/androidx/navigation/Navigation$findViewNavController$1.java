package androidx.navigation;

import android.view.View;
import android.view.ViewParent;
import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: Navigation.kt */
public final class Navigation$findViewNavController$1 extends Lambda implements l<View, View> {
    public static final Navigation$findViewNavController$1 INSTANCE = new Navigation$findViewNavController$1();

    public Navigation$findViewNavController$1() {
        super(1);
    }

    public final View invoke(View view) {
        d0.g(view, "it");
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            return (View) parent;
        }
        return null;
    }
}
