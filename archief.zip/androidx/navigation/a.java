package androidx.navigation;

import android.os.Bundle;
import androidx.navigation.Navigator;
import b.b;
import h2.l;
import h2.n;
import h2.q;
import h2.w;
import java.util.List;
import rg.d0;
import yf.h;

@Navigator.b("navigation")
/* compiled from: NavGraphNavigator.kt */
public class a extends Navigator<n> {

    /* renamed from: c  reason: collision with root package name */
    public final w f3373c;

    public a(w wVar) {
        d0.g(wVar, "navigatorProvider");
        this.f3373c = wVar;
    }

    public l a() {
        return new n(this);
    }

    public void d(List<NavBackStackEntry> list, q qVar, Navigator.a aVar) {
        String str;
        l lVar;
        d0.g(list, "entries");
        for (NavBackStackEntry next : list) {
            n nVar = (n) next.f3312q;
            Bundle bundle = next.f3313r;
            int i10 = nVar.A;
            String str2 = nVar.C;
            if (!((i10 == 0 && str2 == null) ? false : true)) {
                StringBuilder a10 = f.a.a("no start destination defined via app:startDestination for ");
                int i11 = nVar.f11382w;
                if (i11 != 0) {
                    str = nVar.f11377r;
                    if (str == null) {
                        str = String.valueOf(i11);
                    }
                } else {
                    str = "the root navigation";
                }
                a10.append(str);
                throw new IllegalStateException(a10.toString().toString());
            }
            if (str2 != null) {
                lVar = nVar.z(str2, false);
            } else {
                lVar = nVar.x(i10, false);
            }
            if (lVar == null) {
                if (nVar.B == null) {
                    String str3 = nVar.C;
                    if (str3 == null) {
                        str3 = String.valueOf(nVar.A);
                    }
                    nVar.B = str3;
                }
                String str4 = nVar.B;
                d0.d(str4);
                throw new IllegalArgumentException(b.a("navigation destination ", str4, " is not a direct child of this NavGraph"));
            }
            this.f3373c.c(lVar.f11375p).d(h.u(b().a(lVar, lVar.f(bundle))), qVar, aVar);
        }
    }
}
