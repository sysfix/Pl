package androidx.navigation;

import gg.a;
import java.util.regex.Pattern;
import kotlin.jvm.internal.Lambda;

/* compiled from: NavDeepLink.kt */
public final class NavDeepLink$mimeTypePattern$2 extends Lambda implements a<Pattern> {
    public final /* synthetic */ NavDeepLink this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NavDeepLink$mimeTypePattern$2(NavDeepLink navDeepLink) {
        super(0);
        this.this$0 = navDeepLink;
    }

    public final Pattern invoke() {
        String str = this.this$0.f3366j;
        if (str != null) {
            return Pattern.compile(str);
        }
        return null;
    }
}
