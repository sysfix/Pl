package androidx.navigation;

import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: NavController.kt */
public final class NavController$restoreStateInternal$1 extends Lambda implements l<String, Boolean> {
    public final /* synthetic */ String $backStackId;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NavController$restoreStateInternal$1(String str) {
        super(1);
        this.$backStackId = str;
    }

    public final Boolean invoke(String str) {
        return Boolean.valueOf(d0.b(str, this.$backStackId));
    }
}
