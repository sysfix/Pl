package androidx.navigation;

import gg.l;
import h2.r;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: NavController.kt */
public final class NavController$handleDeepLink$2 extends Lambda implements l<r, g> {
    public final /* synthetic */ h2.l $node;
    public final /* synthetic */ NavController this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NavController$handleDeepLink$2(h2.l lVar, NavController navController) {
        super(1);
        this.$node = lVar;
        this.this$0 = navController;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((r) obj);
        return g.f19030a;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x005d, code lost:
        if (r0 != false) goto L_0x0061;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void invoke(h2.r r7) {
        /*
            r6 = this;
            java.lang.String r0 = "$this$navOptions"
            rg.d0.g(r7, r0)
            androidx.navigation.NavController$handleDeepLink$2$1 r0 = androidx.navigation.NavController$handleDeepLink$2.AnonymousClass1.INSTANCE
            java.lang.String r1 = "animBuilder"
            rg.d0.g(r0, r1)
            h2.b r1 = new h2.b
            r1.<init>()
            r0.invoke(r1)
            h2.q$a r0 = r7.f11416a
            int r2 = r1.f11351a
            r0.f11412g = r2
            int r1 = r1.f11352b
            r0.f11413h = r1
            r1 = -1
            r0.f11414i = r1
            r0.f11415j = r1
            h2.l r0 = r6.$node
            boolean r1 = r0 instanceof h2.n
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L_0x0060
            h2.l r1 = h2.l.f11374y
            java.lang.String r1 = "<this>"
            rg.d0.g(r0, r1)
            androidx.navigation.NavDestination$Companion$hierarchy$1 r1 = androidx.navigation.NavDestination$Companion$hierarchy$1.INSTANCE
            og.g r0 = kotlin.sequences.SequencesKt__SequencesKt.B(r0, r1)
            androidx.navigation.NavController r1 = r6.this$0
            java.util.Iterator r0 = r0.iterator()
        L_0x003e:
            boolean r4 = r0.hasNext()
            if (r4 == 0) goto L_0x005c
            java.lang.Object r4 = r0.next()
            h2.l r4 = (h2.l) r4
            h2.l r5 = r1.f()
            if (r5 == 0) goto L_0x0053
            h2.n r5 = r5.f11376q
            goto L_0x0054
        L_0x0053:
            r5 = 0
        L_0x0054:
            boolean r4 = rg.d0.b(r4, r5)
            if (r4 == 0) goto L_0x003e
            r0 = r3
            goto L_0x005d
        L_0x005c:
            r0 = r2
        L_0x005d:
            if (r0 == 0) goto L_0x0060
            goto L_0x0061
        L_0x0060:
            r2 = r3
        L_0x0061:
            if (r2 == 0) goto L_0x00b0
            androidx.navigation.NavController r0 = r6.this$0
            h2.n r0 = r0.g()
            int r1 = r0.A
            h2.l r0 = r0.w(r1)
            androidx.navigation.NavGraph$Companion$findStartDestination$1 r1 = androidx.navigation.NavGraph$Companion$findStartDestination$1.INSTANCE
            og.g r0 = kotlin.sequences.SequencesKt__SequencesKt.B(r0, r1)
            java.util.Iterator r0 = r0.iterator()
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x00a8
            java.lang.Object r1 = r0.next()
        L_0x0083:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x008e
            java.lang.Object r1 = r0.next()
            goto L_0x0083
        L_0x008e:
            h2.l r1 = (h2.l) r1
            int r0 = r1.f11382w
            androidx.navigation.NavController$handleDeepLink$2$2 r1 = androidx.navigation.NavController$handleDeepLink$2.AnonymousClass2.INSTANCE
            java.lang.String r2 = "popUpToBuilder"
            rg.d0.g(r1, r2)
            r7.f11418c = r0
            h2.y r0 = new h2.y
            r0.<init>()
            r1.invoke(r0)
            boolean r0 = r0.f11447a
            r7.f11420e = r0
            goto L_0x00b0
        L_0x00a8:
            java.util.NoSuchElementException r7 = new java.util.NoSuchElementException
            java.lang.String r0 = "Sequence is empty."
            r7.<init>(r0)
            throw r7
        L_0x00b0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.NavController$handleDeepLink$2.invoke(h2.r):void");
    }
}
