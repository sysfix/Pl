package androidx.navigation;

import gg.l;
import h2.n;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: NavGraph.kt */
public final class NavGraph$Companion$findStartDestination$1 extends Lambda implements l<h2.l, h2.l> {
    public static final NavGraph$Companion$findStartDestination$1 INSTANCE = new NavGraph$Companion$findStartDestination$1();

    public NavGraph$Companion$findStartDestination$1() {
        super(1);
    }

    public final h2.l invoke(h2.l lVar) {
        d0.g(lVar, "it");
        if (!(lVar instanceof n)) {
            return null;
        }
        n nVar = (n) lVar;
        return nVar.w(nVar.A);
    }
}
