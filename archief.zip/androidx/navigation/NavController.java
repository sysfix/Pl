package androidx.navigation;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import androidx.activity.OnBackPressedDispatcher;
import androidx.appcompat.widget.k0;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModelStore;
import androidx.navigation.NavBackStackEntry;
import androidx.navigation.Navigator;
import com.google.android.gms.internal.play_billing.x2;
import h2.c;
import h2.i;
import h2.j;
import h2.l;
import h2.n;
import h2.q;
import h2.w;
import h2.x;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.sequences.SequencesKt__SequencesKt;
import kotlinx.coroutines.channels.BufferOverflow;
import og.n;
import rg.d0;
import ug.f;
import ug.g;
import ug.k;
import ug.m;
import xf.d;
import yf.e;
import yf.h;
import yf.p;

/* compiled from: NavController.kt */
public class NavController {
    public int A;
    public final List<NavBackStackEntry> B;
    public final d C;
    public final f<NavBackStackEntry> D;

    /* renamed from: a  reason: collision with root package name */
    public final Context f3327a;

    /* renamed from: b  reason: collision with root package name */
    public Activity f3328b;

    /* renamed from: c  reason: collision with root package name */
    public n f3329c;

    /* renamed from: d  reason: collision with root package name */
    public Bundle f3330d;

    /* renamed from: e  reason: collision with root package name */
    public Parcelable[] f3331e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f3332f;

    /* renamed from: g  reason: collision with root package name */
    public final e<NavBackStackEntry> f3333g;

    /* renamed from: h  reason: collision with root package name */
    public final g<List<NavBackStackEntry>> f3334h;

    /* renamed from: i  reason: collision with root package name */
    public final m<List<NavBackStackEntry>> f3335i;

    /* renamed from: j  reason: collision with root package name */
    public final Map<NavBackStackEntry, NavBackStackEntry> f3336j;

    /* renamed from: k  reason: collision with root package name */
    public final Map<NavBackStackEntry, AtomicInteger> f3337k;

    /* renamed from: l  reason: collision with root package name */
    public final Map<Integer, String> f3338l;

    /* renamed from: m  reason: collision with root package name */
    public final Map<String, e<NavBackStackEntryState>> f3339m;

    /* renamed from: n  reason: collision with root package name */
    public LifecycleOwner f3340n;

    /* renamed from: o  reason: collision with root package name */
    public OnBackPressedDispatcher f3341o;

    /* renamed from: p  reason: collision with root package name */
    public j f3342p;

    /* renamed from: q  reason: collision with root package name */
    public final CopyOnWriteArrayList<a> f3343q;

    /* renamed from: r  reason: collision with root package name */
    public Lifecycle.State f3344r;

    /* renamed from: s  reason: collision with root package name */
    public final LifecycleObserver f3345s;

    /* renamed from: t  reason: collision with root package name */
    public final androidx.activity.g f3346t;

    /* renamed from: u  reason: collision with root package name */
    public boolean f3347u;

    /* renamed from: v  reason: collision with root package name */
    public w f3348v;

    /* renamed from: w  reason: collision with root package name */
    public final Map<Navigator<? extends l>, NavControllerNavigatorState> f3349w;

    /* renamed from: x  reason: collision with root package name */
    public gg.l<? super NavBackStackEntry, xf.g> f3350x;

    /* renamed from: y  reason: collision with root package name */
    public gg.l<? super NavBackStackEntry, xf.g> f3351y;

    /* renamed from: z  reason: collision with root package name */
    public final Map<NavBackStackEntry, Boolean> f3352z;

    /* compiled from: NavController.kt */
    public final class NavControllerNavigatorState extends x {

        /* renamed from: g  reason: collision with root package name */
        public final Navigator<? extends l> f3353g;

        /* renamed from: h  reason: collision with root package name */
        public final /* synthetic */ NavController f3354h;

        public NavControllerNavigatorState(NavController navController, Navigator<? extends l> navigator) {
            d0.g(navigator, "navigator");
            this.f3354h = navController;
            this.f3353g = navigator;
        }

        public NavBackStackEntry a(l lVar, Bundle bundle) {
            NavBackStackEntry.a aVar = NavBackStackEntry.C;
            NavController navController = this.f3354h;
            return NavBackStackEntry.a.b(aVar, navController.f3327a, lVar, bundle, navController.h(), this.f3354h.f3342p, (String) null, (Bundle) null, 96);
        }

        public void b(NavBackStackEntry navBackStackEntry, boolean z10) {
            Navigator c10 = this.f3354h.f3348v.c(navBackStackEntry.f3312q.f11375p);
            if (d0.b(c10, this.f3353g)) {
                NavController navController = this.f3354h;
                gg.l<? super NavBackStackEntry, xf.g> lVar = navController.f3351y;
                if (lVar != null) {
                    lVar.invoke(navBackStackEntry);
                    super.b(navBackStackEntry, z10);
                    return;
                }
                NavController$NavControllerNavigatorState$pop$1 navController$NavControllerNavigatorState$pop$1 = new NavController$NavControllerNavigatorState$pop$1(this, navBackStackEntry, z10);
                int indexOf = navController.f3333g.indexOf(navBackStackEntry);
                if (indexOf < 0) {
                    Log.i("NavController", "Ignoring pop of " + navBackStackEntry + " as it was not found on the current back stack");
                    return;
                }
                int i10 = indexOf + 1;
                if (i10 != navController.f3333g.size()) {
                    navController.n(navController.f3333g.get(i10).f3312q.f11382w, true, false);
                }
                NavController.q(navController, navBackStackEntry, false, (e) null, 6, (Object) null);
                navController$NavControllerNavigatorState$pop$1.invoke();
                navController.y();
                navController.b();
                return;
            }
            NavControllerNavigatorState navControllerNavigatorState = this.f3354h.f3349w.get(c10);
            d0.d(navControllerNavigatorState);
            navControllerNavigatorState.b(navBackStackEntry, z10);
        }

        public void c(NavBackStackEntry navBackStackEntry) {
            d0.g(navBackStackEntry, "backStackEntry");
            Navigator c10 = this.f3354h.f3348v.c(navBackStackEntry.f3312q.f11375p);
            if (d0.b(c10, this.f3353g)) {
                gg.l<? super NavBackStackEntry, xf.g> lVar = this.f3354h.f3350x;
                if (lVar != null) {
                    lVar.invoke(navBackStackEntry);
                    super.c(navBackStackEntry);
                    return;
                }
                StringBuilder a10 = f.a.a("Ignoring add of destination ");
                a10.append(navBackStackEntry.f3312q);
                a10.append(" outside of the call to navigate(). ");
                Log.i("NavController", a10.toString());
                return;
            }
            NavControllerNavigatorState navControllerNavigatorState = this.f3354h.f3349w.get(c10);
            if (navControllerNavigatorState != null) {
                navControllerNavigatorState.c(navBackStackEntry);
                return;
            }
            throw new IllegalStateException(c.d.a(f.a.a("NavigatorBackStack for "), navBackStackEntry.f3312q.f11375p, " should already be created").toString());
        }

        public final void e(NavBackStackEntry navBackStackEntry) {
            super.c(navBackStackEntry);
        }
    }

    /* compiled from: NavController.kt */
    public interface a {
        void a(NavController navController, l lVar, Bundle bundle);
    }

    /* compiled from: NavController.kt */
    public static final class b extends androidx.activity.g {

        /* renamed from: d  reason: collision with root package name */
        public final /* synthetic */ NavController f3355d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(NavController navController) {
            super(false);
            this.f3355d = navController;
        }

        public void a() {
            this.f3355d.l();
        }
    }

    public NavController(Context context) {
        Object obj;
        this.f3327a = context;
        Iterator it = SequencesKt__SequencesKt.B(context, NavController$activity$1.INSTANCE).iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (((Context) obj) instanceof Activity) {
                break;
            }
        }
        this.f3328b = (Activity) obj;
        this.f3333g = new e<>();
        g<List<NavBackStackEntry>> a10 = ug.n.a(EmptyList.INSTANCE);
        this.f3334h = a10;
        this.f3335i = x2.b(a10);
        this.f3336j = new LinkedHashMap();
        this.f3337k = new LinkedHashMap();
        this.f3338l = new LinkedHashMap();
        this.f3339m = new LinkedHashMap();
        this.f3343q = new CopyOnWriteArrayList<>();
        this.f3344r = Lifecycle.State.INITIALIZED;
        this.f3345s = new i(this);
        this.f3346t = new b(this);
        this.f3347u = true;
        this.f3348v = new w();
        this.f3349w = new LinkedHashMap();
        this.f3352z = new LinkedHashMap();
        w wVar = this.f3348v;
        wVar.a(new a(wVar));
        this.f3348v.a(new ActivityNavigator(this.f3327a));
        this.B = new ArrayList();
        this.C = xf.e.a(new NavController$navInflater$2(this));
        this.D = k.a(1, 0, BufferOverflow.DROP_OLDEST, 2);
    }

    public static /* synthetic */ boolean o(NavController navController, int i10, boolean z10, boolean z11, int i11, Object obj) {
        if ((i11 & 4) != 0) {
            z11 = false;
        }
        return navController.n(i10, z10, z11);
    }

    public static /* synthetic */ void q(NavController navController, NavBackStackEntry navBackStackEntry, boolean z10, e eVar, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            z10 = false;
        }
        navController.p(navBackStackEntry, z10, (i10 & 4) != 0 ? new e() : null);
    }

    public final void a(l lVar, Bundle bundle, NavBackStackEntry navBackStackEntry, List<NavBackStackEntry> list) {
        l lVar2;
        Bundle bundle2;
        List<NavBackStackEntry> list2;
        e<NavBackStackEntry> eVar;
        NavBackStackEntry navBackStackEntry2;
        l lVar3;
        l lVar4;
        NavBackStackEntry navBackStackEntry3;
        n nVar;
        NavBackStackEntry navBackStackEntry4;
        Bundle bundle3;
        List<NavBackStackEntry> list3;
        l lVar5 = lVar;
        Bundle bundle4 = bundle;
        NavBackStackEntry navBackStackEntry5 = navBackStackEntry;
        List<NavBackStackEntry> list4 = list;
        l lVar6 = navBackStackEntry5.f3312q;
        if (!(lVar6 instanceof c)) {
            while (!this.f3333g.isEmpty() && (this.f3333g.last().f3312q instanceof c)) {
                if (!o(this, this.f3333g.last().f3312q.f11382w, true, false, 4, (Object) null)) {
                    break;
                }
            }
        }
        e eVar2 = new e();
        NavBackStackEntry navBackStackEntry6 = null;
        if (lVar5 instanceof n) {
            n nVar2 = lVar6;
            while (true) {
                d0.d(nVar2);
                n nVar3 = nVar2.f11376q;
                if (nVar3 != null) {
                    ListIterator<NavBackStackEntry> listIterator = list4.listIterator(list.size());
                    while (true) {
                        if (!listIterator.hasPrevious()) {
                            navBackStackEntry4 = null;
                            break;
                        }
                        navBackStackEntry4 = listIterator.previous();
                        if (d0.b(navBackStackEntry4.f3312q, nVar3)) {
                            break;
                        }
                    }
                    NavBackStackEntry navBackStackEntry7 = navBackStackEntry4;
                    if (navBackStackEntry7 == null) {
                        lVar2 = lVar6;
                        list3 = list4;
                        bundle3 = bundle4;
                        navBackStackEntry2 = navBackStackEntry5;
                        navBackStackEntry7 = NavBackStackEntry.a.b(NavBackStackEntry.C, this.f3327a, nVar3, bundle, h(), this.f3342p, (String) null, (Bundle) null, 96);
                    } else {
                        lVar2 = lVar6;
                        list3 = list4;
                        navBackStackEntry2 = navBackStackEntry5;
                        bundle3 = bundle4;
                    }
                    eVar2.c(navBackStackEntry7);
                    if (!(!this.f3333g.isEmpty()) || this.f3333g.last().f3312q != nVar3) {
                        list2 = list3;
                        bundle2 = bundle3;
                        nVar = nVar3;
                        eVar = eVar2;
                    } else {
                        list2 = list3;
                        bundle2 = bundle3;
                        nVar = nVar3;
                        eVar = eVar2;
                        q(this, this.f3333g.last(), false, (e) null, 6, (Object) null);
                    }
                } else {
                    nVar = nVar3;
                    eVar = eVar2;
                    lVar2 = lVar6;
                    list2 = list4;
                    navBackStackEntry2 = navBackStackEntry5;
                    bundle2 = bundle4;
                }
                if (nVar == null || nVar == lVar5) {
                    break;
                }
                navBackStackEntry5 = navBackStackEntry2;
                nVar2 = nVar;
                eVar2 = eVar;
                bundle4 = bundle2;
                list4 = list2;
                lVar6 = lVar2;
            }
        } else {
            eVar = eVar2;
            lVar2 = lVar6;
            list2 = list4;
            navBackStackEntry2 = navBackStackEntry5;
            bundle2 = bundle4;
        }
        if (eVar.isEmpty()) {
            lVar3 = lVar2;
        } else {
            lVar3 = ((NavBackStackEntry) eVar.first()).f3312q;
        }
        while (lVar3 != null && c(lVar3.f11382w) == null) {
            lVar3 = lVar3.f11376q;
            if (lVar3 != null) {
                ListIterator<NavBackStackEntry> listIterator2 = list2.listIterator(list.size());
                while (true) {
                    if (!listIterator2.hasPrevious()) {
                        navBackStackEntry3 = null;
                        break;
                    }
                    navBackStackEntry3 = listIterator2.previous();
                    if (d0.b(navBackStackEntry3.f3312q, lVar3)) {
                        break;
                    }
                }
                NavBackStackEntry navBackStackEntry8 = navBackStackEntry3;
                if (navBackStackEntry8 == null) {
                    navBackStackEntry8 = NavBackStackEntry.a.b(NavBackStackEntry.C, this.f3327a, lVar3, lVar3.f(bundle2), h(), this.f3342p, (String) null, (Bundle) null, 96);
                }
                eVar.c(navBackStackEntry8);
            }
        }
        if (eVar.isEmpty()) {
            lVar4 = lVar2;
        } else {
            lVar4 = ((NavBackStackEntry) eVar.last()).f3312q;
        }
        while (!this.f3333g.isEmpty() && (this.f3333g.last().f3312q instanceof n) && ((n) this.f3333g.last().f3312q).x(lVar4.f11382w, false) == null) {
            q(this, this.f3333g.last(), false, (e) null, 6, (Object) null);
        }
        NavBackStackEntry r10 = this.f3333g.r();
        if (r10 == null) {
            r10 = (NavBackStackEntry) eVar.r();
        }
        if (!d0.b(r10 != null ? r10.f3312q : null, this.f3329c)) {
            ListIterator<NavBackStackEntry> listIterator3 = list2.listIterator(list.size());
            while (true) {
                if (!listIterator3.hasPrevious()) {
                    break;
                }
                NavBackStackEntry previous = listIterator3.previous();
                l lVar7 = previous.f3312q;
                n nVar4 = this.f3329c;
                d0.d(nVar4);
                if (d0.b(lVar7, nVar4)) {
                    navBackStackEntry6 = previous;
                    break;
                }
            }
            NavBackStackEntry navBackStackEntry9 = navBackStackEntry6;
            if (navBackStackEntry9 == null) {
                NavBackStackEntry.a aVar = NavBackStackEntry.C;
                Context context = this.f3327a;
                n nVar5 = this.f3329c;
                d0.d(nVar5);
                n nVar6 = this.f3329c;
                d0.d(nVar6);
                navBackStackEntry9 = NavBackStackEntry.a.b(aVar, context, nVar5, nVar6.f(bundle2), h(), this.f3342p, (String) null, (Bundle) null, 96);
            }
            eVar.c(navBackStackEntry9);
        }
        for (NavBackStackEntry navBackStackEntry10 : eVar) {
            NavControllerNavigatorState navControllerNavigatorState = this.f3349w.get(this.f3348v.c(navBackStackEntry10.f3312q.f11375p));
            if (navControllerNavigatorState != null) {
                navControllerNavigatorState.e(navBackStackEntry10);
            } else {
                throw new IllegalStateException(c.d.a(f.a.a("NavigatorBackStack for "), lVar5.f11375p, " should already be created").toString());
            }
        }
        this.f3333g.addAll(eVar);
        this.f3333g.f(navBackStackEntry2);
        for (NavBackStackEntry navBackStackEntry11 : yf.l.l0(eVar, navBackStackEntry2)) {
            n nVar7 = navBackStackEntry11.f3312q.f11376q;
            if (nVar7 != null) {
                i(navBackStackEntry11, e(nVar7.f11382w));
            }
        }
    }

    public final boolean b() {
        while (!this.f3333g.isEmpty() && (this.f3333g.last().f3312q instanceof n)) {
            q(this, this.f3333g.last(), false, (e) null, 6, (Object) null);
        }
        NavBackStackEntry t10 = this.f3333g.t();
        if (t10 != null) {
            this.B.add(t10);
        }
        this.A++;
        x();
        int i10 = this.A - 1;
        this.A = i10;
        if (i10 == 0) {
            List<T> s02 = yf.l.s0(this.B);
            this.B.clear();
            Iterator it = ((ArrayList) s02).iterator();
            while (it.hasNext()) {
                NavBackStackEntry navBackStackEntry = (NavBackStackEntry) it.next();
                Iterator<a> it2 = this.f3343q.iterator();
                while (it2.hasNext()) {
                    it2.next().a(this, navBackStackEntry.f3312q, navBackStackEntry.f3313r);
                }
                this.D.b(navBackStackEntry);
            }
            this.f3334h.b(r());
        }
        if (t10 != null) {
            return true;
        }
        return false;
    }

    public final l c(int i10) {
        l lVar;
        n nVar = this.f3329c;
        if (nVar == null) {
            return null;
        }
        d0.d(nVar);
        if (nVar.f11382w == i10) {
            return this.f3329c;
        }
        NavBackStackEntry t10 = this.f3333g.t();
        if (t10 == null || (lVar = t10.f3312q) == null) {
            lVar = this.f3329c;
            d0.d(lVar);
        }
        return d(lVar, i10);
    }

    public final l d(l lVar, int i10) {
        n nVar;
        if (lVar.f11382w == i10) {
            return lVar;
        }
        if (lVar instanceof n) {
            nVar = (n) lVar;
        } else {
            nVar = lVar.f11376q;
            d0.d(nVar);
        }
        return nVar.x(i10, true);
    }

    public NavBackStackEntry e(int i10) {
        NavBackStackEntry navBackStackEntry;
        boolean z10;
        e<NavBackStackEntry> eVar = this.f3333g;
        ListIterator<NavBackStackEntry> listIterator = eVar.listIterator(eVar.size());
        while (true) {
            if (!listIterator.hasPrevious()) {
                navBackStackEntry = null;
                break;
            }
            navBackStackEntry = listIterator.previous();
            if (navBackStackEntry.f3312q.f11382w == i10) {
                z10 = true;
                continue;
            } else {
                z10 = false;
                continue;
            }
            if (z10) {
                break;
            }
        }
        NavBackStackEntry navBackStackEntry2 = navBackStackEntry;
        if (navBackStackEntry2 != null) {
            return navBackStackEntry2;
        }
        StringBuilder a10 = k0.a("No destination with ID ", i10, " is on the NavController's back stack. The current destination is ");
        a10.append(f());
        throw new IllegalArgumentException(a10.toString().toString());
    }

    public l f() {
        NavBackStackEntry t10 = this.f3333g.t();
        if (t10 != null) {
            return t10.f3312q;
        }
        return null;
    }

    public n g() {
        n nVar = this.f3329c;
        if (nVar != null) {
            Objects.requireNonNull(nVar, "null cannot be cast to non-null type androidx.navigation.NavGraph");
            return nVar;
        }
        throw new IllegalStateException("You must call setGraph() before calling getGraph()".toString());
    }

    public final Lifecycle.State h() {
        if (this.f3340n == null) {
            return Lifecycle.State.CREATED;
        }
        return this.f3344r;
    }

    public final void i(NavBackStackEntry navBackStackEntry, NavBackStackEntry navBackStackEntry2) {
        this.f3336j.put(navBackStackEntry, navBackStackEntry2);
        if (this.f3337k.get(navBackStackEntry2) == null) {
            this.f3337k.put(navBackStackEntry2, new AtomicInteger(0));
        }
        AtomicInteger atomicInteger = this.f3337k.get(navBackStackEntry2);
        d0.d(atomicInteger);
        atomicInteger.incrementAndGet();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0029, code lost:
        r1 = r11.f11398c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0187 A[LOOP:2: B:59:0x0181->B:61:0x0187, LOOP_END] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void j(h2.l r20, android.os.Bundle r21, h2.q r22, androidx.navigation.Navigator.a r23) {
        /*
            r19 = this;
            r0 = r19
            r10 = r20
            r11 = r22
            r12 = r23
            java.util.Map<androidx.navigation.Navigator<? extends h2.l>, androidx.navigation.NavController$NavControllerNavigatorState> r1 = r0.f3349w
            java.util.Collection r1 = r1.values()
            java.util.Iterator r1 = r1.iterator()
        L_0x0012:
            boolean r2 = r1.hasNext()
            r3 = 1
            if (r2 == 0) goto L_0x0022
            java.lang.Object r2 = r1.next()
            androidx.navigation.NavController$NavControllerNavigatorState r2 = (androidx.navigation.NavController.NavControllerNavigatorState) r2
            r2.f11444d = r3
            goto L_0x0012
        L_0x0022:
            kotlin.jvm.internal.Ref$BooleanRef r13 = new kotlin.jvm.internal.Ref$BooleanRef
            r13.<init>()
            if (r11 == 0) goto L_0x0038
            int r1 = r11.f11398c
            r2 = -1
            if (r1 == r2) goto L_0x0038
            boolean r2 = r11.f11399d
            boolean r4 = r11.f11400e
            boolean r1 = r0.n(r1, r2, r4)
            r15 = r1
            goto L_0x0039
        L_0x0038:
            r15 = 0
        L_0x0039:
            android.os.Bundle r9 = r20.f(r21)
            if (r11 == 0) goto L_0x0045
            boolean r1 = r11.f11397b
            if (r1 != r3) goto L_0x0045
            r1 = r3
            goto L_0x0046
        L_0x0045:
            r1 = 0
        L_0x0046:
            if (r1 == 0) goto L_0x0062
            java.util.Map<java.lang.Integer, java.lang.String> r1 = r0.f3338l
            int r2 = r10.f11382w
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            boolean r1 = r1.containsKey(r2)
            if (r1 == 0) goto L_0x0062
            int r1 = r10.f11382w
            boolean r1 = r0.t(r1, r9, r11, r12)
            r13.element = r1
            r18 = r15
            goto L_0x0173
        L_0x0062:
            yf.e<androidx.navigation.NavBackStackEntry> r1 = r0.f3333g
            java.lang.Object r1 = r1.t()
            androidx.navigation.NavBackStackEntry r1 = (androidx.navigation.NavBackStackEntry) r1
            h2.w r2 = r0.f3348v
            java.lang.String r4 = r10.f11375p
            androidx.navigation.Navigator r2 = r2.c(r4)
            if (r11 == 0) goto L_0x007a
            boolean r4 = r11.f11396a
            if (r4 != r3) goto L_0x007a
            r4 = r3
            goto L_0x007b
        L_0x007a:
            r4 = 0
        L_0x007b:
            r8 = 0
            if (r4 == 0) goto L_0x0144
            if (r1 == 0) goto L_0x008c
            h2.l r4 = r1.f3312q
            if (r4 == 0) goto L_0x008c
            int r5 = r10.f11382w
            int r4 = r4.f11382w
            if (r5 != r4) goto L_0x008c
            r4 = r3
            goto L_0x008d
        L_0x008c:
            r4 = 0
        L_0x008d:
            if (r4 == 0) goto L_0x0144
            yf.e<androidx.navigation.NavBackStackEntry> r4 = r0.f3333g
            java.lang.Object r4 = r4.w()
            androidx.navigation.NavBackStackEntry r4 = (androidx.navigation.NavBackStackEntry) r4
            r0.w(r4)
            androidx.navigation.NavBackStackEntry r12 = new androidx.navigation.NavBackStackEntry
            java.lang.String r4 = "entry"
            rg.d0.g(r1, r4)
            android.content.Context r5 = r1.f3311p
            h2.l r6 = r1.f3312q
            androidx.lifecycle.Lifecycle$State r10 = r1.f3314s
            h2.u r11 = r1.f3315t
            java.lang.String r7 = r1.f3316u
            android.os.Bundle r4 = r1.f3317v
            r16 = r4
            r4 = r12
            r17 = r7
            r7 = r9
            r9 = r8
            r8 = r10
            r10 = r9
            r9 = r11
            r11 = r10
            r10 = r17
            r14 = r11
            r11 = r16
            r4.<init>(r5, r6, r7, r8, r9, r10, r11)
            androidx.lifecycle.Lifecycle$State r4 = r1.f3314s
            r12.f3314s = r4
            androidx.lifecycle.Lifecycle$State r1 = r1.B
            r12.a(r1)
            yf.e<androidx.navigation.NavBackStackEntry> r1 = r0.f3333g
            r1.f(r12)
            h2.l r1 = r12.f3312q
            h2.n r1 = r1.f11376q
            if (r1 == 0) goto L_0x00dd
            int r1 = r1.f11382w
            androidx.navigation.NavBackStackEntry r1 = r0.e(r1)
            r0.i(r12, r1)
        L_0x00dd:
            h2.l r8 = r12.f3312q
            boolean r1 = r8 instanceof h2.l
            if (r1 == 0) goto L_0x00e4
            goto L_0x00e5
        L_0x00e4:
            r8 = r14
        L_0x00e5:
            if (r8 != 0) goto L_0x00e8
            goto L_0x0141
        L_0x00e8:
            androidx.navigation.Navigator$onLaunchSingleTop$1 r1 = androidx.navigation.Navigator$onLaunchSingleTop$1.INSTANCE
            h2.q r1 = l7.a.o(r1)
            r2.c(r8, r14, r1, r14)
            h2.x r1 = r2.b()
            ug.g<java.util.List<androidx.navigation.NavBackStackEntry>> r2 = r1.f11442b
            java.lang.Object r4 = r2.getValue()
            java.lang.Iterable r4 = (java.lang.Iterable) r4
            ug.g<java.util.List<androidx.navigation.NavBackStackEntry>> r1 = r1.f11442b
            java.lang.Object r1 = r1.getValue()
            java.util.List r1 = (java.util.List) r1
            java.lang.Object r1 = yf.l.h0(r1)
            java.lang.String r5 = "<this>"
            rg.d0.g(r4, r5)
            java.util.ArrayList r5 = new java.util.ArrayList
            r6 = 10
            int r6 = yf.i.S(r4, r6)
            r5.<init>(r6)
            java.util.Iterator r4 = r4.iterator()
            r6 = 0
        L_0x011e:
            boolean r7 = r4.hasNext()
            if (r7 == 0) goto L_0x013a
            java.lang.Object r7 = r4.next()
            if (r6 != 0) goto L_0x0133
            boolean r8 = rg.d0.b(r7, r1)
            if (r8 == 0) goto L_0x0133
            r6 = r3
            r8 = 0
            goto L_0x0134
        L_0x0133:
            r8 = r3
        L_0x0134:
            if (r8 == 0) goto L_0x011e
            r5.add(r7)
            goto L_0x011e
        L_0x013a:
            java.util.List r1 = yf.l.l0(r5, r12)
            r2.setValue(r1)
        L_0x0141:
            r18 = r15
            goto L_0x0174
        L_0x0144:
            r14 = r8
            androidx.navigation.NavBackStackEntry$a r1 = androidx.navigation.NavBackStackEntry.C
            android.content.Context r3 = r0.f3327a
            androidx.lifecycle.Lifecycle$State r5 = r19.h()
            h2.j r6 = r0.f3342p
            r7 = 0
            r8 = 0
            r16 = 96
            r4 = r2
            r2 = r3
            r3 = r20
            r14 = r4
            r4 = r9
            r18 = r15
            r15 = r9
            r9 = r16
            androidx.navigation.NavBackStackEntry r1 = androidx.navigation.NavBackStackEntry.a.b(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            java.util.List r1 = yf.h.u(r1)
            androidx.navigation.NavController$navigate$4 r2 = new androidx.navigation.NavController$navigate$4
            r2.<init>(r13, r0, r10, r15)
            r0.f3350x = r2
            r14.d(r1, r11, r12)
            r1 = 0
            r0.f3350x = r1
        L_0x0173:
            r3 = 0
        L_0x0174:
            r19.y()
            java.util.Map<androidx.navigation.Navigator<? extends h2.l>, androidx.navigation.NavController$NavControllerNavigatorState> r1 = r0.f3349w
            java.util.Collection r1 = r1.values()
            java.util.Iterator r1 = r1.iterator()
        L_0x0181:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x0191
            java.lang.Object r2 = r1.next()
            androidx.navigation.NavController$NavControllerNavigatorState r2 = (androidx.navigation.NavController.NavControllerNavigatorState) r2
            r4 = 0
            r2.f11444d = r4
            goto L_0x0181
        L_0x0191:
            if (r18 != 0) goto L_0x019e
            boolean r1 = r13.element
            if (r1 != 0) goto L_0x019e
            if (r3 == 0) goto L_0x019a
            goto L_0x019e
        L_0x019a:
            r19.x()
            goto L_0x01a1
        L_0x019e:
            r19.b()
        L_0x01a1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.NavController.j(h2.l, android.os.Bundle, h2.q, androidx.navigation.Navigator$a):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0059  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x005b  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x005e  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00ba  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void k(h2.m r10) {
        /*
            r9 = this;
            int r0 = r10.b()
            android.os.Bundle r10 = r10.a()
            yf.e<androidx.navigation.NavBackStackEntry> r1 = r9.f3333g
            boolean r1 = r1.isEmpty()
            if (r1 == 0) goto L_0x0013
            h2.n r1 = r9.f3329c
            goto L_0x001d
        L_0x0013:
            yf.e<androidx.navigation.NavBackStackEntry> r1 = r9.f3333g
            java.lang.Object r1 = r1.last()
            androidx.navigation.NavBackStackEntry r1 = (androidx.navigation.NavBackStackEntry) r1
            h2.l r1 = r1.f3312q
        L_0x001d:
            if (r1 == 0) goto L_0x00c6
            h2.d r2 = r1.l(r0)
            r3 = 0
            if (r2 == 0) goto L_0x0037
            h2.q r4 = r2.f11354b
            int r5 = r2.f11353a
            android.os.Bundle r6 = r2.f11355c
            if (r6 == 0) goto L_0x0039
            android.os.Bundle r7 = new android.os.Bundle
            r7.<init>()
            r7.putAll(r6)
            goto L_0x003a
        L_0x0037:
            r5 = r0
            r4 = r3
        L_0x0039:
            r7 = r3
        L_0x003a:
            if (r10 == 0) goto L_0x0046
            if (r7 != 0) goto L_0x0043
            android.os.Bundle r7 = new android.os.Bundle
            r7.<init>()
        L_0x0043:
            r7.putAll(r10)
        L_0x0046:
            if (r5 != 0) goto L_0x0055
            if (r4 == 0) goto L_0x0055
            int r10 = r4.f11398c
            r6 = -1
            if (r10 == r6) goto L_0x0055
            boolean r0 = r4.f11399d
            r9.m(r10, r0)
            goto L_0x00b9
        L_0x0055:
            r10 = 1
            r6 = 0
            if (r5 == 0) goto L_0x005b
            r8 = r10
            goto L_0x005c
        L_0x005b:
            r8 = r6
        L_0x005c:
            if (r8 == 0) goto L_0x00ba
            h2.l r8 = r9.c(r5)
            if (r8 != 0) goto L_0x00b6
            h2.l r3 = h2.l.f11374y
            android.content.Context r3 = r9.f3327a
            java.lang.String r3 = h2.l.r(r3, r5)
            if (r2 != 0) goto L_0x006f
            goto L_0x0070
        L_0x006f:
            r10 = r6
        L_0x0070:
            java.lang.String r2 = " cannot be found from the current destination "
            if (r10 != 0) goto L_0x0099
            java.lang.String r10 = "Navigation destination "
            java.lang.String r4 = " referenced from action "
            java.lang.StringBuilder r10 = k.h.a(r10, r3, r4)
            android.content.Context r3 = r9.f3327a
            java.lang.String r0 = h2.l.r(r3, r0)
            r10.append(r0)
            r10.append(r2)
            r10.append(r1)
            java.lang.String r10 = r10.toString()
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r10 = r10.toString()
            r0.<init>(r10)
            throw r0
        L_0x0099:
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r4 = "Navigation action/destination "
            r0.append(r4)
            r0.append(r3)
            r0.append(r2)
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r10.<init>(r0)
            throw r10
        L_0x00b6:
            r9.j(r8, r7, r4, r3)
        L_0x00b9:
            return
        L_0x00ba:
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Destination id == 0 can only be used in conjunction with a valid navOptions.popUpTo"
            java.lang.String r0 = r0.toString()
            r10.<init>(r0)
            throw r10
        L_0x00c6:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r0 = "no current navigation node"
            r10.<init>(r0)
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.NavController.k(h2.m):void");
    }

    public boolean l() {
        if (this.f3333g.isEmpty()) {
            return false;
        }
        l f10 = f();
        d0.d(f10);
        return m(f10.f11382w, true);
    }

    public boolean m(int i10, boolean z10) {
        if (!n(i10, z10, false) || !b()) {
            return false;
        }
        return true;
    }

    public final boolean n(int i10, boolean z10, boolean z11) {
        l lVar;
        String str;
        int i11 = i10;
        boolean z12 = z11;
        if (this.f3333g.isEmpty()) {
            return false;
        }
        ArrayList arrayList = new ArrayList();
        Iterator<T> it = yf.l.m0(this.f3333g).iterator();
        while (true) {
            if (!it.hasNext()) {
                lVar = null;
                break;
            }
            lVar = ((NavBackStackEntry) it.next()).f3312q;
            Navigator c10 = this.f3348v.c(lVar.f11375p);
            if (z10 || lVar.f11382w != i11) {
                arrayList.add(c10);
            }
            if (lVar.f11382w == i11) {
                break;
            }
        }
        l lVar2 = lVar;
        if (lVar2 == null) {
            l lVar3 = l.f11374y;
            String r10 = l.r(this.f3327a, i11);
            Log.i("NavController", "Ignoring popBackStack to destination " + r10 + " as it was not found on the current back stack");
            return false;
        }
        Ref$BooleanRef ref$BooleanRef = new Ref$BooleanRef();
        e eVar = new e();
        Iterator it2 = arrayList.iterator();
        while (true) {
            if (!it2.hasNext()) {
                str = null;
                break;
            }
            Ref$BooleanRef ref$BooleanRef2 = new Ref$BooleanRef();
            this.f3351y = new NavController$popBackStackInternal$2(ref$BooleanRef2, ref$BooleanRef, this, z11, eVar);
            ((Navigator) it2.next()).h(this.f3333g.last(), z12);
            str = null;
            this.f3351y = null;
            if (!ref$BooleanRef2.element) {
                break;
            }
        }
        if (z12) {
            if (!z10) {
                n.a aVar = new n.a(new og.n(SequencesKt__SequencesKt.B(lVar2, NavController$popBackStackInternal$3.INSTANCE), new NavController$popBackStackInternal$4(this)));
                while (aVar.hasNext()) {
                    Map<Integer, String> map = this.f3338l;
                    Integer valueOf = Integer.valueOf(((l) aVar.next()).f11382w);
                    NavBackStackEntryState navBackStackEntryState = (NavBackStackEntryState) eVar.r();
                    map.put(valueOf, navBackStackEntryState != null ? navBackStackEntryState.f3323p : str);
                }
            }
            if (!eVar.isEmpty()) {
                NavBackStackEntryState navBackStackEntryState2 = (NavBackStackEntryState) eVar.first();
                n.a aVar2 = new n.a(new og.n(SequencesKt__SequencesKt.B(c(navBackStackEntryState2.f3324q), NavController$popBackStackInternal$6.INSTANCE), new NavController$popBackStackInternal$7(this)));
                while (aVar2.hasNext()) {
                    this.f3338l.put(Integer.valueOf(((l) aVar2.next()).f11382w), navBackStackEntryState2.f3323p);
                }
                this.f3339m.put(navBackStackEntryState2.f3323p, eVar);
            }
        }
        y();
        return ref$BooleanRef.element;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x002d, code lost:
        r4 = (r4 = r4.f11446f).getValue();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void p(androidx.navigation.NavBackStackEntry r4, boolean r5, yf.e<androidx.navigation.NavBackStackEntryState> r6) {
        /*
            r3 = this;
            yf.e<androidx.navigation.NavBackStackEntry> r0 = r3.f3333g
            java.lang.Object r0 = r0.last()
            androidx.navigation.NavBackStackEntry r0 = (androidx.navigation.NavBackStackEntry) r0
            boolean r1 = rg.d0.b(r0, r4)
            if (r1 == 0) goto L_0x0090
            yf.e<androidx.navigation.NavBackStackEntry> r4 = r3.f3333g
            r4.w()
            h2.w r4 = r3.f3348v
            h2.l r1 = r0.f3312q
            java.lang.String r1 = r1.f11375p
            androidx.navigation.Navigator r4 = r4.c(r1)
            java.util.Map<androidx.navigation.Navigator<? extends h2.l>, androidx.navigation.NavController$NavControllerNavigatorState> r1 = r3.f3349w
            java.lang.Object r4 = r1.get(r4)
            androidx.navigation.NavController$NavControllerNavigatorState r4 = (androidx.navigation.NavController.NavControllerNavigatorState) r4
            r1 = 1
            r2 = 0
            if (r4 == 0) goto L_0x003d
            ug.m<java.util.Set<androidx.navigation.NavBackStackEntry>> r4 = r4.f11446f
            if (r4 == 0) goto L_0x003d
            java.lang.Object r4 = r4.getValue()
            java.util.Set r4 = (java.util.Set) r4
            if (r4 == 0) goto L_0x003d
            boolean r4 = r4.contains(r0)
            if (r4 != r1) goto L_0x003d
            r4 = r1
            goto L_0x003e
        L_0x003d:
            r4 = r2
        L_0x003e:
            if (r4 != 0) goto L_0x004a
            java.util.Map<androidx.navigation.NavBackStackEntry, java.util.concurrent.atomic.AtomicInteger> r4 = r3.f3337k
            boolean r4 = r4.containsKey(r0)
            if (r4 == 0) goto L_0x0049
            goto L_0x004a
        L_0x0049:
            r1 = r2
        L_0x004a:
            androidx.lifecycle.LifecycleRegistry r4 = r0.f3318w
            androidx.lifecycle.Lifecycle$State r4 = r4.getCurrentState()
            androidx.lifecycle.Lifecycle$State r2 = androidx.lifecycle.Lifecycle.State.CREATED
            boolean r4 = r4.isAtLeast(r2)
            if (r4 == 0) goto L_0x0073
            if (r5 == 0) goto L_0x0065
            r0.a(r2)
            androidx.navigation.NavBackStackEntryState r4 = new androidx.navigation.NavBackStackEntryState
            r4.<init>((androidx.navigation.NavBackStackEntry) r0)
            r6.c(r4)
        L_0x0065:
            if (r1 != 0) goto L_0x0070
            androidx.lifecycle.Lifecycle$State r4 = androidx.lifecycle.Lifecycle.State.DESTROYED
            r0.a(r4)
            r3.w(r0)
            goto L_0x0073
        L_0x0070:
            r0.a(r2)
        L_0x0073:
            if (r5 != 0) goto L_0x008f
            if (r1 != 0) goto L_0x008f
            h2.j r4 = r3.f3342p
            if (r4 == 0) goto L_0x008f
            java.lang.String r5 = r0.f3316u
            java.lang.String r6 = "backStackEntryId"
            rg.d0.g(r5, r6)
            java.util.Map<java.lang.String, androidx.lifecycle.ViewModelStore> r4 = r4.f11369p
            java.lang.Object r4 = r4.remove(r5)
            androidx.lifecycle.ViewModelStore r4 = (androidx.lifecycle.ViewModelStore) r4
            if (r4 == 0) goto L_0x008f
            r4.clear()
        L_0x008f:
            return
        L_0x0090:
            java.lang.String r5 = "Attempted to pop "
            java.lang.StringBuilder r5 = f.a.a(r5)
            h2.l r4 = r4.f3312q
            r5.append(r4)
            java.lang.String r4 = ", which is not the top of the back stack ("
            r5.append(r4)
            h2.l r4 = r0.f3312q
            r5.append(r4)
            r4 = 41
            r5.append(r4)
            java.lang.String r4 = r5.toString()
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r4 = r4.toString()
            r5.<init>(r4)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.NavController.p(androidx.navigation.NavBackStackEntry, boolean, yf.e):void");
    }

    public final List<NavBackStackEntry> r() {
        ArrayList arrayList = new ArrayList();
        for (NavControllerNavigatorState navControllerNavigatorState : this.f3349w.values()) {
            ArrayList arrayList2 = new ArrayList();
            for (Object next : navControllerNavigatorState.f11446f.getValue()) {
                NavBackStackEntry navBackStackEntry = (NavBackStackEntry) next;
                if (!arrayList.contains(navBackStackEntry) && !navBackStackEntry.B.isAtLeast(Lifecycle.State.STARTED)) {
                    arrayList2.add(next);
                }
            }
            yf.k.V(arrayList, arrayList2);
        }
        e<NavBackStackEntry> eVar = this.f3333g;
        ArrayList arrayList3 = new ArrayList();
        for (T next2 : eVar) {
            NavBackStackEntry navBackStackEntry2 = (NavBackStackEntry) next2;
            if (!arrayList.contains(navBackStackEntry2) && navBackStackEntry2.B.isAtLeast(Lifecycle.State.STARTED)) {
                arrayList3.add(next2);
            }
        }
        yf.k.V(arrayList, arrayList3);
        ArrayList arrayList4 = new ArrayList();
        for (Object next3 : arrayList) {
            if (!(((NavBackStackEntry) next3).f3312q instanceof h2.n)) {
                arrayList4.add(next3);
            }
        }
        return arrayList4;
    }

    public void s(Bundle bundle) {
        bundle.setClassLoader(this.f3327a.getClassLoader());
        this.f3330d = bundle.getBundle("android-support-nav:controller:navigatorState");
        this.f3331e = bundle.getParcelableArray("android-support-nav:controller:backStack");
        this.f3339m.clear();
        int[] intArray = bundle.getIntArray("android-support-nav:controller:backStackDestIds");
        ArrayList<String> stringArrayList = bundle.getStringArrayList("android-support-nav:controller:backStackIds");
        if (!(intArray == null || stringArrayList == null)) {
            int length = intArray.length;
            int i10 = 0;
            int i11 = 0;
            while (i10 < length) {
                this.f3338l.put(Integer.valueOf(intArray[i10]), stringArrayList.get(i11));
                i10++;
                i11++;
            }
        }
        ArrayList<String> stringArrayList2 = bundle.getStringArrayList("android-support-nav:controller:backStackStates");
        if (stringArrayList2 != null) {
            for (String str : stringArrayList2) {
                Parcelable[] parcelableArray = bundle.getParcelableArray("android-support-nav:controller:backStackStates:" + str);
                if (parcelableArray != null) {
                    Map<String, e<NavBackStackEntryState>> map = this.f3339m;
                    d0.f(str, "id");
                    e eVar = new e(parcelableArray.length);
                    Iterator i12 = xf.a.i(parcelableArray);
                    while (true) {
                        hg.a aVar = (hg.a) i12;
                        if (!aVar.hasNext()) {
                            break;
                        }
                        Parcelable parcelable = (Parcelable) aVar.next();
                        Objects.requireNonNull(parcelable, "null cannot be cast to non-null type androidx.navigation.NavBackStackEntryState");
                        eVar.f((NavBackStackEntryState) parcelable);
                    }
                    map.put(str, eVar);
                }
            }
        }
        this.f3332f = bundle.getBoolean("android-support-nav:controller:deepLinkHandled");
    }

    public final boolean t(int i10, Bundle bundle, q qVar, Navigator.a aVar) {
        l lVar;
        NavBackStackEntry navBackStackEntry;
        l lVar2;
        if (!this.f3338l.containsKey(Integer.valueOf(i10))) {
            return false;
        }
        String str = this.f3338l.get(Integer.valueOf(i10));
        Collection<String> values = this.f3338l.values();
        NavController$restoreStateInternal$1 navController$restoreStateInternal$1 = new NavController$restoreStateInternal$1(str);
        d0.g(values, "<this>");
        yf.k.W(values, navController$restoreStateInternal$1, true);
        e eVar = (e) hg.k.c(this.f3339m).remove(str);
        ArrayList arrayList = new ArrayList();
        NavBackStackEntry t10 = this.f3333g.t();
        if (t10 == null || (lVar = t10.f3312q) == null) {
            lVar = g();
        }
        if (eVar != null) {
            Iterator it = eVar.iterator();
            while (it.hasNext()) {
                NavBackStackEntryState navBackStackEntryState = (NavBackStackEntryState) it.next();
                l d10 = d(lVar, navBackStackEntryState.f3324q);
                if (d10 != null) {
                    arrayList.add(navBackStackEntryState.a(this.f3327a, d10, h(), this.f3342p));
                    lVar = d10;
                } else {
                    l lVar3 = l.f11374y;
                    String r10 = l.r(this.f3327a, navBackStackEntryState.f3324q);
                    throw new IllegalStateException(("Restore State failed: destination " + r10 + " cannot be found from the current destination " + lVar).toString());
                }
            }
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            if (!(((NavBackStackEntry) next).f3312q instanceof h2.n)) {
                arrayList3.add(next);
            }
        }
        Iterator it3 = arrayList3.iterator();
        while (true) {
            String str2 = null;
            if (!it3.hasNext()) {
                break;
            }
            NavBackStackEntry navBackStackEntry2 = (NavBackStackEntry) it3.next();
            List list = (List) yf.l.i0(arrayList2);
            if (!(list == null || (navBackStackEntry = (NavBackStackEntry) yf.l.h0(list)) == null || (lVar2 = navBackStackEntry.f3312q) == null)) {
                str2 = lVar2.f11375p;
            }
            if (d0.b(str2, navBackStackEntry2.f3312q.f11375p)) {
                list.add(navBackStackEntry2);
            } else {
                arrayList2.add(h.B(navBackStackEntry2));
            }
        }
        Ref$BooleanRef ref$BooleanRef = new Ref$BooleanRef();
        Iterator it4 = arrayList2.iterator();
        while (it4.hasNext()) {
            List list2 = (List) it4.next();
            Navigator c10 = this.f3348v.c(((NavBackStackEntry) yf.l.b0(list2)).f3312q.f11375p);
            this.f3350x = new NavController$restoreStateInternal$4(ref$BooleanRef, arrayList, new Ref$IntRef(), this, bundle);
            c10.d(list2, qVar, aVar);
            this.f3350x = null;
        }
        return ref$BooleanRef.element;
    }

    public Bundle u() {
        Bundle bundle;
        ArrayList arrayList = new ArrayList();
        Bundle bundle2 = new Bundle();
        for (Map.Entry next : p.W(this.f3348v.f11440a).entrySet()) {
            String str = (String) next.getKey();
            Bundle g10 = ((Navigator) next.getValue()).g();
            if (g10 != null) {
                arrayList.add(str);
                bundle2.putBundle(str, g10);
            }
        }
        if (!arrayList.isEmpty()) {
            bundle = new Bundle();
            bundle2.putStringArrayList("android-support-nav:controller:navigatorState:names", arrayList);
            bundle.putBundle("android-support-nav:controller:navigatorState", bundle2);
        } else {
            bundle = null;
        }
        if (!this.f3333g.isEmpty()) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            Parcelable[] parcelableArr = new Parcelable[this.f3333g.size()];
            Iterator<NavBackStackEntry> it = this.f3333g.iterator();
            int i10 = 0;
            while (it.hasNext()) {
                parcelableArr[i10] = new NavBackStackEntryState(it.next());
                i10++;
            }
            bundle.putParcelableArray("android-support-nav:controller:backStack", parcelableArr);
        }
        if (!this.f3338l.isEmpty()) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            int[] iArr = new int[this.f3338l.size()];
            ArrayList arrayList2 = new ArrayList();
            int i11 = 0;
            for (Map.Entry next2 : this.f3338l.entrySet()) {
                iArr[i11] = ((Number) next2.getKey()).intValue();
                arrayList2.add((String) next2.getValue());
                i11++;
            }
            bundle.putIntArray("android-support-nav:controller:backStackDestIds", iArr);
            bundle.putStringArrayList("android-support-nav:controller:backStackIds", arrayList2);
        }
        if (!this.f3339m.isEmpty()) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            ArrayList arrayList3 = new ArrayList();
            for (Map.Entry next3 : this.f3339m.entrySet()) {
                String str2 = (String) next3.getKey();
                e eVar = (e) next3.getValue();
                arrayList3.add(str2);
                Parcelable[] parcelableArr2 = new Parcelable[eVar.size()];
                Iterator it2 = eVar.iterator();
                int i12 = 0;
                while (it2.hasNext()) {
                    Object next4 = it2.next();
                    int i13 = i12 + 1;
                    if (i12 >= 0) {
                        parcelableArr2[i12] = (NavBackStackEntryState) next4;
                        i12 = i13;
                    } else {
                        h.P();
                        throw null;
                    }
                }
                bundle.putParcelableArray(a.d.a("android-support-nav:controller:backStackStates:", str2), parcelableArr2);
            }
            bundle.putStringArrayList("android-support-nav:controller:backStackStates", arrayList3);
        }
        if (this.f3332f) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android-support-nav:controller:deepLinkHandled", this.f3332f);
        }
        return bundle;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:85:0x01cd, code lost:
        if ((r2.length == 0) != false) goto L_0x01cf;
     */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x025d  */
    /* JADX WARNING: Removed duplicated region for block: B:191:0x040c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void v(h2.n r25, android.os.Bundle r26) {
        /*
            r24 = this;
            r6 = r24
            r7 = r25
            h2.n r0 = r6.f3329c
            boolean r0 = rg.d0.b(r0, r7)
            r8 = 0
            r9 = 1
            if (r0 != 0) goto L_0x0420
            h2.n r0 = r6.f3329c
            r10 = 0
            if (r0 == 0) goto L_0x007e
            java.util.ArrayList r1 = new java.util.ArrayList
            java.util.Map<java.lang.Integer, java.lang.String> r2 = r6.f3338l
            java.util.Set r2 = r2.keySet()
            r1.<init>(r2)
            java.util.Iterator r1 = r1.iterator()
        L_0x0022:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x0073
            java.lang.Object r2 = r1.next()
            java.lang.Integer r2 = (java.lang.Integer) r2
            java.lang.String r3 = "id"
            rg.d0.f(r2, r3)
            int r2 = r2.intValue()
            java.util.Map<androidx.navigation.Navigator<? extends h2.l>, androidx.navigation.NavController$NavControllerNavigatorState> r3 = r6.f3349w
            java.util.Collection r3 = r3.values()
            java.util.Iterator r3 = r3.iterator()
        L_0x0041:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0050
            java.lang.Object r4 = r3.next()
            androidx.navigation.NavController$NavControllerNavigatorState r4 = (androidx.navigation.NavController.NavControllerNavigatorState) r4
            r4.f11444d = r9
            goto L_0x0041
        L_0x0050:
            boolean r3 = r6.t(r2, r10, r10, r10)
            java.util.Map<androidx.navigation.Navigator<? extends h2.l>, androidx.navigation.NavController$NavControllerNavigatorState> r4 = r6.f3349w
            java.util.Collection r4 = r4.values()
            java.util.Iterator r4 = r4.iterator()
        L_0x005e:
            boolean r5 = r4.hasNext()
            if (r5 == 0) goto L_0x006d
            java.lang.Object r5 = r4.next()
            androidx.navigation.NavController$NavControllerNavigatorState r5 = (androidx.navigation.NavController.NavControllerNavigatorState) r5
            r5.f11444d = r8
            goto L_0x005e
        L_0x006d:
            if (r3 == 0) goto L_0x0022
            r6.n(r2, r9, r8)
            goto L_0x0022
        L_0x0073:
            int r1 = r0.f11382w
            r2 = 1
            r3 = 0
            r4 = 4
            r5 = 0
            r0 = r24
            o(r0, r1, r2, r3, r4, r5)
        L_0x007e:
            r6.f3329c = r7
            android.os.Bundle r0 = r6.f3330d
            if (r0 == 0) goto L_0x00b1
            java.lang.String r1 = "android-support-nav:controller:navigatorState:names"
            java.util.ArrayList r1 = r0.getStringArrayList(r1)
            if (r1 == 0) goto L_0x00b1
            java.util.Iterator r1 = r1.iterator()
        L_0x0090:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x00b1
            java.lang.Object r2 = r1.next()
            java.lang.String r2 = (java.lang.String) r2
            h2.w r3 = r6.f3348v
            java.lang.String r4 = "name"
            rg.d0.f(r2, r4)
            androidx.navigation.Navigator r3 = r3.c(r2)
            android.os.Bundle r2 = r0.getBundle(r2)
            if (r2 == 0) goto L_0x0090
            r3.f(r2)
            goto L_0x0090
        L_0x00b1:
            android.os.Parcelable[] r0 = r6.f3331e
            java.lang.String r7 = " cannot be found from the current destination "
            if (r0 == 0) goto L_0x012d
            int r1 = r0.length
            r2 = r8
        L_0x00b9:
            if (r2 >= r1) goto L_0x0128
            r3 = r0[r2]
            androidx.navigation.NavBackStackEntryState r3 = (androidx.navigation.NavBackStackEntryState) r3
            int r4 = r3.f3324q
            h2.l r4 = r6.c(r4)
            if (r4 == 0) goto L_0x0107
            android.content.Context r5 = r6.f3327a
            androidx.lifecycle.Lifecycle$State r11 = r24.h()
            h2.j r12 = r6.f3342p
            androidx.navigation.NavBackStackEntry r3 = r3.a(r5, r4, r11, r12)
            h2.w r5 = r6.f3348v
            java.lang.String r4 = r4.f11375p
            androidx.navigation.Navigator r4 = r5.c(r4)
            java.util.Map<androidx.navigation.Navigator<? extends h2.l>, androidx.navigation.NavController$NavControllerNavigatorState> r5 = r6.f3349w
            java.lang.Object r11 = r5.get(r4)
            if (r11 != 0) goto L_0x00eb
            androidx.navigation.NavController$NavControllerNavigatorState r11 = new androidx.navigation.NavController$NavControllerNavigatorState
            r11.<init>(r6, r4)
            r5.put(r4, r11)
        L_0x00eb:
            androidx.navigation.NavController$NavControllerNavigatorState r11 = (androidx.navigation.NavController.NavControllerNavigatorState) r11
            yf.e<androidx.navigation.NavBackStackEntry> r4 = r6.f3333g
            r4.f(r3)
            r11.e(r3)
            h2.l r4 = r3.f3312q
            h2.n r4 = r4.f11376q
            if (r4 == 0) goto L_0x0104
            int r4 = r4.f11382w
            androidx.navigation.NavBackStackEntry r4 = r6.e(r4)
            r6.i(r3, r4)
        L_0x0104:
            int r2 = r2 + 1
            goto L_0x00b9
        L_0x0107:
            h2.l r0 = h2.l.f11374y
            android.content.Context r0 = r6.f3327a
            int r1 = r3.f3324q
            java.lang.String r0 = h2.l.r(r0, r1)
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "Restoring the Navigation back stack failed: destination "
            java.lang.StringBuilder r0 = k.h.a(r2, r0, r7)
            h2.l r2 = r24.f()
            r0.append(r2)
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        L_0x0128:
            r24.y()
            r6.f3331e = r10
        L_0x012d:
            h2.w r0 = r6.f3348v
            java.util.Map<java.lang.String, androidx.navigation.Navigator<? extends h2.l>> r0 = r0.f11440a
            java.util.Map r0 = yf.p.W(r0)
            java.util.Collection r0 = r0.values()
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.Iterator r0 = r0.iterator()
        L_0x0142:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x0157
            java.lang.Object r2 = r0.next()
            r3 = r2
            androidx.navigation.Navigator r3 = (androidx.navigation.Navigator) r3
            boolean r3 = r3.f3372b
            if (r3 != 0) goto L_0x0142
            r1.add(r2)
            goto L_0x0142
        L_0x0157:
            java.util.Iterator r0 = r1.iterator()
        L_0x015b:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x017d
            java.lang.Object r1 = r0.next()
            androidx.navigation.Navigator r1 = (androidx.navigation.Navigator) r1
            java.util.Map<androidx.navigation.Navigator<? extends h2.l>, androidx.navigation.NavController$NavControllerNavigatorState> r2 = r6.f3349w
            java.lang.Object r3 = r2.get(r1)
            if (r3 != 0) goto L_0x0177
            androidx.navigation.NavController$NavControllerNavigatorState r3 = new androidx.navigation.NavController$NavControllerNavigatorState
            r3.<init>(r6, r1)
            r2.put(r1, r3)
        L_0x0177:
            androidx.navigation.NavController$NavControllerNavigatorState r3 = (androidx.navigation.NavController.NavControllerNavigatorState) r3
            r1.e(r3)
            goto L_0x015b
        L_0x017d:
            h2.n r0 = r6.f3329c
            if (r0 == 0) goto L_0x041b
            yf.e<androidx.navigation.NavBackStackEntry> r0 = r6.f3333g
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L_0x041b
            boolean r0 = r6.f3332f
            if (r0 != 0) goto L_0x040d
            android.app.Activity r0 = r6.f3328b
            if (r0 == 0) goto L_0x040d
            android.content.Intent r0 = r0.getIntent()
            if (r0 != 0) goto L_0x0199
            goto L_0x0409
        L_0x0199:
            android.os.Bundle r1 = r0.getExtras()
            if (r1 == 0) goto L_0x01a6
            java.lang.String r2 = "android-support-nav:controller:deepLinkIds"
            int[] r2 = r1.getIntArray(r2)
            goto L_0x01a7
        L_0x01a6:
            r2 = r10
        L_0x01a7:
            if (r1 == 0) goto L_0x01b0
            java.lang.String r3 = "android-support-nav:controller:deepLinkArgs"
            java.util.ArrayList r3 = r1.getParcelableArrayList(r3)
            goto L_0x01b1
        L_0x01b0:
            r3 = r10
        L_0x01b1:
            android.os.Bundle r4 = new android.os.Bundle
            r4.<init>()
            if (r1 == 0) goto L_0x01bf
            java.lang.String r5 = "android-support-nav:controller:deepLinkExtras"
            android.os.Bundle r1 = r1.getBundle(r5)
            goto L_0x01c0
        L_0x01bf:
            r1 = r10
        L_0x01c0:
            if (r1 == 0) goto L_0x01c5
            r4.putAll(r1)
        L_0x01c5:
            if (r2 == 0) goto L_0x01cf
            int r1 = r2.length
            if (r1 != 0) goto L_0x01cc
            r1 = r9
            goto L_0x01cd
        L_0x01cc:
            r1 = r8
        L_0x01cd:
            if (r1 == 0) goto L_0x025a
        L_0x01cf:
            h2.n r1 = r6.f3329c
            rg.d0.d(r1)
            h2.k r5 = new h2.k
            r5.<init>((android.content.Intent) r0)
            h2.l$a r1 = r1.s(r5)
            if (r1 == 0) goto L_0x025a
            h2.l r5 = r1.f11384p
            java.util.Objects.requireNonNull(r5)
            yf.e r11 = new yf.e
            r11.<init>()
            r2 = r5
        L_0x01ea:
            h2.n r3 = r2.f11376q
            if (r3 == 0) goto L_0x01f4
            int r12 = r3.A
            int r13 = r2.f11382w
            if (r12 == r13) goto L_0x01f7
        L_0x01f4:
            r11.c(r2)
        L_0x01f7:
            boolean r2 = rg.d0.b(r3, r10)
            if (r2 == 0) goto L_0x01fe
            goto L_0x0200
        L_0x01fe:
            if (r3 != 0) goto L_0x0258
        L_0x0200:
            java.util.List r2 = yf.l.q0(r11)
            java.util.ArrayList r3 = new java.util.ArrayList
            r11 = 10
            int r11 = yf.i.S(r2, r11)
            r3.<init>(r11)
            java.util.Iterator r2 = r2.iterator()
        L_0x0213:
            boolean r11 = r2.hasNext()
            if (r11 == 0) goto L_0x0229
            java.lang.Object r11 = r2.next()
            h2.l r11 = (h2.l) r11
            int r11 = r11.f11382w
            java.lang.Integer r11 = java.lang.Integer.valueOf(r11)
            r3.add(r11)
            goto L_0x0213
        L_0x0229:
            int r2 = r3.size()
            int[] r2 = new int[r2]
            java.util.Iterator r3 = r3.iterator()
            r11 = r8
        L_0x0234:
            boolean r12 = r3.hasNext()
            if (r12 == 0) goto L_0x024a
            java.lang.Object r12 = r3.next()
            java.lang.Number r12 = (java.lang.Number) r12
            int r12 = r12.intValue()
            int r13 = r11 + 1
            r2[r11] = r12
            r11 = r13
            goto L_0x0234
        L_0x024a:
            android.os.Bundle r1 = r1.f11385q
            android.os.Bundle r1 = r5.f(r1)
            if (r1 == 0) goto L_0x0255
            r4.putAll(r1)
        L_0x0255:
            r11 = r2
            r3 = r10
            goto L_0x025b
        L_0x0258:
            r2 = r3
            goto L_0x01ea
        L_0x025a:
            r11 = r2
        L_0x025b:
            if (r11 == 0) goto L_0x0409
            int r1 = r11.length
            if (r1 != 0) goto L_0x0262
            r1 = r9
            goto L_0x0263
        L_0x0262:
            r1 = r8
        L_0x0263:
            if (r1 == 0) goto L_0x0267
            goto L_0x0409
        L_0x0267:
            h2.n r1 = r6.f3329c
            int r2 = r11.length
            r5 = r8
        L_0x026b:
            if (r5 >= r2) goto L_0x02b7
            r12 = r11[r5]
            if (r5 != 0) goto L_0x027f
            h2.n r13 = r6.f3329c
            rg.d0.d(r13)
            int r13 = r13.f11382w
            if (r13 != r12) goto L_0x027d
            h2.n r13 = r6.f3329c
            goto L_0x0286
        L_0x027d:
            r13 = r10
            goto L_0x0286
        L_0x027f:
            rg.d0.d(r1)
            h2.l r13 = r1.w(r12)
        L_0x0286:
            if (r13 != 0) goto L_0x0291
            h2.l r1 = h2.l.f11374y
            android.content.Context r1 = r6.f3327a
            java.lang.String r1 = h2.l.r(r1, r12)
            goto L_0x02b8
        L_0x0291:
            int r12 = r11.length
            int r12 = r12 + -1
            if (r5 == r12) goto L_0x02b4
            boolean r12 = r13 instanceof h2.n
            if (r12 == 0) goto L_0x02b4
            h2.n r13 = (h2.n) r13
        L_0x029c:
            rg.d0.d(r13)
            int r1 = r13.A
            h2.l r1 = r13.w(r1)
            boolean r1 = r1 instanceof h2.n
            if (r1 == 0) goto L_0x02b3
            int r1 = r13.A
            h2.l r1 = r13.w(r1)
            r13 = r1
            h2.n r13 = (h2.n) r13
            goto L_0x029c
        L_0x02b3:
            r1 = r13
        L_0x02b4:
            int r5 = r5 + 1
            goto L_0x026b
        L_0x02b7:
            r1 = r10
        L_0x02b8:
            if (r1 == 0) goto L_0x02da
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Could not find destination "
            r2.append(r3)
            r2.append(r1)
            java.lang.String r1 = " in the navigation graph, ignoring the deep link from "
            r2.append(r1)
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            java.lang.String r1 = "NavController"
            android.util.Log.i(r1, r0)
            goto L_0x0409
        L_0x02da:
            java.lang.String r1 = "android-support-nav:controller:deepLinkIntent"
            r4.putParcelable(r1, r0)
            int r1 = r11.length
            android.os.Bundle[] r12 = new android.os.Bundle[r1]
            r2 = r8
        L_0x02e3:
            if (r2 >= r1) goto L_0x02ff
            android.os.Bundle r5 = new android.os.Bundle
            r5.<init>()
            r5.putAll(r4)
            if (r3 == 0) goto L_0x02fa
            java.lang.Object r13 = r3.get(r2)
            android.os.Bundle r13 = (android.os.Bundle) r13
            if (r13 == 0) goto L_0x02fa
            r5.putAll(r13)
        L_0x02fa:
            r12[r2] = r5
            int r2 = r2 + 1
            goto L_0x02e3
        L_0x02ff:
            int r1 = r0.getFlags()
            r2 = 268435456(0x10000000, float:2.5243549E-29)
            r2 = r2 & r1
            if (r2 == 0) goto L_0x032a
            r3 = 32768(0x8000, float:4.5918E-41)
            r1 = r1 & r3
            if (r1 != 0) goto L_0x032a
            r0.addFlags(r3)
            android.content.Context r1 = r6.f3327a
            a1.c0 r2 = new a1.c0
            r2.<init>(r1)
            r2.c(r0)
            r2.i()
            android.app.Activity r0 = r6.f3328b
            if (r0 == 0) goto L_0x0407
            r0.finish()
            r0.overridePendingTransition(r8, r8)
            goto L_0x0407
        L_0x032a:
            java.lang.String r13 = "Deep Linking failed: destination "
            if (r2 == 0) goto L_0x0381
            yf.e<androidx.navigation.NavBackStackEntry> r0 = r6.f3333g
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L_0x0346
            h2.n r0 = r6.f3329c
            rg.d0.d(r0)
            int r1 = r0.f11382w
            r2 = 1
            r3 = 0
            r4 = 4
            r5 = 0
            r0 = r24
            o(r0, r1, r2, r3, r4, r5)
        L_0x0346:
            r0 = r8
        L_0x0347:
            int r1 = r11.length
            if (r0 >= r1) goto L_0x0407
            r1 = r11[r0]
            int r2 = r0 + 1
            r0 = r12[r0]
            h2.l r3 = r6.c(r1)
            if (r3 == 0) goto L_0x0364
            androidx.navigation.NavController$handleDeepLink$2 r1 = new androidx.navigation.NavController$handleDeepLink$2
            r1.<init>(r3, r6)
            h2.q r1 = l7.a.o(r1)
            r6.j(r3, r0, r1, r10)
            r0 = r2
            goto L_0x0347
        L_0x0364:
            h2.l r0 = h2.l.f11374y
            android.content.Context r0 = r6.f3327a
            java.lang.String r0 = h2.l.r(r0, r1)
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.StringBuilder r0 = k.h.a(r13, r0, r7)
            h2.l r2 = r24.f()
            r0.append(r2)
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        L_0x0381:
            h2.n r0 = r6.f3329c
            int r1 = r11.length
            r2 = r8
        L_0x0385:
            if (r2 >= r1) goto L_0x0405
            r3 = r11[r2]
            r4 = r12[r2]
            if (r2 != 0) goto L_0x0390
            h2.n r5 = r6.f3329c
            goto L_0x0397
        L_0x0390:
            rg.d0.d(r0)
            h2.l r5 = r0.w(r3)
        L_0x0397:
            if (r5 == 0) goto L_0x03e0
            int r3 = r11.length
            int r3 = r3 - r9
            if (r2 == r3) goto L_0x03bc
            boolean r3 = r5 instanceof h2.n
            if (r3 == 0) goto L_0x03dd
            h2.n r5 = (h2.n) r5
        L_0x03a3:
            rg.d0.d(r5)
            int r0 = r5.A
            h2.l r0 = r5.w(r0)
            boolean r0 = r0 instanceof h2.n
            if (r0 == 0) goto L_0x03ba
            int r0 = r5.A
            h2.l r0 = r5.w(r0)
            r5 = r0
            h2.n r5 = (h2.n) r5
            goto L_0x03a3
        L_0x03ba:
            r0 = r5
            goto L_0x03dd
        L_0x03bc:
            r16 = 0
            r15 = 0
            r23 = -1
            h2.n r3 = r6.f3329c
            rg.d0.d(r3)
            int r3 = r3.f11382w
            r18 = 1
            r19 = 0
            r20 = 0
            r21 = 0
            h2.q r7 = new h2.q
            r14 = r7
            r17 = r3
            r22 = r23
            r14.<init>(r15, r16, r17, r18, r19, r20, r21, r22, r23)
            r6.j(r5, r4, r7, r10)
        L_0x03dd:
            int r2 = r2 + 1
            goto L_0x0385
        L_0x03e0:
            h2.l r1 = h2.l.f11374y
            android.content.Context r1 = r6.f3327a
            java.lang.String r1 = h2.l.r(r1, r3)
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            r3.append(r13)
            r3.append(r1)
            java.lang.String r1 = " cannot be found in graph "
            r3.append(r1)
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            r2.<init>(r0)
            throw r2
        L_0x0405:
            r6.f3332f = r9
        L_0x0407:
            r0 = r9
            goto L_0x040a
        L_0x0409:
            r0 = r8
        L_0x040a:
            if (r0 == 0) goto L_0x040d
            r8 = r9
        L_0x040d:
            if (r8 != 0) goto L_0x0498
            h2.n r0 = r6.f3329c
            rg.d0.d(r0)
            r1 = r26
            r6.j(r0, r1, r10, r10)
            goto L_0x0498
        L_0x041b:
            r24.b()
            goto L_0x0498
        L_0x0420:
            o0.h<h2.l> r0 = r7.f11389z
            int r0 = r0.i()
            r1 = r8
        L_0x0427:
            if (r1 >= r0) goto L_0x0498
            o0.h<h2.l> r2 = r7.f11389z
            java.lang.Object r2 = r2.k(r1)
            h2.l r2 = (h2.l) r2
            h2.n r3 = r6.f3329c
            rg.d0.d(r3)
            o0.h<h2.l> r3 = r3.f11389z
            boolean r4 = r3.f14823p
            if (r4 == 0) goto L_0x043f
            r3.c()
        L_0x043f:
            int[] r4 = r3.f14824q
            int r5 = r3.f14826s
            int r4 = o0.c.a(r4, r5, r1)
            if (r4 < 0) goto L_0x044f
            java.lang.Object[] r3 = r3.f14825r
            r5 = r3[r4]
            r3[r4] = r2
        L_0x044f:
            yf.e<androidx.navigation.NavBackStackEntry> r3 = r6.f3333g
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.Iterator r3 = r3.iterator()
        L_0x045a:
            boolean r5 = r3.hasNext()
            if (r5 == 0) goto L_0x047a
            java.lang.Object r5 = r3.next()
            r10 = r5
            androidx.navigation.NavBackStackEntry r10 = (androidx.navigation.NavBackStackEntry) r10
            if (r2 == 0) goto L_0x0473
            h2.l r10 = r10.f3312q
            int r10 = r10.f11382w
            int r11 = r2.f11382w
            if (r10 != r11) goto L_0x0473
            r10 = r9
            goto L_0x0474
        L_0x0473:
            r10 = r8
        L_0x0474:
            if (r10 == 0) goto L_0x045a
            r4.add(r5)
            goto L_0x045a
        L_0x047a:
            java.util.Iterator r3 = r4.iterator()
        L_0x047e:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x0495
            java.lang.Object r4 = r3.next()
            androidx.navigation.NavBackStackEntry r4 = (androidx.navigation.NavBackStackEntry) r4
            java.lang.String r5 = "newDestination"
            rg.d0.f(r2, r5)
            java.util.Objects.requireNonNull(r4)
            r4.f3312q = r2
            goto L_0x047e
        L_0x0495:
            int r1 = r1 + 1
            goto L_0x0427
        L_0x0498:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.NavController.v(h2.n, android.os.Bundle):void");
    }

    public final NavBackStackEntry w(NavBackStackEntry navBackStackEntry) {
        j jVar;
        d0.g(navBackStackEntry, "child");
        NavBackStackEntry remove = this.f3336j.remove(navBackStackEntry);
        Integer num = null;
        if (remove == null) {
            return null;
        }
        AtomicInteger atomicInteger = this.f3337k.get(remove);
        if (atomicInteger != null) {
            num = Integer.valueOf(atomicInteger.decrementAndGet());
        }
        if (num != null && num.intValue() == 0) {
            NavControllerNavigatorState navControllerNavigatorState = this.f3349w.get(this.f3348v.c(remove.f3312q.f11375p));
            if (navControllerNavigatorState != null) {
                d0.g(remove, "entry");
                boolean b10 = d0.b(navControllerNavigatorState.f3354h.f3352z.get(remove), Boolean.TRUE);
                d0.g(remove, "entry");
                g<Set<NavBackStackEntry>> gVar = navControllerNavigatorState.f11443c;
                Set value = gVar.getValue();
                d0.g(value, "<this>");
                LinkedHashSet linkedHashSet = new LinkedHashSet(h.x(value.size()));
                Iterator it = value.iterator();
                boolean z10 = false;
                boolean z11 = false;
                while (true) {
                    boolean z12 = true;
                    if (!it.hasNext()) {
                        break;
                    }
                    Object next = it.next();
                    if (!z11 && d0.b(next, remove)) {
                        z11 = true;
                        z12 = false;
                    }
                    if (z12) {
                        linkedHashSet.add(next);
                    }
                }
                gVar.setValue(linkedHashSet);
                navControllerNavigatorState.f3354h.f3352z.remove(remove);
                if (!navControllerNavigatorState.f3354h.f3333g.contains(remove)) {
                    navControllerNavigatorState.f3354h.w(remove);
                    if (remove.f3318w.getCurrentState().isAtLeast(Lifecycle.State.CREATED)) {
                        remove.a(Lifecycle.State.DESTROYED);
                    }
                    e<NavBackStackEntry> eVar = navControllerNavigatorState.f3354h.f3333g;
                    if (!(eVar instanceof Collection) || !eVar.isEmpty()) {
                        Iterator<NavBackStackEntry> it2 = eVar.iterator();
                        while (true) {
                            if (it2.hasNext()) {
                                if (d0.b(it2.next().f3316u, remove.f3316u)) {
                                    break;
                                }
                            } else {
                                break;
                            }
                        }
                    }
                    z10 = true;
                    if (z10 && !b10 && (jVar = navControllerNavigatorState.f3354h.f3342p) != null) {
                        String str = remove.f3316u;
                        d0.g(str, "backStackEntryId");
                        ViewModelStore remove2 = jVar.f11369p.remove(str);
                        if (remove2 != null) {
                            remove2.clear();
                        }
                    }
                    navControllerNavigatorState.f3354h.x();
                    NavController navController = navControllerNavigatorState.f3354h;
                    navController.f3334h.b(navController.r());
                } else if (!navControllerNavigatorState.f11444d) {
                    navControllerNavigatorState.f3354h.x();
                    NavController navController2 = navControllerNavigatorState.f3354h;
                    navController2.f3334h.b(navController2.r());
                }
            }
            this.f3337k.remove(remove);
        }
        return remove;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x007c, code lost:
        r7 = (r7 = r7.f11446f).getValue();
     */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0050  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00e4  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void x() {
        /*
            r11 = this;
            yf.e<androidx.navigation.NavBackStackEntry> r0 = r11.f3333g
            java.util.List r0 = yf.l.s0(r0)
            r1 = r0
            java.util.ArrayList r1 = (java.util.ArrayList) r1
            boolean r2 = r1.isEmpty()
            if (r2 == 0) goto L_0x0010
            return
        L_0x0010:
            java.lang.Object r2 = yf.l.h0(r0)
            androidx.navigation.NavBackStackEntry r2 = (androidx.navigation.NavBackStackEntry) r2
            h2.l r2 = r2.f3312q
            boolean r3 = r2 instanceof h2.c
            r4 = 0
            if (r3 == 0) goto L_0x003c
            java.util.List r3 = yf.l.m0(r0)
            java.util.Iterator r3 = r3.iterator()
        L_0x0025:
            boolean r5 = r3.hasNext()
            if (r5 == 0) goto L_0x003c
            java.lang.Object r5 = r3.next()
            androidx.navigation.NavBackStackEntry r5 = (androidx.navigation.NavBackStackEntry) r5
            h2.l r5 = r5.f3312q
            boolean r6 = r5 instanceof h2.n
            if (r6 != 0) goto L_0x0025
            boolean r6 = r5 instanceof h2.c
            if (r6 != 0) goto L_0x0025
            goto L_0x003d
        L_0x003c:
            r5 = r4
        L_0x003d:
            java.util.HashMap r3 = new java.util.HashMap
            r3.<init>()
            java.util.List r0 = yf.l.m0(r0)
            java.util.Iterator r0 = r0.iterator()
        L_0x004a:
            boolean r6 = r0.hasNext()
            if (r6 == 0) goto L_0x00da
            java.lang.Object r6 = r0.next()
            androidx.navigation.NavBackStackEntry r6 = (androidx.navigation.NavBackStackEntry) r6
            androidx.lifecycle.Lifecycle$State r7 = r6.B
            h2.l r8 = r6.f3312q
            if (r2 == 0) goto L_0x00b6
            int r9 = r8.f11382w
            int r10 = r2.f11382w
            if (r9 != r10) goto L_0x00b6
            androidx.lifecycle.Lifecycle$State r9 = androidx.lifecycle.Lifecycle.State.RESUMED
            if (r7 == r9) goto L_0x00b3
            h2.w r7 = r11.f3348v
            java.lang.String r8 = r8.f11375p
            androidx.navigation.Navigator r7 = r7.c(r8)
            java.util.Map<androidx.navigation.Navigator<? extends h2.l>, androidx.navigation.NavController$NavControllerNavigatorState> r8 = r11.f3349w
            java.lang.Object r7 = r8.get(r7)
            androidx.navigation.NavController$NavControllerNavigatorState r7 = (androidx.navigation.NavController.NavControllerNavigatorState) r7
            if (r7 == 0) goto L_0x008d
            ug.m<java.util.Set<androidx.navigation.NavBackStackEntry>> r7 = r7.f11446f
            if (r7 == 0) goto L_0x008d
            java.lang.Object r7 = r7.getValue()
            java.util.Set r7 = (java.util.Set) r7
            if (r7 == 0) goto L_0x008d
            boolean r7 = r7.contains(r6)
            java.lang.Boolean r7 = java.lang.Boolean.valueOf(r7)
            goto L_0x008e
        L_0x008d:
            r7 = r4
        L_0x008e:
            java.lang.Boolean r8 = java.lang.Boolean.TRUE
            boolean r7 = rg.d0.b(r7, r8)
            if (r7 != 0) goto L_0x00ae
            java.util.Map<androidx.navigation.NavBackStackEntry, java.util.concurrent.atomic.AtomicInteger> r7 = r11.f3337k
            java.lang.Object r7 = r7.get(r6)
            java.util.concurrent.atomic.AtomicInteger r7 = (java.util.concurrent.atomic.AtomicInteger) r7
            r8 = 0
            if (r7 == 0) goto L_0x00a8
            int r7 = r7.get()
            if (r7 != 0) goto L_0x00a8
            r8 = 1
        L_0x00a8:
            if (r8 != 0) goto L_0x00ae
            r3.put(r6, r9)
            goto L_0x00b3
        L_0x00ae:
            androidx.lifecycle.Lifecycle$State r7 = androidx.lifecycle.Lifecycle.State.STARTED
            r3.put(r6, r7)
        L_0x00b3:
            h2.n r2 = r2.f11376q
            goto L_0x004a
        L_0x00b6:
            if (r5 == 0) goto L_0x00d3
            int r8 = r8.f11382w
            int r9 = r5.f11382w
            if (r8 != r9) goto L_0x00d3
            androidx.lifecycle.Lifecycle$State r8 = androidx.lifecycle.Lifecycle.State.RESUMED
            if (r7 != r8) goto L_0x00c8
            androidx.lifecycle.Lifecycle$State r7 = androidx.lifecycle.Lifecycle.State.STARTED
            r6.a(r7)
            goto L_0x00cf
        L_0x00c8:
            androidx.lifecycle.Lifecycle$State r8 = androidx.lifecycle.Lifecycle.State.STARTED
            if (r7 == r8) goto L_0x00cf
            r3.put(r6, r8)
        L_0x00cf:
            h2.n r5 = r5.f11376q
            goto L_0x004a
        L_0x00d3:
            androidx.lifecycle.Lifecycle$State r7 = androidx.lifecycle.Lifecycle.State.CREATED
            r6.a(r7)
            goto L_0x004a
        L_0x00da:
            java.util.Iterator r0 = r1.iterator()
        L_0x00de:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x00fa
            java.lang.Object r1 = r0.next()
            androidx.navigation.NavBackStackEntry r1 = (androidx.navigation.NavBackStackEntry) r1
            java.lang.Object r2 = r3.get(r1)
            androidx.lifecycle.Lifecycle$State r2 = (androidx.lifecycle.Lifecycle.State) r2
            if (r2 == 0) goto L_0x00f6
            r1.a(r2)
            goto L_0x00de
        L_0x00f6:
            r1.b()
            goto L_0x00de
        L_0x00fa:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.NavController.x():void");
    }

    public final void y() {
        int i10;
        androidx.activity.g gVar = this.f3346t;
        boolean z10 = false;
        if (this.f3347u) {
            e<NavBackStackEntry> eVar = this.f3333g;
            if (!(eVar instanceof Collection) || !eVar.isEmpty()) {
                Iterator<NavBackStackEntry> it = eVar.iterator();
                i10 = 0;
                while (it.hasNext()) {
                    if ((!(it.next().f3312q instanceof h2.n)) && (i10 = i10 + 1) < 0) {
                        throw new ArithmeticException("Count overflow has happened.");
                    }
                }
            } else {
                i10 = 0;
            }
            if (i10 > 1) {
                z10 = true;
            }
        }
        gVar.c(z10);
    }
}
