package androidx.navigation;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.net.Uri;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import androidx.navigation.Navigator;
import h2.l;
import h2.q;
import h2.z;
import java.util.Iterator;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.sequences.SequencesKt__SequencesKt;
import okhttp3.HttpUrl;
import pg.j;
import rg.d0;

@Navigator.b("activity")
/* compiled from: ActivityNavigator.kt */
public class ActivityNavigator extends Navigator<a> {

    /* renamed from: c  reason: collision with root package name */
    public final Context f3308c;

    /* renamed from: d  reason: collision with root package name */
    public final Activity f3309d;

    /* compiled from: ActivityNavigator.kt */
    public static class a extends l {
        public String A;

        /* renamed from: z  reason: collision with root package name */
        public Intent f3310z;

        public a(Navigator<? extends a> navigator) {
            super(navigator);
        }

        public boolean equals(Object obj) {
            if (obj == null || !(obj instanceof a) || !super.equals(obj)) {
                return false;
            }
            Intent intent = this.f3310z;
            if (!(intent != null ? intent.filterEquals(((a) obj).f3310z) : ((a) obj).f3310z == null) || !d0.b(this.A, ((a) obj).A)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            int hashCode = super.hashCode() * 31;
            Intent intent = this.f3310z;
            int i10 = 0;
            int filterHashCode = (hashCode + (intent != null ? intent.filterHashCode() : 0)) * 31;
            String str = this.A;
            if (str != null) {
                i10 = str.hashCode();
            }
            return filterHashCode + i10;
        }

        public void t(Context context, AttributeSet attributeSet) {
            d0.g(context, "context");
            d0.g(attributeSet, "attrs");
            super.t(context, attributeSet);
            TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, z.f11448a);
            d0.f(obtainAttributes, "context.resources.obtain…tyNavigator\n            )");
            String string = obtainAttributes.getString(4);
            if (string != null) {
                String packageName = context.getPackageName();
                d0.f(packageName, "context.packageName");
                string = j.s(string, "${applicationId}", packageName, false, 4);
            }
            if (this.f3310z == null) {
                this.f3310z = new Intent();
            }
            Intent intent = this.f3310z;
            d0.d(intent);
            intent.setPackage(string);
            String string2 = obtainAttributes.getString(0);
            if (string2 != null) {
                if (string2.charAt(0) == '.') {
                    string2 = context.getPackageName() + string2;
                }
                ComponentName componentName = new ComponentName(context, string2);
                if (this.f3310z == null) {
                    this.f3310z = new Intent();
                }
                Intent intent2 = this.f3310z;
                d0.d(intent2);
                intent2.setComponent(componentName);
            }
            String string3 = obtainAttributes.getString(1);
            if (this.f3310z == null) {
                this.f3310z = new Intent();
            }
            Intent intent3 = this.f3310z;
            d0.d(intent3);
            intent3.setAction(string3);
            String string4 = obtainAttributes.getString(2);
            if (string4 != null) {
                Uri parse = Uri.parse(string4);
                if (this.f3310z == null) {
                    this.f3310z = new Intent();
                }
                Intent intent4 = this.f3310z;
                d0.d(intent4);
                intent4.setData(parse);
            }
            this.A = obtainAttributes.getString(3);
            obtainAttributes.recycle();
        }

        public String toString() {
            Intent intent = this.f3310z;
            String str = null;
            ComponentName component = intent != null ? intent.getComponent() : null;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(super.toString());
            if (component != null) {
                sb2.append(" class=");
                sb2.append(component.getClassName());
            } else {
                Intent intent2 = this.f3310z;
                if (intent2 != null) {
                    str = intent2.getAction();
                }
                if (str != null) {
                    sb2.append(" action=");
                    sb2.append(str);
                }
            }
            String sb3 = sb2.toString();
            d0.f(sb3, "sb.toString()");
            return sb3;
        }
    }

    /* compiled from: ActivityNavigator.kt */
    public static final class b implements Navigator.a {
    }

    public ActivityNavigator(Context context) {
        Object obj;
        d0.g(context, "context");
        this.f3308c = context;
        Iterator it = SequencesKt__SequencesKt.B(context, ActivityNavigator$hostActivity$1.INSTANCE).iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (((Context) obj) instanceof Activity) {
                break;
            }
        }
        this.f3309d = (Activity) obj;
    }

    public l a() {
        return new a(this);
    }

    public l c(l lVar, Bundle bundle, q qVar, Navigator.a aVar) {
        Intent intent;
        int intExtra;
        a aVar2 = (a) lVar;
        if (aVar2.f3310z != null) {
            Intent intent2 = new Intent(aVar2.f3310z);
            int i10 = 0;
            if (bundle != null) {
                intent2.putExtras(bundle);
                String str = aVar2.A;
                if (!(str == null || str.length() == 0)) {
                    StringBuffer stringBuffer = new StringBuffer();
                    Matcher matcher = Pattern.compile("\\{(.+?)\\}").matcher(str);
                    while (matcher.find()) {
                        String group = matcher.group(1);
                        if (bundle.containsKey(group)) {
                            matcher.appendReplacement(stringBuffer, HttpUrl.FRAGMENT_ENCODE_SET);
                            stringBuffer.append(Uri.encode(String.valueOf(bundle.get(group))));
                        } else {
                            throw new IllegalArgumentException("Could not find " + group + " in " + bundle + " to fill data pattern " + str);
                        }
                    }
                    matcher.appendTail(stringBuffer);
                    intent2.setData(Uri.parse(stringBuffer.toString()));
                }
            }
            boolean z10 = aVar instanceof b;
            if (z10) {
                Objects.requireNonNull((b) aVar);
                intent2.addFlags(0);
            }
            if (this.f3309d == null) {
                intent2.addFlags(268435456);
            }
            if (qVar != null && qVar.f11396a) {
                intent2.addFlags(536870912);
            }
            Activity activity = this.f3309d;
            if (!(activity == null || (intent = activity.getIntent()) == null || (intExtra = intent.getIntExtra("android-support-navigation:ActivityNavigator:current", 0)) == 0)) {
                intent2.putExtra("android-support-navigation:ActivityNavigator:source", intExtra);
            }
            intent2.putExtra("android-support-navigation:ActivityNavigator:current", aVar2.f11382w);
            Resources resources = this.f3308c.getResources();
            if (qVar != null) {
                int i11 = qVar.f11403h;
                int i12 = qVar.f11404i;
                if ((i11 <= 0 || !d0.b(resources.getResourceTypeName(i11), "animator")) && (i12 <= 0 || !d0.b(resources.getResourceTypeName(i12), "animator"))) {
                    intent2.putExtra("android-support-navigation:ActivityNavigator:popEnterAnim", i11);
                    intent2.putExtra("android-support-navigation:ActivityNavigator:popExitAnim", i12);
                } else {
                    StringBuilder a10 = f.a.a("Activity destinations do not support Animator resource. Ignoring popEnter resource ");
                    a10.append(resources.getResourceName(i11));
                    a10.append(" and popExit resource ");
                    a10.append(resources.getResourceName(i12));
                    a10.append(" when launching ");
                    a10.append(aVar2);
                    Log.w("ActivityNavigator", a10.toString());
                }
            }
            if (z10) {
                Objects.requireNonNull((b) aVar);
                this.f3308c.startActivity(intent2);
            } else {
                this.f3308c.startActivity(intent2);
            }
            if (qVar == null || this.f3309d == null) {
                return null;
            }
            int i13 = qVar.f11401f;
            int i14 = qVar.f11402g;
            if ((i13 > 0 && d0.b(resources.getResourceTypeName(i13), "animator")) || (i14 > 0 && d0.b(resources.getResourceTypeName(i14), "animator"))) {
                StringBuilder a11 = f.a.a("Activity destinations do not support Animator resource. Ignoring enter resource ");
                a11.append(resources.getResourceName(i13));
                a11.append(" and exit resource ");
                a11.append(resources.getResourceName(i14));
                a11.append("when launching ");
                a11.append(aVar2);
                Log.w("ActivityNavigator", a11.toString());
                return null;
            } else if (i13 < 0 && i14 < 0) {
                return null;
            } else {
                if (i13 < 0) {
                    i13 = 0;
                }
                if (i14 >= 0) {
                    i10 = i14;
                }
                this.f3309d.overridePendingTransition(i13, i10);
                return null;
            }
        } else {
            throw new IllegalStateException(ai.plaud.android.plaud.anew.database.recordfile.b.a(f.a.a("Destination "), aVar2.f11382w, " does not have an Intent set.").toString());
        }
    }

    public boolean i() {
        Activity activity = this.f3309d;
        if (activity == null) {
            return false;
        }
        activity.finish();
        return true;
    }
}
