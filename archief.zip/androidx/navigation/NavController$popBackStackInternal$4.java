package androidx.navigation;

import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: NavController.kt */
public final class NavController$popBackStackInternal$4 extends Lambda implements l<h2.l, Boolean> {
    public final /* synthetic */ NavController this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NavController$popBackStackInternal$4(NavController navController) {
        super(1);
        this.this$0 = navController;
    }

    public final Boolean invoke(h2.l lVar) {
        d0.g(lVar, "destination");
        return Boolean.valueOf(!this.this$0.f3338l.containsKey(Integer.valueOf(lVar.f11382w)));
    }
}
