package androidx.room;

import android.annotation.SuppressLint;
import androidx.appcompat.widget.h;
import androidx.arch.core.executor.ArchTaskExecutor;
import androidx.lifecycle.LiveData;
import androidx.room.d;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: RoomTrackingLiveData */
public class i<T> extends LiveData<T> {

    /* renamed from: a  reason: collision with root package name */
    public final RoomDatabase f3842a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f3843b;

    /* renamed from: c  reason: collision with root package name */
    public final Callable<T> f3844c;

    /* renamed from: d  reason: collision with root package name */
    public final h f3845d;

    /* renamed from: e  reason: collision with root package name */
    public final d.c f3846e;

    /* renamed from: f  reason: collision with root package name */
    public final AtomicBoolean f3847f = new AtomicBoolean(true);

    /* renamed from: g  reason: collision with root package name */
    public final AtomicBoolean f3848g = new AtomicBoolean(false);

    /* renamed from: h  reason: collision with root package name */
    public final AtomicBoolean f3849h = new AtomicBoolean(false);

    /* renamed from: i  reason: collision with root package name */
    public final Runnable f3850i = new a();

    /* renamed from: j  reason: collision with root package name */
    public final Runnable f3851j = new b();

    /* compiled from: RoomTrackingLiveData */
    public class a implements Runnable {
        public a() {
        }

        /* JADX WARNING: Removed duplicated region for block: B:22:0x0064  */
        /* JADX WARNING: Removed duplicated region for block: B:5:0x002d  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void run() {
            /*
                r5 = this;
                androidx.room.i r0 = androidx.room.i.this
                java.util.concurrent.atomic.AtomicBoolean r0 = r0.f3849h
                r1 = 0
                r2 = 1
                boolean r0 = r0.compareAndSet(r1, r2)
                if (r0 == 0) goto L_0x0023
                androidx.room.i r0 = androidx.room.i.this
                androidx.room.RoomDatabase r0 = r0.f3842a
                androidx.room.d r0 = r0.getInvalidationTracker()
                androidx.room.i r3 = androidx.room.i.this
                androidx.room.d$c r3 = r3.f3846e
                java.util.Objects.requireNonNull(r0)
                androidx.room.d$e r4 = new androidx.room.d$e
                r4.<init>(r0, r3)
                r0.a(r4)
            L_0x0023:
                androidx.room.i r0 = androidx.room.i.this
                java.util.concurrent.atomic.AtomicBoolean r0 = r0.f3848g
                boolean r0 = r0.compareAndSet(r1, r2)
                if (r0 == 0) goto L_0x0064
                r0 = 0
                r3 = r1
            L_0x002f:
                androidx.room.i r4 = androidx.room.i.this     // Catch:{ all -> 0x005b }
                java.util.concurrent.atomic.AtomicBoolean r4 = r4.f3847f     // Catch:{ all -> 0x005b }
                boolean r4 = r4.compareAndSet(r2, r1)     // Catch:{ all -> 0x005b }
                if (r4 == 0) goto L_0x004c
                androidx.room.i r0 = androidx.room.i.this     // Catch:{ Exception -> 0x0043 }
                java.util.concurrent.Callable<T> r0 = r0.f3844c     // Catch:{ Exception -> 0x0043 }
                java.lang.Object r0 = r0.call()     // Catch:{ Exception -> 0x0043 }
                r3 = r2
                goto L_0x002f
            L_0x0043:
                r0 = move-exception
                java.lang.RuntimeException r2 = new java.lang.RuntimeException     // Catch:{ all -> 0x005b }
                java.lang.String r3 = "Exception while computing database live data."
                r2.<init>(r3, r0)     // Catch:{ all -> 0x005b }
                throw r2     // Catch:{ all -> 0x005b }
            L_0x004c:
                if (r3 == 0) goto L_0x0053
                androidx.room.i r4 = androidx.room.i.this     // Catch:{ all -> 0x005b }
                r4.postValue(r0)     // Catch:{ all -> 0x005b }
            L_0x0053:
                androidx.room.i r0 = androidx.room.i.this
                java.util.concurrent.atomic.AtomicBoolean r0 = r0.f3848g
                r0.set(r1)
                goto L_0x0065
            L_0x005b:
                r0 = move-exception
                androidx.room.i r2 = androidx.room.i.this
                java.util.concurrent.atomic.AtomicBoolean r2 = r2.f3848g
                r2.set(r1)
                throw r0
            L_0x0064:
                r3 = r1
            L_0x0065:
                if (r3 == 0) goto L_0x0071
                androidx.room.i r0 = androidx.room.i.this
                java.util.concurrent.atomic.AtomicBoolean r0 = r0.f3847f
                boolean r0 = r0.get()
                if (r0 != 0) goto L_0x0023
            L_0x0071:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.room.i.a.run():void");
        }
    }

    /* compiled from: RoomTrackingLiveData */
    public class b implements Runnable {
        public b() {
        }

        public void run() {
            Executor executor;
            boolean hasActiveObservers = i.this.hasActiveObservers();
            if (i.this.f3847f.compareAndSet(false, true) && hasActiveObservers) {
                i iVar = i.this;
                if (iVar.f3843b) {
                    executor = iVar.f3842a.getTransactionExecutor();
                } else {
                    executor = iVar.f3842a.getQueryExecutor();
                }
                executor.execute(i.this.f3850i);
            }
        }
    }

    /* compiled from: RoomTrackingLiveData */
    public class c extends d.c {
        public c(String[] strArr) {
            super(strArr);
        }

        public void a(Set<String> set) {
            ArchTaskExecutor.getInstance().executeOnMainThread(i.this.f3851j);
        }
    }

    @SuppressLint({"RestrictedApi"})
    public i(RoomDatabase roomDatabase, h hVar, boolean z10, Callable<T> callable, String[] strArr) {
        this.f3842a = roomDatabase;
        this.f3843b = z10;
        this.f3844c = callable;
        this.f3845d = hVar;
        this.f3846e = new c(strArr);
    }

    public void onActive() {
        Executor executor;
        super.onActive();
        ((Set) this.f3845d.f1897q).add(this);
        if (this.f3843b) {
            executor = this.f3842a.getTransactionExecutor();
        } else {
            executor = this.f3842a.getQueryExecutor();
        }
        executor.execute(this.f3850i);
    }

    public void onInactive() {
        super.onInactive();
        ((Set) this.f3845d.f1897q).remove(this);
    }
}
