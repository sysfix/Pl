package androidx.room;

import android.database.Cursor;
import q2.b;

/* compiled from: RoomOpenHelper */
public class h extends b.a {

    /* renamed from: b  reason: collision with root package name */
    public a f3836b;

    /* renamed from: c  reason: collision with root package name */
    public final a f3837c;

    /* renamed from: d  reason: collision with root package name */
    public final String f3838d;

    /* renamed from: e  reason: collision with root package name */
    public final String f3839e;

    /* compiled from: RoomOpenHelper */
    public static abstract class a {
        public final int version;

        public a(int i10) {
            this.version = i10;
        }

        public abstract void createAllTables(q2.a aVar);

        public abstract void dropAllTables(q2.a aVar);

        public abstract void onCreate(q2.a aVar);

        public abstract void onOpen(q2.a aVar);

        public abstract void onPostMigrate(q2.a aVar);

        public abstract void onPreMigrate(q2.a aVar);

        public abstract b onValidateSchema(q2.a aVar);

        @Deprecated
        public void validateMigration(q2.a aVar) {
            throw new UnsupportedOperationException("validateMigration is deprecated");
        }
    }

    /* compiled from: RoomOpenHelper */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final boolean f3840a;

        /* renamed from: b  reason: collision with root package name */
        public final String f3841b;

        public b(boolean z10, String str) {
            this.f3840a = z10;
            this.f3841b = str;
        }
    }

    public h(a aVar, a aVar2, String str, String str2) {
        super(aVar2.version);
        this.f3836b = aVar;
        this.f3837c = aVar2;
        this.f3838d = str;
        this.f3839e = str2;
    }

    public void b(q2.a aVar) {
    }

    /* JADX INFO: finally extract failed */
    public void c(q2.a aVar) {
        r2.a aVar2 = (r2.a) aVar;
        Cursor g12 = aVar2.g1("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
        try {
            boolean z10 = false;
            if (g12.moveToFirst() && g12.getInt(0) == 0) {
                z10 = true;
            }
            g12.close();
            this.f3837c.createAllTables(aVar2);
            if (!z10) {
                b onValidateSchema = this.f3837c.onValidateSchema(aVar2);
                if (!onValidateSchema.f3840a) {
                    StringBuilder a10 = f.a.a("Pre-packaged database has an invalid schema: ");
                    a10.append(onValidateSchema.f3841b);
                    throw new IllegalStateException(a10.toString());
                }
            }
            g(aVar2);
            this.f3837c.onCreate(aVar2);
        } catch (Throwable th2) {
            g12.close();
            throw th2;
        }
    }

    public void d(q2.a aVar, int i10, int i11) {
        f(aVar, i10, i11);
    }

    /* JADX INFO: finally extract failed */
    public void e(q2.a aVar) {
        r2.a aVar2 = (r2.a) aVar;
        Cursor g12 = aVar2.g1("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
        try {
            boolean z10 = g12.moveToFirst() && g12.getInt(0) != 0;
            g12.close();
            if (z10) {
                Cursor A = aVar2.A(new androidx.appcompat.widget.h("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1", 2));
                try {
                    String string = A.moveToFirst() ? A.getString(0) : null;
                    A.close();
                    if (!this.f3838d.equals(string) && !this.f3839e.equals(string)) {
                        throw new IllegalStateException("Room cannot verify the data integrity. Looks like you've changed schema but forgot to update the version number. You can simply fix this by increasing the version number.");
                    }
                } catch (Throwable th2) {
                    A.close();
                    throw th2;
                }
            } else {
                b onValidateSchema = this.f3837c.onValidateSchema(aVar2);
                if (onValidateSchema.f3840a) {
                    this.f3837c.onPostMigrate(aVar2);
                    g(aVar2);
                } else {
                    StringBuilder a10 = f.a.a("Pre-packaged database has an invalid schema: ");
                    a10.append(onValidateSchema.f3841b);
                    throw new IllegalStateException(a10.toString());
                }
            }
            this.f3837c.onOpen(aVar2);
            this.f3836b = null;
        } catch (Throwable th3) {
            g12.close();
            throw th3;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0079, code lost:
        r0 = r4;
     */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00c0  */
    /* JADX WARNING: Removed duplicated region for block: B:64:? A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void f(q2.a r12, int r13, int r14) {
        /*
            r11 = this;
            androidx.room.a r0 = r11.f3836b
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L_0x00bd
            androidx.room.RoomDatabase$c r0 = r0.f3788d
            java.util.Objects.requireNonNull(r0)
            if (r13 != r14) goto L_0x0013
            java.util.List r0 = java.util.Collections.emptyList()
            goto L_0x007a
        L_0x0013:
            if (r14 <= r13) goto L_0x0017
            r3 = r1
            goto L_0x0018
        L_0x0017:
            r3 = r2
        L_0x0018:
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r5 = r13
        L_0x001e:
            if (r3 == 0) goto L_0x0023
            if (r5 >= r14) goto L_0x0079
            goto L_0x0025
        L_0x0023:
            if (r5 <= r14) goto L_0x0079
        L_0x0025:
            java.util.HashMap<java.lang.Integer, java.util.TreeMap<java.lang.Integer, n2.b>> r6 = r0.f3784a
            java.lang.Integer r7 = java.lang.Integer.valueOf(r5)
            java.lang.Object r6 = r6.get(r7)
            java.util.TreeMap r6 = (java.util.TreeMap) r6
            r7 = 0
            if (r6 != 0) goto L_0x0035
            goto L_0x0077
        L_0x0035:
            if (r3 == 0) goto L_0x003c
            java.util.NavigableSet r8 = r6.descendingKeySet()
            goto L_0x0040
        L_0x003c:
            java.util.Set r8 = r6.keySet()
        L_0x0040:
            java.util.Iterator r8 = r8.iterator()
        L_0x0044:
            boolean r9 = r8.hasNext()
            if (r9 == 0) goto L_0x0074
            java.lang.Object r9 = r8.next()
            java.lang.Integer r9 = (java.lang.Integer) r9
            int r9 = r9.intValue()
            if (r3 == 0) goto L_0x005b
            if (r9 > r14) goto L_0x0061
            if (r9 <= r5) goto L_0x0061
            goto L_0x005f
        L_0x005b:
            if (r9 < r14) goto L_0x0061
            if (r9 >= r5) goto L_0x0061
        L_0x005f:
            r10 = r1
            goto L_0x0062
        L_0x0061:
            r10 = r2
        L_0x0062:
            if (r10 == 0) goto L_0x0044
            java.lang.Integer r5 = java.lang.Integer.valueOf(r9)
            java.lang.Object r5 = r6.get(r5)
            n2.b r5 = (n2.b) r5
            r4.add(r5)
            r6 = r1
            r5 = r9
            goto L_0x0075
        L_0x0074:
            r6 = r2
        L_0x0075:
            if (r6 != 0) goto L_0x001e
        L_0x0077:
            r0 = r7
            goto L_0x007a
        L_0x0079:
            r0 = r4
        L_0x007a:
            if (r0 == 0) goto L_0x00bd
            androidx.room.h$a r2 = r11.f3837c
            r2.onPreMigrate(r12)
            java.util.Iterator r0 = r0.iterator()
        L_0x0085:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x0095
            java.lang.Object r2 = r0.next()
            n2.b r2 = (n2.b) r2
            r2.migrate(r12)
            goto L_0x0085
        L_0x0095:
            androidx.room.h$a r0 = r11.f3837c
            androidx.room.h$b r0 = r0.onValidateSchema(r12)
            boolean r2 = r0.f3840a
            if (r2 == 0) goto L_0x00a8
            androidx.room.h$a r0 = r11.f3837c
            r0.onPostMigrate(r12)
            r11.g(r12)
            goto L_0x00be
        L_0x00a8:
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
            java.lang.String r13 = "Migration didn't properly handle: "
            java.lang.StringBuilder r13 = f.a.a(r13)
            java.lang.String r14 = r0.f3841b
            r13.append(r14)
            java.lang.String r13 = r13.toString()
            r12.<init>(r13)
            throw r12
        L_0x00bd:
            r1 = r2
        L_0x00be:
            if (r1 != 0) goto L_0x00e5
            androidx.room.a r0 = r11.f3836b
            if (r0 == 0) goto L_0x00d5
            boolean r0 = r0.a(r13, r14)
            if (r0 != 0) goto L_0x00d5
            androidx.room.h$a r13 = r11.f3837c
            r13.dropAllTables(r12)
            androidx.room.h$a r13 = r11.f3837c
            r13.createAllTables(r12)
            goto L_0x00e5
        L_0x00d5:
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
            java.lang.String r0 = "A migration from "
            java.lang.String r1 = " to "
            java.lang.String r2 = " was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods."
            java.lang.String r13 = m2.h.a(r0, r13, r1, r14, r2)
            r12.<init>(r13)
            throw r12
        L_0x00e5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.room.h.f(q2.a, int, int):void");
    }

    public final void g(q2.a aVar) {
        aVar.I("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        String str = this.f3838d;
        aVar.I("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '" + str + "')");
    }
}
