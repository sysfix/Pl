package androidx.room;

import android.content.Context;
import android.content.ServiceConnection;
import androidx.room.d;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: MultiInstanceInvalidationClient */
public class e {

    /* renamed from: a  reason: collision with root package name */
    public final Context f3827a;

    /* renamed from: b  reason: collision with root package name */
    public int f3828b;

    /* renamed from: c  reason: collision with root package name */
    public final d f3829c;

    /* renamed from: d  reason: collision with root package name */
    public final d.c f3830d;

    /* renamed from: e  reason: collision with root package name */
    public c f3831e;

    /* renamed from: f  reason: collision with root package name */
    public final b f3832f;

    /* renamed from: g  reason: collision with root package name */
    public final AtomicBoolean f3833g;

    /* renamed from: h  reason: collision with root package name */
    public final ServiceConnection f3834h;
}
