package androidx.room;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.os.RemoteException;
import android.util.Log;
import androidx.appcompat.widget.h;
import androidx.arch.core.internal.SafeIterableMap;
import androidx.lifecycle.LiveData;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;

/* compiled from: InvalidationTracker */
public class d {

    /* renamed from: n  reason: collision with root package name */
    public static final String[] f3801n = {"UPDATE", "DELETE", "INSERT"};

    /* renamed from: a  reason: collision with root package name */
    public final HashMap<String, Integer> f3802a;

    /* renamed from: b  reason: collision with root package name */
    public final String[] f3803b;

    /* renamed from: c  reason: collision with root package name */
    public Map<String, Set<String>> f3804c;

    /* renamed from: d  reason: collision with root package name */
    public final RoomDatabase f3805d;

    /* renamed from: e  reason: collision with root package name */
    public AtomicBoolean f3806e = new AtomicBoolean(false);

    /* renamed from: f  reason: collision with root package name */
    public volatile boolean f3807f = false;

    /* renamed from: g  reason: collision with root package name */
    public volatile q2.e f3808g;

    /* renamed from: h  reason: collision with root package name */
    public final b f3809h;

    /* renamed from: i  reason: collision with root package name */
    public final h f3810i;
    @SuppressLint({"RestrictedApi"})

    /* renamed from: j  reason: collision with root package name */
    public final SafeIterableMap<c, C0038d> f3811j = new SafeIterableMap<>();

    /* renamed from: k  reason: collision with root package name */
    public e f3812k;

    /* renamed from: l  reason: collision with root package name */
    public final Object f3813l = new Object();

    /* renamed from: m  reason: collision with root package name */
    public Runnable f3814m = new a();

    /* compiled from: InvalidationTracker */
    public class a implements Runnable {
        public a() {
        }

        /* JADX INFO: finally extract failed */
        public final Set<Integer> a() {
            HashSet hashSet = new HashSet();
            Cursor query = d.this.f3805d.query(new h("SELECT * FROM room_table_modification_log WHERE invalidated = 1;", 2));
            while (query.moveToNext()) {
                try {
                    hashSet.add(Integer.valueOf(query.getInt(0)));
                } catch (Throwable th2) {
                    query.close();
                    throw th2;
                }
            }
            query.close();
            if (!hashSet.isEmpty()) {
                d.this.f3808g.T();
            }
            return hashSet;
        }

        /* JADX WARNING: Removed duplicated region for block: B:41:0x008a  */
        /* JADX WARNING: Removed duplicated region for block: B:75:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void run() {
            /*
                r11 = this;
                androidx.room.d r0 = androidx.room.d.this
                androidx.room.RoomDatabase r0 = r0.f3805d
                java.util.concurrent.locks.Lock r0 = r0.getCloseLock()
                r0.lock()
                r1 = 0
                r2 = 0
                r3 = 1
                androidx.room.d r4 = androidx.room.d.this     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                boolean r4 = r4.c()     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                if (r4 != 0) goto L_0x001f
                r0.unlock()
                androidx.room.d r0 = androidx.room.d.this
                java.util.Objects.requireNonNull(r0)
                return
            L_0x001f:
                androidx.room.d r4 = androidx.room.d.this     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                java.util.concurrent.atomic.AtomicBoolean r4 = r4.f3806e     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                boolean r4 = r4.compareAndSet(r3, r1)     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                if (r4 != 0) goto L_0x0032
                r0.unlock()
                androidx.room.d r0 = androidx.room.d.this
                java.util.Objects.requireNonNull(r0)
                return
            L_0x0032:
                androidx.room.d r4 = androidx.room.d.this     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                androidx.room.RoomDatabase r4 = r4.f3805d     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                boolean r4 = r4.inTransaction()     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                if (r4 == 0) goto L_0x0045
                r0.unlock()
                androidx.room.d r0 = androidx.room.d.this
                java.util.Objects.requireNonNull(r0)
                return
            L_0x0045:
                androidx.room.d r4 = androidx.room.d.this     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                androidx.room.RoomDatabase r4 = r4.f3805d     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                q2.b r4 = r4.getOpenHelper()     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                q2.a r4 = r4.c1()     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                r4.S0()     // Catch:{ IllegalStateException -> 0x0078, SQLiteException -> 0x0076 }
                java.util.Set r5 = r11.a()     // Catch:{ all -> 0x006d }
                r4.P0()     // Catch:{ all -> 0x006b }
                r4.s()     // Catch:{ IllegalStateException -> 0x0069, SQLiteException -> 0x0067 }
            L_0x005e:
                r0.unlock()
                androidx.room.d r0 = androidx.room.d.this
                java.util.Objects.requireNonNull(r0)
                goto L_0x0082
            L_0x0067:
                r4 = move-exception
                goto L_0x007a
            L_0x0069:
                r4 = move-exception
                goto L_0x007a
            L_0x006b:
                r6 = move-exception
                goto L_0x006f
            L_0x006d:
                r6 = move-exception
                r5 = r2
            L_0x006f:
                r4.s()     // Catch:{ IllegalStateException -> 0x0069, SQLiteException -> 0x0067 }
                throw r6     // Catch:{ IllegalStateException -> 0x0069, SQLiteException -> 0x0067 }
            L_0x0073:
                r1 = move-exception
                goto L_0x00e2
            L_0x0076:
                r4 = move-exception
                goto L_0x0079
            L_0x0078:
                r4 = move-exception
            L_0x0079:
                r5 = r2
            L_0x007a:
                java.lang.String r6 = "ROOM"
                java.lang.String r7 = "Cannot run invalidation tracker. Is the db closed?"
                android.util.Log.e(r6, r7, r4)     // Catch:{ all -> 0x0073 }
                goto L_0x005e
            L_0x0082:
                if (r5 == 0) goto L_0x00e1
                boolean r0 = r5.isEmpty()
                if (r0 != 0) goto L_0x00e1
                androidx.room.d r0 = androidx.room.d.this
                androidx.arch.core.internal.SafeIterableMap<androidx.room.d$c, androidx.room.d$d> r0 = r0.f3811j
                monitor-enter(r0)
                androidx.room.d r4 = androidx.room.d.this     // Catch:{ all -> 0x00de }
                androidx.arch.core.internal.SafeIterableMap<androidx.room.d$c, androidx.room.d$d> r4 = r4.f3811j     // Catch:{ all -> 0x00de }
                java.util.Iterator r4 = r4.iterator()     // Catch:{ all -> 0x00de }
            L_0x0097:
                boolean r6 = r4.hasNext()     // Catch:{ all -> 0x00de }
                if (r6 == 0) goto L_0x00dc
                java.lang.Object r6 = r4.next()     // Catch:{ all -> 0x00de }
                java.util.Map$Entry r6 = (java.util.Map.Entry) r6     // Catch:{ all -> 0x00de }
                java.lang.Object r6 = r6.getValue()     // Catch:{ all -> 0x00de }
                androidx.room.d$d r6 = (androidx.room.d.C0038d) r6     // Catch:{ all -> 0x00de }
                int[] r7 = r6.f3821a     // Catch:{ all -> 0x00de }
                int r7 = r7.length     // Catch:{ all -> 0x00de }
                r8 = r1
                r9 = r2
            L_0x00ae:
                if (r8 >= r7) goto L_0x00d4
                int[] r10 = r6.f3821a     // Catch:{ all -> 0x00de }
                r10 = r10[r8]     // Catch:{ all -> 0x00de }
                java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ all -> 0x00de }
                boolean r10 = r5.contains(r10)     // Catch:{ all -> 0x00de }
                if (r10 == 0) goto L_0x00d1
                if (r7 != r3) goto L_0x00c3
                java.util.Set<java.lang.String> r9 = r6.f3824d     // Catch:{ all -> 0x00de }
                goto L_0x00d1
            L_0x00c3:
                if (r9 != 0) goto L_0x00ca
                java.util.HashSet r9 = new java.util.HashSet     // Catch:{ all -> 0x00de }
                r9.<init>(r7)     // Catch:{ all -> 0x00de }
            L_0x00ca:
                java.lang.String[] r10 = r6.f3822b     // Catch:{ all -> 0x00de }
                r10 = r10[r8]     // Catch:{ all -> 0x00de }
                r9.add(r10)     // Catch:{ all -> 0x00de }
            L_0x00d1:
                int r8 = r8 + 1
                goto L_0x00ae
            L_0x00d4:
                if (r9 == 0) goto L_0x0097
                androidx.room.d$c r6 = r6.f3823c     // Catch:{ all -> 0x00de }
                r6.a(r9)     // Catch:{ all -> 0x00de }
                goto L_0x0097
            L_0x00dc:
                monitor-exit(r0)     // Catch:{ all -> 0x00de }
                goto L_0x00e1
            L_0x00de:
                r1 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x00de }
                throw r1
            L_0x00e1:
                return
            L_0x00e2:
                r0.unlock()
                androidx.room.d r0 = androidx.room.d.this
                java.util.Objects.requireNonNull(r0)
                throw r1
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.room.d.a.run():void");
        }
    }

    /* compiled from: InvalidationTracker */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final long[] f3816a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean[] f3817b;

        /* renamed from: c  reason: collision with root package name */
        public final int[] f3818c;

        /* renamed from: d  reason: collision with root package name */
        public boolean f3819d;

        public b(int i10) {
            long[] jArr = new long[i10];
            this.f3816a = jArr;
            boolean[] zArr = new boolean[i10];
            this.f3817b = zArr;
            this.f3818c = new int[i10];
            Arrays.fill(jArr, 0);
            Arrays.fill(zArr, false);
        }

        public int[] a() {
            synchronized (this) {
                if (!this.f3819d) {
                    return null;
                }
                int length = this.f3816a.length;
                for (int i10 = 0; i10 < length; i10++) {
                    int i11 = 1;
                    boolean z10 = this.f3816a[i10] > 0;
                    boolean[] zArr = this.f3817b;
                    if (z10 != zArr[i10]) {
                        int[] iArr = this.f3818c;
                        if (!z10) {
                            i11 = 2;
                        }
                        iArr[i10] = i11;
                    } else {
                        this.f3818c[i10] = 0;
                    }
                    zArr[i10] = z10;
                }
                this.f3819d = false;
                int[] iArr2 = (int[]) this.f3818c.clone();
                return iArr2;
            }
        }
    }

    /* compiled from: InvalidationTracker */
    public static abstract class c {

        /* renamed from: a  reason: collision with root package name */
        public final String[] f3820a;

        public c(String[] strArr) {
            this.f3820a = (String[]) Arrays.copyOf(strArr, strArr.length);
        }

        public abstract void a(Set<String> set);
    }

    /* renamed from: androidx.room.d$d  reason: collision with other inner class name */
    /* compiled from: InvalidationTracker */
    public static class C0038d {

        /* renamed from: a  reason: collision with root package name */
        public final int[] f3821a;

        /* renamed from: b  reason: collision with root package name */
        public final String[] f3822b;

        /* renamed from: c  reason: collision with root package name */
        public final c f3823c;

        /* renamed from: d  reason: collision with root package name */
        public final Set<String> f3824d;

        public C0038d(c cVar, int[] iArr, String[] strArr) {
            this.f3823c = cVar;
            this.f3821a = iArr;
            this.f3822b = strArr;
            if (iArr.length == 1) {
                HashSet hashSet = new HashSet();
                hashSet.add(strArr[0]);
                this.f3824d = Collections.unmodifiableSet(hashSet);
                return;
            }
            this.f3824d = null;
        }
    }

    /* compiled from: InvalidationTracker */
    public static class e extends c {

        /* renamed from: b  reason: collision with root package name */
        public final d f3825b;

        /* renamed from: c  reason: collision with root package name */
        public final WeakReference<c> f3826c;

        public e(d dVar, c cVar) {
            super(cVar.f3820a);
            this.f3825b = dVar;
            this.f3826c = new WeakReference<>(cVar);
        }

        public void a(Set<String> set) {
            c cVar = (c) this.f3826c.get();
            if (cVar == null) {
                this.f3825b.d(this);
            } else {
                cVar.a(set);
            }
        }
    }

    public d(RoomDatabase roomDatabase, Map<String, String> map, Map<String, Set<String>> map2, String... strArr) {
        this.f3805d = roomDatabase;
        this.f3809h = new b(strArr.length);
        this.f3802a = new HashMap<>();
        this.f3804c = map2;
        this.f3810i = new h(roomDatabase);
        int length = strArr.length;
        this.f3803b = new String[length];
        for (int i10 = 0; i10 < length; i10++) {
            String str = strArr[i10];
            Locale locale = Locale.US;
            String lowerCase = str.toLowerCase(locale);
            this.f3802a.put(lowerCase, Integer.valueOf(i10));
            String str2 = map.get(strArr[i10]);
            if (str2 != null) {
                this.f3803b[i10] = str2.toLowerCase(locale);
            } else {
                this.f3803b[i10] = lowerCase;
            }
        }
        for (Map.Entry next : map.entrySet()) {
            Locale locale2 = Locale.US;
            String lowerCase2 = ((String) next.getValue()).toLowerCase(locale2);
            if (this.f3802a.containsKey(lowerCase2)) {
                String lowerCase3 = ((String) next.getKey()).toLowerCase(locale2);
                HashMap<String, Integer> hashMap = this.f3802a;
                hashMap.put(lowerCase3, hashMap.get(lowerCase2));
            }
        }
    }

    @SuppressLint({"RestrictedApi"})
    public void a(c cVar) {
        C0038d putIfAbsent;
        boolean z10;
        String[] e10 = e(cVar.f3820a);
        int length = e10.length;
        int[] iArr = new int[length];
        int length2 = e10.length;
        int i10 = 0;
        while (i10 < length2) {
            Integer num = this.f3802a.get(e10[i10].toLowerCase(Locale.US));
            if (num != null) {
                iArr[i10] = num.intValue();
                i10++;
            } else {
                StringBuilder a10 = f.a.a("There is no table with name ");
                a10.append(e10[i10]);
                throw new IllegalArgumentException(a10.toString());
            }
        }
        C0038d dVar = new C0038d(cVar, iArr, e10);
        synchronized (this.f3811j) {
            putIfAbsent = this.f3811j.putIfAbsent(cVar, dVar);
        }
        if (putIfAbsent == null) {
            b bVar = this.f3809h;
            synchronized (bVar) {
                z10 = false;
                for (int i11 = 0; i11 < length; i11++) {
                    int i12 = iArr[i11];
                    long[] jArr = bVar.f3816a;
                    long j10 = jArr[i12];
                    jArr[i12] = 1 + j10;
                    if (j10 == 0) {
                        bVar.f3819d = true;
                        z10 = true;
                    }
                }
            }
            if (z10) {
                i();
            }
        }
    }

    public <T> LiveData<T> b(String[] strArr, boolean z10, Callable<T> callable) {
        h hVar = this.f3810i;
        String[] e10 = e(strArr);
        int length = e10.length;
        int i10 = 0;
        while (i10 < length) {
            String str = e10[i10];
            if (this.f3802a.containsKey(str.toLowerCase(Locale.US))) {
                i10++;
            } else {
                throw new IllegalArgumentException(a.d.a("There is no table with name ", str));
            }
        }
        Objects.requireNonNull(hVar);
        return new i((RoomDatabase) hVar.f1898r, hVar, z10, callable, e10);
    }

    public boolean c() {
        if (!this.f3805d.isOpen()) {
            return false;
        }
        if (!this.f3807f) {
            this.f3805d.getOpenHelper().c1();
        }
        if (this.f3807f) {
            return true;
        }
        Log.e("ROOM", "database is not initialized even though it is open");
        return false;
    }

    @SuppressLint({"RestrictedApi"})
    public void d(c cVar) {
        C0038d remove;
        boolean z10;
        synchronized (this.f3811j) {
            remove = this.f3811j.remove(cVar);
        }
        if (remove != null) {
            b bVar = this.f3809h;
            int[] iArr = remove.f3821a;
            synchronized (bVar) {
                z10 = false;
                for (int i10 : iArr) {
                    long[] jArr = bVar.f3816a;
                    long j10 = jArr[i10];
                    jArr[i10] = j10 - 1;
                    if (j10 == 1) {
                        bVar.f3819d = true;
                        z10 = true;
                    }
                }
            }
            if (z10) {
                i();
            }
        }
    }

    public final String[] e(String[] strArr) {
        HashSet hashSet = new HashSet();
        for (String str : strArr) {
            String lowerCase = str.toLowerCase(Locale.US);
            if (this.f3804c.containsKey(lowerCase)) {
                hashSet.addAll(this.f3804c.get(lowerCase));
            } else {
                hashSet.add(str);
            }
        }
        return (String[]) hashSet.toArray(new String[hashSet.size()]);
    }

    public final void f(q2.a aVar, int i10) {
        aVar.I("INSERT OR IGNORE INTO room_table_modification_log VALUES(" + i10 + ", 0)");
        String str = this.f3803b[i10];
        StringBuilder sb2 = new StringBuilder();
        for (String str2 : f3801n) {
            sb2.setLength(0);
            sb2.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
            sb2.append("`");
            sb2.append("room_table_modification_trigger_");
            sb2.append(str);
            sb2.append("_");
            sb2.append(str2);
            sb2.append("`");
            sb2.append(" AFTER ");
            sb2.append(str2);
            sb2.append(" ON `");
            sb2.append(str);
            sb2.append("` BEGIN UPDATE ");
            sb2.append("room_table_modification_log");
            sb2.append(" SET ");
            sb2.append("invalidated");
            sb2.append(" = 1");
            sb2.append(" WHERE ");
            sb2.append("table_id");
            sb2.append(" = ");
            sb2.append(i10);
            sb2.append(" AND ");
            sb2.append("invalidated");
            sb2.append(" = 0");
            sb2.append("; END");
            aVar.I(sb2.toString());
        }
    }

    public void g() {
        e eVar = this.f3812k;
        if (eVar != null) {
            if (eVar.f3833g.compareAndSet(false, true)) {
                eVar.f3829c.d(eVar.f3830d);
                try {
                    c cVar = eVar.f3831e;
                    if (cVar != null) {
                        cVar.W(eVar.f3832f, eVar.f3828b);
                    }
                } catch (RemoteException e10) {
                    Log.w("ROOM", "Cannot unregister multi-instance invalidation callback", e10);
                }
                eVar.f3827a.unbindService(eVar.f3834h);
            }
            this.f3812k = null;
        }
    }

    public final void h(q2.a aVar, int i10) {
        String str = this.f3803b[i10];
        StringBuilder sb2 = new StringBuilder();
        for (String append : f3801n) {
            sb2.setLength(0);
            sb2.append("DROP TRIGGER IF EXISTS ");
            sb2.append("`");
            sb2.append("room_table_modification_trigger_");
            sb2.append(str);
            sb2.append("_");
            sb2.append(append);
            sb2.append("`");
            aVar.I(sb2.toString());
        }
    }

    public void i() {
        if (this.f3805d.isOpen()) {
            j(this.f3805d.getOpenHelper().c1());
        }
    }

    public void j(q2.a aVar) {
        if (!aVar.n0()) {
            try {
                Lock closeLock = this.f3805d.getCloseLock();
                closeLock.lock();
                try {
                    synchronized (this.f3813l) {
                        int[] a10 = this.f3809h.a();
                        if (a10 != null) {
                            int length = a10.length;
                            if (aVar.F0()) {
                                aVar.S0();
                            } else {
                                aVar.t();
                            }
                            int i10 = 0;
                            while (i10 < length) {
                                try {
                                    int i11 = a10[i10];
                                    if (i11 == 1) {
                                        f(aVar, i10);
                                    } else if (i11 == 2) {
                                        h(aVar, i10);
                                    }
                                    i10++;
                                } catch (Throwable th2) {
                                    aVar.s();
                                    throw th2;
                                }
                            }
                            aVar.P0();
                            aVar.s();
                            closeLock.unlock();
                        }
                    }
                } finally {
                    closeLock.unlock();
                }
            } catch (SQLiteException | IllegalStateException e10) {
                Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", e10);
            }
        }
    }
}
