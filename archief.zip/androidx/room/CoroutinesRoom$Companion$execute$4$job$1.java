package androidx.room;

import ag.c;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import java.util.concurrent.Callable;
import kotlin.Result;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import rg.c0;
import rg.i;
import xf.g;

@a(c = "androidx.room.CoroutinesRoom$Companion$execute$4$job$1", f = "CoroutinesRoom.kt", l = {}, m = "invokeSuspend")
/* compiled from: CoroutinesRoom.kt */
public final class CoroutinesRoom$Companion$execute$4$job$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ Callable<Object> $callable;
    public final /* synthetic */ i<Object> $continuation;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CoroutinesRoom$Companion$execute$4$job$1(Callable<Object> callable, i<Object> iVar, c<? super CoroutinesRoom$Companion$execute$4$job$1> cVar) {
        super(2, cVar);
        this.$callable = callable;
        this.$continuation = iVar;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new CoroutinesRoom$Companion$execute$4$job$1(this.$callable, this.$continuation, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((CoroutinesRoom$Companion$execute$4$job$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            try {
                this.$continuation.resumeWith(Result.m97constructorimpl(this.$callable.call()));
            } catch (Throwable th2) {
                this.$continuation.resumeWith(Result.m97constructorimpl(x2.k(th2)));
            }
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
