package androidx.room;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.CancellationSignal;
import android.os.Looper;
import android.util.Log;
import androidx.appcompat.widget.h;
import androidx.arch.core.executor.ArchTaskExecutor;
import androidx.room.migration.Migration;
import java.io.File;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import m2.j;
import m2.m;
import q2.b;
import q2.e;

public abstract class RoomDatabase {
    private static final String DB_IMPL_SUFFIX = "_Impl";
    public static final int MAX_BIND_PARAMETER_CNT = 999;
    private boolean mAllowMainThreadQueries;
    private m2.a mAutoCloser;
    public Map<Class<? extends n2.a>, n2.a> mAutoMigrationSpecs = new HashMap();
    private final Map<String, Object> mBackingFieldMap = Collections.synchronizedMap(new HashMap());
    @Deprecated
    public List<b> mCallbacks;
    private final ReentrantReadWriteLock mCloseLock = new ReentrantReadWriteLock();
    @Deprecated
    public volatile q2.a mDatabase;
    private final d mInvalidationTracker = createInvalidationTracker();
    private q2.b mOpenHelper;
    private Executor mQueryExecutor;
    private final ThreadLocal<Integer> mSuspendingTransactionId = new ThreadLocal<>();
    private Executor mTransactionExecutor;
    private final Map<Class<?>, Object> mTypeConverters = new HashMap();
    public boolean mWriteAheadLoggingEnabled;

    public enum JournalMode {
        AUTOMATIC,
        TRUNCATE,
        WRITE_AHEAD_LOGGING;

        public JournalMode resolve(Context context) {
            if (this != AUTOMATIC) {
                return this;
            }
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            if (activityManager == null || activityManager.isLowRamDevice()) {
                return TRUNCATE;
            }
            return WRITE_AHEAD_LOGGING;
        }
    }

    public static class a<T extends RoomDatabase> {

        /* renamed from: a  reason: collision with root package name */
        public final Class<T> f3771a;

        /* renamed from: b  reason: collision with root package name */
        public final String f3772b;

        /* renamed from: c  reason: collision with root package name */
        public final Context f3773c;

        /* renamed from: d  reason: collision with root package name */
        public ArrayList<b> f3774d;

        /* renamed from: e  reason: collision with root package name */
        public Executor f3775e;

        /* renamed from: f  reason: collision with root package name */
        public Executor f3776f;

        /* renamed from: g  reason: collision with root package name */
        public b.c f3777g;

        /* renamed from: h  reason: collision with root package name */
        public boolean f3778h;

        /* renamed from: i  reason: collision with root package name */
        public JournalMode f3779i = JournalMode.AUTOMATIC;

        /* renamed from: j  reason: collision with root package name */
        public boolean f3780j = true;

        /* renamed from: k  reason: collision with root package name */
        public boolean f3781k;

        /* renamed from: l  reason: collision with root package name */
        public final c f3782l = new c();

        /* renamed from: m  reason: collision with root package name */
        public Set<Integer> f3783m;

        public a(Context context, Class<T> cls, String str) {
            this.f3773c = context;
            this.f3771a = cls;
            this.f3772b = str;
        }

        public a<T> a(Migration... migrationArr) {
            if (this.f3783m == null) {
                this.f3783m = new HashSet();
            }
            for (n2.b bVar : migrationArr) {
                this.f3783m.add(Integer.valueOf(bVar.startVersion));
                this.f3783m.add(Integer.valueOf(bVar.endVersion));
            }
            this.f3782l.a(migrationArr);
            return this;
        }

        @SuppressLint({"RestrictedApi"})
        public T b() {
            String str;
            Executor executor;
            if (this.f3773c == null) {
                throw new IllegalArgumentException("Cannot provide null context for the database.");
            } else if (this.f3771a != null) {
                Executor executor2 = this.f3775e;
                if (executor2 == null && this.f3776f == null) {
                    Executor iOThreadExecutor = ArchTaskExecutor.getIOThreadExecutor();
                    this.f3776f = iOThreadExecutor;
                    this.f3775e = iOThreadExecutor;
                } else if (executor2 != null && this.f3776f == null) {
                    this.f3776f = executor2;
                } else if (executor2 == null && (executor = this.f3776f) != null) {
                    this.f3775e = executor;
                }
                b.c cVar = this.f3777g;
                if (cVar == null) {
                    cVar = new r2.c();
                }
                Context context = this.f3773c;
                a aVar = new a(context, this.f3772b, cVar, this.f3782l, this.f3774d, this.f3778h, this.f3779i.resolve(context), this.f3775e, this.f3776f, (Intent) null, this.f3780j, this.f3781k, (Set) null, (String) null, (File) null, (Callable) null, (List) null, (List) null);
                Class<T> cls = this.f3771a;
                String name = cls.getPackage().getName();
                String canonicalName = cls.getCanonicalName();
                if (!name.isEmpty()) {
                    canonicalName = canonicalName.substring(name.length() + 1);
                }
                String str2 = canonicalName.replace('.', '_') + RoomDatabase.DB_IMPL_SUFFIX;
                try {
                    if (name.isEmpty()) {
                        str = str2;
                    } else {
                        str = name + "." + str2;
                    }
                    T t10 = (RoomDatabase) Class.forName(str, true, cls.getClassLoader()).newInstance();
                    t10.init(aVar);
                    return t10;
                } catch (ClassNotFoundException unused) {
                    StringBuilder a10 = f.a.a("cannot find implementation for ");
                    a10.append(cls.getCanonicalName());
                    a10.append(". ");
                    a10.append(str2);
                    a10.append(" does not exist");
                    throw new RuntimeException(a10.toString());
                } catch (IllegalAccessException unused2) {
                    StringBuilder a11 = f.a.a("Cannot access the constructor");
                    a11.append(cls.getCanonicalName());
                    throw new RuntimeException(a11.toString());
                } catch (InstantiationException unused3) {
                    StringBuilder a12 = f.a.a("Failed to create an instance of ");
                    a12.append(cls.getCanonicalName());
                    throw new RuntimeException(a12.toString());
                }
            } else {
                throw new IllegalArgumentException("Must provide an abstract class that extends RoomDatabase");
            }
        }
    }

    public static abstract class b {
        public void a(q2.a aVar) {
        }
    }

    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public HashMap<Integer, TreeMap<Integer, n2.b>> f3784a = new HashMap<>();

        public void a(n2.b... bVarArr) {
            for (n2.b bVar : bVarArr) {
                int i10 = bVar.startVersion;
                int i11 = bVar.endVersion;
                TreeMap treeMap = this.f3784a.get(Integer.valueOf(i10));
                if (treeMap == null) {
                    treeMap = new TreeMap();
                    this.f3784a.put(Integer.valueOf(i10), treeMap);
                }
                n2.b bVar2 = (n2.b) treeMap.get(Integer.valueOf(i11));
                if (bVar2 != null) {
                    Log.w("ROOM", "Overriding migration " + bVar2 + " with " + bVar);
                }
                treeMap.put(Integer.valueOf(i11), bVar);
            }
        }
    }

    public interface d {
        void a(String str, List<Object> list);
    }

    private void internalBeginTransaction() {
        assertNotMainThread();
        q2.a c12 = this.mOpenHelper.c1();
        this.mInvalidationTracker.j(c12);
        if (c12.F0()) {
            c12.S0();
        } else {
            c12.t();
        }
    }

    private void internalEndTransaction() {
        this.mOpenHelper.c1().s();
        if (!inTransaction()) {
            d dVar = this.mInvalidationTracker;
            if (dVar.f3806e.compareAndSet(false, true)) {
                dVar.f3805d.getQueryExecutor().execute(dVar.f3814m);
            }
        }
    }

    private static boolean isMainThread() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }

    private /* synthetic */ Object lambda$beginTransaction$0(q2.a aVar) {
        internalBeginTransaction();
        return null;
    }

    private /* synthetic */ Object lambda$endTransaction$1(q2.a aVar) {
        internalEndTransaction();
        return null;
    }

    private <T> T unwrapOpenHelper(Class<T> cls, q2.b bVar) {
        if (cls.isInstance(bVar)) {
            return bVar;
        }
        if (bVar instanceof m2.d) {
            return unwrapOpenHelper(cls, ((m2.d) bVar).getDelegate());
        }
        return null;
    }

    public void assertNotMainThread() {
        if (!this.mAllowMainThreadQueries && isMainThread()) {
            throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
        }
    }

    public void assertNotSuspendingTransaction() {
        if (!inTransaction() && this.mSuspendingTransactionId.get() != null) {
            throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
        }
    }

    @Deprecated
    public void beginTransaction() {
        assertNotMainThread();
        internalBeginTransaction();
    }

    public abstract void clearAllTables();

    public void close() {
        if (isOpen()) {
            ReentrantReadWriteLock.WriteLock writeLock = this.mCloseLock.writeLock();
            writeLock.lock();
            try {
                this.mInvalidationTracker.g();
                this.mOpenHelper.close();
            } finally {
                writeLock.unlock();
            }
        }
    }

    public e compileStatement(String str) {
        assertNotMainThread();
        assertNotSuspendingTransaction();
        return this.mOpenHelper.c1().V(str);
    }

    public abstract d createInvalidationTracker();

    public abstract q2.b createOpenHelper(a aVar);

    @Deprecated
    public void endTransaction() {
        internalEndTransaction();
    }

    public List<n2.b> getAutoMigrations(Map<Class<? extends n2.a>, n2.a> map) {
        return Collections.emptyList();
    }

    public Map<String, Object> getBackingFieldMap() {
        return this.mBackingFieldMap;
    }

    public Lock getCloseLock() {
        return this.mCloseLock.readLock();
    }

    public d getInvalidationTracker() {
        return this.mInvalidationTracker;
    }

    public q2.b getOpenHelper() {
        return this.mOpenHelper;
    }

    public Executor getQueryExecutor() {
        return this.mQueryExecutor;
    }

    public Set<Class<? extends n2.a>> getRequiredAutoMigrationSpecs() {
        return Collections.emptySet();
    }

    public Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
        return Collections.emptyMap();
    }

    public ThreadLocal<Integer> getSuspendingTransactionId() {
        return this.mSuspendingTransactionId;
    }

    public Executor getTransactionExecutor() {
        return this.mTransactionExecutor;
    }

    public <T> T getTypeConverter(Class<T> cls) {
        return this.mTypeConverters.get(cls);
    }

    public boolean inTransaction() {
        return this.mOpenHelper.c1().n0();
    }

    public void init(a aVar) {
        boolean z10;
        this.mOpenHelper = createOpenHelper(aVar);
        Set<Class<? extends n2.a>> requiredAutoMigrationSpecs = getRequiredAutoMigrationSpecs();
        BitSet bitSet = new BitSet();
        Iterator<Class<? extends n2.a>> it = requiredAutoMigrationSpecs.iterator();
        while (true) {
            int i10 = -1;
            if (it.hasNext()) {
                Class next = it.next();
                int size = aVar.f3791g.size() - 1;
                while (true) {
                    if (size < 0) {
                        break;
                    } else if (next.isAssignableFrom(aVar.f3791g.get(size).getClass())) {
                        bitSet.set(size);
                        i10 = size;
                        break;
                    } else {
                        size--;
                    }
                }
                if (i10 >= 0) {
                    this.mAutoMigrationSpecs.put(next, aVar.f3791g.get(i10));
                } else {
                    StringBuilder a10 = f.a.a("A required auto migration spec (");
                    a10.append(next.getCanonicalName());
                    a10.append(") is missing in the database configuration.");
                    throw new IllegalArgumentException(a10.toString());
                }
            } else {
                int size2 = aVar.f3791g.size() - 1;
                while (size2 >= 0) {
                    if (bitSet.get(size2)) {
                        size2--;
                    } else {
                        throw new IllegalArgumentException("Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder.");
                    }
                }
                Iterator<n2.b> it2 = getAutoMigrations(this.mAutoMigrationSpecs).iterator();
                while (true) {
                    z10 = false;
                    if (!it2.hasNext()) {
                        break;
                    }
                    n2.b next2 = it2.next();
                    if (!Collections.unmodifiableMap(aVar.f3788d.f3784a).containsKey(Integer.valueOf(next2.startVersion))) {
                        aVar.f3788d.a(next2);
                    }
                }
                j jVar = (j) unwrapOpenHelper(j.class, this.mOpenHelper);
                if (jVar != null) {
                    jVar.f14174v = aVar;
                }
                if (((m2.b) unwrapOpenHelper(m2.b.class, this.mOpenHelper)) == null) {
                    if (aVar.f3793i == JournalMode.WRITE_AHEAD_LOGGING) {
                        z10 = true;
                    }
                    this.mOpenHelper.setWriteAheadLoggingEnabled(z10);
                    this.mCallbacks = aVar.f3789e;
                    this.mQueryExecutor = aVar.f3794j;
                    this.mTransactionExecutor = new m(aVar.f3795k);
                    this.mAllowMainThreadQueries = aVar.f3792h;
                    this.mWriteAheadLoggingEnabled = z10;
                    Map<Class<?>, List<Class<?>>> requiredTypeConverters = getRequiredTypeConverters();
                    BitSet bitSet2 = new BitSet();
                    for (Map.Entry next3 : requiredTypeConverters.entrySet()) {
                        Class cls = (Class) next3.getKey();
                        Iterator it3 = ((List) next3.getValue()).iterator();
                        while (true) {
                            if (it3.hasNext()) {
                                Class cls2 = (Class) it3.next();
                                int size3 = aVar.f3790f.size() - 1;
                                while (true) {
                                    if (size3 < 0) {
                                        size3 = -1;
                                        break;
                                    } else if (cls2.isAssignableFrom(aVar.f3790f.get(size3).getClass())) {
                                        bitSet2.set(size3);
                                        break;
                                    } else {
                                        size3--;
                                    }
                                }
                                if (size3 >= 0) {
                                    this.mTypeConverters.put(cls2, aVar.f3790f.get(size3));
                                } else {
                                    throw new IllegalArgumentException("A required type converter (" + cls2 + ") for " + cls.getCanonicalName() + " is missing in the database configuration.");
                                }
                            }
                        }
                    }
                    int size4 = aVar.f3790f.size() - 1;
                    while (size4 >= 0) {
                        if (bitSet2.get(size4)) {
                            size4--;
                        } else {
                            throw new IllegalArgumentException("Unexpected type converter " + aVar.f3790f.get(size4) + ". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
                        }
                    }
                    return;
                }
                Objects.requireNonNull(this.mInvalidationTracker);
                throw null;
            }
        }
    }

    public void internalInitInvalidationTracker(q2.a aVar) {
        d dVar = this.mInvalidationTracker;
        synchronized (dVar) {
            if (dVar.f3807f) {
                Log.e("ROOM", "Invalidation tracker is initialized twice :/.");
                return;
            }
            aVar.I("PRAGMA temp_store = MEMORY;");
            aVar.I("PRAGMA recursive_triggers='ON';");
            aVar.I("CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
            dVar.j(aVar);
            dVar.f3808g = aVar.V("UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 ");
            dVar.f3807f = true;
        }
    }

    public boolean isOpen() {
        q2.a aVar = this.mDatabase;
        return aVar != null && aVar.isOpen();
    }

    public Cursor query(String str, Object[] objArr) {
        return this.mOpenHelper.c1().A(new h(str, objArr));
    }

    public void runInTransaction(Runnable runnable) {
        beginTransaction();
        try {
            runnable.run();
            setTransactionSuccessful();
        } finally {
            endTransaction();
        }
    }

    @Deprecated
    public void setTransactionSuccessful() {
        this.mOpenHelper.c1().P0();
    }

    public Cursor query(q2.d dVar) {
        return query(dVar, (CancellationSignal) null);
    }

    public Cursor query(q2.d dVar, CancellationSignal cancellationSignal) {
        assertNotMainThread();
        assertNotSuspendingTransaction();
        if (cancellationSignal != null) {
            return this.mOpenHelper.c1().O0(dVar, cancellationSignal);
        }
        return this.mOpenHelper.c1().A(dVar);
    }

    public <V> V runInTransaction(Callable<V> callable) {
        beginTransaction();
        try {
            V call = callable.call();
            setTransactionSuccessful();
            endTransaction();
            return call;
        } catch (RuntimeException e10) {
            throw e10;
        } catch (Exception e11) {
            throw e11;
        } catch (Throwable th2) {
            endTransaction();
            throw th2;
        }
    }
}
