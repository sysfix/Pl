package androidx.room;

import android.os.CancellationSignal;
import gg.l;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.Lambda;
import rg.z0;
import xf.g;

/* compiled from: CoroutinesRoom.kt */
public final class CoroutinesRoom$Companion$execute$4$1 extends Lambda implements l<Throwable, g> {
    public final /* synthetic */ CancellationSignal $cancellationSignal;
    public final /* synthetic */ z0 $job;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CoroutinesRoom$Companion$execute$4$1(CancellationSignal cancellationSignal, z0 z0Var) {
        super(1);
        this.$cancellationSignal = cancellationSignal;
        this.$job = z0Var;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((Throwable) obj);
        return g.f19030a;
    }

    public final void invoke(Throwable th2) {
        this.$cancellationSignal.cancel();
        this.$job.d((CancellationException) null);
    }
}
