package androidx.room;

import androidx.room.RoomDatabase;
import q2.a;

/* compiled from: QueryInterceptorDatabase */
public final class f implements a {

    /* renamed from: p  reason: collision with root package name */
    public final RoomDatabase.d f3835p;
}
