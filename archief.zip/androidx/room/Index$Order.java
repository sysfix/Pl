package androidx.room;

public enum Index$Order {
    ASC,
    DESC
}
