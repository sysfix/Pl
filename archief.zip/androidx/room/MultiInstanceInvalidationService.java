package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import androidx.room.c;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {

    /* renamed from: p  reason: collision with root package name */
    public int f3764p = 0;

    /* renamed from: q  reason: collision with root package name */
    public final HashMap<Integer, String> f3765q = new HashMap<>();

    /* renamed from: r  reason: collision with root package name */
    public final RemoteCallbackList<b> f3766r = new a();

    /* renamed from: s  reason: collision with root package name */
    public final c.a f3767s = new b();

    public class a extends RemoteCallbackList<b> {
        public a() {
        }

        public void onCallbackDied(IInterface iInterface, Object obj) {
            b bVar = (b) iInterface;
            MultiInstanceInvalidationService.this.f3765q.remove(Integer.valueOf(((Integer) obj).intValue()));
        }
    }

    public class b extends c.a {
        public b() {
        }

        public void W(b bVar, int i10) {
            synchronized (MultiInstanceInvalidationService.this.f3766r) {
                MultiInstanceInvalidationService.this.f3766r.unregister(bVar);
                MultiInstanceInvalidationService.this.f3765q.remove(Integer.valueOf(i10));
            }
        }

        public void d(int i10, String[] strArr) {
            synchronized (MultiInstanceInvalidationService.this.f3766r) {
                String str = MultiInstanceInvalidationService.this.f3765q.get(Integer.valueOf(i10));
                if (str == null) {
                    Log.w("ROOM", "Remote invalidation client ID not registered");
                    return;
                }
                int beginBroadcast = MultiInstanceInvalidationService.this.f3766r.beginBroadcast();
                for (int i11 = 0; i11 < beginBroadcast; i11++) {
                    try {
                        int intValue = ((Integer) MultiInstanceInvalidationService.this.f3766r.getBroadcastCookie(i11)).intValue();
                        String str2 = MultiInstanceInvalidationService.this.f3765q.get(Integer.valueOf(intValue));
                        if (i10 != intValue && str.equals(str2)) {
                            MultiInstanceInvalidationService.this.f3766r.getBroadcastItem(i11).w(strArr);
                        }
                    } catch (RemoteException e10) {
                        Log.w("ROOM", "Error invoking a remote callback", e10);
                    } catch (Throwable th2) {
                        MultiInstanceInvalidationService.this.f3766r.finishBroadcast();
                        throw th2;
                    }
                }
                MultiInstanceInvalidationService.this.f3766r.finishBroadcast();
            }
        }

        public int e(b bVar, String str) {
            if (str == null) {
                return 0;
            }
            synchronized (MultiInstanceInvalidationService.this.f3766r) {
                MultiInstanceInvalidationService multiInstanceInvalidationService = MultiInstanceInvalidationService.this;
                int i10 = multiInstanceInvalidationService.f3764p + 1;
                multiInstanceInvalidationService.f3764p = i10;
                if (multiInstanceInvalidationService.f3766r.register(bVar, Integer.valueOf(i10))) {
                    MultiInstanceInvalidationService.this.f3765q.put(Integer.valueOf(i10), str);
                    return i10;
                }
                MultiInstanceInvalidationService multiInstanceInvalidationService2 = MultiInstanceInvalidationService.this;
                multiInstanceInvalidationService2.f3764p--;
                return 0;
            }
        }
    }

    public IBinder onBind(Intent intent) {
        return this.f3767s;
    }
}
