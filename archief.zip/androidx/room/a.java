package androidx.room;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import androidx.room.RoomDatabase;
import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import q2.b;

/* compiled from: DatabaseConfiguration */
public class a {

    /* renamed from: a  reason: collision with root package name */
    public final b.c f3785a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f3786b;

    /* renamed from: c  reason: collision with root package name */
    public final String f3787c;

    /* renamed from: d  reason: collision with root package name */
    public final RoomDatabase.c f3788d;

    /* renamed from: e  reason: collision with root package name */
    public final List<RoomDatabase.b> f3789e;

    /* renamed from: f  reason: collision with root package name */
    public final List<Object> f3790f;

    /* renamed from: g  reason: collision with root package name */
    public final List<n2.a> f3791g;

    /* renamed from: h  reason: collision with root package name */
    public final boolean f3792h;

    /* renamed from: i  reason: collision with root package name */
    public final RoomDatabase.JournalMode f3793i;

    /* renamed from: j  reason: collision with root package name */
    public final Executor f3794j;

    /* renamed from: k  reason: collision with root package name */
    public final Executor f3795k;

    /* renamed from: l  reason: collision with root package name */
    public final boolean f3796l = false;

    /* renamed from: m  reason: collision with root package name */
    public final boolean f3797m;

    /* renamed from: n  reason: collision with root package name */
    public final boolean f3798n;

    @SuppressLint({"LambdaLast"})
    public a(Context context, String str, b.c cVar, RoomDatabase.c cVar2, List list, boolean z10, RoomDatabase.JournalMode journalMode, Executor executor, Executor executor2, Intent intent, boolean z11, boolean z12, Set set, String str2, File file, Callable callable, List list2, List list3) {
        this.f3785a = cVar;
        this.f3786b = context;
        this.f3787c = str;
        this.f3788d = cVar2;
        this.f3789e = list;
        this.f3792h = z10;
        this.f3793i = journalMode;
        this.f3794j = executor;
        this.f3795k = executor2;
        this.f3797m = z11;
        this.f3798n = z12;
        this.f3790f = Collections.emptyList();
        this.f3791g = Collections.emptyList();
    }

    public boolean a(int i10, int i11) {
        if ((i10 > i11) && this.f3798n) {
            return false;
        }
        if (this.f3797m) {
            return true;
        }
        return false;
    }
}
