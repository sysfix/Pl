package androidx.room;

import ag.c;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import java.util.concurrent.Callable;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import rg.c0;
import xf.g;

@a(c = "androidx.room.CoroutinesRoom$Companion$execute$2", f = "CoroutinesRoom.kt", l = {}, m = "invokeSuspend")
/* compiled from: CoroutinesRoom.kt */
public final class CoroutinesRoom$Companion$execute$2 extends SuspendLambda implements p<c0, c<Object>, Object> {
    public final /* synthetic */ Callable<Object> $callable;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CoroutinesRoom$Companion$execute$2(Callable<Object> callable, c<? super CoroutinesRoom$Companion$execute$2> cVar) {
        super(2, cVar);
        this.$callable = callable;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new CoroutinesRoom$Companion$execute$2(this.$callable, cVar);
    }

    public final Object invoke(c0 c0Var, c<Object> cVar) {
        return ((CoroutinesRoom$Companion$execute$2) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        if (this.label == 0) {
            x2.s(obj);
            return this.$callable.call();
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
