package androidx.room;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* compiled from: IMultiInstanceInvalidationCallback */
public interface b extends IInterface {

    /* compiled from: IMultiInstanceInvalidationCallback */
    public static abstract class a extends Binder implements b {

        /* renamed from: c  reason: collision with root package name */
        public static final /* synthetic */ int f3799c = 0;

        /* renamed from: androidx.room.b$a$a  reason: collision with other inner class name */
        /* compiled from: IMultiInstanceInvalidationCallback */
        public static class C0037a implements b {

            /* renamed from: c  reason: collision with root package name */
            public IBinder f3800c;

            public C0037a(IBinder iBinder) {
                this.f3800c = iBinder;
            }

            public IBinder asBinder() {
                return this.f3800c;
            }

            public void w(String[] strArr) {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
                    obtain.writeStringArray(strArr);
                    if (!this.f3800c.transact(1, obtain, (Parcel) null, 1)) {
                        int i10 = a.f3799c;
                    }
                } finally {
                    obtain.recycle();
                }
            }
        }

        public static b d(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationCallback");
            if (queryLocalInterface == null || !(queryLocalInterface instanceof b)) {
                return new C0037a(iBinder);
            }
            return (b) queryLocalInterface;
        }
    }

    void w(String[] strArr);
}
