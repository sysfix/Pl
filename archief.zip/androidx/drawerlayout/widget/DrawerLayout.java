package androidx.drawerlayout.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import androidx.customview.view.AbsSavedState;
import b1.a;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;
import o1.e0;
import o1.k0;
import o1.o0;
import p1.c;
import p1.g;

public class DrawerLayout extends ViewGroup {
    public static final int[] C = {16842931};
    public static final boolean D = true;
    public static final boolean E = true;
    public static boolean F;
    public Rect A;
    public Matrix B;

    /* renamed from: p  reason: collision with root package name */
    public float f2904p;

    /* renamed from: q  reason: collision with root package name */
    public float f2905q;

    /* renamed from: r  reason: collision with root package name */
    public boolean f2906r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f2907s;

    /* renamed from: t  reason: collision with root package name */
    public int f2908t;

    /* renamed from: u  reason: collision with root package name */
    public int f2909u;

    /* renamed from: v  reason: collision with root package name */
    public int f2910v;

    /* renamed from: w  reason: collision with root package name */
    public int f2911w;

    /* renamed from: x  reason: collision with root package name */
    public a f2912x;

    /* renamed from: y  reason: collision with root package name */
    public List<a> f2913y;

    /* renamed from: z  reason: collision with root package name */
    public Drawable f2914z;

    public interface a {
        void a(View view, float f10);
    }

    static {
        boolean z10 = true;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 29) {
            z10 = false;
        }
        F = z10;
    }

    public boolean a(View view, int i10) {
        return (g(view) & i10) == i10;
    }

    public void addFocusables(ArrayList<View> arrayList, int i10, int i11) {
        if (getDescendantFocusability() != 393216) {
            int childCount = getChildCount();
            int i12 = 0;
            boolean z10 = false;
            while (i12 < childCount) {
                View childAt = getChildAt(i12);
                if (j(childAt)) {
                    if (i(childAt)) {
                        childAt.addFocusables(arrayList, i10, i11);
                        z10 = true;
                    }
                    i12++;
                } else {
                    throw null;
                }
            }
            if (!z10) {
                throw null;
            }
            throw null;
        }
    }

    public void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i10, layoutParams);
        if (d() != null || j(view)) {
            WeakHashMap<View, k0> weakHashMap = e0.f14849a;
            e0.d.s(view, 4);
        } else {
            WeakHashMap<View, k0> weakHashMap2 = e0.f14849a;
            e0.d.s(view, 1);
        }
        if (!D) {
            e0.p(view, (o1.a) null);
        }
    }

    public void b(boolean z10) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            b bVar = (b) childAt.getLayoutParams();
            if (j(childAt)) {
                if (z10) {
                    Objects.requireNonNull(bVar);
                } else {
                    childAt.getWidth();
                    if (a(childAt, 3)) {
                        childAt.getTop();
                        throw null;
                    }
                    getWidth();
                    childAt.getTop();
                    throw null;
                }
            }
        }
        throw null;
    }

    public View c(int i10) {
        WeakHashMap<View, k0> weakHashMap = e0.f14849a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, e0.e.d(this)) & 7;
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if ((g(childAt) & 7) == absoluteGravity) {
                return childAt;
            }
        }
        return null;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof b) && super.checkLayoutParams(layoutParams);
    }

    public void computeScroll() {
        int childCount = getChildCount();
        float f10 = 0.0f;
        for (int i10 = 0; i10 < childCount; i10++) {
            f10 = Math.max(f10, ((b) getChildAt(i10).getLayoutParams()).f2921b);
        }
        this.f2905q = f10;
        throw null;
    }

    public View d() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if ((((b) childAt.getLayoutParams()).f2922c & 1) == 1) {
                return childAt;
            }
        }
        return null;
    }

    public boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        boolean z10;
        if ((motionEvent.getSource() & 2) == 0 || motionEvent.getAction() == 10 || this.f2905q <= 0.0f) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int childCount = getChildCount();
        if (childCount == 0) {
            return false;
        }
        float x10 = motionEvent.getX();
        float y10 = motionEvent.getY();
        for (int i10 = childCount - 1; i10 >= 0; i10--) {
            View childAt = getChildAt(i10);
            if (this.A == null) {
                this.A = new Rect();
            }
            childAt.getHitRect(this.A);
            if (this.A.contains((int) x10, (int) y10) && !h(childAt)) {
                if (!childAt.getMatrix().isIdentity()) {
                    MotionEvent obtain = MotionEvent.obtain(motionEvent);
                    obtain.offsetLocation((float) (getScrollX() - childAt.getLeft()), (float) (getScrollY() - childAt.getTop()));
                    Matrix matrix = childAt.getMatrix();
                    if (!matrix.isIdentity()) {
                        if (this.B == null) {
                            this.B = new Matrix();
                        }
                        matrix.invert(this.B);
                        obtain.transform(this.B);
                    }
                    z10 = childAt.dispatchGenericMotionEvent(obtain);
                    obtain.recycle();
                } else {
                    float scrollX = (float) (getScrollX() - childAt.getLeft());
                    float scrollY = (float) (getScrollY() - childAt.getTop());
                    motionEvent.offsetLocation(scrollX, scrollY);
                    z10 = childAt.dispatchGenericMotionEvent(motionEvent);
                    motionEvent.offsetLocation(-scrollX, -scrollY);
                }
                if (z10) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean drawChild(Canvas canvas, View view, long j10) {
        int height = getHeight();
        boolean h10 = h(view);
        int width = getWidth();
        int save = canvas.save();
        if (h10) {
            int childCount = getChildCount();
            int i10 = 0;
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                if (childAt != view && childAt.getVisibility() == 0) {
                    Drawable background = childAt.getBackground();
                    if ((background != null && background.getOpacity() == -1) && j(childAt) && childAt.getHeight() >= height) {
                        if (a(childAt, 3)) {
                            int right = childAt.getRight();
                            if (right > i10) {
                                i10 = right;
                            }
                        } else {
                            int left = childAt.getLeft();
                            if (left < width) {
                                width = left;
                            }
                        }
                    }
                }
            }
            canvas.clipRect(i10, 0, width, getHeight());
        }
        boolean drawChild = super.drawChild(canvas, view, j10);
        canvas.restoreToCount(save);
        if (this.f2905q <= 0.0f || !h10) {
            return drawChild;
        }
        throw null;
    }

    public View e() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (j(childAt)) {
                if (j(childAt)) {
                    if (((b) childAt.getLayoutParams()).f2921b > 0.0f) {
                        return childAt;
                    }
                } else {
                    throw new IllegalArgumentException("View " + childAt + " is not a drawer");
                }
            }
        }
        return null;
    }

    public int f(View view) {
        if (j(view)) {
            int i10 = ((b) view.getLayoutParams()).f2920a;
            WeakHashMap<View, k0> weakHashMap = e0.f14849a;
            int d10 = e0.e.d(this);
            if (i10 == 3) {
                int i11 = this.f2908t;
                if (i11 != 3) {
                    return i11;
                }
                int i12 = d10 == 0 ? this.f2910v : this.f2911w;
                if (i12 != 3) {
                    return i12;
                }
            } else if (i10 == 5) {
                int i13 = this.f2909u;
                if (i13 != 3) {
                    return i13;
                }
                int i14 = d10 == 0 ? this.f2911w : this.f2910v;
                if (i14 != 3) {
                    return i14;
                }
            } else if (i10 == 8388611) {
                int i15 = this.f2910v;
                if (i15 != 3) {
                    return i15;
                }
                int i16 = d10 == 0 ? this.f2908t : this.f2909u;
                if (i16 != 3) {
                    return i16;
                }
            } else if (i10 == 8388613) {
                int i17 = this.f2911w;
                if (i17 != 3) {
                    return i17;
                }
                int i18 = d10 == 0 ? this.f2909u : this.f2908t;
                if (i18 != 3) {
                    return i18;
                }
            }
            return 0;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    public int g(View view) {
        int i10 = ((b) view.getLayoutParams()).f2920a;
        WeakHashMap<View, k0> weakHashMap = e0.f14849a;
        return Gravity.getAbsoluteGravity(i10, e0.e.d(this));
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new b(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof b) {
            return new b((b) layoutParams);
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            return new b((ViewGroup.MarginLayoutParams) layoutParams);
        }
        return new b(layoutParams);
    }

    public float getDrawerElevation() {
        if (E) {
            return this.f2904p;
        }
        return 0.0f;
    }

    public Drawable getStatusBarBackgroundDrawable() {
        return this.f2914z;
    }

    public boolean h(View view) {
        return ((b) view.getLayoutParams()).f2920a == 0;
    }

    public boolean i(View view) {
        if (j(view)) {
            return (((b) view.getLayoutParams()).f2922c & 1) == 1;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    public boolean j(View view) {
        int i10 = ((b) view.getLayoutParams()).f2920a;
        WeakHashMap<View, k0> weakHashMap = e0.f14849a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, e0.e.d(view));
        return ((absoluteGravity & 3) == 0 && (absoluteGravity & 5) == 0) ? false : true;
    }

    public void k(View view) {
        if (j(view)) {
            b bVar = (b) view.getLayoutParams();
            if (this.f2907s) {
                bVar.f2921b = 1.0f;
                bVar.f2922c = 1;
                o(view, true);
                n(view);
                invalidate();
                return;
            }
            bVar.f2922c |= 2;
            if (a(view, 3)) {
                view.getTop();
                throw null;
            }
            getWidth();
            view.getWidth();
            view.getTop();
            throw null;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    public void l(int i10, int i11) {
        View c10;
        WeakHashMap<View, k0> weakHashMap = e0.f14849a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i11, e0.e.d(this));
        if (i11 == 3) {
            this.f2908t = i10;
        } else if (i11 == 5) {
            this.f2909u = i10;
        } else if (i11 == 8388611) {
            this.f2910v = i10;
        } else if (i11 == 8388613) {
            this.f2911w = i10;
        }
        if (i10 != 0) {
            throw null;
        } else if (i10 == 1) {
            View c11 = c(absoluteGravity);
            if (c11 == null) {
                return;
            }
            if (j(c11)) {
                b bVar = (b) c11.getLayoutParams();
                if (this.f2907s) {
                    bVar.f2921b = 0.0f;
                    bVar.f2922c = 0;
                    invalidate();
                    return;
                }
                bVar.f2922c |= 4;
                if (a(c11, 3)) {
                    c11.getWidth();
                    c11.getTop();
                    throw null;
                }
                getWidth();
                c11.getTop();
                throw null;
            }
            throw new IllegalArgumentException("View " + c11 + " is not a sliding drawer");
        } else if (i10 == 2 && (c10 = c(absoluteGravity)) != null) {
            k(c10);
        }
    }

    public void m(View view, float f10) {
        b bVar = (b) view.getLayoutParams();
        if (f10 != bVar.f2921b) {
            bVar.f2921b = f10;
            List<a> list = this.f2913y;
            if (list != null) {
                int size = list.size();
                while (true) {
                    size--;
                    if (size >= 0) {
                        this.f2913y.get(size).a(view, f10);
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public final void n(View view) {
        c.a aVar = c.a.f15353j;
        e0.m(aVar.a(), view);
        e0.j(view, 0);
        if (i(view) && f(view) != 2) {
            e0.n(view, aVar, (CharSequence) null, (g) null);
        }
    }

    public final void o(View view, boolean z10) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if ((z10 || j(childAt)) && (!z10 || childAt != view)) {
                WeakHashMap<View, k0> weakHashMap = e0.f14849a;
                e0.d.s(childAt, 4);
            } else {
                WeakHashMap<View, k0> weakHashMap2 = e0.f14849a;
                e0.d.s(childAt, 1);
            }
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f2907s = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f2907s = true;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        motionEvent.getActionMasked();
        throw null;
    }

    public boolean onKeyDown(int i10, KeyEvent keyEvent) {
        if (i10 == 4) {
            if (e() != null) {
                keyEvent.startTracking();
                return true;
            }
        }
        return super.onKeyDown(i10, keyEvent);
    }

    public boolean onKeyUp(int i10, KeyEvent keyEvent) {
        if (i10 != 4) {
            return super.onKeyUp(i10, keyEvent);
        }
        View e10 = e();
        if (e10 != null && f(e10) == 0) {
            b(false);
            throw null;
        } else if (e10 != null) {
            return true;
        } else {
            return false;
        }
    }

    public void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        WindowInsets rootWindowInsets;
        float f10;
        int i14;
        boolean z11 = true;
        this.f2906r = true;
        int i15 = i12 - i10;
        int childCount = getChildCount();
        int i16 = 0;
        while (i16 < childCount) {
            View childAt = getChildAt(i16);
            if (childAt.getVisibility() != 8) {
                b bVar = (b) childAt.getLayoutParams();
                if (h(childAt)) {
                    int i17 = bVar.leftMargin;
                    childAt.layout(i17, bVar.topMargin, childAt.getMeasuredWidth() + i17, childAt.getMeasuredHeight() + bVar.topMargin);
                } else {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (a(childAt, 3)) {
                        float f11 = (float) measuredWidth;
                        i14 = (-measuredWidth) + ((int) (bVar.f2921b * f11));
                        f10 = ((float) (measuredWidth + i14)) / f11;
                    } else {
                        float f12 = (float) measuredWidth;
                        int i18 = i15 - ((int) (bVar.f2921b * f12));
                        f10 = ((float) (i15 - i18)) / f12;
                        i14 = i18;
                    }
                    boolean z12 = f10 != bVar.f2921b ? z11 : false;
                    int i19 = bVar.f2920a & 112;
                    if (i19 == 16) {
                        int i20 = i13 - i11;
                        int i21 = (i20 - measuredHeight) / 2;
                        int i22 = bVar.topMargin;
                        if (i21 < i22) {
                            i21 = i22;
                        } else {
                            int i23 = i21 + measuredHeight;
                            int i24 = i20 - bVar.bottomMargin;
                            if (i23 > i24) {
                                i21 = i24 - measuredHeight;
                            }
                        }
                        childAt.layout(i14, i21, measuredWidth + i14, measuredHeight + i21);
                    } else if (i19 != 80) {
                        int i25 = bVar.topMargin;
                        childAt.layout(i14, i25, measuredWidth + i14, measuredHeight + i25);
                    } else {
                        int i26 = i13 - i11;
                        childAt.layout(i14, (i26 - bVar.bottomMargin) - childAt.getMeasuredHeight(), measuredWidth + i14, i26 - bVar.bottomMargin);
                    }
                    if (z12) {
                        m(childAt, f10);
                    }
                    int i27 = bVar.f2921b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i27) {
                        childAt.setVisibility(i27);
                    }
                }
            }
            i16++;
            z11 = true;
        }
        if (!F || (rootWindowInsets = getRootWindowInsets()) == null) {
            this.f2906r = false;
            this.f2907s = false;
            return;
        }
        o0.i(rootWindowInsets, (View) null).f14895a.h();
        throw null;
    }

    @SuppressLint({"WrongConstant"})
    public void onMeasure(int i10, int i11) {
        String str;
        int mode = View.MeasureSpec.getMode(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i10);
        int size2 = View.MeasureSpec.getSize(i11);
        if (!(mode == 1073741824 && mode2 == 1073741824)) {
            if (isInEditMode()) {
                if (mode == 0) {
                    size = 300;
                }
                if (mode2 == 0) {
                    size2 = 300;
                }
            } else {
                throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
            }
        }
        setMeasuredDimension(size, size2);
        WeakHashMap<View, k0> weakHashMap = e0.f14849a;
        e0.e.d(this);
        int childCount = getChildCount();
        boolean z10 = false;
        boolean z11 = false;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                b bVar = (b) childAt.getLayoutParams();
                if (h(childAt)) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec((size - bVar.leftMargin) - bVar.rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec((size2 - bVar.topMargin) - bVar.bottomMargin, 1073741824));
                } else if (j(childAt)) {
                    if (E) {
                        float i13 = e0.i.i(childAt);
                        float f10 = this.f2904p;
                        if (i13 != f10) {
                            e0.i.s(childAt, f10);
                        }
                    }
                    int g10 = g(childAt) & 7;
                    boolean z12 = g10 == 3;
                    if ((!z12 || !z10) && (z12 || !z11)) {
                        if (z12) {
                            z10 = true;
                        } else {
                            z11 = true;
                        }
                        childAt.measure(ViewGroup.getChildMeasureSpec(i10, bVar.leftMargin + 0 + bVar.rightMargin, bVar.width), ViewGroup.getChildMeasureSpec(i11, bVar.topMargin + bVar.bottomMargin, bVar.height));
                    } else {
                        StringBuilder a10 = f.a.a("Child drawer has absolute gravity ");
                        if ((g10 & 3) != 3) {
                            str = (g10 & 5) == 5 ? "RIGHT" : Integer.toHexString(g10);
                        } else {
                            str = "LEFT";
                        }
                        a10.append(str);
                        a10.append(" but this ");
                        a10.append("DrawerLayout");
                        a10.append(" already has a drawer view along that edge");
                        throw new IllegalStateException(a10.toString());
                    }
                } else {
                    throw new IllegalStateException("Child " + childAt + " at index " + i12 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                }
            }
            int i14 = i10;
            int i15 = i11;
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        View c10;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.f2670p);
        int i10 = savedState.f2915r;
        if (!(i10 == 0 || (c10 = c(i10)) == null)) {
            k(c10);
        }
        int i11 = savedState.f2916s;
        if (i11 != 3) {
            l(i11, 3);
        }
        int i12 = savedState.f2917t;
        if (i12 != 3) {
            l(i12, 5);
        }
        int i13 = savedState.f2918u;
        if (i13 != 3) {
            l(i13, 8388611);
        }
        int i14 = savedState.f2919v;
        if (i14 != 3) {
            l(i14, 8388613);
        }
    }

    public void onRtlPropertiesChanged(int i10) {
        if (!E) {
            WeakHashMap<View, k0> weakHashMap = e0.f14849a;
            e0.e.d(this);
            e0.e.d(this);
        }
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        int childCount = getChildCount();
        int i10 = 0;
        while (true) {
            if (i10 >= childCount) {
                break;
            }
            b bVar = (b) getChildAt(i10).getLayoutParams();
            int i11 = bVar.f2922c;
            boolean z10 = true;
            boolean z11 = i11 == 1;
            if (i11 != 2) {
                z10 = false;
            }
            if (z11 || z10) {
                savedState.f2915r = bVar.f2920a;
            } else {
                i10++;
            }
        }
        savedState.f2916s = this.f2908t;
        savedState.f2917t = this.f2909u;
        savedState.f2918u = this.f2910v;
        savedState.f2919v = this.f2911w;
        return savedState;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        throw null;
    }

    public void requestDisallowInterceptTouchEvent(boolean z10) {
        super.requestDisallowInterceptTouchEvent(z10);
        if (z10) {
            b(true);
            throw null;
        }
    }

    public void requestLayout() {
        if (!this.f2906r) {
            super.requestLayout();
        }
    }

    public void setDrawerElevation(float f10) {
        this.f2904p = f10;
        for (int i10 = 0; i10 < getChildCount(); i10++) {
            View childAt = getChildAt(i10);
            if (j(childAt)) {
                float f11 = this.f2904p;
                WeakHashMap<View, k0> weakHashMap = e0.f14849a;
                e0.i.s(childAt, f11);
            }
        }
    }

    @Deprecated
    public void setDrawerListener(a aVar) {
        List<a> list;
        a aVar2 = this.f2912x;
        if (!(aVar2 == null || aVar2 == null || (list = this.f2913y) == null)) {
            list.remove(aVar2);
        }
        if (aVar != null) {
            if (this.f2913y == null) {
                this.f2913y = new ArrayList();
            }
            this.f2913y.add(aVar);
        }
        this.f2912x = aVar;
    }

    public void setDrawerLockMode(int i10) {
        l(i10, 3);
        l(i10, 5);
    }

    public void setScrimColor(int i10) {
        invalidate();
    }

    public void setStatusBarBackground(Drawable drawable) {
        this.f2914z = drawable;
        invalidate();
    }

    public void setStatusBarBackgroundColor(int i10) {
        this.f2914z = new ColorDrawable(i10);
        invalidate();
    }

    public void setStatusBarBackground(int i10) {
        Drawable drawable;
        if (i10 != 0) {
            Context context = getContext();
            Object obj = b1.a.f4191a;
            drawable = a.c.b(context, i10);
        } else {
            drawable = null;
        }
        this.f2914z = drawable;
        invalidate();
    }

    public static class b extends ViewGroup.MarginLayoutParams {

        /* renamed from: a  reason: collision with root package name */
        public int f2920a = 0;

        /* renamed from: b  reason: collision with root package name */
        public float f2921b;

        /* renamed from: c  reason: collision with root package name */
        public int f2922c;

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, DrawerLayout.C);
            this.f2920a = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public b(int i10, int i11) {
            super(i10, i11);
        }

        public b(b bVar) {
            super(bVar);
            this.f2920a = bVar.f2920a;
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new b(getContext(), attributeSet);
    }

    public static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new a();

        /* renamed from: r  reason: collision with root package name */
        public int f2915r = 0;

        /* renamed from: s  reason: collision with root package name */
        public int f2916s;

        /* renamed from: t  reason: collision with root package name */
        public int f2917t;

        /* renamed from: u  reason: collision with root package name */
        public int f2918u;

        /* renamed from: v  reason: collision with root package name */
        public int f2919v;

        public class a implements Parcelable.ClassLoaderCreator<SavedState> {
            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            public Object[] newArray(int i10) {
                return new SavedState[i10];
            }

            public Object createFromParcel(Parcel parcel) {
                return new SavedState(parcel, (ClassLoader) null);
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f2915r = parcel.readInt();
            this.f2916s = parcel.readInt();
            this.f2917t = parcel.readInt();
            this.f2918u = parcel.readInt();
            this.f2919v = parcel.readInt();
        }

        public void writeToParcel(Parcel parcel, int i10) {
            parcel.writeParcelable(this.f2670p, i10);
            parcel.writeInt(this.f2915r);
            parcel.writeInt(this.f2916s);
            parcel.writeInt(this.f2917t);
            parcel.writeInt(this.f2918u);
            parcel.writeInt(this.f2919v);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }
    }
}
