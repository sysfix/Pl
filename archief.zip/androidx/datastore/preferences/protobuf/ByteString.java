package androidx.datastore.preferences.protobuf;

import androidx.datastore.preferences.protobuf.CodedOutputStream;
import com.google.protobuf.GeneratedMessageLite;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.logging.Logger;
import okhttp3.HttpUrl;
import org.slf4j.Marker;

public abstract class ByteString implements Iterable<Byte>, Serializable {
    public static final int CONCATENATE_BY_COPY_SIZE = 128;
    public static final ByteString EMPTY = new LiteralByteString(o.f2867b);
    public static final int MAX_READ_FROM_CHUNK_SIZE = 8192;
    public static final int MIN_READ_FROM_CHUNK_SIZE = 256;

    /* renamed from: p  reason: collision with root package name */
    public static final e f2704p = (y1.a.a() ? new i((a) null) : new d((a) null));

    /* renamed from: q  reason: collision with root package name */
    public static final Comparator<ByteString> f2705q = new b();
    private int hash = 0;

    public static final class BoundedByteString extends LiteralByteString {
        private static final long serialVersionUID = 1;
        private final int bytesLength;
        private final int bytesOffset;

        public BoundedByteString(byte[] bArr, int i10, int i11) {
            super(bArr);
            ByteString.checkRange(i10, i10 + i11, bArr.length);
            this.bytesOffset = i10;
            this.bytesLength = i11;
        }

        private void readObject(ObjectInputStream objectInputStream) {
            throw new InvalidObjectException("BoundedByteStream instances are not to be serialized directly");
        }

        public byte byteAt(int i10) {
            ByteString.checkIndex(i10, size());
            return this.bytes[this.bytesOffset + i10];
        }

        public void copyToInternal(byte[] bArr, int i10, int i11, int i12) {
            System.arraycopy(this.bytes, getOffsetIntoBytes() + i10, bArr, i11, i12);
        }

        public int getOffsetIntoBytes() {
            return this.bytesOffset;
        }

        public byte internalByteAt(int i10) {
            return this.bytes[this.bytesOffset + i10];
        }

        public int size() {
            return this.bytesLength;
        }

        public Object writeReplace() {
            return ByteString.wrap(toByteArray());
        }
    }

    public static abstract class LeafByteString extends ByteString {
        public abstract boolean equalsRange(ByteString byteString, int i10, int i11);

        public final int getTreeDepth() {
            return 0;
        }

        public final boolean isBalanced() {
            return true;
        }

        public /* bridge */ /* synthetic */ Iterator iterator() {
            return ByteString.super.iterator();
        }

        public void writeToReverse(y1.d dVar) {
            writeTo(dVar);
        }
    }

    public static class LiteralByteString extends LeafByteString {
        private static final long serialVersionUID = 1;
        public final byte[] bytes;

        public LiteralByteString(byte[] bArr) {
            Objects.requireNonNull(bArr);
            this.bytes = bArr;
        }

        public final ByteBuffer asReadOnlyByteBuffer() {
            return ByteBuffer.wrap(this.bytes, getOffsetIntoBytes(), size()).asReadOnlyBuffer();
        }

        public final List<ByteBuffer> asReadOnlyByteBufferList() {
            return Collections.singletonList(asReadOnlyByteBuffer());
        }

        public byte byteAt(int i10) {
            return this.bytes[i10];
        }

        public final void copyTo(ByteBuffer byteBuffer) {
            byteBuffer.put(this.bytes, getOffsetIntoBytes(), size());
        }

        public void copyToInternal(byte[] bArr, int i10, int i11, int i12) {
            System.arraycopy(this.bytes, i10, bArr, i11, i12);
        }

        public final boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof ByteString) || size() != ((ByteString) obj).size()) {
                return false;
            }
            if (size() == 0) {
                return true;
            }
            if (!(obj instanceof LiteralByteString)) {
                return obj.equals(this);
            }
            LiteralByteString literalByteString = (LiteralByteString) obj;
            int peekCachedHashCode = peekCachedHashCode();
            int peekCachedHashCode2 = literalByteString.peekCachedHashCode();
            if (peekCachedHashCode == 0 || peekCachedHashCode2 == 0 || peekCachedHashCode == peekCachedHashCode2) {
                return equalsRange(literalByteString, 0, size());
            }
            return false;
        }

        public final boolean equalsRange(ByteString byteString, int i10, int i11) {
            if (i11 <= byteString.size()) {
                int i12 = i10 + i11;
                if (i12 > byteString.size()) {
                    StringBuilder a10 = c.c.a("Ran off end of other: ", i10, ", ", i11, ", ");
                    a10.append(byteString.size());
                    throw new IllegalArgumentException(a10.toString());
                } else if (!(byteString instanceof LiteralByteString)) {
                    return byteString.substring(i10, i12).equals(substring(0, i11));
                } else {
                    LiteralByteString literalByteString = (LiteralByteString) byteString;
                    byte[] bArr = this.bytes;
                    byte[] bArr2 = literalByteString.bytes;
                    int offsetIntoBytes = getOffsetIntoBytes() + i11;
                    int offsetIntoBytes2 = getOffsetIntoBytes();
                    int offsetIntoBytes3 = literalByteString.getOffsetIntoBytes() + i10;
                    while (offsetIntoBytes2 < offsetIntoBytes) {
                        if (bArr[offsetIntoBytes2] != bArr2[offsetIntoBytes3]) {
                            return false;
                        }
                        offsetIntoBytes2++;
                        offsetIntoBytes3++;
                    }
                    return true;
                }
            } else {
                throw new IllegalArgumentException("Length too large: " + i11 + size());
            }
        }

        public int getOffsetIntoBytes() {
            return 0;
        }

        public byte internalByteAt(int i10) {
            return this.bytes[i10];
        }

        public final boolean isValidUtf8() {
            int offsetIntoBytes = getOffsetIntoBytes();
            if (Utf8.f2755a.f(0, this.bytes, offsetIntoBytes, size() + offsetIntoBytes) == 0) {
                return true;
            }
            return false;
        }

        public final e newCodedInput() {
            return e.g(this.bytes, getOffsetIntoBytes(), size(), true);
        }

        public final InputStream newInput() {
            return new ByteArrayInputStream(this.bytes, getOffsetIntoBytes(), size());
        }

        public final int partialHash(int i10, int i11, int i12) {
            byte[] bArr = this.bytes;
            int offsetIntoBytes = getOffsetIntoBytes() + i11;
            Charset charset = o.f2866a;
            for (int i13 = offsetIntoBytes; i13 < offsetIntoBytes + i12; i13++) {
                i10 = (i10 * 31) + bArr[i13];
            }
            return i10;
        }

        public final int partialIsValidUtf8(int i10, int i11, int i12) {
            int offsetIntoBytes = getOffsetIntoBytes() + i11;
            return Utf8.f2755a.f(i10, this.bytes, offsetIntoBytes, i12 + offsetIntoBytes);
        }

        public int size() {
            return this.bytes.length;
        }

        public final ByteString substring(int i10, int i11) {
            int checkRange = ByteString.checkRange(i10, i11, size());
            if (checkRange == 0) {
                return ByteString.EMPTY;
            }
            return new BoundedByteString(this.bytes, getOffsetIntoBytes() + i10, checkRange);
        }

        public final String toStringInternal(Charset charset) {
            return new String(this.bytes, getOffsetIntoBytes(), size(), charset);
        }

        public final void writeTo(OutputStream outputStream) {
            outputStream.write(toByteArray());
        }

        public final void writeToInternal(OutputStream outputStream, int i10, int i11) {
            outputStream.write(this.bytes, getOffsetIntoBytes() + i10, i11);
        }

        public final void writeTo(y1.d dVar) {
            dVar.b(this.bytes, getOffsetIntoBytes(), size());
        }
    }

    public class a extends c {

        /* renamed from: p  reason: collision with root package name */
        public int f2706p = 0;

        /* renamed from: q  reason: collision with root package name */
        public final int f2707q;

        public a() {
            this.f2707q = ByteString.this.size();
        }

        public byte a() {
            int i10 = this.f2706p;
            if (i10 < this.f2707q) {
                this.f2706p = i10 + 1;
                return ByteString.this.internalByteAt(i10);
            }
            throw new NoSuchElementException();
        }

        public boolean hasNext() {
            return this.f2706p < this.f2707q;
        }
    }

    public static class b implements Comparator<ByteString> {
        public int compare(Object obj, Object obj2) {
            ByteString byteString = (ByteString) obj;
            ByteString byteString2 = (ByteString) obj2;
            f it = byteString.iterator();
            f it2 = byteString2.iterator();
            while (it.hasNext() && it2.hasNext()) {
                int compare = Integer.compare(ByteString.access$200(it.a()), ByteString.access$200(it2.a()));
                if (compare != 0) {
                    return compare;
                }
            }
            return Integer.compare(byteString.size(), byteString2.size());
        }
    }

    public static abstract class c implements f {
        public Object next() {
            return Byte.valueOf(a());
        }

        public final void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public static final class d implements e {
        public d(a aVar) {
        }

        public byte[] a(byte[] bArr, int i10, int i11) {
            return Arrays.copyOfRange(bArr, i10, i11 + i10);
        }
    }

    public interface e {
        byte[] a(byte[] bArr, int i10, int i11);
    }

    public interface f extends Iterator<Byte> {
        byte a();
    }

    public static final class g {

        /* renamed from: a  reason: collision with root package name */
        public final CodedOutputStream f2709a;

        /* renamed from: b  reason: collision with root package name */
        public final byte[] f2710b;

        public g(int i10, a aVar) {
            byte[] bArr = new byte[i10];
            this.f2710b = bArr;
            Logger logger = CodedOutputStream.f2716b;
            this.f2709a = new CodedOutputStream.c(bArr, 0, i10);
        }

        public ByteString a() {
            if (this.f2709a.G() == 0) {
                return new LiteralByteString(this.f2710b);
            }
            throw new IllegalStateException("Did not write as much data as expected.");
        }
    }

    public static final class i implements e {
        public i(a aVar) {
        }

        public byte[] a(byte[] bArr, int i10, int i11) {
            byte[] bArr2 = new byte[i11];
            System.arraycopy(bArr, i10, bArr2, 0, i11);
            return bArr2;
        }
    }

    public static int access$200(byte b10) {
        return b10 & 255;
    }

    public static ByteString c(Iterator<ByteString> it, int i10) {
        if (i10 < 1) {
            throw new IllegalArgumentException(String.format("length (%s) must be >= 1", new Object[]{Integer.valueOf(i10)}));
        } else if (i10 == 1) {
            return it.next();
        } else {
            int i11 = i10 >>> 1;
            return c(it, i11).concat(c(it, i10 - i11));
        }
    }

    public static void checkIndex(int i10, int i11) {
        if (((i11 - (i10 + 1)) | i10) >= 0) {
            return;
        }
        if (i10 < 0) {
            throw new ArrayIndexOutOfBoundsException(ai.plaud.android.plaud.anew.flutter.audio.e.a("Index < 0: ", i10));
        }
        throw new ArrayIndexOutOfBoundsException(ai.plaud.android.plaud.anew.flutter.audio.c.a("Index > length: ", i10, ", ", i11));
    }

    public static int checkRange(int i10, int i11, int i12) {
        int i13 = i11 - i10;
        if ((i10 | i11 | i13 | (i12 - i11)) >= 0) {
            return i13;
        }
        if (i10 < 0) {
            throw new IndexOutOfBoundsException(ai.plaud.android.plaud.anew.flutter.audio.f.a("Beginning index: ", i10, " < 0"));
        } else if (i11 < i10) {
            throw new IndexOutOfBoundsException(ai.plaud.android.plaud.anew.flutter.audio.c.a("Beginning index larger than ending index: ", i10, ", ", i11));
        } else {
            throw new IndexOutOfBoundsException(ai.plaud.android.plaud.anew.flutter.audio.c.a("End index: ", i11, " >= ", i12));
        }
    }

    public static ByteString copyFrom(byte[] bArr, int i10, int i11) {
        checkRange(i10, i10 + i11, bArr.length);
        return new LiteralByteString(f2704p.a(bArr, i10, i11));
    }

    public static ByteString copyFromUtf8(String str) {
        return new LiteralByteString(str.getBytes(o.f2866a));
    }

    public static g newCodedBuilder(int i10) {
        return new g(i10, (a) null);
    }

    public static h newOutput(int i10) {
        return new h(i10);
    }

    public static ByteString readFrom(InputStream inputStream) {
        return readFrom(inputStream, 256, 8192);
    }

    public static Comparator<ByteString> unsignedLexicographicalComparator() {
        return f2705q;
    }

    public static ByteString wrap(ByteBuffer byteBuffer) {
        if (!byteBuffer.hasArray()) {
            return new NioByteString(byteBuffer);
        }
        return wrap(byteBuffer.array(), byteBuffer.position() + byteBuffer.arrayOffset(), byteBuffer.remaining());
    }

    public abstract ByteBuffer asReadOnlyByteBuffer();

    public abstract List<ByteBuffer> asReadOnlyByteBufferList();

    public abstract byte byteAt(int i10);

    public final ByteString concat(ByteString byteString) {
        if (GeneratedMessageLite.UNINITIALIZED_SERIALIZED_SIZE - size() >= byteString.size()) {
            return RopeByteString.concatenate(this, byteString);
        }
        StringBuilder a10 = f.a.a("ByteString would be too long: ");
        a10.append(size());
        a10.append(Marker.ANY_NON_NULL_MARKER);
        a10.append(byteString.size());
        throw new IllegalArgumentException(a10.toString());
    }

    public abstract void copyTo(ByteBuffer byteBuffer);

    public void copyTo(byte[] bArr, int i10) {
        copyTo(bArr, 0, i10, size());
    }

    public abstract void copyToInternal(byte[] bArr, int i10, int i11, int i12);

    public final boolean endsWith(ByteString byteString) {
        return size() >= byteString.size() && substring(size() - byteString.size()).equals(byteString);
    }

    public abstract boolean equals(Object obj);

    public abstract int getTreeDepth();

    public final int hashCode() {
        int i10 = this.hash;
        if (i10 == 0) {
            int size = size();
            i10 = partialHash(size, 0, size);
            if (i10 == 0) {
                i10 = 1;
            }
            this.hash = i10;
        }
        return i10;
    }

    public abstract byte internalByteAt(int i10);

    public abstract boolean isBalanced();

    public final boolean isEmpty() {
        return size() == 0;
    }

    public abstract boolean isValidUtf8();

    public abstract e newCodedInput();

    public abstract InputStream newInput();

    public abstract int partialHash(int i10, int i11, int i12);

    public abstract int partialIsValidUtf8(int i10, int i11, int i12);

    public final int peekCachedHashCode() {
        return this.hash;
    }

    public abstract int size();

    public final boolean startsWith(ByteString byteString) {
        return size() >= byteString.size() && substring(0, byteString.size()).equals(byteString);
    }

    public final ByteString substring(int i10) {
        return substring(i10, size());
    }

    public abstract ByteString substring(int i10, int i11);

    public final byte[] toByteArray() {
        int size = size();
        if (size == 0) {
            return o.f2867b;
        }
        byte[] bArr = new byte[size];
        copyToInternal(bArr, 0, 0, size);
        return bArr;
    }

    public final String toString(String str) {
        try {
            return toString(Charset.forName(str));
        } catch (UnsupportedCharsetException e10) {
            UnsupportedEncodingException unsupportedEncodingException = new UnsupportedEncodingException(str);
            unsupportedEncodingException.initCause(e10);
            throw unsupportedEncodingException;
        }
    }

    public abstract String toStringInternal(Charset charset);

    public final String toStringUtf8() {
        return toString(o.f2866a);
    }

    public abstract void writeTo(OutputStream outputStream);

    public final void writeTo(OutputStream outputStream, int i10, int i11) {
        checkRange(i10, i10 + i11, size());
        if (i11 > 0) {
            writeToInternal(outputStream, i10, i11);
        }
    }

    public abstract void writeTo(y1.d dVar);

    public abstract void writeToInternal(OutputStream outputStream, int i10, int i11);

    public abstract void writeToReverse(y1.d dVar);

    public static h newOutput() {
        return new h(128);
    }

    public static ByteString readFrom(InputStream inputStream, int i10) {
        return readFrom(inputStream, i10, i10);
    }

    @Deprecated
    public final void copyTo(byte[] bArr, int i10, int i11, int i12) {
        checkRange(i10, i10 + i12, size());
        checkRange(i11, i11 + i12, bArr.length);
        if (i12 > 0) {
            copyToInternal(bArr, i10, i11, i12);
        }
    }

    public f iterator() {
        return new a();
    }

    public static ByteString copyFrom(byte[] bArr) {
        return copyFrom(bArr, 0, bArr.length);
    }

    public static ByteString readFrom(InputStream inputStream, int i10, int i11) {
        ByteString byteString;
        ArrayList arrayList = new ArrayList();
        while (true) {
            byte[] bArr = new byte[i10];
            int i12 = 0;
            while (i12 < i10) {
                int read = inputStream.read(bArr, i12, i10 - i12);
                if (read == -1) {
                    break;
                }
                i12 += read;
            }
            if (i12 == 0) {
                byteString = null;
            } else {
                byteString = copyFrom(bArr, 0, i12);
            }
            if (byteString == null) {
                return copyFrom((Iterable<ByteString>) arrayList);
            }
            arrayList.add(byteString);
            i10 = Math.min(i10 * 2, i11);
        }
    }

    public static final class h extends OutputStream {

        /* renamed from: p  reason: collision with root package name */
        public final int f2711p;

        /* renamed from: q  reason: collision with root package name */
        public final ArrayList<ByteString> f2712q;

        /* renamed from: r  reason: collision with root package name */
        public int f2713r;

        /* renamed from: s  reason: collision with root package name */
        public byte[] f2714s;

        /* renamed from: t  reason: collision with root package name */
        public int f2715t;

        public h(int i10) {
            if (i10 >= 0) {
                this.f2711p = i10;
                this.f2712q = new ArrayList<>();
                this.f2714s = new byte[i10];
                return;
            }
            throw new IllegalArgumentException("Buffer size < 0");
        }

        public final void a(int i10) {
            this.f2712q.add(new LiteralByteString(this.f2714s));
            int length = this.f2713r + this.f2714s.length;
            this.f2713r = length;
            this.f2714s = new byte[Math.max(this.f2711p, Math.max(i10, length >>> 1))];
            this.f2715t = 0;
        }

        public String toString() {
            int i10;
            Object[] objArr = new Object[2];
            objArr[0] = Integer.toHexString(System.identityHashCode(this));
            synchronized (this) {
                i10 = this.f2713r + this.f2715t;
            }
            objArr[1] = Integer.valueOf(i10);
            return String.format("<ByteString.Output@%s size=%d>", objArr);
        }

        public synchronized void write(int i10) {
            if (this.f2715t == this.f2714s.length) {
                a(1);
            }
            byte[] bArr = this.f2714s;
            int i11 = this.f2715t;
            this.f2715t = i11 + 1;
            bArr[i11] = (byte) i10;
        }

        public synchronized void write(byte[] bArr, int i10, int i11) {
            byte[] bArr2 = this.f2714s;
            int length = bArr2.length;
            int i12 = this.f2715t;
            if (i11 <= length - i12) {
                System.arraycopy(bArr, i10, bArr2, i12, i11);
                this.f2715t += i11;
            } else {
                int length2 = bArr2.length - i12;
                System.arraycopy(bArr, i10, bArr2, i12, length2);
                int i13 = i11 - length2;
                a(i13);
                System.arraycopy(bArr, i10 + length2, this.f2714s, 0, i13);
                this.f2715t = i13;
            }
        }
    }

    public static ByteString copyFrom(ByteBuffer byteBuffer, int i10) {
        checkRange(0, i10, byteBuffer.remaining());
        byte[] bArr = new byte[i10];
        byteBuffer.get(bArr);
        return new LiteralByteString(bArr);
    }

    public static ByteString wrap(byte[] bArr) {
        return new LiteralByteString(bArr);
    }

    public final String toString(Charset charset) {
        return size() == 0 ? HttpUrl.FRAGMENT_ENCODE_SET : toStringInternal(charset);
    }

    public static ByteString wrap(byte[] bArr, int i10, int i11) {
        return new BoundedByteString(bArr, i10, i11);
    }

    public final String toString() {
        return String.format("<ByteString@%s size=%d>", new Object[]{Integer.toHexString(System.identityHashCode(this)), Integer.valueOf(size())});
    }

    public static ByteString copyFrom(ByteBuffer byteBuffer) {
        return copyFrom(byteBuffer, byteBuffer.remaining());
    }

    public static ByteString copyFrom(String str, String str2) {
        return new LiteralByteString(str.getBytes(str2));
    }

    public static ByteString copyFrom(String str, Charset charset) {
        return new LiteralByteString(str.getBytes(charset));
    }

    public static ByteString copyFrom(Iterable<ByteString> iterable) {
        int i10;
        if (!(iterable instanceof Collection)) {
            i10 = 0;
            Iterator<ByteString> it = iterable.iterator();
            while (it.hasNext()) {
                it.next();
                i10++;
            }
        } else {
            i10 = ((Collection) iterable).size();
        }
        if (i10 == 0) {
            return EMPTY;
        }
        return c(iterable.iterator(), i10);
    }
}
