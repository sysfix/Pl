package androidx.datastore.preferences.protobuf;

import androidx.appcompat.widget.k0;
import androidx.datastore.preferences.protobuf.o;
import com.google.protobuf.GeneratedMessageLite;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.RandomAccess;
import y1.b;
import y1.s;

/* compiled from: LongArrayList */
public final class t extends c<Long> implements RandomAccess, s {

    /* renamed from: q  reason: collision with root package name */
    public long[] f2876q;

    /* renamed from: r  reason: collision with root package name */
    public int f2877r;

    static {
        new t(new long[0], 0).f2763p = false;
    }

    public t() {
        this.f2876q = new long[10];
        this.f2877r = 0;
    }

    public void add(int i10, Object obj) {
        int i11;
        long longValue = ((Long) obj).longValue();
        c();
        if (i10 < 0 || i10 > (i11 = this.f2877r)) {
            throw new IndexOutOfBoundsException(n(i10));
        }
        long[] jArr = this.f2876q;
        if (i11 < jArr.length) {
            System.arraycopy(jArr, i10, jArr, i10 + 1, i11 - i10);
        } else {
            long[] jArr2 = new long[b.a(i11, 3, 2, 1)];
            System.arraycopy(jArr, 0, jArr2, 0, i10);
            System.arraycopy(this.f2876q, i10, jArr2, i10 + 1, this.f2877r - i10);
            this.f2876q = jArr2;
        }
        this.f2876q[i10] = longValue;
        this.f2877r++;
        this.modCount++;
    }

    public boolean addAll(Collection<? extends Long> collection) {
        c();
        Charset charset = o.f2866a;
        Objects.requireNonNull(collection);
        if (!(collection instanceof t)) {
            return super.addAll(collection);
        }
        t tVar = (t) collection;
        int i10 = tVar.f2877r;
        if (i10 == 0) {
            return false;
        }
        int i11 = this.f2877r;
        if (GeneratedMessageLite.UNINITIALIZED_SERIALIZED_SIZE - i11 >= i10) {
            int i12 = i11 + i10;
            long[] jArr = this.f2876q;
            if (i12 > jArr.length) {
                this.f2876q = Arrays.copyOf(jArr, i12);
            }
            System.arraycopy(tVar.f2876q, 0, this.f2876q, this.f2877r, tVar.f2877r);
            this.f2877r = i12;
            this.modCount++;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof t)) {
            return super.equals(obj);
        }
        t tVar = (t) obj;
        if (this.f2877r != tVar.f2877r) {
            return false;
        }
        long[] jArr = tVar.f2876q;
        for (int i10 = 0; i10 < this.f2877r; i10++) {
            if (this.f2876q[i10] != jArr[i10]) {
                return false;
            }
        }
        return true;
    }

    public void f(long j10) {
        c();
        int i10 = this.f2877r;
        long[] jArr = this.f2876q;
        if (i10 == jArr.length) {
            long[] jArr2 = new long[b.a(i10, 3, 2, 1)];
            System.arraycopy(jArr, 0, jArr2, 0, i10);
            this.f2876q = jArr2;
        }
        long[] jArr3 = this.f2876q;
        int i11 = this.f2877r;
        this.f2877r = i11 + 1;
        jArr3[i11] = j10;
    }

    public Object get(int i10) {
        i(i10);
        return Long.valueOf(this.f2876q[i10]);
    }

    public int hashCode() {
        int i10 = 1;
        for (int i11 = 0; i11 < this.f2877r; i11++) {
            i10 = (i10 * 31) + o.b(this.f2876q[i11]);
        }
        return i10;
    }

    public final void i(int i10) {
        if (i10 < 0 || i10 >= this.f2877r) {
            throw new IndexOutOfBoundsException(n(i10));
        }
    }

    public o.c j(int i10) {
        if (i10 >= this.f2877r) {
            return new t(Arrays.copyOf(this.f2876q, i10), this.f2877r);
        }
        throw new IllegalArgumentException();
    }

    public long l(int i10) {
        i(i10);
        return this.f2876q[i10];
    }

    public final String n(int i10) {
        StringBuilder a10 = k0.a("Index:", i10, ", Size:");
        a10.append(this.f2877r);
        return a10.toString();
    }

    public boolean remove(Object obj) {
        c();
        for (int i10 = 0; i10 < this.f2877r; i10++) {
            if (obj.equals(Long.valueOf(this.f2876q[i10]))) {
                long[] jArr = this.f2876q;
                System.arraycopy(jArr, i10 + 1, jArr, i10, (this.f2877r - i10) - 1);
                this.f2877r--;
                this.modCount++;
                return true;
            }
        }
        return false;
    }

    public void removeRange(int i10, int i11) {
        c();
        if (i11 >= i10) {
            long[] jArr = this.f2876q;
            System.arraycopy(jArr, i11, jArr, i10, this.f2877r - i11);
            this.f2877r -= i11 - i10;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public Object set(int i10, Object obj) {
        long longValue = ((Long) obj).longValue();
        c();
        i(i10);
        long[] jArr = this.f2876q;
        long j10 = jArr[i10];
        jArr[i10] = longValue;
        return Long.valueOf(j10);
    }

    public int size() {
        return this.f2877r;
    }

    public t(long[] jArr, int i10) {
        this.f2876q = jArr;
        this.f2877r = i10;
    }

    public Object remove(int i10) {
        c();
        i(i10);
        long[] jArr = this.f2876q;
        long j10 = jArr[i10];
        int i11 = this.f2877r;
        if (i10 < i11 - 1) {
            System.arraycopy(jArr, i10 + 1, jArr, i10, (i11 - i10) - 1);
        }
        this.f2877r--;
        this.modCount++;
        return Long.valueOf(j10);
    }

    public boolean add(Object obj) {
        f(((Long) obj).longValue());
        return true;
    }
}
