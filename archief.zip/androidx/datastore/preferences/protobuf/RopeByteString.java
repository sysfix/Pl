package androidx.datastore.preferences.protobuf;

import androidx.datastore.preferences.protobuf.ByteString;
import com.google.protobuf.GeneratedMessageLite;
import java.io.InputStream;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

public final class RopeByteString extends ByteString {
    public static final int[] minLengthByDepth = {1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811, 514229, 832040, 1346269, 2178309, 3524578, 5702887, 9227465, 14930352, 24157817, 39088169, 63245986, 102334155, 165580141, 267914296, 433494437, 701408733, 1134903170, 1836311903, GeneratedMessageLite.UNINITIALIZED_SERIALIZED_SIZE};
    private static final long serialVersionUID = 1;
    /* access modifiers changed from: private */
    public final ByteString left;
    private final int leftLength;
    /* access modifiers changed from: private */
    public final ByteString right;
    private final int totalLength;
    private final int treeDepth;

    public class a extends ByteString.c {

        /* renamed from: p  reason: collision with root package name */
        public final c f2743p;

        /* renamed from: q  reason: collision with root package name */
        public ByteString.f f2744q = b();

        public a(RopeByteString ropeByteString) {
            this.f2743p = new c(ropeByteString, (a) null);
        }

        public byte a() {
            ByteString.f fVar = this.f2744q;
            if (fVar != null) {
                byte a10 = fVar.a();
                if (!this.f2744q.hasNext()) {
                    this.f2744q = b();
                }
                return a10;
            }
            throw new NoSuchElementException();
        }

        public final ByteString.f b() {
            if (this.f2743p.hasNext()) {
                return this.f2743p.next().iterator();
            }
            return null;
        }

        public boolean hasNext() {
            return this.f2744q != null;
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final ArrayDeque<ByteString> f2745a = new ArrayDeque<>();

        public b(a aVar) {
        }

        public final void a(ByteString byteString) {
            if (byteString.isBalanced()) {
                int size = byteString.size();
                int[] iArr = RopeByteString.minLengthByDepth;
                int binarySearch = Arrays.binarySearch(iArr, size);
                if (binarySearch < 0) {
                    binarySearch = (-(binarySearch + 1)) - 1;
                }
                int i10 = iArr[binarySearch + 1];
                if (this.f2745a.isEmpty() || this.f2745a.peek().size() >= i10) {
                    this.f2745a.push(byteString);
                    return;
                }
                int i11 = iArr[binarySearch];
                ByteString pop = this.f2745a.pop();
                while (!this.f2745a.isEmpty() && this.f2745a.peek().size() < i11) {
                    pop = new RopeByteString(this.f2745a.pop(), pop, (a) null);
                }
                RopeByteString ropeByteString = new RopeByteString(pop, byteString, (a) null);
                while (!this.f2745a.isEmpty()) {
                    int size2 = ropeByteString.size();
                    int[] iArr2 = RopeByteString.minLengthByDepth;
                    int binarySearch2 = Arrays.binarySearch(iArr2, size2);
                    if (binarySearch2 < 0) {
                        binarySearch2 = (-(binarySearch2 + 1)) - 1;
                    }
                    if (this.f2745a.peek().size() >= iArr2[binarySearch2 + 1]) {
                        break;
                    }
                    ropeByteString = new RopeByteString(this.f2745a.pop(), ropeByteString, (a) null);
                }
                this.f2745a.push(ropeByteString);
            } else if (byteString instanceof RopeByteString) {
                RopeByteString ropeByteString2 = (RopeByteString) byteString;
                a(ropeByteString2.left);
                a(ropeByteString2.right);
            } else {
                StringBuilder a10 = f.a.a("Has a new type of ByteString been created? Found ");
                a10.append(byteString.getClass());
                throw new IllegalArgumentException(a10.toString());
            }
        }
    }

    public static final class c implements Iterator<ByteString.LeafByteString> {

        /* renamed from: p  reason: collision with root package name */
        public final ArrayDeque<RopeByteString> f2746p;

        /* renamed from: q  reason: collision with root package name */
        public ByteString.LeafByteString f2747q;

        public c(ByteString byteString, a aVar) {
            if (byteString instanceof RopeByteString) {
                RopeByteString ropeByteString = (RopeByteString) byteString;
                ArrayDeque<RopeByteString> arrayDeque = new ArrayDeque<>(ropeByteString.getTreeDepth());
                this.f2746p = arrayDeque;
                arrayDeque.push(ropeByteString);
                ByteString access$400 = ropeByteString.left;
                while (access$400 instanceof RopeByteString) {
                    RopeByteString ropeByteString2 = (RopeByteString) access$400;
                    this.f2746p.push(ropeByteString2);
                    access$400 = ropeByteString2.left;
                }
                this.f2747q = (ByteString.LeafByteString) access$400;
                return;
            }
            this.f2746p = null;
            this.f2747q = (ByteString.LeafByteString) byteString;
        }

        /* renamed from: b */
        public ByteString.LeafByteString next() {
            ByteString.LeafByteString leafByteString;
            ByteString.LeafByteString leafByteString2 = this.f2747q;
            if (leafByteString2 != null) {
                while (true) {
                    ArrayDeque<RopeByteString> arrayDeque = this.f2746p;
                    if (arrayDeque != null && !arrayDeque.isEmpty()) {
                        ByteString access$500 = this.f2746p.pop().right;
                        while (access$500 instanceof RopeByteString) {
                            RopeByteString ropeByteString = (RopeByteString) access$500;
                            this.f2746p.push(ropeByteString);
                            access$500 = ropeByteString.left;
                        }
                        leafByteString = (ByteString.LeafByteString) access$500;
                        if (!leafByteString.isEmpty()) {
                            break;
                        }
                    } else {
                        leafByteString = null;
                    }
                }
                leafByteString = null;
                this.f2747q = leafByteString;
                return leafByteString2;
            }
            throw new NoSuchElementException();
        }

        public boolean hasNext() {
            return this.f2747q != null;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public /* synthetic */ RopeByteString(ByteString byteString, ByteString byteString2, a aVar) {
        this(byteString, byteString2);
    }

    public static ByteString concatenate(ByteString byteString, ByteString byteString2) {
        if (byteString2.size() == 0) {
            return byteString;
        }
        if (byteString.size() == 0) {
            return byteString2;
        }
        int size = byteString2.size() + byteString.size();
        if (size < 128) {
            return f(byteString, byteString2);
        }
        if (byteString instanceof RopeByteString) {
            RopeByteString ropeByteString = (RopeByteString) byteString;
            if (byteString2.size() + ropeByteString.right.size() < 128) {
                return new RopeByteString(ropeByteString.left, f(ropeByteString.right, byteString2));
            } else if (ropeByteString.left.getTreeDepth() > ropeByteString.right.getTreeDepth() && ropeByteString.getTreeDepth() > byteString2.getTreeDepth()) {
                return new RopeByteString(ropeByteString.left, new RopeByteString(ropeByteString.right, byteString2));
            }
        }
        if (size >= minLengthByDepth[Math.max(byteString.getTreeDepth(), byteString2.getTreeDepth()) + 1]) {
            return new RopeByteString(byteString, byteString2);
        }
        b bVar = new b((a) null);
        bVar.a(byteString);
        bVar.a(byteString2);
        ByteString pop = bVar.f2745a.pop();
        while (!bVar.f2745a.isEmpty()) {
            pop = new RopeByteString(bVar.f2745a.pop(), pop, (a) null);
        }
        return pop;
    }

    public static ByteString f(ByteString byteString, ByteString byteString2) {
        int size = byteString.size();
        int size2 = byteString2.size();
        byte[] bArr = new byte[(size + size2)];
        byteString.copyTo(bArr, 0, 0, size);
        byteString2.copyTo(bArr, 0, size, size2);
        return ByteString.wrap(bArr);
    }

    public static RopeByteString newInstanceForTest(ByteString byteString, ByteString byteString2) {
        return new RopeByteString(byteString, byteString2);
    }

    private void readObject(ObjectInputStream objectInputStream) {
        throw new InvalidObjectException("RopeByteStream instances are not to be serialized directly");
    }

    public ByteBuffer asReadOnlyByteBuffer() {
        return ByteBuffer.wrap(toByteArray()).asReadOnlyBuffer();
    }

    public List<ByteBuffer> asReadOnlyByteBufferList() {
        ByteString.LeafByteString leafByteString;
        ArrayList arrayList = new ArrayList();
        ArrayDeque arrayDeque = new ArrayDeque(getTreeDepth());
        arrayDeque.push(this);
        ByteString access$400 = this.left;
        while (access$400 instanceof RopeByteString) {
            RopeByteString ropeByteString = (RopeByteString) access$400;
            arrayDeque.push(ropeByteString);
            access$400 = ropeByteString.left;
        }
        ByteString.LeafByteString leafByteString2 = (ByteString.LeafByteString) access$400;
        while (true) {
            if (!(leafByteString2 != null)) {
                return arrayList;
            }
            if (leafByteString2 != null) {
                while (true) {
                    if (!arrayDeque.isEmpty()) {
                        ByteString access$500 = ((RopeByteString) arrayDeque.pop()).right;
                        while (access$500 instanceof RopeByteString) {
                            RopeByteString ropeByteString2 = (RopeByteString) access$500;
                            arrayDeque.push(ropeByteString2);
                            access$500 = ropeByteString2.left;
                        }
                        leafByteString = (ByteString.LeafByteString) access$500;
                        if (!leafByteString.isEmpty()) {
                            break;
                        }
                    } else {
                        leafByteString = null;
                        break;
                    }
                }
                arrayList.add(leafByteString2.asReadOnlyByteBuffer());
                leafByteString2 = leafByteString;
            } else {
                throw new NoSuchElementException();
            }
        }
    }

    public byte byteAt(int i10) {
        ByteString.checkIndex(i10, this.totalLength);
        return internalByteAt(i10);
    }

    public void copyTo(ByteBuffer byteBuffer) {
        this.left.copyTo(byteBuffer);
        this.right.copyTo(byteBuffer);
    }

    public void copyToInternal(byte[] bArr, int i10, int i11, int i12) {
        int i13 = i10 + i12;
        int i14 = this.leftLength;
        if (i13 <= i14) {
            this.left.copyToInternal(bArr, i10, i11, i12);
        } else if (i10 >= i14) {
            this.right.copyToInternal(bArr, i10 - i14, i11, i12);
        } else {
            int i15 = i14 - i10;
            this.left.copyToInternal(bArr, i10, i11, i15);
            this.right.copyToInternal(bArr, 0, i11 + i15, i12 - i15);
        }
    }

    public boolean equals(Object obj) {
        boolean z10;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ByteString)) {
            return false;
        }
        ByteString byteString = (ByteString) obj;
        if (this.totalLength != byteString.size()) {
            return false;
        }
        if (this.totalLength == 0) {
            return true;
        }
        int peekCachedHashCode = peekCachedHashCode();
        int peekCachedHashCode2 = byteString.peekCachedHashCode();
        if (peekCachedHashCode != 0 && peekCachedHashCode2 != 0 && peekCachedHashCode != peekCachedHashCode2) {
            return false;
        }
        c cVar = new c(this, (a) null);
        ByteString.LeafByteString leafByteString = (ByteString.LeafByteString) cVar.next();
        c cVar2 = new c(byteString, (a) null);
        ByteString.LeafByteString leafByteString2 = (ByteString.LeafByteString) cVar2.next();
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        while (true) {
            int size = leafByteString.size() - i10;
            int size2 = leafByteString2.size() - i11;
            int min = Math.min(size, size2);
            if (i10 == 0) {
                z10 = leafByteString.equalsRange(leafByteString2, i11, min);
            } else {
                z10 = leafByteString2.equalsRange(leafByteString, i10, min);
            }
            if (!z10) {
                return false;
            }
            i12 += min;
            int i13 = this.totalLength;
            if (i12 < i13) {
                if (min == size) {
                    leafByteString = (ByteString.LeafByteString) cVar.next();
                    i10 = 0;
                } else {
                    i10 += min;
                }
                if (min == size2) {
                    leafByteString2 = (ByteString.LeafByteString) cVar2.next();
                    i11 = 0;
                } else {
                    i11 += min;
                }
            } else if (i12 == i13) {
                return true;
            } else {
                throw new IllegalStateException();
            }
        }
    }

    public int getTreeDepth() {
        return this.treeDepth;
    }

    public byte internalByteAt(int i10) {
        int i11 = this.leftLength;
        if (i10 < i11) {
            return this.left.internalByteAt(i10);
        }
        return this.right.internalByteAt(i10 - i11);
    }

    public boolean isBalanced() {
        return this.totalLength >= minLengthByDepth[this.treeDepth];
    }

    public boolean isValidUtf8() {
        int partialIsValidUtf8 = this.left.partialIsValidUtf8(0, 0, this.leftLength);
        ByteString byteString = this.right;
        if (byteString.partialIsValidUtf8(partialIsValidUtf8, 0, byteString.size()) == 0) {
            return true;
        }
        return false;
    }

    public e newCodedInput() {
        return e.f(new d());
    }

    public InputStream newInput() {
        return new d();
    }

    public int partialHash(int i10, int i11, int i12) {
        int i13 = i11 + i12;
        int i14 = this.leftLength;
        if (i13 <= i14) {
            return this.left.partialHash(i10, i11, i12);
        }
        if (i11 >= i14) {
            return this.right.partialHash(i10, i11 - i14, i12);
        }
        int i15 = i14 - i11;
        return this.right.partialHash(this.left.partialHash(i10, i11, i15), 0, i12 - i15);
    }

    public int partialIsValidUtf8(int i10, int i11, int i12) {
        int i13 = i11 + i12;
        int i14 = this.leftLength;
        if (i13 <= i14) {
            return this.left.partialIsValidUtf8(i10, i11, i12);
        }
        if (i11 >= i14) {
            return this.right.partialIsValidUtf8(i10, i11 - i14, i12);
        }
        int i15 = i14 - i11;
        return this.right.partialIsValidUtf8(this.left.partialIsValidUtf8(i10, i11, i15), 0, i12 - i15);
    }

    public int size() {
        return this.totalLength;
    }

    public ByteString substring(int i10, int i11) {
        int checkRange = ByteString.checkRange(i10, i11, this.totalLength);
        if (checkRange == 0) {
            return ByteString.EMPTY;
        }
        if (checkRange == this.totalLength) {
            return this;
        }
        int i12 = this.leftLength;
        if (i11 <= i12) {
            return this.left.substring(i10, i11);
        }
        if (i10 >= i12) {
            return this.right.substring(i10 - i12, i11 - i12);
        }
        return new RopeByteString(this.left.substring(i10), this.right.substring(0, i11 - this.leftLength));
    }

    public String toStringInternal(Charset charset) {
        return new String(toByteArray(), charset);
    }

    public Object writeReplace() {
        return ByteString.wrap(toByteArray());
    }

    public void writeTo(OutputStream outputStream) {
        this.left.writeTo(outputStream);
        this.right.writeTo(outputStream);
    }

    public void writeToInternal(OutputStream outputStream, int i10, int i11) {
        int i12 = i10 + i11;
        int i13 = this.leftLength;
        if (i12 <= i13) {
            this.left.writeToInternal(outputStream, i10, i11);
        } else if (i10 >= i13) {
            this.right.writeToInternal(outputStream, i10 - i13, i11);
        } else {
            int i14 = i13 - i10;
            this.left.writeToInternal(outputStream, i10, i14);
            this.right.writeToInternal(outputStream, 0, i11 - i14);
        }
    }

    public void writeToReverse(y1.d dVar) {
        this.right.writeToReverse(dVar);
        this.left.writeToReverse(dVar);
    }

    public RopeByteString(ByteString byteString, ByteString byteString2) {
        this.left = byteString;
        this.right = byteString2;
        int size = byteString.size();
        this.leftLength = size;
        this.totalLength = byteString2.size() + size;
        this.treeDepth = Math.max(byteString.getTreeDepth(), byteString2.getTreeDepth()) + 1;
    }

    public ByteString.f iterator() {
        return new a(this);
    }

    public void writeTo(y1.d dVar) {
        this.left.writeTo(dVar);
        this.right.writeTo(dVar);
    }

    public class d extends InputStream {

        /* renamed from: p  reason: collision with root package name */
        public c f2748p;

        /* renamed from: q  reason: collision with root package name */
        public ByteString.LeafByteString f2749q;

        /* renamed from: r  reason: collision with root package name */
        public int f2750r;

        /* renamed from: s  reason: collision with root package name */
        public int f2751s;

        /* renamed from: t  reason: collision with root package name */
        public int f2752t;

        /* renamed from: u  reason: collision with root package name */
        public int f2753u;

        public d() {
            b();
        }

        public final void a() {
            int i10;
            if (this.f2749q != null && this.f2751s == (i10 = this.f2750r)) {
                this.f2752t += i10;
                this.f2751s = 0;
                if (this.f2748p.hasNext()) {
                    ByteString.LeafByteString b10 = this.f2748p.next();
                    this.f2749q = b10;
                    this.f2750r = b10.size();
                    return;
                }
                this.f2749q = null;
                this.f2750r = 0;
            }
        }

        public int available() {
            return RopeByteString.this.size() - (this.f2752t + this.f2751s);
        }

        public final void b() {
            c cVar = new c(RopeByteString.this, (a) null);
            this.f2748p = cVar;
            ByteString.LeafByteString b10 = cVar.next();
            this.f2749q = b10;
            this.f2750r = b10.size();
            this.f2751s = 0;
            this.f2752t = 0;
        }

        public final int d(byte[] bArr, int i10, int i11) {
            int i12 = i11;
            while (true) {
                if (i12 <= 0) {
                    break;
                }
                a();
                if (this.f2749q != null) {
                    int min = Math.min(this.f2750r - this.f2751s, i12);
                    if (bArr != null) {
                        this.f2749q.copyTo(bArr, this.f2751s, i10, min);
                        i10 += min;
                    }
                    this.f2751s += min;
                    i12 -= min;
                } else if (i12 == i11) {
                    return -1;
                }
            }
            return i11 - i12;
        }

        public void mark(int i10) {
            this.f2753u = this.f2752t + this.f2751s;
        }

        public boolean markSupported() {
            return true;
        }

        public int read(byte[] bArr, int i10, int i11) {
            Objects.requireNonNull(bArr);
            if (i10 >= 0 && i11 >= 0 && i11 <= bArr.length - i10) {
                return d(bArr, i10, i11);
            }
            throw new IndexOutOfBoundsException();
        }

        public synchronized void reset() {
            b();
            d((byte[]) null, 0, this.f2753u);
        }

        public long skip(long j10) {
            if (j10 >= 0) {
                if (j10 > 2147483647L) {
                    j10 = 2147483647L;
                }
                return (long) d((byte[]) null, 0, (int) j10);
            }
            throw new IndexOutOfBoundsException();
        }

        public int read() {
            a();
            ByteString.LeafByteString leafByteString = this.f2749q;
            if (leafByteString == null) {
                return -1;
            }
            int i10 = this.f2751s;
            this.f2751s = i10 + 1;
            return leafByteString.byteAt(i10) & 255;
        }
    }
}
