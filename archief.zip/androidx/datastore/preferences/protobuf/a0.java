package androidx.datastore.preferences.protobuf;

import androidx.datastore.preferences.protobuf.GeneratedMessageLite;
import androidx.datastore.preferences.protobuf.l;
import androidx.datastore.preferences.protobuf.p;
import java.util.Iterator;
import java.util.Map;
import y1.v;

/* compiled from: MessageSetSchema */
public final class a0<T> implements v<T> {

    /* renamed from: a  reason: collision with root package name */
    public final x f2759a;

    /* renamed from: b  reason: collision with root package name */
    public final h0<?, ?> f2760b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f2761c;

    /* renamed from: d  reason: collision with root package name */
    public final j<?> f2762d;

    public a0(h0<?, ?> h0Var, j<?> jVar, x xVar) {
        this.f2760b = h0Var;
        this.f2761c = jVar.e(xVar);
        this.f2762d = jVar;
        this.f2759a = xVar;
    }

    public void a(T t10, T t11) {
        h0<?, ?> h0Var = this.f2760b;
        Class<?> cls = e0.f2798a;
        h0Var.o(t10, h0Var.k(h0Var.g(t10), h0Var.g(t11)));
        if (this.f2761c) {
            e0.A(this.f2762d, t10, t11);
        }
    }

    public void b(T t10) {
        this.f2760b.j(t10);
        this.f2762d.f(t10);
    }

    public final boolean c(T t10) {
        return this.f2762d.c(t10).i();
    }

    public boolean d(T t10, T t11) {
        if (!this.f2760b.g(t10).equals(this.f2760b.g(t11))) {
            return false;
        }
        if (this.f2761c) {
            return this.f2762d.c(t10).equals(this.f2762d.c(t11));
        }
        return true;
    }

    public int e(T t10) {
        h0<?, ?> h0Var = this.f2760b;
        int i10 = h0Var.i(h0Var.g(t10)) + 0;
        if (!this.f2761c) {
            return i10;
        }
        l<?> c10 = this.f2762d.c(t10);
        int i11 = 0;
        for (int i12 = 0; i12 < c10.f2857a.d(); i12++) {
            i11 += c10.g(c10.f2857a.c(i12));
        }
        for (Map.Entry<T, Object> g10 : c10.f2857a.e()) {
            i11 += c10.g(g10);
        }
        return i10 + i11;
    }

    public T f() {
        return ((GeneratedMessageLite.a) this.f2759a.d()).i();
    }

    public int g(T t10) {
        int hashCode = this.f2760b.g(t10).hashCode();
        return this.f2761c ? (hashCode * 53) + this.f2762d.c(t10).hashCode() : hashCode;
    }

    public void h(T t10, d0 d0Var, i iVar) {
        h0<?, ?> h0Var = this.f2760b;
        j<?> jVar = this.f2762d;
        Object f10 = h0Var.f(t10);
        l<?> d10 = jVar.d(t10);
        do {
            try {
                if (d0Var.q() == Integer.MAX_VALUE) {
                    break;
                }
            } finally {
                h0Var.n(t10, f10);
            }
        } while (j(d0Var, iVar, jVar, d10, h0Var, f10));
    }

    public void i(T t10, Writer writer) {
        Iterator<Map.Entry<?, Object>> k10 = this.f2762d.c(t10).k();
        while (k10.hasNext()) {
            Map.Entry next = k10.next();
            l.b bVar = (l.b) next.getKey();
            if (bVar.e() != WireFormat$JavaType.MESSAGE || bVar.c() || bVar.isPacked()) {
                throw new IllegalStateException("Found invalid MessageSet item.");
            } else if (next instanceof p.b) {
                ((g) writer).e(bVar.getNumber(), ((p.b) next).f2868p.getValue().b());
            } else {
                ((g) writer).e(bVar.getNumber(), next.getValue());
            }
        }
        h0<?, ?> h0Var = this.f2760b;
        h0Var.r(h0Var.g(t10), writer);
    }

    public final <UT, UB, ET extends l.b<ET>> boolean j(d0 d0Var, i iVar, j<ET> jVar, l<ET> lVar, h0<UT, UB> h0Var, UB ub2) {
        int a10 = d0Var.a();
        if (a10 == 11) {
            int i10 = 0;
            Object obj = null;
            ByteString byteString = null;
            while (d0Var.q() != Integer.MAX_VALUE) {
                int a11 = d0Var.a();
                if (a11 == 16) {
                    i10 = d0Var.y();
                    obj = jVar.b(iVar, this.f2759a, i10);
                } else if (a11 == 26) {
                    if (obj != null) {
                        jVar.h(d0Var, obj, iVar, lVar);
                    } else {
                        byteString = d0Var.v();
                    }
                } else if (!d0Var.A()) {
                    break;
                }
            }
            if (d0Var.a() == 12) {
                if (byteString != null) {
                    if (obj != null) {
                        jVar.i(byteString, obj, iVar, lVar);
                    } else {
                        h0Var.d(ub2, i10, byteString);
                    }
                }
                return true;
            }
            throw InvalidProtocolBufferException.invalidEndTag();
        } else if ((a10 & 7) != 2) {
            return d0Var.A();
        } else {
            Object b10 = jVar.b(iVar, this.f2759a, a10 >>> 3);
            if (b10 == null) {
                return h0Var.l(ub2, d0Var);
            }
            jVar.h(d0Var, b10, iVar, lVar);
            return true;
        }
    }
}
