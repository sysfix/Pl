package aa;

import aa.b;
import z9.d;

/* compiled from: EncoderConfig */
public interface b<T extends b<T>> {
    <U> T a(Class<U> cls, d<? super U> dVar);
}
