package aa;

/* compiled from: Configurator */
public interface a {
}
