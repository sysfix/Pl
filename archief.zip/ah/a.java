package ah;

/* compiled from: Properties.kt */
public final class a {
}
