package a6;

/* compiled from: Transition */
public interface b<R> {
}
