package a6;

/* compiled from: NoTransition */
public class a<R> implements b<R> {

    /* renamed from: a  reason: collision with root package name */
    public static final a<?> f848a = new a<>();

    /* renamed from: b  reason: collision with root package name */
    public static final c<?> f849b = new C0012a();

    /* renamed from: a6.a$a  reason: collision with other inner class name */
    /* compiled from: NoTransition */
    public static class C0012a<R> implements c<R> {
    }
}
