package a6;

/* compiled from: TransitionFactory */
public interface c<R> {
}
