package a7;

import android.os.Parcelable;
import com.google.android.gms.common.data.DataHolder;

/* compiled from: com.google.android.gms:play-services-base@@18.2.0 */
public final class b implements Parcelable.Creator {
    /* JADX WARNING: type inference failed for: r2v9, types: [java.lang.Object[]] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object createFromParcel(android.os.Parcel r11) {
        /*
            r10 = this;
            int r0 = com.google.android.gms.common.internal.safeparcel.SafeParcelReader.w(r11)
            r1 = 0
            r2 = 0
            r4 = r1
            r7 = r4
            r5 = r2
            r6 = r5
            r8 = r6
        L_0x000b:
            int r2 = r11.dataPosition()
            if (r2 >= r0) goto L_0x0048
            int r2 = r11.readInt()
            char r3 = (char) r2
            r9 = 1
            if (r3 == r9) goto L_0x0043
            r9 = 2
            if (r3 == r9) goto L_0x0039
            r9 = 3
            if (r3 == r9) goto L_0x0034
            r9 = 4
            if (r3 == r9) goto L_0x002f
            r9 = 1000(0x3e8, float:1.401E-42)
            if (r3 == r9) goto L_0x002a
            com.google.android.gms.common.internal.safeparcel.SafeParcelReader.v(r11, r2)
            goto L_0x000b
        L_0x002a:
            int r4 = com.google.android.gms.common.internal.safeparcel.SafeParcelReader.r(r11, r2)
            goto L_0x000b
        L_0x002f:
            android.os.Bundle r8 = com.google.android.gms.common.internal.safeparcel.SafeParcelReader.c(r11, r2)
            goto L_0x000b
        L_0x0034:
            int r7 = com.google.android.gms.common.internal.safeparcel.SafeParcelReader.r(r11, r2)
            goto L_0x000b
        L_0x0039:
            android.os.Parcelable$Creator r3 = android.database.CursorWindow.CREATOR
            java.lang.Object[] r2 = com.google.android.gms.common.internal.safeparcel.SafeParcelReader.k(r11, r2, r3)
            r6 = r2
            android.database.CursorWindow[] r6 = (android.database.CursorWindow[]) r6
            goto L_0x000b
        L_0x0043:
            java.lang.String[] r5 = com.google.android.gms.common.internal.safeparcel.SafeParcelReader.i(r11, r2)
            goto L_0x000b
        L_0x0048:
            com.google.android.gms.common.internal.safeparcel.SafeParcelReader.m(r11, r0)
            com.google.android.gms.common.data.DataHolder r11 = new com.google.android.gms.common.data.DataHolder
            r3 = r11
            r3.<init>(r4, r5, r6, r7, r8)
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            r11.f6512r = r0
            r0 = r1
        L_0x0059:
            java.lang.String[] r2 = r11.f6511q
            int r3 = r2.length
            if (r0 >= r3) goto L_0x0068
            android.os.Bundle r3 = r11.f6512r
            r2 = r2[r0]
            r3.putInt(r2, r0)
            int r0 = r0 + 1
            goto L_0x0059
        L_0x0068:
            android.database.CursorWindow[] r0 = r11.f6513s
            int r0 = r0.length
            int[] r0 = new int[r0]
            r11.f6516v = r0
            r0 = r1
        L_0x0070:
            android.database.CursorWindow[] r2 = r11.f6513s
            int r3 = r2.length
            if (r1 >= r3) goto L_0x008e
            int[] r3 = r11.f6516v
            r3[r1] = r0
            r2 = r2[r1]
            int r2 = r2.getStartPosition()
            int r2 = r0 - r2
            android.database.CursorWindow[] r3 = r11.f6513s
            r3 = r3[r1]
            int r3 = r3.getNumRows()
            int r3 = r3 - r2
            int r0 = r0 + r3
            int r1 = r1 + 1
            goto L_0x0070
        L_0x008e:
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: a7.b.createFromParcel(android.os.Parcel):java.lang.Object");
    }

    public final /* synthetic */ Object[] newArray(int i10) {
        return new DataHolder[i10];
    }
}
