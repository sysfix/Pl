package a7;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import com.google.android.gms.common.data.BitmapTeleporter;
import com.google.android.gms.common.internal.safeparcel.SafeParcelReader;

/* compiled from: com.google.android.gms:play-services-base@@18.2.0 */
public final class a implements Parcelable.Creator {
    public final Object createFromParcel(Parcel parcel) {
        int w10 = SafeParcelReader.w(parcel);
        int i10 = 0;
        ParcelFileDescriptor parcelFileDescriptor = null;
        int i11 = 0;
        while (parcel.dataPosition() < w10) {
            int readInt = parcel.readInt();
            char c10 = (char) readInt;
            if (c10 == 1) {
                i10 = SafeParcelReader.r(parcel, readInt);
            } else if (c10 == 2) {
                parcelFileDescriptor = (ParcelFileDescriptor) SafeParcelReader.g(parcel, readInt, ParcelFileDescriptor.CREATOR);
            } else if (c10 != 3) {
                SafeParcelReader.v(parcel, readInt);
            } else {
                i11 = SafeParcelReader.r(parcel, readInt);
            }
        }
        SafeParcelReader.m(parcel, w10);
        return new BitmapTeleporter(i10, parcelFileDescriptor, i11);
    }

    public final /* synthetic */ Object[] newArray(int i10) {
        return new BitmapTeleporter[i10];
    }
}
