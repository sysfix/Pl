package aj;

import android.content.Context;
import android.os.Build;

/* compiled from: ImageStreamService */
public class j {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1087a;

    /* renamed from: b  reason: collision with root package name */
    public final c f1088b;

    public j(Context context) {
        this.f1087a = context.getApplicationContext();
        this.f1088b = new c(context, Build.VERSION.SDK_INT);
    }
}
