package aj;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import bb.c;
import java.util.List;

/* compiled from: MediaSource */
public class q {

    /* renamed from: a  reason: collision with root package name */
    public final s f1099a;

    /* renamed from: b  reason: collision with root package name */
    public final c f1100b;

    /* renamed from: c  reason: collision with root package name */
    public final Context f1101c;

    public q(Context context, s sVar, c cVar) {
        this.f1101c = context;
        this.f1099a = sVar;
        this.f1100b = cVar;
    }

    @TargetApi(19)
    public final Intent a(String str, boolean z10, List<String> list) {
        p.a("Belvedere", "Gallery Intent, using 'ACTION_OPEN_DOCUMENT'");
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.setType(str);
        intent.addCategory("android.intent.category.OPENABLE");
        intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", z10);
        if (list != null && !list.isEmpty()) {
            intent.putExtra("android.intent.extra.MIME_TYPES", (String[]) list.toArray(new String[0]));
        }
        return intent;
    }
}
