package aj;

import android.content.Context;

/* compiled from: ImageStreamCursorProvider */
public class c {

    /* renamed from: b  reason: collision with root package name */
    public static final String[] f1076b = {"_id", "_display_name", "_size", "width", "height"};

    /* renamed from: a  reason: collision with root package name */
    public final Context f1077a;

    public c(Context context, int i10) {
        this.f1077a = context;
    }
}
