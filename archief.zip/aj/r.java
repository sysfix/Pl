package aj;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import java.lang.ref.WeakReference;
import java.util.List;
import zendesk.belvedere.MediaResult;

/* compiled from: ResolveUriTask */
public class r extends AsyncTask<Uri, Void, List<MediaResult>> {

    /* renamed from: a  reason: collision with root package name */
    public final WeakReference<b<List<MediaResult>>> f1102a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f1103b;

    /* renamed from: c  reason: collision with root package name */
    public final s f1104c;

    /* renamed from: d  reason: collision with root package name */
    public final String f1105d;

    public r(Context context, s sVar, b<List<MediaResult>> bVar, String str) {
        this.f1103b = context;
        this.f1104c = sVar;
        this.f1105d = str;
        this.f1102a = new WeakReference<>(bVar);
    }

    public static void a(Context context, s sVar, b<List<MediaResult>> bVar, List<Uri> list, String str) {
        new r(context, sVar, bVar, str).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Uri[]) list.toArray(new Uri[list.size()]));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:108:0x01db, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:109:0x01dc, code lost:
        r27 = r3;
        r2 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:111:0x01e3, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:0x01e4, code lost:
        r32 = r2;
        r27 = r3;
        r2 = r4;
        r25 = r7;
        r26 = r8;
        r30 = r15;
        r9 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x021b, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:128:0x021c, code lost:
        r32 = r2;
        r1 = r3;
        r2 = r4;
        r25 = r7;
        r26 = r8;
        r30 = r15;
        r9 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00ec, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x00ed, code lost:
        r27 = r3;
        r28 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x00f2, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x00f3, code lost:
        r27 = r3;
        r28 = r4;
        r25 = r7;
        r26 = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x00fc, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x00fd, code lost:
        r27 = r3;
        r28 = r4;
        r25 = r7;
        r26 = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x010f, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x0110, code lost:
        r32 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x0119, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x011a, code lost:
        r32 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0145, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0146, code lost:
        r27 = r3;
        r3 = r0;
        r1 = r27;
        r2 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0151, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x0152, code lost:
        r32 = r2;
        r27 = r3;
        r28 = r4;
        r25 = r7;
        r26 = r8;
        r30 = r15;
        r9 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0163, code lost:
        r0 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0164, code lost:
        r32 = r2;
        r27 = r3;
        r28 = r4;
        r25 = r7;
        r26 = r8;
        r30 = r15;
        r9 = 1;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x01db A[ExcHandler: all (th java.lang.Throwable), Splitter:B:3:0x001e] */
    /* JADX WARNING: Removed duplicated region for block: B:111:0x01e3 A[ExcHandler: IOException (e java.io.IOException), Splitter:B:3:0x001e] */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x0202 A[SYNTHETIC, Splitter:B:116:0x0202] */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x020d A[SYNTHETIC, Splitter:B:121:0x020d] */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x0239 A[SYNTHETIC, Splitter:B:132:0x0239] */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x0244 A[SYNTHETIC, Splitter:B:137:0x0244] */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x025f A[SYNTHETIC, Splitter:B:145:0x025f] */
    /* JADX WARNING: Removed duplicated region for block: B:150:0x026a A[SYNTHETIC, Splitter:B:150:0x026a] */
    /* JADX WARNING: Removed duplicated region for block: B:159:0x024d A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00ec A[ExcHandler: all (th java.lang.Throwable), Splitter:B:15:0x0051] */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0145 A[ExcHandler: all (r0v32 'th' java.lang.Throwable A[CUSTOM_DECLARE]), Splitter:B:10:0x0037] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object doInBackground(java.lang.Object[] r32) {
        /*
            r31 = this;
            r1 = r31
            r2 = r32
            android.net.Uri[] r2 = (android.net.Uri[]) r2
            java.lang.String r3 = "Error closing FileOutputStream"
            java.lang.String r4 = "Error closing InputStream"
            java.lang.String r5 = "Belvedere"
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            r0 = 1048576(0x100000, float:1.469368E-39)
            byte[] r7 = new byte[r0]
            int r8 = r2.length
            r0 = 0
            r10 = r0
            r11 = r10
            r12 = 0
        L_0x001a:
            if (r12 >= r8) goto L_0x0274
            r15 = r2[r12]
            android.content.Context r0 = r1.f1103b     // Catch:{ FileNotFoundException -> 0x021b, IOException -> 0x01e3, all -> 0x01db }
            android.content.ContentResolver r0 = r0.getContentResolver()     // Catch:{ FileNotFoundException -> 0x01ce, IOException -> 0x01e3, all -> 0x01db }
            java.io.InputStream r10 = r0.openInputStream(r15)     // Catch:{ FileNotFoundException -> 0x01ce, IOException -> 0x01e3, all -> 0x01db }
            aj.s r0 = r1.f1104c     // Catch:{ FileNotFoundException -> 0x01ce, IOException -> 0x01e3, all -> 0x01db }
            android.content.Context r13 = r1.f1103b     // Catch:{ FileNotFoundException -> 0x01ce, IOException -> 0x01e3, all -> 0x01db }
            java.lang.String r14 = r1.f1105d     // Catch:{ FileNotFoundException -> 0x01ce, IOException -> 0x01e3, all -> 0x01db }
            java.io.File r14 = r0.c(r13, r15, r14)     // Catch:{ FileNotFoundException -> 0x01ce, IOException -> 0x01e3, all -> 0x01db }
            r0 = 2
            if (r10 == 0) goto L_0x0177
            if (r14 == 0) goto L_0x0177
            java.util.Locale r13 = java.util.Locale.US     // Catch:{ FileNotFoundException -> 0x0163, IOException -> 0x0151, all -> 0x0145 }
            java.lang.String r9 = "Copying media file into private cache - Uri: %s - Dest: %s"
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ FileNotFoundException -> 0x0163, IOException -> 0x0151, all -> 0x0145 }
            r16 = 0
            r0[r16] = r15     // Catch:{ FileNotFoundException -> 0x0163, IOException -> 0x0151, all -> 0x0145 }
            r16 = 1
            r0[r16] = r14     // Catch:{ FileNotFoundException -> 0x0135, IOException -> 0x0125, all -> 0x0145 }
            java.lang.String r0 = java.lang.String.format(r13, r9, r0)     // Catch:{ FileNotFoundException -> 0x0135, IOException -> 0x0125, all -> 0x0145 }
            aj.p.a(r5, r0)     // Catch:{ FileNotFoundException -> 0x0135, IOException -> 0x0125, all -> 0x0145 }
            java.io.FileOutputStream r9 = new java.io.FileOutputStream     // Catch:{ FileNotFoundException -> 0x0135, IOException -> 0x0125, all -> 0x0145 }
            r9.<init>(r14)     // Catch:{ FileNotFoundException -> 0x0135, IOException -> 0x0125, all -> 0x0145 }
        L_0x0051:
            int r0 = r10.read(r7)     // Catch:{ FileNotFoundException -> 0x0119, IOException -> 0x010f, all -> 0x00ec }
            if (r0 <= 0) goto L_0x0083
            r11 = 0
            r9.write(r7, r11, r0)     // Catch:{ FileNotFoundException -> 0x0073, IOException -> 0x0062, all -> 0x005c }
            goto L_0x0051
        L_0x005c:
            r0 = move-exception
            r1 = r3
            r2 = r4
            r11 = r9
            goto L_0x025c
        L_0x0062:
            r0 = move-exception
            r32 = r2
            r27 = r3
            r2 = r4
            r25 = r7
            r26 = r8
            r11 = r9
            r30 = r15
            r9 = r16
            goto L_0x01f0
        L_0x0073:
            r0 = move-exception
            r32 = r2
            r1 = r3
            r2 = r4
            r25 = r7
            r26 = r8
            r11 = r9
            r30 = r15
            r9 = r16
            goto L_0x0227
        L_0x0083:
            android.content.Context r0 = r1.f1103b     // Catch:{ FileNotFoundException -> 0x0119, IOException -> 0x010f, all -> 0x00ec }
            zendesk.belvedere.MediaResult r0 = aj.s.e(r0, r15)     // Catch:{ FileNotFoundException -> 0x0119, IOException -> 0x010f, all -> 0x00ec }
            zendesk.belvedere.MediaResult r11 = new zendesk.belvedere.MediaResult     // Catch:{ FileNotFoundException -> 0x0119, IOException -> 0x010f, all -> 0x00ec }
            aj.s r13 = r1.f1104c     // Catch:{ FileNotFoundException -> 0x0119, IOException -> 0x010f, all -> 0x00ec }
            r32 = r2
            android.content.Context r2 = r1.f1103b     // Catch:{ FileNotFoundException -> 0x00fc, IOException -> 0x00f2, all -> 0x00ec }
            android.net.Uri r2 = r13.d(r2, r14)     // Catch:{ FileNotFoundException -> 0x00fc, IOException -> 0x00f2, all -> 0x00ec }
            java.lang.String r17 = r14.getName()     // Catch:{ FileNotFoundException -> 0x00fc, IOException -> 0x00f2, all -> 0x00ec }
            java.lang.String r13 = r0.f19757t     // Catch:{ FileNotFoundException -> 0x00fc, IOException -> 0x00f2, all -> 0x00ec }
            r25 = r7
            r26 = r8
            long r7 = r0.f19758u     // Catch:{ FileNotFoundException -> 0x00e6, IOException -> 0x00e0, all -> 0x00ec }
            r27 = r3
            r28 = r4
            long r3 = r0.f19759v     // Catch:{ FileNotFoundException -> 0x00d8, IOException -> 0x00d0, all -> 0x00cc }
            long r0 = r0.f19760w     // Catch:{ FileNotFoundException -> 0x00d8, IOException -> 0x00d0, all -> 0x00cc }
            r18 = r13
            r13 = r11
            r29 = r9
            r9 = r16
            r30 = r15
            r15 = r2
            r16 = r30
            r19 = r7
            r21 = r3
            r23 = r0
            r13.<init>(r14, r15, r16, r17, r18, r19, r21, r23)     // Catch:{ FileNotFoundException -> 0x00c9, IOException -> 0x00c7, all -> 0x00c5 }
            r6.add(r11)     // Catch:{ FileNotFoundException -> 0x00c9, IOException -> 0x00c7, all -> 0x00c5 }
            r11 = r29
            goto L_0x01a8
        L_0x00c5:
            r0 = move-exception
            goto L_0x0106
        L_0x00c7:
            r0 = move-exception
            goto L_0x0113
        L_0x00c9:
            r0 = move-exception
            goto L_0x011d
        L_0x00cc:
            r0 = move-exception
        L_0x00cd:
            r29 = r9
            goto L_0x0106
        L_0x00d0:
            r0 = move-exception
        L_0x00d1:
            r29 = r9
            r30 = r15
            r9 = r16
            goto L_0x0113
        L_0x00d8:
            r0 = move-exception
        L_0x00d9:
            r29 = r9
            r30 = r15
            r9 = r16
            goto L_0x011d
        L_0x00e0:
            r0 = move-exception
            r27 = r3
            r28 = r4
            goto L_0x00d1
        L_0x00e6:
            r0 = move-exception
            r27 = r3
            r28 = r4
            goto L_0x00d9
        L_0x00ec:
            r0 = move-exception
            r27 = r3
            r28 = r4
            goto L_0x00cd
        L_0x00f2:
            r0 = move-exception
        L_0x00f3:
            r27 = r3
            r28 = r4
            r25 = r7
            r26 = r8
            goto L_0x00d1
        L_0x00fc:
            r0 = move-exception
        L_0x00fd:
            r27 = r3
            r28 = r4
            r25 = r7
            r26 = r8
            goto L_0x00d9
        L_0x0106:
            r3 = r0
            r1 = r27
            r2 = r28
            r11 = r29
            goto L_0x025d
        L_0x010f:
            r0 = move-exception
            r32 = r2
            goto L_0x00f3
        L_0x0113:
            r2 = r28
            r11 = r29
            goto L_0x01f0
        L_0x0119:
            r0 = move-exception
            r32 = r2
            goto L_0x00fd
        L_0x011d:
            r1 = r27
            r2 = r28
            r11 = r29
            goto L_0x0227
        L_0x0125:
            r0 = move-exception
            r32 = r2
            r27 = r3
            r28 = r4
            r25 = r7
            r26 = r8
            r30 = r15
            r9 = r16
            goto L_0x015f
        L_0x0135:
            r0 = move-exception
            r32 = r2
            r27 = r3
            r28 = r4
            r25 = r7
            r26 = r8
            r30 = r15
            r9 = r16
            goto L_0x0171
        L_0x0145:
            r0 = move-exception
            r27 = r3
            r28 = r4
            r3 = r0
            r1 = r27
            r2 = r28
            goto L_0x025d
        L_0x0151:
            r0 = move-exception
            r32 = r2
            r27 = r3
            r28 = r4
            r25 = r7
            r26 = r8
            r30 = r15
            r9 = 1
        L_0x015f:
            r2 = r28
            goto L_0x01f0
        L_0x0163:
            r0 = move-exception
            r32 = r2
            r27 = r3
            r28 = r4
            r25 = r7
            r26 = r8
            r30 = r15
            r9 = 1
        L_0x0171:
            r1 = r27
            r2 = r28
            goto L_0x0227
        L_0x0177:
            r32 = r2
            r27 = r3
            r28 = r4
            r25 = r7
            r26 = r8
            r30 = r15
            r9 = 1
            java.util.Locale r1 = java.util.Locale.US     // Catch:{ FileNotFoundException -> 0x01c7, IOException -> 0x01c5, all -> 0x01c1 }
            java.lang.String r2 = "Unable to resolve uri. InputStream null = %s, File null = %s"
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ FileNotFoundException -> 0x01c7, IOException -> 0x01c5, all -> 0x01c1 }
            if (r10 != 0) goto L_0x018e
            r3 = r9
            goto L_0x018f
        L_0x018e:
            r3 = 0
        L_0x018f:
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)     // Catch:{ FileNotFoundException -> 0x01c7, IOException -> 0x01c5, all -> 0x01c1 }
            r4 = 0
            r0[r4] = r3     // Catch:{ FileNotFoundException -> 0x01c7, IOException -> 0x01c5, all -> 0x01c1 }
            if (r14 != 0) goto L_0x019a
            r14 = r9
            goto L_0x019b
        L_0x019a:
            r14 = 0
        L_0x019b:
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r14)     // Catch:{ FileNotFoundException -> 0x01c7, IOException -> 0x01c5, all -> 0x01c1 }
            r0[r9] = r3     // Catch:{ FileNotFoundException -> 0x01c7, IOException -> 0x01c5, all -> 0x01c1 }
            java.lang.String r0 = java.lang.String.format(r1, r2, r0)     // Catch:{ FileNotFoundException -> 0x01c7, IOException -> 0x01c5, all -> 0x01c1 }
            aj.p.c(r5, r0)     // Catch:{ FileNotFoundException -> 0x01c7, IOException -> 0x01c5, all -> 0x01c1 }
        L_0x01a8:
            if (r10 == 0) goto L_0x01b6
            r10.close()     // Catch:{ IOException -> 0x01ae }
            goto L_0x01b6
        L_0x01ae:
            r0 = move-exception
            r1 = r0
            r2 = r28
            aj.p.b(r5, r2, r1)
            goto L_0x01b8
        L_0x01b6:
            r2 = r28
        L_0x01b8:
            if (r11 == 0) goto L_0x01bd
            r11.close()     // Catch:{ IOException -> 0x0211 }
        L_0x01bd:
            r1 = r27
            goto L_0x0217
        L_0x01c1:
            r0 = move-exception
            r2 = r28
            goto L_0x01df
        L_0x01c5:
            r0 = move-exception
            goto L_0x015f
        L_0x01c7:
            r0 = move-exception
            r2 = r28
            r1 = r27
            goto L_0x0227
        L_0x01ce:
            r0 = move-exception
            r32 = r2
            r2 = r4
            r25 = r7
            r26 = r8
            r30 = r15
            r9 = 1
            r1 = r3
            goto L_0x0227
        L_0x01db:
            r0 = move-exception
            r27 = r3
            r2 = r4
        L_0x01df:
            r1 = r27
            goto L_0x025c
        L_0x01e3:
            r0 = move-exception
            r32 = r2
            r27 = r3
            r2 = r4
            r25 = r7
            r26 = r8
            r30 = r15
            r9 = 1
        L_0x01f0:
            java.util.Locale r1 = java.util.Locale.US     // Catch:{ all -> 0x0219 }
            java.lang.String r3 = "IO Error copying file, uri: %s"
            java.lang.Object[] r4 = new java.lang.Object[r9]     // Catch:{ all -> 0x0219 }
            r7 = 0
            r4[r7] = r30     // Catch:{ all -> 0x0219 }
            java.lang.String r1 = java.lang.String.format(r1, r3, r4)     // Catch:{ all -> 0x0219 }
            aj.p.b(r5, r1, r0)     // Catch:{ all -> 0x0219 }
            if (r10 == 0) goto L_0x020b
            r10.close()     // Catch:{ IOException -> 0x0206 }
            goto L_0x020b
        L_0x0206:
            r0 = move-exception
            r1 = r0
            aj.p.b(r5, r2, r1)
        L_0x020b:
            if (r11 == 0) goto L_0x01bd
            r11.close()     // Catch:{ IOException -> 0x0211 }
            goto L_0x01bd
        L_0x0211:
            r0 = move-exception
            r1 = r27
            aj.p.b(r5, r1, r0)
        L_0x0217:
            r8 = 0
            goto L_0x024d
        L_0x0219:
            r0 = move-exception
            goto L_0x01df
        L_0x021b:
            r0 = move-exception
            r32 = r2
            r1 = r3
            r2 = r4
            r25 = r7
            r26 = r8
            r30 = r15
            r9 = 1
        L_0x0227:
            java.util.Locale r3 = java.util.Locale.US     // Catch:{ all -> 0x025b }
            java.lang.String r4 = "File not found error copying file, uri: %s"
            java.lang.Object[] r7 = new java.lang.Object[r9]     // Catch:{ all -> 0x025b }
            r8 = 0
            r7[r8] = r30     // Catch:{ all -> 0x025b }
            java.lang.String r3 = java.lang.String.format(r3, r4, r7)     // Catch:{ all -> 0x025b }
            aj.p.b(r5, r3, r0)     // Catch:{ all -> 0x025b }
            if (r10 == 0) goto L_0x0242
            r10.close()     // Catch:{ IOException -> 0x023d }
            goto L_0x0242
        L_0x023d:
            r0 = move-exception
            r3 = r0
            aj.p.b(r5, r2, r3)
        L_0x0242:
            if (r11 == 0) goto L_0x024d
            r11.close()     // Catch:{ IOException -> 0x0248 }
            goto L_0x024d
        L_0x0248:
            r0 = move-exception
            r3 = r0
            aj.p.b(r5, r1, r3)
        L_0x024d:
            int r12 = r12 + 1
            r3 = r1
            r4 = r2
            r7 = r25
            r8 = r26
            r1 = r31
            r2 = r32
            goto L_0x001a
        L_0x025b:
            r0 = move-exception
        L_0x025c:
            r3 = r0
        L_0x025d:
            if (r10 == 0) goto L_0x0268
            r10.close()     // Catch:{ IOException -> 0x0263 }
            goto L_0x0268
        L_0x0263:
            r0 = move-exception
            r4 = r0
            aj.p.b(r5, r2, r4)
        L_0x0268:
            if (r11 == 0) goto L_0x0273
            r11.close()     // Catch:{ IOException -> 0x026e }
            goto L_0x0273
        L_0x026e:
            r0 = move-exception
            r2 = r0
            aj.p.b(r5, r1, r2)
        L_0x0273:
            throw r3
        L_0x0274:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: aj.r.doInBackground(java.lang.Object[]):java.lang.Object");
    }

    public void onPostExecute(Object obj) {
        List list = (List) obj;
        super.onPostExecute(list);
        b bVar = (b) this.f1102a.get();
        if (bVar != null) {
            bVar.internalSuccess(list);
        } else {
            p.c("Belvedere", "Callback null");
        }
    }
}
