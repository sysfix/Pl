package aj;

import ai.plaud.android.plaud.R;
import android.view.View;
import android.widget.ImageView;
import zendesk.belvedere.MediaResult;
import zendesk.belvedere.c;

/* compiled from: ImageStreamItems */
public class e extends d {

    /* renamed from: e  reason: collision with root package name */
    public final int f1082e;

    /* renamed from: f  reason: collision with root package name */
    public final View.OnClickListener f1083f;

    public e(int i10, int i11, View.OnClickListener onClickListener, c cVar) {
        super(i10, (MediaResult) null);
        this.f1082e = i11;
        this.f1083f = onClickListener;
    }

    public void a(View view) {
        ((ImageView) view.findViewById(R.id.list_item_static_image)).setImageResource(this.f1082e);
        view.findViewById(R.id.list_item_static_click_area).setOnClickListener(this.f1083f);
    }
}
