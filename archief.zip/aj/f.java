package aj;

/* compiled from: ImageStreamMvp */
public interface f {
}
