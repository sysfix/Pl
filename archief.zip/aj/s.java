package aj;

import ai.plaud.android.plaud.R;
import aj.p;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.content.FileProvider;
import f.a;
import java.io.File;
import java.util.Locale;
import okhttp3.HttpUrl;
import zendesk.belvedere.MediaResult;

/* compiled from: Storage */
public class s {
    public static MediaResult e(Context context, Uri uri) {
        long j10;
        String str;
        String str2;
        boolean equals = "content".equals(uri.getScheme());
        String str3 = HttpUrl.FRAGMENT_ENCODE_SET;
        long j11 = -1;
        if (equals) {
            ContentResolver contentResolver = context.getContentResolver();
            Uri uri2 = uri;
            Cursor query = contentResolver.query(uri2, new String[]{"_size", "_display_name"}, (String) null, (String[]) null, (String) null);
            String type = contentResolver.getType(uri2);
            if (query != null) {
                try {
                    if (query.moveToFirst()) {
                        long j12 = query.getLong(query.getColumnIndex("_size"));
                        str3 = query.getString(query.getColumnIndex("_display_name"));
                        j11 = j12;
                    }
                } finally {
                    query.close();
                }
            }
            str2 = str3;
            j10 = j11;
            str = type;
        } else {
            Uri uri3 = uri;
            str2 = str3;
            str = str2;
            j10 = -1;
        }
        return new MediaResult((File) null, uri, uri, str2, str, j10, -1, -1);
    }

    public final File a(File file, String str, String str2) {
        StringBuilder a10 = a.a(str);
        if (TextUtils.isEmpty(str2)) {
            str2 = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        a10.append(str2);
        return new File(file, a10.toString());
    }

    public final File b(Context context, String str) {
        String str2;
        if (!TextUtils.isEmpty(str)) {
            StringBuilder a10 = a.a(str);
            a10.append(File.separator);
            str2 = a10.toString();
        } else {
            str2 = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(context.getCacheDir().getAbsolutePath());
        String str3 = File.separator;
        sb2.append(str3);
        sb2.append("belvedere-data-v2");
        sb2.append(str3);
        sb2.append(str2);
        File file = new File(sb2.toString());
        if (!file.isDirectory()) {
            file.mkdirs();
        }
        if (file.isDirectory()) {
            return file;
        }
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:31:0x00ba, code lost:
        r2 = r18.getLastPathSegment();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.io.File c(android.content.Context r17, android.net.Uri r18, java.lang.String r19) {
        /*
            r16 = this;
            r1 = r16
            boolean r0 = android.text.TextUtils.isEmpty(r19)
            if (r0 != 0) goto L_0x0017
            java.lang.String r0 = "user"
            java.lang.StringBuilder r0 = f.a.a(r0)
            java.lang.String r2 = java.io.File.separator
            r3 = r19
            java.lang.String r0 = c.d.a(r0, r2, r3)
            goto L_0x0019
        L_0x0017:
            java.lang.String r0 = "media"
        L_0x0019:
            r2 = r17
            java.io.File r0 = r1.b(r2, r0)
            r3 = 0
            if (r0 != 0) goto L_0x002a
            java.lang.String r0 = "Belvedere"
            java.lang.String r2 = "Error creating cache directory"
            aj.p.c(r0, r2)
            return r3
        L_0x002a:
            java.lang.String r4 = r18.getScheme()
            java.lang.String r5 = "content"
            boolean r6 = r5.equals(r4)
            java.lang.String r7 = ""
            java.lang.String r8 = "file"
            r9 = 0
            if (r6 == 0) goto L_0x0064
            java.lang.String r4 = "_display_name"
            java.lang.String[] r12 = new java.lang.String[]{r4}
            android.content.ContentResolver r10 = r17.getContentResolver()
            r13 = 0
            r14 = 0
            r15 = 0
            r11 = r18
            android.database.Cursor r4 = r10.query(r11, r12, r13, r14, r15)
            if (r4 == 0) goto L_0x006e
            boolean r6 = r4.moveToFirst()     // Catch:{ all -> 0x005f }
            if (r6 == 0) goto L_0x005b
            java.lang.String r6 = r4.getString(r9)     // Catch:{ all -> 0x005f }
            r7 = r6
        L_0x005b:
            r4.close()
            goto L_0x006e
        L_0x005f:
            r0 = move-exception
            r4.close()
            throw r0
        L_0x0064:
            boolean r4 = r8.equals(r4)
            if (r4 == 0) goto L_0x006e
            java.lang.String r7 = r18.getLastPathSegment()
        L_0x006e:
            boolean r4 = android.text.TextUtils.isEmpty(r7)
            if (r4 == 0) goto L_0x00dd
            java.text.SimpleDateFormat r3 = new java.text.SimpleDateFormat
            java.util.Locale r4 = java.util.Locale.US
            java.lang.String r6 = "yyyyMMddHHmmssSSS"
            r3.<init>(r6, r4)
            r6 = 1
            java.lang.Object[] r7 = new java.lang.Object[r6]
            java.util.Date r10 = new java.util.Date
            long r11 = java.lang.System.currentTimeMillis()
            r10.<init>(r11)
            java.lang.String r3 = r3.format(r10)
            r7[r9] = r3
            java.lang.String r3 = "attachment_%s"
            java.lang.String r7 = java.lang.String.format(r4, r3, r7)
            android.webkit.MimeTypeMap r3 = android.webkit.MimeTypeMap.getSingleton()
            java.lang.String r10 = r18.getScheme()
            boolean r5 = r5.equals(r10)
            if (r5 == 0) goto L_0x00b2
            android.content.ContentResolver r2 = r17.getContentResolver()
            r5 = r18
            java.lang.String r2 = r2.getType(r5)
            java.lang.String r2 = r3.getExtensionFromMimeType(r2)
            goto L_0x00d3
        L_0x00b2:
            r5 = r18
            boolean r2 = r8.equals(r10)
            if (r2 == 0) goto L_0x00d1
            java.lang.String r2 = r18.getLastPathSegment()
            java.lang.String r3 = "."
            int r3 = r2.lastIndexOf(r3)
            r5 = -1
            if (r3 == r5) goto L_0x00d1
            int r3 = r3 + r6
            int r5 = r2.length()
            java.lang.String r2 = r2.substring(r3, r5)
            goto L_0x00d3
        L_0x00d1:
            java.lang.String r2 = "tmp"
        L_0x00d3:
            java.lang.Object[] r3 = new java.lang.Object[r6]
            r3[r9] = r2
            java.lang.String r2 = ".%s"
            java.lang.String r3 = java.lang.String.format(r4, r2, r3)
        L_0x00dd:
            java.io.File r0 = r1.a(r0, r7, r3)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: aj.s.c(android.content.Context, android.net.Uri, java.lang.String):java.io.File");
    }

    public Uri d(Context context, File file) {
        String string = context.getString(R.string.belvedere_sdk_fpa_suffix_v2);
        String format = String.format(Locale.US, "%s%s", new Object[]{context.getPackageName(), string});
        try {
            return FileProvider.getUriForFile(context, format, file);
        } catch (IllegalArgumentException unused) {
            String format2 = String.format(Locale.US, "The selected file can't be shared %s", new Object[]{file.toString()});
            if (!((p.a) p.f1097a).f1098a) {
                return null;
            }
            Log.e("Belvedere", format2);
            return null;
        } catch (NullPointerException e10) {
            String format3 = String.format(Locale.US, "=====================\nFileProvider failed to retrieve file uri. There might be an issue with the FileProvider \nPlease make sure that manifest-merger is working, and that you have defined the applicationId (package name) in the build.gradle\nManifest merger: http://tools.android.com/tech-docs/new-build-system/user-guide/manifest-merger\nIf your are not able to use gradle or the manifest merger, please add the following to your AndroidManifest.xml:\n        <provider\n            android:name=\"com.zendesk.belvedere.BelvedereFileProvider\"\n            android:authorities=\"${applicationId}%s\"\n            android:exported=\"false\"\n            android:grantUriPermissions=\"true\">\n            <meta-data\n                android:name=\"android.support.FILE_PROVIDER_PATHS\"\n                android:resource=\"@xml/belvedere_attachment_storage_v2\" />\n        </provider>\n=====================", new Object[]{format});
            Log.e("Belvedere", format3, e10);
            p.b("Belvedere", format3, e10);
            throw new RuntimeException("Please specify your application id");
        }
    }
}
