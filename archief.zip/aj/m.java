package aj;

import android.view.View;
import java.lang.ref.WeakReference;
import java.util.List;
import zendesk.belvedere.MediaResult;
import zendesk.belvedere.a;
import zendesk.belvedere.f;
import zendesk.belvedere.i;
import zendesk.belvedere.k;

/* compiled from: ImageStreamUi */
public class m implements View.OnClickListener {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ k f1092p;

    public m(k kVar) {
        this.f1092p = kVar;
    }

    public void onClick(View view) {
        i iVar = this.f1092p.f19805a;
        List<MediaResult> list = ((f) iVar.f19798a).f19793c;
        for (WeakReference<a.d> weakReference : iVar.f19800c.f19770r) {
            a.d dVar = (a.d) weakReference.get();
            if (dVar != null) {
                dVar.a(list);
            }
        }
        this.f1092p.dismiss();
    }
}
