package aj;

import android.view.View;
import java.lang.ref.WeakReference;

/* compiled from: ImageStreamPresenter */
public class i implements View.OnClickListener {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ zendesk.belvedere.i f1086p;

    public i(zendesk.belvedere.i iVar) {
        this.f1086p = iVar;
    }

    public void onClick(View view) {
        t.b(new WeakReference(this.f1086p.f19800c.getActivity()));
    }
}
