package aj;

import ai.plaud.android.plaud.R;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;
import b1.a;
import java.lang.ref.WeakReference;
import java.util.Locale;
import uc.k;

/* compiled from: Utils */
public class t {

    /* compiled from: Utils */
    public static class a implements Runnable {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ com.google.android.material.bottomsheet.a f1106p;

        public a(com.google.android.material.bottomsheet.a aVar) {
            this.f1106p = aVar;
        }

        public void run() {
            this.f1106p.cancel();
        }
    }

    /* compiled from: Utils */
    public static class b implements View.OnClickListener {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ View.OnClickListener f1107p;

        /* renamed from: q  reason: collision with root package name */
        public final /* synthetic */ View f1108q;

        /* renamed from: r  reason: collision with root package name */
        public final /* synthetic */ com.google.android.material.bottomsheet.a f1109r;

        public b(View.OnClickListener onClickListener, View view, com.google.android.material.bottomsheet.a aVar) {
            this.f1107p = onClickListener;
            this.f1108q = view;
            this.f1109r = aVar;
        }

        public void onClick(View view) {
            this.f1107p.onClick(this.f1108q);
            this.f1109r.cancel();
        }
    }

    /* compiled from: Utils */
    public static class c implements DialogInterface.OnCancelListener {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ Handler f1110p;

        /* renamed from: q  reason: collision with root package name */
        public final /* synthetic */ Runnable f1111q;

        public c(Handler handler, Runnable runnable) {
            this.f1110p = handler;
            this.f1111q = runnable;
        }

        public void onCancel(DialogInterface dialogInterface) {
            this.f1110p.removeCallbacks(this.f1111q);
        }
    }

    /* compiled from: Utils */
    public static class d implements DialogInterface.OnDismissListener {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ Handler f1112p;

        /* renamed from: q  reason: collision with root package name */
        public final /* synthetic */ Runnable f1113q;

        public d(Handler handler, Runnable runnable) {
            this.f1112p = handler;
            this.f1113q = runnable;
        }

        public void onDismiss(DialogInterface dialogInterface) {
            this.f1112p.removeCallbacks(this.f1113q);
        }
    }

    /* compiled from: Utils */
    public static class e implements k {

        /* renamed from: a  reason: collision with root package name */
        public final int f1114a;

        public e(int i10, int i11) {
            this.f1114a = i10;
        }

        public String key() {
            return String.format(Locale.US, "rounded-%s-%s", new Object[]{Integer.valueOf(this.f1114a), 0});
        }

        public Bitmap transform(Bitmap bitmap) {
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            Shader.TileMode tileMode = Shader.TileMode.CLAMP;
            paint.setShader(new BitmapShader(bitmap, tileMode, tileMode));
            Bitmap createBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            float f10 = (float) 0;
            RectF rectF = new RectF(f10, f10, (float) (bitmap.getWidth() - 0), (float) (bitmap.getHeight() - 0));
            float f11 = (float) this.f1114a;
            canvas.drawRoundRect(rectF, f11, f11, paint);
            if (bitmap != createBitmap) {
                bitmap.recycle();
            }
            return createBitmap;
        }
    }

    public static int a(Context context, int i10) {
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(i10, typedValue, true)) {
            return -16777216;
        }
        int i11 = typedValue.resourceId;
        if (i11 == 0) {
            return typedValue.data;
        }
        Object obj = b1.a.f4191a;
        return a.d.a(context, i11);
    }

    public static void b(WeakReference<Activity> weakReference) {
        Intent intent = new Intent();
        intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", ((Activity) weakReference.get()).getPackageName(), (String) null));
        ((Activity) weakReference.get()).startActivity(intent);
    }

    public static void c(View view, String str, long j10, CharSequence charSequence, View.OnClickListener onClickListener) {
        com.google.android.material.bottomsheet.a aVar = new com.google.android.material.bottomsheet.a(view.getContext());
        Handler handler = new Handler();
        a aVar2 = new a(aVar);
        aVar.setContentView((int) R.layout.belvedere_bottom_sheet);
        TextView textView = (TextView) aVar.findViewById(R.id.belvedere_bottom_sheet_message_text);
        if (textView != null) {
            textView.setText(str);
        }
        TextView textView2 = (TextView) aVar.findViewById(R.id.belvedere_bottom_sheet_actions_text);
        if (textView2 != null) {
            textView2.setText(charSequence);
            textView2.setOnClickListener(new b(onClickListener, view, aVar));
        }
        aVar.setCancelable(true);
        aVar.setOnCancelListener(new c(handler, aVar2));
        aVar.setOnDismissListener(new d(handler, aVar2));
        aVar.show();
        handler.postDelayed(aVar2, j10);
    }

    public static void d(View view, boolean z10) {
        int i10 = 0;
        view.findViewById(R.id.image_stream_toolbar).setVisibility(z10 ? 0 : 8);
        View findViewById = view.findViewById(R.id.image_stream_toolbar_container);
        if (findViewById != null) {
            if (!z10) {
                i10 = 8;
            }
            findViewById.setVisibility(i10);
        }
    }
}
