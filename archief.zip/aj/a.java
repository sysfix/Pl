package aj;

import aj.p;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Pair;
import bb.c;
import c.d;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import zendesk.belvedere.MediaResult;

/* compiled from: Belvedere */
public class a {
    @SuppressLint({"StaticFieldLeak"})

    /* renamed from: e  reason: collision with root package name */
    public static a f1067e;

    /* renamed from: a  reason: collision with root package name */
    public final Context f1068a;

    /* renamed from: b  reason: collision with root package name */
    public s f1069b;

    /* renamed from: c  reason: collision with root package name */
    public c f1070c;

    /* renamed from: d  reason: collision with root package name */
    public q f1071d;

    /* renamed from: aj.a$a  reason: collision with other inner class name */
    /* compiled from: Belvedere */
    public static class C0015a {

        /* renamed from: a  reason: collision with root package name */
        public Context f1072a;

        /* renamed from: b  reason: collision with root package name */
        public p.b f1073b = new p.a();

        public C0015a(Context context) {
            this.f1072a = context.getApplicationContext();
        }
    }

    public a(C0015a aVar) {
        Context context = aVar.f1072a;
        this.f1068a = context;
        p.b bVar = aVar.f1073b;
        ((p.a) bVar).f1098a = false;
        p.f1097a = bVar;
        c cVar = new c(13);
        this.f1070c = cVar;
        s sVar = new s();
        this.f1069b = sVar;
        this.f1071d = new q(context, sVar, cVar);
        p.a("Belvedere", "Belvedere initialized");
    }

    public static a a(Context context) {
        synchronized (a.class) {
            if (f1067e == null) {
                if (context == null || context.getApplicationContext() == null) {
                    throw new IllegalArgumentException("Invalid context provided");
                }
                f1067e = new a(new C0015a(context.getApplicationContext()));
            }
        }
        return f1067e;
    }

    public MediaResult b(String str, String str2) {
        File file;
        Uri d10;
        long j10;
        long j11;
        s sVar = this.f1069b;
        Context context = this.f1068a;
        Objects.requireNonNull(sVar);
        String str3 = "user";
        if (!TextUtils.isEmpty(str)) {
            str3 = d.a(f.a.a(str3), File.separator, str);
        }
        File b10 = sVar.b(context, str3);
        if (b10 == null) {
            p.c("Belvedere", "Error creating cache directory");
            String str4 = str2;
            file = null;
        } else {
            file = sVar.a(b10, str2, (String) null);
        }
        p.a("Belvedere", String.format(Locale.US, "Get internal File: %s", new Object[]{file}));
        if (file == null || (d10 = this.f1069b.d(this.f1068a, file)) == null) {
            return null;
        }
        MediaResult e10 = s.e(this.f1068a, d10);
        if (e10.f19757t.contains("image")) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            Pair create = Pair.create(Integer.valueOf(options.outWidth), Integer.valueOf(options.outHeight));
            j11 = (long) ((Integer) create.first).intValue();
            j10 = (long) ((Integer) create.second).intValue();
        } else {
            j11 = -1;
            j10 = -1;
        }
        return new MediaResult(file, d10, d10, str2, e10.f19757t, e10.f19758u, j11, j10);
    }

    public void c(List<Uri> list, String str, b<List<MediaResult>> bVar) {
        if (list == null || list.size() <= 0) {
            bVar.internalSuccess(new ArrayList(0));
        } else {
            r.a(this.f1068a, this.f1069b, bVar, list, str);
        }
    }
}
