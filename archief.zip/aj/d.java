package aj;

import android.view.View;
import java.util.UUID;
import zendesk.belvedere.MediaResult;

/* compiled from: ImageStreamItems */
public abstract class d {

    /* renamed from: a  reason: collision with root package name */
    public final int f1078a;

    /* renamed from: b  reason: collision with root package name */
    public final long f1079b = ((long) UUID.randomUUID().hashCode());

    /* renamed from: c  reason: collision with root package name */
    public final MediaResult f1080c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1081d = false;

    public d(int i10, MediaResult mediaResult) {
        this.f1078a = i10;
        this.f1080c = mediaResult;
    }

    public abstract void a(View view);
}
