package aj;

import android.util.Log;

/* compiled from: L */
public class p {

    /* renamed from: a  reason: collision with root package name */
    public static b f1097a = new a();

    /* compiled from: L */
    public static class a implements b {

        /* renamed from: a  reason: collision with root package name */
        public boolean f1098a = false;
    }

    /* compiled from: L */
    public interface b {
    }

    public static void a(String str, String str2) {
        if (((a) f1097a).f1098a) {
            Log.d(str, str2);
        }
    }

    public static void b(String str, String str2, Throwable th2) {
        if (((a) f1097a).f1098a) {
            Log.e(str, str2, th2);
        }
    }

    public static void c(String str, String str2) {
        if (((a) f1097a).f1098a) {
            Log.w(str, str2);
        }
    }
}
