package aj;

import android.os.Handler;
import android.os.Looper;

/* compiled from: Callback */
public abstract class b<E> {
    private boolean canceled = false;

    /* compiled from: Callback */
    public class a implements Runnable {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ Object f1074p;

        public a(Object obj) {
            this.f1074p = obj;
        }

        public void run() {
            b.this.success(this.f1074p);
        }
    }

    public void cancel() {
        this.canceled = true;
    }

    public void internalSuccess(E e10) {
        if (!this.canceled) {
            new Handler(Looper.getMainLooper()).post(new a(e10));
        }
    }

    public abstract void success(E e10);
}
