package aj;

import android.content.Intent;
import android.view.View;
import zendesk.belvedere.MediaIntent;
import zendesk.belvedere.f;
import zendesk.belvedere.i;
import zendesk.belvedere.k;

/* compiled from: ImageStreamPresenter */
public class g implements View.OnClickListener {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ i f1084p;

    public g(i iVar) {
        this.f1084p = iVar;
    }

    public void onClick(View view) {
        i iVar = this.f1084p;
        zendesk.belvedere.g gVar = iVar.f19799b;
        MediaIntent a10 = ((f) iVar.f19798a).a();
        if (a10 == null) {
            a10 = null;
        } else {
            Intent intent = a10.f19750r;
            intent.setPackage("com.google.android.apps.photos");
            intent.setAction("android.intent.action.GET_CONTENT");
        }
        ((k) gVar).a(a10, this.f1084p.f19800c);
    }
}
