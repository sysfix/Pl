package aj;

import android.view.View;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import zendesk.belvedere.k;

/* compiled from: ImageStreamUi */
public class l extends BottomSheetBehavior.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ k f1091a;

    public l(k kVar) {
        this.f1091a = kVar;
    }

    public void a(View view, float f10) {
    }

    public void b(View view, int i10) {
        if (i10 == 5) {
            this.f1091a.dismiss();
        }
    }
}
