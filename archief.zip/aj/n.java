package aj;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;
import java.util.Iterator;
import java.util.List;
import zendesk.belvedere.k;

/* compiled from: ImageStreamUi */
public class n implements View.OnTouchListener {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ List f1093p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Activity f1094q;

    /* renamed from: r  reason: collision with root package name */
    public final /* synthetic */ k f1095r;

    public n(k kVar, List list, Activity activity) {
        this.f1095r = kVar;
        this.f1093p = list;
        this.f1094q = activity;
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouch(View view, MotionEvent motionEvent) {
        boolean z10;
        int rawX = (int) motionEvent.getRawX();
        int rawY = (int) motionEvent.getRawY();
        Iterator it = this.f1093p.iterator();
        while (true) {
            z10 = false;
            if (!it.hasNext()) {
                z10 = true;
                break;
            }
            View findViewById = this.f1094q.findViewById(((Integer) it.next()).intValue());
            if (findViewById != null) {
                Rect rect = new Rect();
                findViewById.getGlobalVisibleRect(rect);
                boolean z11 = rawX >= rect.left && rawX <= rect.right;
                boolean z12 = rawY >= rect.top && rawY <= rect.bottom;
                if (z11 && z12) {
                    this.f1094q.dispatchTouchEvent(MotionEvent.obtain(motionEvent));
                    break;
                }
            }
        }
        if (z10) {
            this.f1095r.dismiss();
        }
        return true;
    }
}
