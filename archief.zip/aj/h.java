package aj;

import android.os.Build;
import android.view.View;
import com.hjq.permissions.Permission;
import java.util.Arrays;
import zendesk.belvedere.a;
import zendesk.belvedere.f;
import zendesk.belvedere.i;
import zendesk.belvedere.k;

/* compiled from: ImageStreamPresenter */
public class h implements View.OnClickListener {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ i f1085p;

    public h(i iVar) {
        this.f1085p = iVar;
    }

    public void onClick(View view) {
        if (Build.VERSION.SDK_INT >= 33) {
            i iVar = this.f1085p;
            a aVar = iVar.f19800c;
            aVar.f19775w.a(aVar, Arrays.asList(new String[]{Permission.READ_MEDIA_AUDIO}), new zendesk.belvedere.h(iVar));
            return;
        }
        i iVar2 = this.f1085p;
        ((k) iVar2.f19799b).a(((f) iVar2.f19798a).a(), this.f1085p.f19800c);
    }
}
