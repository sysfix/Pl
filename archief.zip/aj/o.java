package aj;

import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

/* compiled from: KeyboardHelper */
public final class o implements Runnable {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ EditText f1096p;

    public o(EditText editText) {
        this.f1096p = editText;
    }

    public void run() {
        InputMethodManager inputMethodManager;
        if (this.f1096p.requestFocus() && (inputMethodManager = (InputMethodManager) this.f1096p.getContext().getSystemService("input_method")) != null) {
            inputMethodManager.showSoftInput(this.f1096p, 1);
        }
    }
}
