package aj;

import android.view.View;

/* compiled from: ImageStreamUi */
public class k implements View.OnClickListener {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ boolean f1089p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ zendesk.belvedere.k f1090q;

    public k(zendesk.belvedere.k kVar, boolean z10) {
        this.f1090q = kVar;
        this.f1089p = z10;
    }

    public void onClick(View view) {
        if (!this.f1089p) {
            this.f1090q.f19815k.m(4);
        } else {
            this.f1090q.dismiss();
        }
    }
}
