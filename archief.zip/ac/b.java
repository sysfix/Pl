package ac;

import io.flutter.embedding.engine.a;
import re.j;

/* compiled from: FlutterIsolatePlugin */
public class b {

    /* renamed from: a  reason: collision with root package name */
    public a f874a;

    /* renamed from: b  reason: collision with root package name */
    public String f875b;

    /* renamed from: c  reason: collision with root package name */
    public j f876c;

    /* renamed from: d  reason: collision with root package name */
    public Long f877d;

    /* renamed from: e  reason: collision with root package name */
    public j.d f878e;
}
