package ac;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Trace;
import android.util.Log;
import ef.b;
import ie.a;
import io.flutter.view.FlutterCallbackInformation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import le.a;
import re.c;
import re.d;
import re.i;
import re.j;

/* compiled from: FlutterIsolatePlugin */
public class a implements le.a, j.c, d.C0248d {

    /* renamed from: a  reason: collision with root package name */
    public Queue<b> f871a;

    /* renamed from: b  reason: collision with root package name */
    public Map<String, b> f872b;

    /* renamed from: c  reason: collision with root package name */
    public Context f873c;

    public final void a() {
        b peek = this.f871a.peek();
        ee.a.a().f10570a.a(this.f873c, (String[]) null);
        peek.f874a = new io.flutter.embedding.engine.a(this.f873c);
        FlutterCallbackInformation lookupCallbackInformation = FlutterCallbackInformation.lookupCallbackInformation(peek.f877d.longValue());
        String str = ee.a.a().f10570a.f13854d.f13845b;
        String str2 = lookupCallbackInformation.callbackLibraryPath;
        peek.f876c = new j(peek.f874a.f12224c.f12051s, "com.rmawatson.flutterisolate/control");
        new d(peek.f874a.f12224c.f12051s, "com.rmawatson.flutterisolate/event").a(this);
        peek.f876c.b(this);
        AssetManager assets = this.f873c.getAssets();
        a.b bVar = new a.b(assets, str, lookupCallbackInformation);
        ie.a aVar = peek.f874a.f12224c;
        if (aVar.f12052t) {
            Log.w("DartExecutor", "Attempted to run a DartExecutor that is already running.");
            return;
        }
        Trace.beginSection(b.a("DartExecutor#executeDartCallback"));
        try {
            Objects.toString(bVar);
            aVar.f12048p.runBundleAndSnapshotFromLibrary(str, lookupCallbackInformation.callbackName, lookupCallbackInformation.callbackLibraryPath, assets, (List<String>) null);
            aVar.f12052t = true;
            Trace.endSection();
            return;
        } catch (Throwable th2) {
            th.addSuppressed(th2);
        }
        throw th;
    }

    public void b(Object obj) {
    }

    public void d(a.b bVar) {
        c cVar = bVar.f14106b;
        this.f873c = bVar.f14105a;
        j jVar = new j(cVar, "com.rmawatson.flutterisolate/control");
        this.f871a = new LinkedList();
        this.f872b = new HashMap();
        jVar.b(this);
    }

    public void f(Object obj, d.b bVar) {
        if (this.f871a.size() != 0) {
            b remove = this.f871a.remove();
            d.c.a aVar = (d.c.a) bVar;
            aVar.a(remove.f875b);
            aVar.c();
            this.f872b.put(remove.f875b, remove);
            remove.f878e.a((Object) null);
            remove.f878e = null;
        }
        if (this.f871a.size() != 0) {
            a();
        }
    }

    public void g(i iVar, j.d dVar) {
        if (iVar.f16444a.equals("spawn_isolate")) {
            b bVar = new b();
            Object a10 = iVar.a("entry_point");
            if (a10 instanceof Long) {
                bVar.f877d = (Long) a10;
            }
            if (a10 instanceof Integer) {
                bVar.f877d = Long.valueOf((long) ((Integer) a10).intValue());
            }
            bVar.f875b = (String) iVar.a("isolate_id");
            bVar.f878e = dVar;
            this.f871a.add(bVar);
            if (this.f871a.size() == 1) {
                a();
            }
        } else if (iVar.f16444a.equals("kill_isolate")) {
            String str = (String) iVar.a("isolate_id");
            this.f872b.get(str).f874a.a();
            this.f872b.remove(str);
        } else if (iVar.f16444a.equals("get_isolate_list")) {
            dVar.a(new ArrayList(this.f872b.keySet()));
        } else if (iVar.f16444a.equals("kill_all_isolates")) {
            for (b bVar2 : this.f872b.values()) {
                bVar2.f874a.a();
            }
            this.f871a.clear();
            this.f872b.clear();
        } else {
            dVar.c();
        }
    }

    public void h(a.b bVar) {
    }
}
