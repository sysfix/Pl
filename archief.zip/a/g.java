package a;

import ai.plaud.android.plaud.component.dialog.InformationButtonDialog;
import ai.plaud.android.plaud.landing.LandingActivity;
import ai.plaud.android.plaud.splash.SplashActivity;
import android.app.Activity;
import com.google.common.collect.ImmutableSet;
import n.b;
import rg.d0;
import td.c;
import ud.a;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class g extends a0 {

    /* renamed from: a  reason: collision with root package name */
    public final Activity f596a;

    /* renamed from: b  reason: collision with root package name */
    public final p f597b;

    /* renamed from: c  reason: collision with root package name */
    public final k f598c;

    /* renamed from: d  reason: collision with root package name */
    public final g f599d = this;

    /* renamed from: e  reason: collision with root package name */
    public wf.a<InformationButtonDialog> f600e;

    /* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
    public static final class a<T> implements wf.a<T> {

        /* renamed from: a  reason: collision with root package name */
        public final g f601a;

        public a(p pVar, k kVar, g gVar, int i10) {
            this.f601a = gVar;
        }

        public T get() {
            Activity activity = this.f601a.f596a;
            d0.g(activity, "context");
            return new InformationButtonDialog(activity);
        }
    }

    public g(p pVar, k kVar, Activity activity, h hVar) {
        this.f597b = pVar;
        this.f598c = kVar;
        this.f596a = activity;
        wf.a aVar = new a(pVar, kVar, this, 0);
        Object obj = xd.a.f19005c;
        this.f600e = !(aVar instanceof xd.a) ? new xd.a(aVar) : aVar;
    }

    public a.c a() {
        return new a.c(ImmutableSet.of("ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel", "ai.plaud.android.plaud.anew.pages.login.LoginViewModel", "ai.plaud.android.plaud.anew.pages.register.RegisterViewModel"), new s(this.f597b, this.f598c, (r) null));
    }

    public void b(LandingActivity landingActivity) {
        landingActivity.f14765w = this.f597b.f613b.get();
        b bVar = this.f597b.f614c.get();
    }

    public c c() {
        return new n(this.f597b, this.f598c, this.f599d, (m) null);
    }

    public void d(SplashActivity splashActivity) {
        splashActivity.f14765w = this.f597b.f613b.get();
        b bVar = this.f597b.f614c.get();
    }
}
