package a;

import ad.b;
import ad.c;
import ad.d;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.util.JsonReader;
import androidx.arch.core.util.Function;
import bb.f;
import ci.a;
import com.google.android.datatransport.runtime.synchronization.SynchronizationException;
import com.google.firebase.components.ComponentRegistrar;
import com.google.firebase.perf.v1.NetworkRequestMetric;
import com.google.firebase.remoteconfig.internal.ConfigFetchHandler;
import dd.j;
import dd.r;
import i9.g;
import io.flutter.plugins.webviewflutter.GeneratedAndroidWebView;
import io.flutter.plugins.webviewflutter.s;
import io.flutter.plugins.webviewflutter.w;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Objects;
import okhttp3.HttpUrl;
import okhttp3.internal.ws.WebSocketProtocol;
import p6.n;
import q2.e;
import q9.b0;
import q9.d;
import r9.a;

public final /* synthetic */ class a implements b, di.b, c, d, Function, n.b, f.a, g, a.C0242a, f6.c, b8.f, GeneratedAndroidWebView.k.a, GeneratedAndroidWebView.z.a, GeneratedAndroidWebView.o.a, GeneratedAndroidWebView.w.a {
    public static final /* synthetic */ a A = new a(10);
    public static final /* synthetic */ a B = new a(11);
    public static final /* synthetic */ a C = new a(13);
    public static final /* synthetic */ a D = new a(15);
    public static final /* synthetic */ a E = new a(16);
    public static final /* synthetic */ a F = new a(17);
    public static final /* synthetic */ a G = new a(18);
    public static final /* synthetic */ a H = new a(19);
    public static final /* synthetic */ a I = new a(20);
    public static final /* synthetic */ a J = new a(21);
    public static final /* synthetic */ a K = new a(22);
    public static final /* synthetic */ a L = new a(23);
    public static final /* synthetic */ a M = new a(24);
    public static final /* synthetic */ a N = new a(25);
    public static final /* synthetic */ a O = new a(26);
    public static final /* synthetic */ a P = new a(27);
    public static final /* synthetic */ a Q = new a(28);
    public static final /* synthetic */ a R = new a(29);

    /* renamed from: q  reason: collision with root package name */
    public static final /* synthetic */ a f571q = new a(0);

    /* renamed from: r  reason: collision with root package name */
    public static final /* synthetic */ a f572r = new a(1);

    /* renamed from: s  reason: collision with root package name */
    public static final /* synthetic */ a f573s = new a(2);

    /* renamed from: t  reason: collision with root package name */
    public static final /* synthetic */ a f574t = new a(3);

    /* renamed from: u  reason: collision with root package name */
    public static final /* synthetic */ a f575u = new a(4);

    /* renamed from: v  reason: collision with root package name */
    public static final /* synthetic */ a f576v = new a(5);

    /* renamed from: w  reason: collision with root package name */
    public static final /* synthetic */ a f577w = new a(6);

    /* renamed from: x  reason: collision with root package name */
    public static final /* synthetic */ a f578x = new a(7);

    /* renamed from: y  reason: collision with root package name */
    public static final /* synthetic */ a f579y = new a(8);

    /* renamed from: z  reason: collision with root package name */
    public static final /* synthetic */ a f580z = new a(9);

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f581p;

    public /* synthetic */ a(int i10) {
        this.f581p = i10;
    }

    public void a(Object obj) {
        switch (this.f581p) {
            case AndroidVersion.ANDROID_6 /*23*/:
                Void voidR = (Void) obj;
                return;
            case AndroidVersion.ANDROID_7 /*24*/:
                Void voidR2 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_7_1 /*25*/:
                Void voidR3 = (Void) obj;
                int i10 = s.c.f12900h;
                return;
            case AndroidVersion.ANDROID_8 /*26*/:
                Void voidR4 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_8_1 /*27*/:
                Void voidR5 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_9 /*28*/:
                Void voidR6 = (Void) obj;
                int i11 = w.a.f12917d;
                return;
            default:
                Void voidR7 = (Void) obj;
                int i12 = w.c.f12920c;
                return;
        }
    }

    public Object apply(Object obj) {
        switch (this.f581p) {
            case NetworkRequestMetric.PERF_SESSIONS_FIELD_NUMBER /*13*/:
                q2.a aVar = (q2.a) obj;
                return null;
            case AndroidVersion.ANDROID_4_0 /*14*/:
                return Integer.valueOf(((e) obj).T());
            case WebSocketProtocol.B0_MASK_OPCODE /*15*/:
                f6.b bVar = n.f15429u;
                throw new SynchronizationException("Timed out while trying to open db.", (Throwable) obj);
            case 16:
                Cursor cursor = (Cursor) obj;
                f6.b bVar2 = n.f15429u;
                if (!cursor.moveToNext()) {
                    return null;
                }
                return Long.valueOf(cursor.getLong(0));
            default:
                return u9.a.f17299b.i((b0) obj).getBytes(Charset.forName("UTF-8"));
        }
    }

    public void b(fd.a aVar) {
        FlutterDeviceManager.m48configMethodChannel$lambda48$lambda47((fd.b) aVar);
    }

    public List c(ComponentRegistrar componentRegistrar) {
        return componentRegistrar.getComponents();
    }

    public Object d(JsonReader jsonReader) {
        switch (this.f581p) {
            case AndroidVersion.ANDROID_4_4 /*19*/:
                z9.a aVar = r9.a.f16362a;
                jsonReader.beginObject();
                String str = null;
                String str2 = null;
                String str3 = null;
                while (jsonReader.hasNext()) {
                    String a10 = c.a(jsonReader);
                    char c10 = 65535;
                    switch (a10.hashCode()) {
                        case -609862170:
                            if (a10.equals("libraryName")) {
                                c10 = 0;
                                break;
                            }
                            break;
                        case 3002454:
                            if (a10.equals("arch")) {
                                c10 = 1;
                                break;
                            }
                            break;
                        case 230943785:
                            if (a10.equals("buildId")) {
                                c10 = 2;
                                break;
                            }
                            break;
                    }
                    switch (c10) {
                        case 0:
                            str2 = jsonReader.nextString();
                            Objects.requireNonNull(str2, "Null libraryName");
                            break;
                        case 1:
                            str = jsonReader.nextString();
                            Objects.requireNonNull(str, "Null arch");
                            break;
                        case 2:
                            str3 = jsonReader.nextString();
                            Objects.requireNonNull(str3, "Null buildId");
                            break;
                        default:
                            jsonReader.skipValue();
                            break;
                    }
                }
                jsonReader.endObject();
                String str4 = str == null ? " arch" : HttpUrl.FRAGMENT_ENCODE_SET;
                if (str2 == null) {
                    str4 = d.a(str4, " libraryName");
                }
                if (str3 == null) {
                    str4 = d.a(str4, " buildId");
                }
                if (str4.isEmpty()) {
                    return new q9.d(str, str2, str3, (d.a) null);
                }
                throw new IllegalStateException(d.a("Missing required properties:", str4));
            default:
                return r9.a.a(jsonReader);
        }
    }

    public String extract(Object obj) {
        ApplicationInfo applicationInfo = ((Context) obj).getApplicationInfo();
        return applicationInfo != null ? String.valueOf(applicationInfo.targetSdkVersion) : HttpUrl.FRAGMENT_ENCODE_SET;
    }

    public void f(z1.c cVar) {
        switch (this.f581p) {
            case 4:
                FlutterDeviceManager.m13configMethodChannel$lambda48$lambda14((j) cVar);
                return;
            case 5:
                FlutterDeviceManager.m19configMethodChannel$lambda48$lambda20((j) cVar);
                return;
            case 8:
                FlutterDeviceManager.m36configMethodChannel$lambda48$lambda36((r) cVar);
                return;
            case 9:
                FlutterDeviceManager.m43configMethodChannel$lambda48$lambda42((dd.b0) cVar);
                return;
            default:
                FlutterDeviceManager.m11configMethodChannel$lambda48$lambda12((j) cVar);
                return;
        }
    }

    public void g(boolean z10) {
        switch (this.f581p) {
            case 0:
                a.C0057a aVar = ci.a.f4931a;
                aVar.a("BleSleepWorker setActive false:[" + z10 + "]", new Object[0]);
                return;
            case 2:
                FlutterDeviceManager.m60getStorage$lambda60(z10);
                return;
            case 3:
                FlutterDeviceManager.m62setDeviceName$lambda66(z10);
                return;
            case 6:
                FlutterDeviceManager.m24configMethodChannel$lambda48$lambda25(z10);
                return;
            default:
                FlutterDeviceManager.m31configMethodChannel$lambda48$lambda31(z10);
                return;
        }
    }

    public b8.g h(Object obj) {
        ConfigFetchHandler.a aVar = (ConfigFetchHandler.a) obj;
        return b8.j.e(null);
    }
}
