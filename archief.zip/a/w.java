package a;

import ad.b;
import ad.c;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import android.content.Context;
import android.os.Build;
import android.util.Base64;
import android.util.JsonReader;
import androidx.arch.core.util.Function;
import bb.f;
import ca.e;
import ci.a;
import com.google.android.datatransport.runtime.synchronization.SynchronizationException;
import dd.j;
import dd.l;
import dd.m;
import df.y;
import ga.a;
import i9.p;
import io.flutter.plugins.webviewflutter.GeneratedAndroidWebView;
import io.flutter.plugins.webviewflutter.WebViewHostApiImpl;
import io.flutter.plugins.webviewflutter.s;
import io.flutter.plugins.webviewflutter.w;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Objects;
import okhttp3.HttpUrl;
import p6.n;
import q9.g;
import r9.a;
import s3.b;

public final /* synthetic */ class w implements b, c, jf.b, Function, b.C0257b, n.b, f.a, a.C0134a, a.C0242a, b8.a, f6.c, y, GeneratedAndroidWebView.o.a, GeneratedAndroidWebView.z.a, GeneratedAndroidWebView.w.a {
    public static final /* synthetic */ w A = new w(10);
    public static final /* synthetic */ w B = new w(11);
    public static final /* synthetic */ w C = new w(12);
    public static final /* synthetic */ w D = new w(13);
    public static final /* synthetic */ w E = new w(14);
    public static final /* synthetic */ w F = new w(15);
    public static final /* synthetic */ w G = new w(16);
    public static final /* synthetic */ w H = new w(17);
    public static final /* synthetic */ w I = new w(18);
    public static final /* synthetic */ w J = new w(19);
    public static final /* synthetic */ w K = new w(20);
    public static final /* synthetic */ w L = new w(21);
    public static final /* synthetic */ w M = new w(22);
    public static final /* synthetic */ w N = new w(23);
    public static final /* synthetic */ w O = new w(24);
    public static final /* synthetic */ w P = new w(25);
    public static final /* synthetic */ w Q = new w(26);
    public static final /* synthetic */ w R = new w(27);

    /* renamed from: q  reason: collision with root package name */
    public static final /* synthetic */ w f638q = new w(0);

    /* renamed from: r  reason: collision with root package name */
    public static final /* synthetic */ w f639r = new w(1);

    /* renamed from: s  reason: collision with root package name */
    public static final /* synthetic */ w f640s = new w(2);

    /* renamed from: t  reason: collision with root package name */
    public static final /* synthetic */ w f641t = new w(3);

    /* renamed from: u  reason: collision with root package name */
    public static final /* synthetic */ w f642u = new w(4);

    /* renamed from: v  reason: collision with root package name */
    public static final /* synthetic */ w f643v = new w(5);

    /* renamed from: w  reason: collision with root package name */
    public static final /* synthetic */ w f644w = new w(6);

    /* renamed from: x  reason: collision with root package name */
    public static final /* synthetic */ w f645x = new w(7);

    /* renamed from: y  reason: collision with root package name */
    public static final /* synthetic */ w f646y = new w(8);

    /* renamed from: z  reason: collision with root package name */
    public static final /* synthetic */ w f647z = new w(9);

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f648p;

    public /* synthetic */ w(int i10) {
        this.f648p = i10;
    }

    public void a(Object obj) {
        switch (this.f648p) {
            case 20:
                Void voidR = (Void) obj;
                return;
            case AndroidVersion.ANDROID_5 /*21*/:
                Void voidR2 = (Void) obj;
                int i10 = s.c.f12900h;
                return;
            case AndroidVersion.ANDROID_5_1 /*22*/:
                Void voidR3 = (Void) obj;
                int i11 = s.c.f12900h;
                return;
            case AndroidVersion.ANDROID_6 /*23*/:
                Void voidR4 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_7 /*24*/:
                Void voidR5 = (Void) obj;
                int i12 = w.a.f12917d;
                return;
            case AndroidVersion.ANDROID_7_1 /*25*/:
                Void voidR6 = (Void) obj;
                int i13 = w.a.f12917d;
                return;
            case AndroidVersion.ANDROID_8 /*26*/:
                Void voidR7 = (Void) obj;
                int i14 = w.c.f12920c;
                return;
            default:
                Void voidR8 = (Void) obj;
                int i15 = WebViewHostApiImpl.WebViewPlatformView.f12848t;
                return;
        }
    }

    public void accept(Object obj) {
        Throwable th2 = (Throwable) obj;
    }

    public Object apply(Object obj) {
        switch (this.f648p) {
            case 12:
                return ((q2.a) obj).C();
            case AndroidVersion.ANDROID_4_0 /*14*/:
                f6.b bVar = n.f15429u;
                throw new SynchronizationException("Timed out while trying to acquire the lock.", (Throwable) obj);
            default:
                na.a aVar = (na.a) obj;
                Objects.requireNonNull(aVar);
                e eVar = ma.w.f14437a;
                Objects.requireNonNull(eVar);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    eVar.a(aVar, byteArrayOutputStream);
                } catch (IOException unused) {
                }
                return byteArrayOutputStream.toByteArray();
        }
    }

    public void c(ga.b bVar) {
        a.C0134a<Object> aVar = p.f11968c;
    }

    public Object d(JsonReader jsonReader) {
        z9.a aVar = r9.a.f16362a;
        jsonReader.beginObject();
        String str = null;
        byte[] bArr = null;
        while (jsonReader.hasNext()) {
            String nextName = jsonReader.nextName();
            Objects.requireNonNull(nextName);
            if (nextName.equals("filename")) {
                str = jsonReader.nextString();
                Objects.requireNonNull(str, "Null filename");
            } else if (!nextName.equals("contents")) {
                jsonReader.skipValue();
            } else {
                bArr = Base64.decode(jsonReader.nextString(), 2);
                Objects.requireNonNull(bArr, "Null contents");
            }
        }
        jsonReader.endObject();
        String str2 = str == null ? " filename" : HttpUrl.FRAGMENT_ENCODE_SET;
        if (bArr == null) {
            str2 = d.a(str2, " contents");
        }
        if (str2.isEmpty()) {
            return new g(str, bArr, (g.a) null);
        }
        throw new IllegalStateException(d.a("Missing required properties:", str2));
    }

    public String extract(Object obj) {
        Context context = (Context) obj;
        int i10 = Build.VERSION.SDK_INT;
        if (context.getPackageManager().hasSystemFeature("android.hardware.type.television")) {
            return "tv";
        }
        if (context.getPackageManager().hasSystemFeature("android.hardware.type.watch")) {
            return "watch";
        }
        if (context.getPackageManager().hasSystemFeature("android.hardware.type.automotive")) {
            return "auto";
        }
        return (i10 < 26 || !context.getPackageManager().hasSystemFeature("android.hardware.type.embedded")) ? HttpUrl.FRAGMENT_ENCODE_SET : "embedded";
    }

    public void f(z1.c cVar) {
        switch (this.f648p) {
            case 4:
                FlutterDeviceManager.m15configMethodChannel$lambda48$lambda16((j) cVar);
                return;
            case 5:
                FlutterDeviceManager.m21configMethodChannel$lambda48$lambda22((j) cVar);
                return;
            case 8:
                FlutterDeviceManager.m38configMethodChannel$lambda48$lambda38((m) cVar);
                return;
            default:
                FlutterDeviceManager.m52configMethodChannel$lambda48$lambda8((l) cVar);
                return;
        }
    }

    public void g(boolean z10) {
        switch (this.f648p) {
            case 0:
                a.C0057a aVar = ci.a.f4931a;
                aVar.a("BleSleepWorker setActive:[" + z10 + "]", new Object[0]);
                return;
            case 1:
                FlutterDeviceManager.m58getState$lambda68(z10);
                return;
            case 2:
                FlutterDeviceManager.m70syncTime$lambda0(z10);
                return;
            case 3:
                FlutterDeviceManager.m56getDeviceName$lambda64(z10);
                return;
            case 6:
                FlutterDeviceManager.m26configMethodChannel$lambda48$lambda27(z10);
                return;
            case 7:
                FlutterDeviceManager.m49configMethodChannel$lambda48$lambda5(z10);
                return;
            default:
                FlutterDeviceManager.m44configMethodChannel$lambda48$lambda43(z10);
                return;
        }
    }

    public Object k(b8.g gVar) {
        Object obj = ma.l.f14411b;
        return -1;
    }
}
