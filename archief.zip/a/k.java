package a;

import ud.d;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class k extends b0 {

    /* renamed from: a  reason: collision with root package name */
    public final p f603a;

    /* renamed from: b  reason: collision with root package name */
    public final k f604b = this;

    /* renamed from: c  reason: collision with root package name */
    public wf.a<qd.a> f605c;

    /* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
    public static final class a<T> implements wf.a<T> {
        public a(p pVar, k kVar, int i10) {
        }

        public T get() {
            return new d();
        }
    }

    public k(p pVar, l lVar) {
        this.f603a = pVar;
        wf.a aVar = new a(pVar, this, 0);
        Object obj = xd.a.f19005c;
        this.f605c = !(aVar instanceof xd.a) ? new xd.a(aVar) : aVar;
    }

    public td.a a() {
        return new f(this.f603a, this.f604b, (e) null);
    }

    public qd.a b() {
        return this.f605c.get();
    }
}
