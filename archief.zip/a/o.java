package a;

import ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordFragment;
import ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordSuccessFragment;
import ai.plaud.android.plaud.anew.pages.login.LoginFragment;
import ai.plaud.android.plaud.anew.pages.register.RegisterFragment;
import ai.plaud.android.plaud.component.dialog.InformationButtonDialog;
import ai.plaud.android.plaud.webview.WebViewFragment;
import androidx.fragment.app.Fragment;
import ud.a;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class o extends c0 {

    /* renamed from: a  reason: collision with root package name */
    public final p f610a;

    /* renamed from: b  reason: collision with root package name */
    public final g f611b;

    public o(p pVar, k kVar, g gVar, Fragment fragment) {
        this.f610a = pVar;
        this.f611b = gVar;
    }

    public a.c a() {
        return this.f611b.a();
    }

    public void b(WebViewFragment webViewFragment) {
        webViewFragment.f996s = this.f610a.f613b.get();
        webViewFragment.f999v = this.f610a.f615d.get();
    }

    public void c(LoginFragment loginFragment) {
        loginFragment.f996s = this.f610a.f613b.get();
        loginFragment.f999v = this.f610a.f615d.get();
        InformationButtonDialog informationButtonDialog = this.f611b.f600e.get();
    }

    public void d(ForgetPasswordSuccessFragment forgetPasswordSuccessFragment) {
        forgetPasswordSuccessFragment.f996s = this.f610a.f613b.get();
        forgetPasswordSuccessFragment.f999v = this.f610a.f615d.get();
    }

    public void e(RegisterFragment registerFragment) {
        registerFragment.f996s = this.f610a.f613b.get();
        registerFragment.f999v = this.f610a.f615d.get();
    }

    public void f(ForgetPasswordFragment forgetPasswordFragment) {
        forgetPasswordFragment.f996s = this.f610a.f613b.get();
        forgetPasswordFragment.f999v = this.f610a.f615d.get();
    }
}
