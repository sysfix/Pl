package a;

import ai.plaud.android.plaud.NiceBuildApplication;
import android.app.Application;
import dagger.hilt.android.internal.managers.d;
import dagger.hilt.android.internal.managers.e;
import wd.b;

/* compiled from: Hilt_NiceBuildApplication */
public abstract class v extends Application implements b {

    /* renamed from: p  reason: collision with root package name */
    public boolean f636p = false;

    /* renamed from: q  reason: collision with root package name */
    public final d f637q = new d(new a(this));

    /* compiled from: Hilt_NiceBuildApplication */
    public class a implements e {
        public a(v vVar) {
        }
    }

    public final Object a() {
        return this.f637q.a();
    }

    public void onCreate() {
        if (!this.f636p) {
            this.f636p = true;
            ((z) this.f637q.a()).b((NiceBuildApplication) this);
        }
        super.onCreate();
    }
}
