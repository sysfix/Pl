package a;

import androidx.lifecycle.SavedStateHandle;
import qd.c;
import td.d;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class s implements d {

    /* renamed from: a  reason: collision with root package name */
    public final p f624a;

    /* renamed from: b  reason: collision with root package name */
    public final k f625b;

    /* renamed from: c  reason: collision with root package name */
    public SavedStateHandle f626c;

    /* renamed from: d  reason: collision with root package name */
    public c f627d;

    public s(p pVar, k kVar, r rVar) {
        this.f624a = pVar;
        this.f625b = kVar;
    }
}
