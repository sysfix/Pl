package a;

import ai.plaud.android.plaud.NiceBuildApplication;
import ai.plaud.android.plaud.anew.api.network.interceptor.HttpLoggingInterceptor;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import b.c;
import com.google.common.collect.ImmutableSet;
import ff.j;
import hb.h;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import n.b;
import okhttp3.OkHttpClient;
import retrofit2.i;
import rg.d0;
import xh.f;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class p extends d0 {

    /* renamed from: a  reason: collision with root package name */
    public final p f612a = this;

    /* renamed from: b  reason: collision with root package name */
    public wf.a<n.a> f613b;

    /* renamed from: c  reason: collision with root package name */
    public wf.a<b> f614c;

    /* renamed from: d  reason: collision with root package name */
    public wf.a<p.b> f615d;

    /* renamed from: e  reason: collision with root package name */
    public wf.a<c> f616e;

    /* renamed from: f  reason: collision with root package name */
    public wf.a<OkHttpClient> f617f;

    /* renamed from: g  reason: collision with root package name */
    public wf.a<String> f618g;

    /* renamed from: h  reason: collision with root package name */
    public wf.a<b.a> f619h;

    /* renamed from: i  reason: collision with root package name */
    public wf.a<AuthRepository> f620i;

    /* renamed from: j  reason: collision with root package name */
    public wf.a<g.a> f621j;

    /* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
    public static final class a<T> implements wf.a<T> {

        /* renamed from: a  reason: collision with root package name */
        public final p f622a;

        /* renamed from: b  reason: collision with root package name */
        public final int f623b;

        public a(p pVar, int i10) {
            this.f622a = pVar;
            this.f623b = i10;
        }

        public T get() {
            switch (this.f623b) {
                case 0:
                    return new n.a();
                case 1:
                    uf.a.f17386a = w.B;
                    return new b();
                case 2:
                    return new p.b();
                case 3:
                    b.a aVar = this.f622a.f619h.get();
                    d0.g(aVar, "plaudApiService");
                    return new AuthRepository(aVar);
                case 4:
                    OkHttpClient okHttpClient = this.f622a.f617f.get();
                    String str = this.f622a.f618g.get();
                    d0.g(okHttpClient, "httpClient");
                    d0.g(str, "baseUrl");
                    i.b bVar = new i.b();
                    bVar.d(okHttpClient);
                    bVar.b(str);
                    bVar.f16511d.add(new yh.a(new h()));
                    bVar.f16512e.add(new f((j) null, false));
                    bVar.f16509b = new e.a(okHttpClient);
                    T b10 = bVar.c().b(b.a.class);
                    d0.f(b10, "Builder()\n            .c…udApiService::class.java)");
                    return (b.a) b10;
                case 5:
                    c cVar = this.f622a.f616e.get();
                    d0.g(cVar, "plaudAuthenticator");
                    OkHttpClient.Builder builder = new OkHttpClient.Builder();
                    TimeUnit timeUnit = TimeUnit.SECONDS;
                    OkHttpClient.Builder writeTimeout = builder.callTimeout(60, timeUnit).connectTimeout(60, timeUnit).readTimeout(60, timeUnit).writeTimeout(60, timeUnit);
                    HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor("HttpsLog- ");
                    HttpLoggingInterceptor.Level level = HttpLoggingInterceptor.Level.BODY;
                    Objects.requireNonNull(httpLoggingInterceptor.f895a, "printLevel == null. Use Level.NONE instead.");
                    httpLoggingInterceptor.f895a = level;
                    httpLoggingInterceptor.f896b = Level.INFO;
                    T build = writeTimeout.addInterceptor(httpLoggingInterceptor).addInterceptor(cVar).addInterceptor(new f.b()).build();
                    Objects.requireNonNull(build, "Cannot return null from a non-@Nullable @Provides method");
                    return build;
                case 6:
                    return new c();
                case 7:
                    return "https://api.plaud.ai/";
                case 8:
                    b.a aVar2 = this.f622a.f619h.get();
                    d0.g(aVar2, "plaudApiService");
                    return new g.a(aVar2);
                default:
                    throw new AssertionError(this.f623b);
            }
        }
    }

    public p(q qVar) {
        wf.a aVar = new a(this, 0);
        Object obj = xd.a.f19005c;
        this.f613b = !(aVar instanceof xd.a) ? new xd.a(aVar) : aVar;
        wf.a aVar2 = new a(this, 1);
        this.f614c = !(aVar2 instanceof xd.a) ? new xd.a(aVar2) : aVar2;
        wf.a aVar3 = new a(this, 2);
        this.f615d = !(aVar3 instanceof xd.a) ? new xd.a(aVar3) : aVar3;
        wf.a aVar4 = new a(this, 6);
        this.f616e = !(aVar4 instanceof xd.a) ? new xd.a(aVar4) : aVar4;
        wf.a aVar5 = new a(this, 5);
        this.f617f = !(aVar5 instanceof xd.a) ? new xd.a(aVar5) : aVar5;
        wf.a aVar6 = new a(this, 7);
        this.f618g = !(aVar6 instanceof xd.a) ? new xd.a(aVar6) : aVar6;
        wf.a aVar7 = new a(this, 4);
        this.f619h = !(aVar7 instanceof xd.a) ? new xd.a(aVar7) : aVar7;
        wf.a aVar8 = new a(this, 3);
        this.f620i = !(aVar8 instanceof xd.a) ? new xd.a(aVar8) : aVar8;
        wf.a aVar9 = new a(this, 8);
        this.f621j = !(aVar9 instanceof xd.a) ? new xd.a(aVar9) : aVar9;
    }

    public Set<Boolean> a() {
        return ImmutableSet.of();
    }

    public void b(NiceBuildApplication niceBuildApplication) {
    }

    public td.b c() {
        return new j(this.f612a, (i) null);
    }
}
