package a;

import ad.b;
import ad.c;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import android.content.Context;
import android.database.Cursor;
import android.util.Base64;
import android.util.JsonReader;
import androidx.arch.core.util.Function;
import bb.f;
import ci.a;
import com.google.firebase.FirebaseCommonRegistrar;
import dd.e0;
import dd.i;
import dd.o;
import dd.v;
import df.g;
import i6.j;
import i6.r;
import io.flutter.plugins.webviewflutter.GeneratedAndroidWebView;
import io.flutter.plugins.webviewflutter.WebViewHostApiImpl;
import io.flutter.plugins.webviewflutter.s;
import io.flutter.plugins.webviewflutter.w;
import java.util.ArrayList;
import java.util.Objects;
import okhttp3.HttpUrl;
import okhttp3.internal.ws.WebSocketProtocol;
import p6.n;
import q9.c0;
import q9.r;
import r9.a;

public final /* synthetic */ class x implements c, b, Function, n.b, f.a, a.C0242a, g, GeneratedAndroidWebView.o.a, GeneratedAndroidWebView.z.a, GeneratedAndroidWebView.w.a, WebViewHostApiImpl.WebViewPlatformView.a {
    public static final /* synthetic */ x A = new x(10);
    public static final /* synthetic */ x B = new x(11);
    public static final /* synthetic */ x C = new x(13);
    public static final /* synthetic */ x D = new x(14);
    public static final /* synthetic */ x E = new x(15);
    public static final /* synthetic */ x F = new x(16);
    public static final /* synthetic */ x G = new x(17);
    public static final /* synthetic */ x H = new x(18);
    public static final /* synthetic */ x I = new x(19);
    public static final /* synthetic */ x J = new x(20);
    public static final /* synthetic */ x K = new x(21);
    public static final /* synthetic */ x L = new x(22);

    /* renamed from: q  reason: collision with root package name */
    public static final /* synthetic */ x f649q = new x(0);

    /* renamed from: r  reason: collision with root package name */
    public static final /* synthetic */ x f650r = new x(1);

    /* renamed from: s  reason: collision with root package name */
    public static final /* synthetic */ x f651s = new x(2);

    /* renamed from: t  reason: collision with root package name */
    public static final /* synthetic */ x f652t = new x(3);

    /* renamed from: u  reason: collision with root package name */
    public static final /* synthetic */ x f653u = new x(4);

    /* renamed from: v  reason: collision with root package name */
    public static final /* synthetic */ x f654v = new x(5);

    /* renamed from: w  reason: collision with root package name */
    public static final /* synthetic */ x f655w = new x(6);

    /* renamed from: x  reason: collision with root package name */
    public static final /* synthetic */ x f656x = new x(7);

    /* renamed from: y  reason: collision with root package name */
    public static final /* synthetic */ x f657y = new x(8);

    /* renamed from: z  reason: collision with root package name */
    public static final /* synthetic */ x f658z = new x(9);

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f659p;

    public /* synthetic */ x(int i10) {
        this.f659p = i10;
    }

    public void a(Object obj) {
        switch (this.f659p) {
            case WebSocketProtocol.B0_MASK_OPCODE /*15*/:
                Void voidR = (Void) obj;
                return;
            case 16:
                Void voidR2 = (Void) obj;
                int i10 = s.c.f12900h;
                return;
            case AndroidVersion.ANDROID_4_2 /*17*/:
                Void voidR3 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_4_3 /*18*/:
                Void voidR4 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_4_4 /*19*/:
                Void voidR5 = (Void) obj;
                int i11 = w.a.f12917d;
                return;
            case 20:
                Void voidR6 = (Void) obj;
                int i12 = w.a.f12917d;
                return;
            default:
                Void voidR7 = (Void) obj;
                int i13 = w.c.f12920c;
                return;
        }
    }

    public Object apply(Object obj) {
        byte[] bArr;
        switch (this.f659p) {
            case 11:
                return ((q2.a) obj).i();
            default:
                Cursor cursor = (Cursor) obj;
                f6.b bVar = n.f15429u;
                ArrayList arrayList = new ArrayList();
                while (cursor.moveToNext()) {
                    r.a a10 = r.a();
                    a10.b(cursor.getString(1));
                    a10.c(s6.a.b(cursor.getInt(2)));
                    String string = cursor.getString(3);
                    if (string == null) {
                        bArr = null;
                    } else {
                        bArr = Base64.decode(string, 0);
                    }
                    j.b bVar2 = (j.b) a10;
                    bVar2.f11875b = bArr;
                    arrayList.add(bVar2.a());
                }
                return arrayList;
        }
    }

    public Object d(JsonReader jsonReader) {
        z9.a aVar = a.f16362a;
        jsonReader.beginObject();
        String str = null;
        Integer num = null;
        c0 c0Var = null;
        while (jsonReader.hasNext()) {
            String a10 = c.a(jsonReader);
            char c10 = 65535;
            switch (a10.hashCode()) {
                case -1266514778:
                    if (a10.equals("frames")) {
                        c10 = 0;
                        break;
                    }
                    break;
                case 3373707:
                    if (a10.equals("name")) {
                        c10 = 1;
                        break;
                    }
                    break;
                case 2125650548:
                    if (a10.equals("importance")) {
                        c10 = 2;
                        break;
                    }
                    break;
            }
            switch (c10) {
                case 0:
                    c0Var = a.d(jsonReader, a.I);
                    break;
                case 1:
                    str = jsonReader.nextString();
                    Objects.requireNonNull(str, "Null name");
                    break;
                case 2:
                    num = Integer.valueOf(jsonReader.nextInt());
                    break;
                default:
                    jsonReader.skipValue();
                    break;
            }
        }
        jsonReader.endObject();
        String str2 = str == null ? " name" : HttpUrl.FRAGMENT_ENCODE_SET;
        if (num == null) {
            str2 = d.a(str2, " importance");
        }
        if (c0Var == null) {
            str2 = d.a(str2, " frames");
        }
        if (str2.isEmpty()) {
            return new q9.r(str, num.intValue(), c0Var, (r.a) null);
        }
        throw new IllegalStateException(d.a("Missing required properties:", str2));
    }

    public String extract(Object obj) {
        Context context = (Context) obj;
        String installerPackageName = context.getPackageManager().getInstallerPackageName(context.getPackageName());
        return installerPackageName != null ? FirebaseCommonRegistrar.a(installerPackageName) : HttpUrl.FRAGMENT_ENCODE_SET;
    }

    public void f(z1.c cVar) {
        switch (this.f659p) {
            case 0:
                a.C0057a aVar = ci.a.f4931a;
                aVar.a("BleSleepWorker setActive result:[" + ((dd.a) cVar) + "]", new Object[0]);
                return;
            case 1:
                FlutterDeviceManager.m59getState$lambda69((o) cVar);
                return;
            case 2:
                FlutterDeviceManager.m71syncTime$lambda2((e0) cVar);
                return;
            case 3:
                FlutterDeviceManager.m57getDeviceName$lambda65((dd.g) cVar);
                return;
            case 5:
                FlutterDeviceManager.m40configMethodChannel$lambda48$lambda4((dd.s) cVar);
                return;
            case 6:
                FlutterDeviceManager.m27configMethodChannel$lambda48$lambda28((v) cVar);
                return;
            default:
                FlutterDeviceManager.m45configMethodChannel$lambda48$lambda44((i) cVar);
                return;
        }
    }

    public void g(boolean z10) {
        switch (this.f659p) {
            case 4:
                FlutterDeviceManager.m16configMethodChannel$lambda48$lambda17(z10);
                return;
            case 7:
                FlutterDeviceManager.m33configMethodChannel$lambda48$lambda33(z10);
                return;
            case 8:
                FlutterDeviceManager.m39configMethodChannel$lambda48$lambda39(z10);
                return;
            default:
                FlutterDeviceManager.m53configMethodChannel$lambda48$lambda9(z10);
                return;
        }
    }
}
