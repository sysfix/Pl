package a;

public final /* synthetic */ class d {
    public static String a(String str, String str2) {
        return str + str2;
    }
}
