package a;

import android.app.Activity;
import td.a;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class f implements a {

    /* renamed from: a  reason: collision with root package name */
    public final p f593a;

    /* renamed from: b  reason: collision with root package name */
    public final k f594b;

    /* renamed from: c  reason: collision with root package name */
    public Activity f595c;

    public f(p pVar, k kVar, e eVar) {
        this.f593a = pVar;
        this.f594b = kVar;
    }
}
