package a;

import android.util.JsonReader;
import java.util.Objects;

public final /* synthetic */ class c {
    public static String a(JsonReader jsonReader) {
        String nextName = jsonReader.nextName();
        Objects.requireNonNull(nextName);
        return nextName;
    }
}
