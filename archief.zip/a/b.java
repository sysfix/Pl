package a;

import ad.c;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.os.Build;
import android.util.JsonReader;
import androidx.arch.core.util.Function;
import bb.f;
import ci.a;
import com.google.firebase.perf.v1.NetworkRequestMetric;
import com.google.firebase.perf.v1.g;
import dd.j;
import dd.u;
import dd.y;
import df.k;
import df.s;
import df.v;
import di.a;
import io.flutter.plugins.webviewflutter.GeneratedAndroidWebView;
import io.flutter.plugins.webviewflutter.s;
import io.flutter.plugins.webviewflutter.w;
import java.util.ArrayList;
import okhttp3.HttpUrl;
import p6.n;
import r9.a;

public final /* synthetic */ class b implements c, a, ad.b, Function, n.b, f.a, a.C0242a, f6.c, v, k, GeneratedAndroidWebView.o.a, GeneratedAndroidWebView.z.a, GeneratedAndroidWebView.w.a, s {
    public static final /* synthetic */ b A = new b(10);
    public static final /* synthetic */ b B = new b(11);
    public static final /* synthetic */ b C = new b(13);
    public static final /* synthetic */ b D = new b(14);
    public static final /* synthetic */ b E = new b(15);
    public static final /* synthetic */ b F = new b(16);
    public static final /* synthetic */ b G = new b(17);
    public static final /* synthetic */ b H = new b(18);
    public static final /* synthetic */ b I = new b(19);
    public static final /* synthetic */ b J = new b(20);
    public static final /* synthetic */ b K = new b(21);
    public static final /* synthetic */ b L = new b(22);
    public static final /* synthetic */ b M = new b(23);
    public static final /* synthetic */ b N = new b(24);
    public static final /* synthetic */ b O = new b(25);

    /* renamed from: q  reason: collision with root package name */
    public static final /* synthetic */ b f582q = new b(0);

    /* renamed from: r  reason: collision with root package name */
    public static final /* synthetic */ b f583r = new b(1);

    /* renamed from: s  reason: collision with root package name */
    public static final /* synthetic */ b f584s = new b(2);

    /* renamed from: t  reason: collision with root package name */
    public static final /* synthetic */ b f585t = new b(3);

    /* renamed from: u  reason: collision with root package name */
    public static final /* synthetic */ b f586u = new b(4);

    /* renamed from: v  reason: collision with root package name */
    public static final /* synthetic */ b f587v = new b(5);

    /* renamed from: w  reason: collision with root package name */
    public static final /* synthetic */ b f588w = new b(6);

    /* renamed from: x  reason: collision with root package name */
    public static final /* synthetic */ b f589x = new b(7);

    /* renamed from: y  reason: collision with root package name */
    public static final /* synthetic */ b f590y = new b(8);

    /* renamed from: z  reason: collision with root package name */
    public static final /* synthetic */ b f591z = new b(9);

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f592p;

    public /* synthetic */ b(int i10) {
        this.f592p = i10;
    }

    public void a(Object obj) {
        switch (this.f592p) {
            case AndroidVersion.ANDROID_4_3 /*18*/:
                Void voidR = (Void) obj;
                return;
            case AndroidVersion.ANDROID_4_4 /*19*/:
                Void voidR2 = (Void) obj;
                return;
            case 20:
                Void voidR3 = (Void) obj;
                int i10 = s.c.f12900h;
                return;
            case AndroidVersion.ANDROID_5 /*21*/:
                Void voidR4 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_5_1 /*22*/:
                Void voidR5 = (Void) obj;
                int i11 = w.a.f12917d;
                return;
            case AndroidVersion.ANDROID_6 /*23*/:
                Void voidR6 = (Void) obj;
                int i12 = w.a.f12917d;
                return;
            case AndroidVersion.ANDROID_7 /*24*/:
                Void voidR7 = (Void) obj;
                int i13 = w.c.f12920c;
                return;
            default:
                Void voidR8 = (Void) obj;
                return;
        }
    }

    public Object apply(Object obj) {
        switch (this.f592p) {
            case 11:
                return Boolean.valueOf(((q2.a) obj).n0());
            case NetworkRequestMetric.PERF_SESSIONS_FIELD_NUMBER /*13*/:
                Cursor cursor = (Cursor) obj;
                f6.b bVar = n.f15429u;
                if (cursor.moveToNext()) {
                    return Long.valueOf(cursor.getLong(0));
                }
                return 0L;
            case AndroidVersion.ANDROID_4_0 /*14*/:
                Cursor cursor2 = (Cursor) obj;
                f6.b bVar2 = n.f15429u;
                ArrayList arrayList = new ArrayList();
                int i10 = 0;
                while (cursor2.moveToNext()) {
                    byte[] blob = cursor2.getBlob(0);
                    arrayList.add(blob);
                    i10 += blob.length;
                }
                byte[] bArr = new byte[i10];
                int i11 = 0;
                for (int i12 = 0; i12 < arrayList.size(); i12++) {
                    byte[] bArr2 = (byte[]) arrayList.get(i12);
                    System.arraycopy(bArr2, 0, bArr, i11, bArr2.length);
                    i11 += bArr2.length;
                }
                return bArr;
            default:
                return ((g) obj).s();
        }
    }

    public Object d(JsonReader jsonReader) {
        return r9.a.e(jsonReader);
    }

    public String extract(Object obj) {
        ApplicationInfo applicationInfo = ((Context) obj).getApplicationInfo();
        return (applicationInfo == null || Build.VERSION.SDK_INT < 24) ? HttpUrl.FRAGMENT_ENCODE_SET : String.valueOf(applicationInfo.minSdkVersion);
    }

    public void f(z1.c cVar) {
        switch (this.f592p) {
            case 0:
                a.C0057a aVar = ci.a.f4931a;
                aVar.a("BleSleepWorker setActive false:[" + ((dd.a) cVar) + "]", new Object[0]);
                return;
            case 2:
                FlutterDeviceManager.m61getStorage$lambda61((y) cVar);
                return;
            case 3:
                FlutterDeviceManager.m63setDeviceName$lambda67((dd.g) cVar);
                return;
            case 6:
                FlutterDeviceManager.m25configMethodChannel$lambda48$lambda26((j) cVar);
                return;
            case 7:
                FlutterDeviceManager.m32configMethodChannel$lambda48$lambda32((u) cVar);
                return;
            default:
                FlutterDeviceManager.m50configMethodChannel$lambda48$lambda6((j) cVar);
                return;
        }
    }

    public void g(boolean z10) {
        switch (this.f592p) {
            case 4:
                FlutterDeviceManager.m14configMethodChannel$lambda48$lambda15(z10);
                return;
            case 5:
                FlutterDeviceManager.m20configMethodChannel$lambda48$lambda21(z10);
                return;
            case 8:
                FlutterDeviceManager.m37configMethodChannel$lambda48$lambda37(z10);
                return;
            default:
                FlutterDeviceManager.m51configMethodChannel$lambda48$lambda7(z10);
                return;
        }
    }
}
