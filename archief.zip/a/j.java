package a;

import td.b;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class j implements b {

    /* renamed from: a  reason: collision with root package name */
    public final p f602a;

    public j(p pVar, i iVar) {
        this.f602a = pVar;
    }
}
