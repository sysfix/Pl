package a;

import androidx.fragment.app.Fragment;
import td.c;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class n implements c {

    /* renamed from: a  reason: collision with root package name */
    public final p f606a;

    /* renamed from: b  reason: collision with root package name */
    public final k f607b;

    /* renamed from: c  reason: collision with root package name */
    public final g f608c;

    /* renamed from: d  reason: collision with root package name */
    public Fragment f609d;

    public n(p pVar, k kVar, g gVar, m mVar) {
        this.f606a = pVar;
        this.f607b = kVar;
        this.f608c = gVar;
    }
}
