package a;

import ai.plaud.android.plaud.NiceBuildApplication;

/* compiled from: NiceBuildApplication_GeneratedInjector */
public interface z {
    void b(NiceBuildApplication niceBuildApplication);
}
