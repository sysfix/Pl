package a;

import ai.plaud.android.plaud.BleSleepWorker;
import ai.plaud.android.plaud.NiceBuildApplication;
import ai.plaud.android.plaud.anew.flutter.data.FlutterDataManager;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import androidx.work.ExistingWorkPolicy;
import ci.a;
import e3.k;
import f3.f;
import f3.j;
import io.flutter.embedding.android.FlutterActivity;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import q3.b;
import rg.d0;

/* compiled from: NiceBuildApplication.kt */
public final class y implements Application.ActivityLifecycleCallbacks {
    public void onActivityCreated(Activity activity, Bundle bundle) {
        d0.g(activity, "activity");
        a.C0057a aVar = a.f4931a;
        aVar.d("onActivityCreated activity " + activity, new Object[0]);
        if (activity instanceof FlutterActivity) {
            FlutterDataManager flutterDataManager = FlutterDataManager.INSTANCE;
            PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
            flutterDataManager.sendUserInfo(PreferencesUtil.d().b("user_id_key"), PreferencesUtil.d().b("accessToken_key"));
        }
    }

    public void onActivityDestroyed(Activity activity) {
        d0.g(activity, "activity");
        a.C0057a aVar = a.f4931a;
        aVar.d("onActivityDestroyed activity " + activity, new Object[0]);
    }

    public void onActivityPaused(Activity activity) {
        d0.g(activity, "activity");
        NiceBuildApplication.f891r = true;
        a.C0057a aVar = a.f4931a;
        aVar.d("onActivityPaused activity " + activity, new Object[0]);
        if (activity instanceof FlutterActivity) {
            k.a aVar2 = new k.a(BleSleepWorker.class);
            TimeUnit timeUnit = TimeUnit.SECONDS;
            aVar2.f10409b.f14575g = timeUnit.toMillis(15);
            if (Long.MAX_VALUE - System.currentTimeMillis() > aVar2.f10409b.f14575g) {
                aVar2.f10410c.add("WORK_TAG_BLE_SLEEP");
                j a10 = j.a(AppProvider.a());
                ExistingWorkPolicy existingWorkPolicy = ExistingWorkPolicy.REPLACE;
                Objects.requireNonNull(a10);
                new f(a10, "WORK_NAME_BLE_SLEEP", existingWorkPolicy, Collections.singletonList((k) aVar2.a()), (List<f>) null).o();
                return;
            }
            throw new IllegalArgumentException("The given initial delay is too large and will cause an overflow!");
        }
    }

    public void onActivityResumed(Activity activity) {
        d0.g(activity, "activity");
        NiceBuildApplication.f891r = false;
        a.C0057a aVar = a.f4931a;
        aVar.d("onActivityResumed activity " + activity, new Object[0]);
        if (activity instanceof FlutterActivity) {
            j a10 = j.a(AppProvider.a());
            Objects.requireNonNull(a10);
            ((b) a10.f10664d).f15675a.execute(new o3.b(a10, "WORK_NAME_BLE_SLEEP", true));
            FlutterDeviceManager.INSTANCE.getBleAgent().p(true, w.f638q, x.f649q);
        }
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        d0.g(activity, "activity");
        d0.g(bundle, "outState");
        a.C0057a aVar = a.f4931a;
        aVar.d("onActivitySaveInstanceState activity " + activity, new Object[0]);
    }

    public void onActivityStarted(Activity activity) {
        d0.g(activity, "activity");
        a.C0057a aVar = a.f4931a;
        aVar.d("onActivityStarted activity " + activity, new Object[0]);
    }

    public void onActivityStopped(Activity activity) {
        d0.g(activity, "activity");
        a.C0057a aVar = a.f4931a;
        aVar.d("onActivityPaused activity " + activity, new Object[0]);
    }
}
