package a;

import ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel;
import ai.plaud.android.plaud.anew.pages.login.LoginViewModel;
import ai.plaud.android.plaud.anew.pages.register.RegisterViewModel;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;
import com.google.common.collect.ImmutableMap;
import java.util.Map;
import qd.c;

/* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
public final class t extends e0 {

    /* renamed from: a  reason: collision with root package name */
    public final p f628a;

    /* renamed from: b  reason: collision with root package name */
    public final k f629b;

    /* renamed from: c  reason: collision with root package name */
    public final t f630c = this;

    /* renamed from: d  reason: collision with root package name */
    public wf.a<ForgetPasswordViewModel> f631d;

    /* renamed from: e  reason: collision with root package name */
    public wf.a<LoginViewModel> f632e;

    /* renamed from: f  reason: collision with root package name */
    public wf.a<RegisterViewModel> f633f;

    /* compiled from: DaggerNiceBuildApplication_HiltComponents_SingletonC */
    public static final class a<T> implements wf.a<T> {

        /* renamed from: a  reason: collision with root package name */
        public final p f634a;

        /* renamed from: b  reason: collision with root package name */
        public final int f635b;

        public a(p pVar, k kVar, t tVar, int i10) {
            this.f634a = pVar;
            this.f635b = i10;
        }

        public T get() {
            int i10 = this.f635b;
            if (i10 == 0) {
                return new ForgetPasswordViewModel(this.f634a.f613b.get(), this.f634a.f620i.get());
            }
            if (i10 == 1) {
                return new LoginViewModel(this.f634a.f613b.get(), this.f634a.f620i.get(), this.f634a.f621j.get());
            }
            if (i10 == 2) {
                return new RegisterViewModel(this.f634a.f613b.get(), this.f634a.f620i.get());
            }
            throw new AssertionError(this.f635b);
        }
    }

    public t(p pVar, k kVar, SavedStateHandle savedStateHandle, c cVar, u uVar) {
        this.f628a = pVar;
        this.f629b = kVar;
        this.f631d = new a(pVar, kVar, this, 0);
        this.f632e = new a(pVar, kVar, this, 1);
        this.f633f = new a(pVar, kVar, this, 2);
    }

    public Map<String, wf.a<ViewModel>> a() {
        return ImmutableMap.of("ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel", this.f631d, "ai.plaud.android.plaud.anew.pages.login.LoginViewModel", this.f632e, "ai.plaud.android.plaud.anew.pages.register.RegisterViewModel", this.f633f);
    }
}
