package ag;

import ag.e;
import gg.p;
import rg.d0;

/* compiled from: CoroutineContextImpl.kt */
public abstract class a implements e.a {
    private final e.b<?> key;

    public a(e.b<?> bVar) {
        d0.g(bVar, "key");
        this.key = bVar;
    }

    public <R> R fold(R r10, p<? super R, ? super e.a, ? extends R> pVar) {
        return e.a.C0013a.a(this, r10, pVar);
    }

    public <E extends e.a> E get(e.b<E> bVar) {
        return e.a.C0013a.b(this, bVar);
    }

    public e.b<?> getKey() {
        return this.key;
    }

    public e minusKey(e.b<?> bVar) {
        return e.a.C0013a.c(this, bVar);
    }

    public e plus(e eVar) {
        return e.a.C0013a.d(this, eVar);
    }
}
