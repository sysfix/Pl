package ag;

import bg.b;
import f.a;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Result;
import kotlin.coroutines.intrinsics.CoroutineSingletons;

/* compiled from: SafeContinuationJvm.kt */
public final class f<T> implements c<T>, b {

    /* renamed from: q  reason: collision with root package name */
    public static final AtomicReferenceFieldUpdater<f<?>, Object> f889q = AtomicReferenceFieldUpdater.newUpdater(f.class, Object.class, "result");

    /* renamed from: p  reason: collision with root package name */
    public final c<T> f890p;
    private volatile Object result;

    public f(c<? super T> cVar) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.UNDECIDED;
        this.f890p = cVar;
        this.result = coroutineSingletons;
    }

    public final Object a() {
        Object obj = this.result;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.UNDECIDED;
        if (obj == coroutineSingletons) {
            AtomicReferenceFieldUpdater<f<?>, Object> atomicReferenceFieldUpdater = f889q;
            CoroutineSingletons coroutineSingletons2 = CoroutineSingletons.COROUTINE_SUSPENDED;
            if (atomicReferenceFieldUpdater.compareAndSet(this, coroutineSingletons, coroutineSingletons2)) {
                return coroutineSingletons2;
            }
            obj = this.result;
        }
        if (obj == CoroutineSingletons.RESUMED) {
            return CoroutineSingletons.COROUTINE_SUSPENDED;
        }
        if (!(obj instanceof Result.Failure)) {
            return obj;
        }
        throw ((Result.Failure) obj).exception;
    }

    public b getCallerFrame() {
        c<T> cVar = this.f890p;
        if (cVar instanceof b) {
            return (b) cVar;
        }
        return null;
    }

    public e getContext() {
        return this.f890p.getContext();
    }

    public void resumeWith(Object obj) {
        while (true) {
            Object obj2 = this.result;
            CoroutineSingletons coroutineSingletons = CoroutineSingletons.UNDECIDED;
            if (obj2 != coroutineSingletons) {
                CoroutineSingletons coroutineSingletons2 = CoroutineSingletons.COROUTINE_SUSPENDED;
                if (obj2 != coroutineSingletons2) {
                    throw new IllegalStateException("Already resumed");
                } else if (f889q.compareAndSet(this, coroutineSingletons2, CoroutineSingletons.RESUMED)) {
                    this.f890p.resumeWith(obj);
                    return;
                }
            } else if (f889q.compareAndSet(this, coroutineSingletons, obj)) {
                return;
            }
        }
    }

    public String toString() {
        StringBuilder a10 = a.a("SafeContinuation for ");
        a10.append(this.f890p);
        return a10.toString();
    }
}
