package ag;

import gg.p;
import kotlin.coroutines.CoroutineContext$plus$1;
import kotlin.coroutines.EmptyCoroutineContext;
import rg.d0;

/* compiled from: CoroutineContext.kt */
public interface e {

    /* compiled from: CoroutineContext.kt */
    public interface a extends e {

        /* renamed from: ag.e$a$a  reason: collision with other inner class name */
        /* compiled from: CoroutineContext.kt */
        public static final class C0013a {
            public static <R> R a(a aVar, R r10, p<? super R, ? super a, ? extends R> pVar) {
                d0.g(pVar, "operation");
                return pVar.invoke(r10, aVar);
            }

            public static <E extends a> E b(a aVar, b<E> bVar) {
                d0.g(bVar, "key");
                if (d0.b(aVar.getKey(), bVar)) {
                    return aVar;
                }
                return null;
            }

            public static e c(a aVar, b<?> bVar) {
                d0.g(bVar, "key");
                return d0.b(aVar.getKey(), bVar) ? EmptyCoroutineContext.INSTANCE : aVar;
            }

            public static e d(a aVar, e eVar) {
                d0.g(eVar, "context");
                return eVar == EmptyCoroutineContext.INSTANCE ? aVar : (e) eVar.fold(aVar, CoroutineContext$plus$1.INSTANCE);
            }
        }

        <E extends a> E get(b<E> bVar);

        b<?> getKey();
    }

    /* compiled from: CoroutineContext.kt */
    public interface b<E extends a> {
    }

    <R> R fold(R r10, p<? super R, ? super a, ? extends R> pVar);

    <E extends a> E get(b<E> bVar);

    e minusKey(b<?> bVar);

    e plus(e eVar);
}
