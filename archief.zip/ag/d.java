package ag;

import ag.e;

/* compiled from: ContinuationInterceptor.kt */
public interface d extends e.a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f887a = 0;

    /* compiled from: ContinuationInterceptor.kt */
    public static final class a implements e.b<d> {

        /* renamed from: p  reason: collision with root package name */
        public static final /* synthetic */ a f888p = new a();
    }

    <T> c<T> interceptContinuation(c<? super T> cVar);

    void releaseInterceptedContinuation(c<?> cVar);
}
