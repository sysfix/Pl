package ag;

import ag.e;
import ag.e.a;
import gg.l;
import rg.d0;

/* compiled from: CoroutineContextImpl.kt */
public abstract class b<B extends e.a, E extends B> implements e.b<E> {

    /* renamed from: p  reason: collision with root package name */
    public final l<e.a, E> f885p;

    /* renamed from: q  reason: collision with root package name */
    public final e.b<?> f886q;

    public b(e.b<B> bVar, l<? super e.a, ? extends E> lVar) {
        d0.g(bVar, "baseKey");
        d0.g(lVar, "safeCast");
        this.f885p = lVar;
        this.f886q = bVar instanceof b ? ((b) bVar).f886q : bVar;
    }
}
