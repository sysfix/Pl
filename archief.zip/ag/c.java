package ag;

/* compiled from: Continuation.kt */
public interface c<T> {
    e getContext();

    void resumeWith(Object obj);
}
