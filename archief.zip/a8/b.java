package a8;

import w0.c;

/* compiled from: com.google.android.gms:play-services-stats@@17.0.1 */
public final class b {

    /* renamed from: a  reason: collision with root package name */
    public int f867a;

    public b() {
    }

    public /* synthetic */ b(c cVar) {
    }
}
