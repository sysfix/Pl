package a8;

import android.os.PowerManager;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import com.android.billingclient.api.w;
import j7.c;
import j7.d;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: com.google.android.gms:play-services-stats@@17.0.1 */
public class a {

    /* renamed from: o  reason: collision with root package name */
    public static final long f850o = TimeUnit.DAYS.toMillis(366);

    /* renamed from: p  reason: collision with root package name */
    public static volatile ScheduledExecutorService f851p = null;

    /* renamed from: q  reason: collision with root package name */
    public static final Object f852q = new Object();

    /* renamed from: a  reason: collision with root package name */
    public final Object f853a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public final PowerManager.WakeLock f854b;

    /* renamed from: c  reason: collision with root package name */
    public int f855c = 0;

    /* renamed from: d  reason: collision with root package name */
    public Future<?> f856d;

    /* renamed from: e  reason: collision with root package name */
    public long f857e;

    /* renamed from: f  reason: collision with root package name */
    public final Set<c> f858f = new HashSet();

    /* renamed from: g  reason: collision with root package name */
    public boolean f859g = true;

    /* renamed from: h  reason: collision with root package name */
    public int f860h;

    /* renamed from: i  reason: collision with root package name */
    public s7.a f861i;

    /* renamed from: j  reason: collision with root package name */
    public c f862j = d.f13361a;

    /* renamed from: k  reason: collision with root package name */
    public final String f863k;

    /* renamed from: l  reason: collision with root package name */
    public final Map<String, b> f864l = new HashMap();

    /* renamed from: m  reason: collision with root package name */
    public AtomicInteger f865m = new AtomicInteger(0);

    /* renamed from: n  reason: collision with root package name */
    public final ScheduledExecutorService f866n;

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0090  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00ea  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public a(android.content.Context r7, int r8, java.lang.String r9) {
        /*
            r6 = this;
            java.lang.String r0 = r7.getPackageName()
            r6.<init>()
            java.lang.Object r1 = new java.lang.Object
            r1.<init>()
            r6.f853a = r1
            r1 = 0
            r6.f855c = r1
            java.util.HashSet r2 = new java.util.HashSet
            r2.<init>()
            r6.f858f = r2
            r2 = 1
            r6.f859g = r2
            j7.d r3 = j7.d.f13361a
            r6.f862j = r3
            java.util.HashMap r3 = new java.util.HashMap
            r3.<init>()
            r6.f864l = r3
            java.util.concurrent.atomic.AtomicInteger r3 = new java.util.concurrent.atomic.AtomicInteger
            r3.<init>(r1)
            r6.f865m = r3
            java.lang.String r3 = "WakeLock: wakeLockName must not be empty"
            com.google.android.gms.common.internal.c.g(r9, r3)
            r7.getApplicationContext()
            r3 = 0
            r6.f861i = r3
            java.lang.String r4 = "com.google.android.gms"
            java.lang.String r5 = r7.getPackageName()
            boolean r4 = r4.equals(r5)
            if (r4 != 0) goto L_0x005a
            java.lang.String r4 = "*gcore*:"
            int r5 = r9.length()
            if (r5 == 0) goto L_0x0051
            java.lang.String r4 = r4.concat(r9)
            goto L_0x0057
        L_0x0051:
            java.lang.String r5 = new java.lang.String
            r5.<init>(r4)
            r4 = r5
        L_0x0057:
            r6.f863k = r4
            goto L_0x005c
        L_0x005a:
            r6.f863k = r9
        L_0x005c:
            java.lang.String r4 = "power"
            java.lang.Object r4 = r7.getSystemService(r4)
            android.os.PowerManager r4 = (android.os.PowerManager) r4
            if (r4 == 0) goto L_0x0103
            android.os.PowerManager$WakeLock r8 = r4.newWakeLock(r8, r9)
            r6.f854b = r8
            java.lang.reflect.Method r8 = j7.k.f13371a
            android.content.pm.PackageManager r8 = r7.getPackageManager()
            if (r8 != 0) goto L_0x0075
            goto L_0x008d
        L_0x0075:
            l7.b r8 = l7.c.a(r7)
            java.lang.String r9 = r7.getPackageName()
            android.content.Context r8 = r8.f14085a
            android.content.pm.PackageManager r8 = r8.getPackageManager()
            java.lang.String r4 = "android.permission.UPDATE_DEVICE_STATS"
            int r8 = r8.checkPermission(r4, r9)
            if (r8 != 0) goto L_0x008d
            r8 = r2
            goto L_0x008e
        L_0x008d:
            r8 = r1
        L_0x008e:
            if (r8 == 0) goto L_0x00e6
            boolean r8 = com.google.android.gms.common.util.a.a(r0)
            if (r8 == 0) goto L_0x009a
            java.lang.String r0 = r7.getPackageName()
        L_0x009a:
            java.lang.String r8 = "WorkSourceUtil"
            android.content.pm.PackageManager r9 = r7.getPackageManager()
            if (r9 == 0) goto L_0x00d2
            if (r0 == 0) goto L_0x00d2
            l7.b r7 = l7.c.a(r7)     // Catch:{ NameNotFoundException -> 0x00c9 }
            android.content.Context r7 = r7.f14085a     // Catch:{ NameNotFoundException -> 0x00c9 }
            android.content.pm.PackageManager r7 = r7.getPackageManager()     // Catch:{ NameNotFoundException -> 0x00c9 }
            android.content.pm.ApplicationInfo r7 = r7.getApplicationInfo(r0, r1)     // Catch:{ NameNotFoundException -> 0x00c9 }
            if (r7 != 0) goto L_0x00be
            java.lang.String r7 = "Could not get applicationInfo from package: "
            java.lang.String r7 = r7.concat(r0)
            android.util.Log.e(r8, r7)
            goto L_0x00d2
        L_0x00be:
            int r7 = r7.uid
            android.os.WorkSource r3 = new android.os.WorkSource
            r3.<init>()
            j7.k.a(r3, r7, r0)
            goto L_0x00d2
        L_0x00c9:
            java.lang.String r7 = "Could not find package: "
            java.lang.String r7 = r7.concat(r0)
            android.util.Log.e(r8, r7)
        L_0x00d2:
            if (r3 == 0) goto L_0x00e6
            android.os.PowerManager$WakeLock r7 = r6.f854b
            r7.setWorkSource(r3)     // Catch:{ IllegalArgumentException -> 0x00dc, ArrayIndexOutOfBoundsException -> 0x00da }
            goto L_0x00e6
        L_0x00da:
            r7 = move-exception
            goto L_0x00dd
        L_0x00dc:
            r7 = move-exception
        L_0x00dd:
            java.lang.String r7 = r7.toString()
            java.lang.String r8 = "WakeLock"
            android.util.Log.wtf(r8, r7)
        L_0x00e6:
            java.util.concurrent.ScheduledExecutorService r7 = f851p
            if (r7 != 0) goto L_0x0100
            java.lang.Object r8 = f852q
            monitor-enter(r8)
            java.util.concurrent.ScheduledExecutorService r7 = f851p     // Catch:{ all -> 0x00fd }
            if (r7 != 0) goto L_0x00fb
            java.util.concurrent.ScheduledExecutorService r7 = java.util.concurrent.Executors.newScheduledThreadPool(r2)     // Catch:{ all -> 0x00fd }
            java.util.concurrent.ScheduledExecutorService r7 = java.util.concurrent.Executors.unconfigurableScheduledExecutorService(r7)     // Catch:{ all -> 0x00fd }
            f851p = r7     // Catch:{ all -> 0x00fd }
        L_0x00fb:
            monitor-exit(r8)     // Catch:{ all -> 0x00fd }
            goto L_0x0100
        L_0x00fd:
            r7 = move-exception
            monitor-exit(r8)     // Catch:{ all -> 0x00fd }
            throw r7
        L_0x0100:
            r6.f866n = r7
            return
        L_0x0103:
            com.google.android.gms.internal.stats.zzi r7 = new com.google.android.gms.internal.stats.zzi
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r9 = 29
            r8.<init>(r9)
            java.lang.String r0 = "expected a non-null reference"
            r8.append(r0, r1, r9)
            java.lang.String r8 = r8.toString()
            r7.<init>(r8)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: a8.a.<init>(android.content.Context, int, java.lang.String):void");
    }

    public void a(long j10) {
        this.f865m.incrementAndGet();
        long j11 = Long.MAX_VALUE;
        long max = Math.max(Math.min(Long.MAX_VALUE, f850o), 1);
        if (j10 > 0) {
            max = Math.min(j10, max);
        }
        synchronized (this.f853a) {
            if (!b()) {
                this.f861i = s7.a.f16734p;
                this.f854b.acquire();
                Objects.requireNonNull((d) this.f862j);
                SystemClock.elapsedRealtime();
            }
            this.f855c++;
            this.f860h++;
            if (this.f859g) {
                TextUtils.isEmpty((CharSequence) null);
            }
            b bVar = this.f864l.get((Object) null);
            if (bVar == null) {
                bVar = new b((w0.c) null);
                this.f864l.put((Object) null, bVar);
            }
            bVar.f867a++;
            Objects.requireNonNull((d) this.f862j);
            long elapsedRealtime = SystemClock.elapsedRealtime();
            if (Long.MAX_VALUE - elapsedRealtime > max) {
                j11 = elapsedRealtime + max;
            }
            if (j11 > this.f857e) {
                this.f857e = j11;
                Future<?> future = this.f856d;
                if (future != null) {
                    future.cancel(false);
                }
                this.f856d = this.f866n.schedule(new w(this), max, TimeUnit.MILLISECONDS);
            }
        }
    }

    public boolean b() {
        boolean z10;
        synchronized (this.f853a) {
            z10 = this.f855c > 0;
        }
        return z10;
    }

    public void c() {
        if (this.f865m.decrementAndGet() < 0) {
            Log.e("WakeLock", String.valueOf(this.f863k).concat(" release without a matched acquire!"));
        }
        synchronized (this.f853a) {
            if (this.f859g) {
                TextUtils.isEmpty((CharSequence) null);
            }
            if (this.f864l.containsKey((Object) null)) {
                b bVar = this.f864l.get((Object) null);
                if (bVar != null) {
                    int i10 = bVar.f867a - 1;
                    bVar.f867a = i10;
                    if (i10 == 0) {
                        this.f864l.remove((Object) null);
                    }
                }
            } else {
                Log.w("WakeLock", String.valueOf(this.f863k).concat(" counter does not exist"));
            }
            e(0);
        }
    }

    public final void d() {
        if (!this.f858f.isEmpty()) {
            ArrayList arrayList = new ArrayList(this.f858f);
            this.f858f.clear();
            if (arrayList.size() > 0) {
                c cVar = (c) arrayList.get(0);
                throw null;
            }
        }
    }

    public final void e(int i10) {
        synchronized (this.f853a) {
            if (b()) {
                if (this.f859g) {
                    int i11 = this.f855c - 1;
                    this.f855c = i11;
                    if (i11 > 0) {
                        return;
                    }
                } else {
                    this.f855c = 0;
                }
                d();
                for (b bVar : this.f864l.values()) {
                    bVar.f867a = 0;
                }
                this.f864l.clear();
                Future<?> future = this.f856d;
                if (future != null) {
                    future.cancel(false);
                    this.f856d = null;
                    this.f857e = 0;
                }
                this.f860h = 0;
                if (this.f854b.isHeld()) {
                    try {
                        this.f854b.release();
                        if (this.f861i != null) {
                            this.f861i = null;
                        }
                    } catch (RuntimeException e10) {
                        if (e10.getClass().equals(RuntimeException.class)) {
                            Log.e("WakeLock", String.valueOf(this.f863k).concat(" failed to release!"), e10);
                            if (this.f861i != null) {
                                this.f861i = null;
                            }
                            return;
                        }
                        throw e10;
                    } catch (Throwable th2) {
                        if (this.f861i != null) {
                            this.f861i = null;
                        }
                        throw th2;
                    }
                } else {
                    Log.e("WakeLock", String.valueOf(this.f863k).concat(" should be held!"));
                }
            }
        }
    }
}
