package af;

import io.flutter.plugins.pathprovider.Messages;
import java.io.File;
import java.util.ArrayList;
import java.util.Objects;
import re.a;
import re.c;
import re.q;

/* compiled from: Messages */
public final /* synthetic */ class b {
    public static void b(Messages.a aVar, Object obj, a.e eVar) {
        ArrayList<Object> arrayList = new ArrayList<>();
        ArrayList arrayList2 = (ArrayList) obj;
        Messages.StorageDirectory storageDirectory = arrayList2.get(0) == null ? null : Messages.StorageDirectory.values()[((Integer) arrayList2.get(0)).intValue()];
        try {
            io.flutter.plugins.pathprovider.a aVar2 = (io.flutter.plugins.pathprovider.a) aVar;
            Objects.requireNonNull(aVar2);
            ArrayList arrayList3 = new ArrayList();
            for (File file : aVar2.f12798a.getExternalFilesDirs(aVar2.a(storageDirectory))) {
                if (file != null) {
                    arrayList3.add(file.getAbsolutePath());
                }
            }
            arrayList.add(0, arrayList3);
        } catch (Throwable th2) {
            arrayList = Messages.a(th2);
        }
        eVar.a(arrayList);
    }

    public static void c(c cVar, Messages.a aVar) {
        a aVar2 = new a(cVar, "dev.flutter.pigeon.PathProviderApi.getTemporaryPath", new q(), cVar.d());
        if (aVar != null) {
            aVar2.b(new a(aVar, 0));
        } else {
            aVar2.b((a.d) null);
        }
        a aVar3 = new a(cVar, "dev.flutter.pigeon.PathProviderApi.getApplicationSupportPath", new q(), cVar.d());
        if (aVar != null) {
            aVar3.b(new a(aVar, 1));
        } else {
            aVar3.b((a.d) null);
        }
        a aVar4 = new a(cVar, "dev.flutter.pigeon.PathProviderApi.getApplicationDocumentsPath", new q(), cVar.d());
        if (aVar != null) {
            aVar4.b(new a(aVar, 2));
        } else {
            aVar4.b((a.d) null);
        }
        a aVar5 = new a(cVar, "dev.flutter.pigeon.PathProviderApi.getApplicationCachePath", new q(), cVar.d());
        if (aVar != null) {
            aVar5.b(new a(aVar, 3));
        } else {
            aVar5.b((a.d) null);
        }
        a aVar6 = new a(cVar, "dev.flutter.pigeon.PathProviderApi.getExternalStoragePath", new q(), cVar.d());
        if (aVar != null) {
            aVar6.b(new a(aVar, 4));
        } else {
            aVar6.b((a.d) null);
        }
        a aVar7 = new a(cVar, "dev.flutter.pigeon.PathProviderApi.getExternalCachePaths", new q(), cVar.d());
        if (aVar != null) {
            aVar7.b(new a(aVar, 5));
        } else {
            aVar7.b((a.d) null);
        }
        a aVar8 = new a(cVar, "dev.flutter.pigeon.PathProviderApi.getExternalStoragePaths", new q(), cVar.d());
        if (aVar != null) {
            aVar8.b(new a(aVar, 6));
        } else {
            aVar8.b((a.d) null);
        }
    }
}
