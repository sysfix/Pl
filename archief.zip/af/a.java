package af;

import io.flutter.plugins.pathprovider.Messages;
import java.io.File;
import java.util.ArrayList;
import java.util.Objects;
import re.a;

public final /* synthetic */ class a implements a.d {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f883p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Messages.a f884q;

    public /* synthetic */ a(Messages.a aVar, int i10) {
        this.f883p = i10;
        switch (i10) {
        }
        this.f884q = aVar;
    }

    private final void a(Object obj, a.e eVar) {
        b.b(this.f884q, obj, eVar);
    }

    public final void b(Object obj, a.e eVar) {
        switch (this.f883p) {
            case 0:
                Messages.a aVar = this.f884q;
                ArrayList<Object> arrayList = new ArrayList<>();
                try {
                    arrayList.add(0, ((io.flutter.plugins.pathprovider.a) aVar).f12798a.getCacheDir().getPath());
                } catch (Throwable th2) {
                    arrayList = Messages.a(th2);
                }
                eVar.a(arrayList);
                return;
            case 1:
                Messages.a aVar2 = this.f884q;
                ArrayList<Object> arrayList2 = new ArrayList<>();
                try {
                    arrayList2.add(0, ef.a.c(((io.flutter.plugins.pathprovider.a) aVar2).f12798a));
                } catch (Throwable th3) {
                    arrayList2 = Messages.a(th3);
                }
                eVar.a(arrayList2);
                return;
            case 2:
                Messages.a aVar3 = this.f884q;
                ArrayList<Object> arrayList3 = new ArrayList<>();
                try {
                    arrayList3.add(0, ef.a.b(((io.flutter.plugins.pathprovider.a) aVar3).f12798a));
                } catch (Throwable th4) {
                    arrayList3 = Messages.a(th4);
                }
                eVar.a(arrayList3);
                return;
            case 3:
                Messages.a aVar4 = this.f884q;
                ArrayList<Object> arrayList4 = new ArrayList<>();
                try {
                    arrayList4.add(0, ((io.flutter.plugins.pathprovider.a) aVar4).f12798a.getCacheDir().getPath());
                } catch (Throwable th5) {
                    arrayList4 = Messages.a(th5);
                }
                eVar.a(arrayList4);
                return;
            case 4:
                Messages.a aVar5 = this.f884q;
                ArrayList<Object> arrayList5 = new ArrayList<>();
                try {
                    String str = null;
                    File externalFilesDir = ((io.flutter.plugins.pathprovider.a) aVar5).f12798a.getExternalFilesDir((String) null);
                    if (externalFilesDir != null) {
                        str = externalFilesDir.getAbsolutePath();
                    }
                    arrayList5.add(0, str);
                } catch (Throwable th6) {
                    arrayList5 = Messages.a(th6);
                }
                eVar.a(arrayList5);
                return;
            case 5:
                Messages.a aVar6 = this.f884q;
                ArrayList<Object> arrayList6 = new ArrayList<>();
                try {
                    io.flutter.plugins.pathprovider.a aVar7 = (io.flutter.plugins.pathprovider.a) aVar6;
                    Objects.requireNonNull(aVar7);
                    ArrayList arrayList7 = new ArrayList();
                    for (File file : aVar7.f12798a.getExternalCacheDirs()) {
                        if (file != null) {
                            arrayList7.add(file.getAbsolutePath());
                        }
                    }
                    arrayList6.add(0, arrayList7);
                } catch (Throwable th7) {
                    arrayList6 = Messages.a(th7);
                }
                eVar.a(arrayList6);
                return;
            default:
                a(obj, eVar);
                return;
        }
    }
}
