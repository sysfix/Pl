package ai.plaud.android.plaud;

import a.b;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import android.annotation.SuppressLint;
import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import ci.a;
import rg.d0;

/* compiled from: BleSleepWorker.kt */
public final class BleSleepWorker extends Worker {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public BleSleepWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        d0.g(context, "appContext");
        d0.g(workerParameters, "workerParams");
    }

    @SuppressLint({"MissingPermission"})
    public ListenableWorker.a h() {
        a.C0057a aVar = a.f4931a;
        aVar.d("BleSleepWorker doWork", new Object[0]);
        FlutterDeviceManager flutterDeviceManager = FlutterDeviceManager.INSTANCE;
        if (flutterDeviceManager.getBleAgent().W()) {
            flutterDeviceManager.getBleAgent().p(false, a.a.f571q, b.f582q);
        }
        aVar.a("BleSleepWorker done", new Object[0]);
        return new ListenableWorker.a.c();
    }
}
