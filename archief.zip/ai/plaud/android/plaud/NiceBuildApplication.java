package ai.plaud.android.plaud;

import a.v;
import a.y;
import ag.e;
import ai.plaud.android.plaud.anew.flutter.audio.FlutterPlayAudioManager;
import ai.plaud.android.plaud.anew.flutter.data.FlutterDataManager;
import ai.plaud.android.plaud.anew.flutter.data.FlutterDatabaseManager;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import ai.plaud.android.plaud.soundplus.LibSoundPlus;
import android.text.TextUtils;
import android.util.Log;
import ci.a;
import com.google.android.gms.internal.measurement.n8;
import ie.a;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.CoroutineStart;
import rg.d0;
import wi.c;
import z.b;
import zendesk.android.Zendesk;
import zendesk.android.Zendesk$Companion$initialize$1;
import zendesk.messaging.android.DefaultMessagingFactory;

/* compiled from: NiceBuildApplication.kt */
public final class NiceBuildApplication extends v {

    /* renamed from: r  reason: collision with root package name */
    public static boolean f891r;

    /* renamed from: s  reason: collision with root package name */
    public static boolean f892s;

    /* compiled from: NiceBuildApplication.kt */
    public final class a extends a.b {
        public a(NiceBuildApplication niceBuildApplication) {
        }

        public void e(int i10, String str, String str2, Throwable th2) {
            d0.g(str2, "message");
            if (i10 == 1) {
                b.c(str2);
            } else if (i10 != 2) {
                String str3 = "PLAUD_LOG";
                if (i10 != 3) {
                    if (i10 != 4) {
                        if (i10 == 5 && !TextUtils.isEmpty(str2)) {
                            if (!TextUtils.isEmpty((CharSequence) null)) {
                                str3 = "PLAUD_LOG:null";
                            }
                            StringBuilder a10 = b.a();
                            a10.append(str2);
                            String sb2 = a10.toString();
                            Log.v(str3, sb2);
                            b.b(sb2, 5);
                        }
                    } else if (!TextUtils.isEmpty(str2)) {
                        if (!TextUtils.isEmpty((CharSequence) null)) {
                            str3 = "PLAUD_LOG:null";
                        }
                        StringBuilder a11 = b.a();
                        a11.append(str2);
                        String sb3 = a11.toString();
                        Log.i(str3, sb3);
                        b.b(sb3, 4);
                    }
                } else if (!TextUtils.isEmpty(str2)) {
                    if (!TextUtils.isEmpty((CharSequence) null)) {
                        str3 = "PLAUD_LOG:null";
                    }
                    StringBuilder a12 = b.a();
                    a12.append(str2);
                    String sb4 = a12.toString();
                    Log.d(str3, sb4);
                    b.b(sb4, 3);
                }
            } else {
                b.c(str2);
            }
        }
    }

    public void onCreate() {
        super.onCreate();
        io.flutter.embedding.engine.a aVar = new io.flutter.embedding.engine.a(this);
        aVar.f12224c.b(a.c.a(), (List<String>) null);
        he.b.a().f11704a.put("plaud_flutter_engine_id", aVar);
        FlutterPlayAudioManager.INSTANCE.configMethodChannel(aVar);
        FlutterDeviceManager.INSTANCE.configMethodChannel(aVar);
        FlutterDatabaseManager.INSTANCE.configMethodChannel(aVar);
        FlutterDataManager.INSTANCE.configMethodChannel(aVar);
        a.C0057a aVar2 = ci.a.f4931a;
        a aVar3 = new a(this);
        Objects.requireNonNull(aVar2);
        d0.g(aVar3, "tree");
        boolean z10 = false;
        if (aVar3 != aVar2) {
            ArrayList<a.b> arrayList = ci.a.f4932b;
            synchronized (arrayList) {
                arrayList.add(aVar3);
                Object[] array = arrayList.toArray(new a.b[0]);
                if (array != null) {
                    ci.a.f4933c = (a.b[]) array;
                } else {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
                }
            }
            Log.d("ChenTian", "initZendesk");
            Zendesk.Companion companion = Zendesk.f19438e;
            a.a aVar4 = a.a.f572r;
            a.b bVar = a.b.f583r;
            DefaultMessagingFactory defaultMessagingFactory = new DefaultMessagingFactory((c) null, (c) null, 3, (DefaultConstructorMarker) null);
            d0.g(this, "context");
            d0.g("eyJzZXR0aW5nc191cmwiOiJodHRwczovL25pY2VidWlsZGxsYy56ZW5kZXNrLmNvbS9tb2JpbGVfc2RrX2FwaS9zZXR0aW5ncy8wMUg1SE1WNUdDU1dRVzBBUThDMURQUTJOOS5qc29uIn0=", "channelKey");
            d0.g(aVar4, "successCallback");
            d0.g(bVar, "failureCallback");
            n8.f(Zendesk.f19440g, (e) null, (CoroutineStart) null, new Zendesk$Companion$initialize$1(this, "eyJzZXR0aW5nc191cmwiOiJodHRwczovL25pY2VidWlsZGxsYy56ZW5kZXNrLmNvbS9tb2JpbGVfc2RrX2FwaS9zZXR0aW5ncy8wMUg1SE1WNUdDU1dRVzBBUThDMURQUTJOOS5qc29uIn0=", defaultMessagingFactory, bVar, aVar4, (ag.c<? super Zendesk$Companion$initialize$1>) null), 3, (Object) null);
            a0.b bVar2 = a0.b.f660a;
            if (bVar2 == null) {
                bVar2 = new a0.b();
            }
            a0.b.f660a = bVar2;
            registerActivityLifecycleCallbacks(new y());
            PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
            PreferencesUtil d10 = PreferencesUtil.d();
            Objects.requireNonNull(d10);
            d0.g("OPTIMIZE_PLAUD_APP_STORAGE", "key");
            if (!d10.f1010a.a("OPTIMIZE_PLAUD_APP_STORAGE")) {
                d10.f1010a.g("OPTIMIZE_PLAUD_APP_STORAGE", true);
            }
            LibSoundPlus libSoundPlus = LibSoundPlus.f1056a;
            if (!LibSoundPlus.f1057b) {
                if (libSoundPlus.initSoundPlus(16000) == 0) {
                    z10 = true;
                }
                LibSoundPlus.f1057b = z10;
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Cannot plant Timber into itself.".toString());
    }
}
