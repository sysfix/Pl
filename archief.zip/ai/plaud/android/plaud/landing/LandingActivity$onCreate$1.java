package ai.plaud.android.plaud.landing;

import ag.c;
import ai.plaud.android.plaud.base.util.FlowEventBus;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.RepeatOnLifecycleKt;
import ci.a;
import com.google.android.gms.internal.measurement.n8;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import gg.p;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import kotlinx.coroutines.CoroutineStart;
import rg.c0;
import rg.d0;
import rg.g1;
import rg.l0;
import rg.s0;
import wg.q;
import xf.g;

@a(c = "ai.plaud.android.plaud.landing.LandingActivity$onCreate$1", f = "LandingActivity.kt", l = {32}, m = "invokeSuspend")
/* compiled from: LandingActivity.kt */
public final class LandingActivity$onCreate$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public int label;
    public final /* synthetic */ LandingActivity this$0;

    @a(c = "ai.plaud.android.plaud.landing.LandingActivity$onCreate$1$1", f = "LandingActivity.kt", l = {33}, m = "invokeSuspend")
    /* renamed from: ai.plaud.android.plaud.landing.LandingActivity$onCreate$1$1  reason: invalid class name */
    /* compiled from: LandingActivity.kt */
    public static final class AnonymousClass1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
        public int label;

        public final c<g> create(Object obj, c<?> cVar) {
            return new AnonymousClass1(landingActivity, cVar);
        }

        public final Object invoke(c0 c0Var, c<? super g> cVar) {
            return ((AnonymousClass1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
        }

        public final Object invokeSuspend(Object obj) {
            CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
            int i10 = this.label;
            if (i10 == 0) {
                x2.s(obj);
                FlowEventBus flowEventBus = FlowEventBus.f1002a;
                final LandingActivity landingActivity = landingActivity;
                AnonymousClass1 r12 = new l<Boolean, g>() {
                    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                        invoke(((Boolean) obj).booleanValue());
                        return g.f19030a;
                    }

                    public final void invoke(final boolean z10) {
                        a.C0057a aVar = ci.a.f4931a;
                        aVar.a("SHOW_LOADING:[" + z10 + "]", new Object[0]);
                        s0 s0Var = s0.f16640p;
                        l0 l0Var = l0.f16618a;
                        g1 g1Var = q.f18099a;
                        final LandingActivity landingActivity = landingActivity;
                        n8.f(s0Var, g1Var, (CoroutineStart) null, new p<c0, c<? super g>, Object>((c<? super AnonymousClass1>) null) {
                            public int label;

                            public final c<g> create(Object obj, c<?> cVar) {
                                return 

                                /* JADX INFO: super call moved to the top of the method (can break code semantics) */
                                public LandingActivity$onCreate$1(LandingActivity landingActivity, c<? super LandingActivity$onCreate$1> cVar) {
                                    super(2, cVar);
                                    this.this$0 = landingActivity;
                                }

                                public final c<g> create(Object obj, c<?> cVar) {
                                    return new LandingActivity$onCreate$1(this.this$0, cVar);
                                }

                                public final Object invoke(c0 c0Var, c<? super g> cVar) {
                                    return ((LandingActivity$onCreate$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
                                }

                                public final Object invokeSuspend(Object obj) {
                                    CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
                                    int i10 = this.label;
                                    if (i10 == 0) {
                                        x2.s(obj);
                                        Lifecycle lifecycle = this.this$0.getLifecycle();
                                        d0.f(lifecycle, "lifecycle");
                                        Lifecycle.State state = Lifecycle.State.RESUMED;
                                        final LandingActivity landingActivity = this.this$0;
                                        AnonymousClass1 r32 = new AnonymousClass1((c<? super AnonymousClass1>) null);
                                        this.label = 1;
                                        if (RepeatOnLifecycleKt.repeatOnLifecycle(lifecycle, state, (p<? super c0, ? super c<? super g>, ? extends Object>) r32, (c<? super g>) this) == coroutineSingletons) {
                                            return coroutineSingletons;
                                        }
                                    } else if (i10 == 1) {
                                        x2.s(obj);
                                    } else {
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    return g.f19030a;
                                }
                            }
