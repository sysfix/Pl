package ai.plaud.android.plaud.landing;

import ag.c;
import ag.e;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.base.util.StatusBarTextColor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.LifecycleOwnerKt;
import com.google.android.gms.internal.measurement.n8;
import kotlinx.coroutines.CoroutineStart;
import u.a;
import v.b;

/* compiled from: LandingActivity.kt */
public final class LandingActivity extends b<a> {
    public static final /* synthetic */ int C = 0;

    public LandingActivity() {
        super(AnonymousClass1.INSTANCE);
    }

    public StatusBarTextColor i() {
        return StatusBarTextColor.DARK;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int color = getResources().getColor(R.color.white);
        Window window = getWindow();
        window.addFlags(CellBase.GROUP_ID_SYSTEM_MESSAGE);
        window.setNavigationBarColor(color);
        Window window2 = getWindow();
        if (Build.VERSION.SDK_INT >= 26) {
            View decorView = window2.getDecorView();
            decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | 16);
        }
        n8.f(LifecycleOwnerKt.getLifecycleScope(this), (e) null, (CoroutineStart) null, new LandingActivity$onCreate$1(this, (c<? super LandingActivity$onCreate$1>) null), 3, (Object) null);
    }
}
