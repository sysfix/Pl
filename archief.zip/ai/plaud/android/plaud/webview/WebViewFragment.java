package ai.plaud.android.plaud.webview;

import ai.plaud.android.plaud.R;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import b0.b;
import b0.c;
import h2.f;
import hg.h;
import i.m;
import pg.j;
import rg.d0;
import u.g;

/* compiled from: WebViewFragment.kt */
public final class WebViewFragment extends b0.a<g> {
    public static final /* synthetic */ int G = 0;
    public final f F = new f(h.a(c.class), new WebViewFragment$special$$inlined$navArgs$1(this));

    /* compiled from: WebViewFragment.kt */
    public static final class a extends androidx.activity.g {

        /* renamed from: d  reason: collision with root package name */
        public final /* synthetic */ WebViewFragment f1066d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(WebViewFragment webViewFragment) {
            super(true);
            this.f1066d = webViewFragment;
        }

        public void a() {
            WebViewFragment webViewFragment = this.f1066d;
            int i10 = WebViewFragment.G;
            webViewFragment.i();
        }
    }

    public WebViewFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    public final c h() {
        return (c) this.F.getValue();
    }

    public final void i() {
        VB vb2 = this.f14772x;
        d0.d(vb2);
        if (((g) vb2).f17171d.canGoBack()) {
            VB vb3 = this.f14772x;
            d0.d(vb3);
            ((g) vb3).f17171d.goBack();
            return;
        }
        m.f(this).l();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requireActivity().getOnBackPressedDispatcher().a(this, new a(this));
    }

    public void onViewCreated(View view, Bundle bundle) {
        d0.g(view, "view");
        super.onViewCreated(view, bundle);
        VB vb2 = this.f14772x;
        d0.d(vb2);
        ((g) vb2).f17169b.setOnClickListener(new i.a(this));
        String str = h().f4186a;
        if (d0.b(str, "https://note.plaud.ai/privacy")) {
            VB vb3 = this.f14772x;
            d0.d(vb3);
            ((g) vb3).f17170c.setText(getString(R.string.Privacy_Policy));
        } else if (d0.b(str, "https://note.plaud.ai/user-service-agreement")) {
            VB vb4 = this.f14772x;
            d0.d(vb4);
            ((g) vb4).f17170c.setText(getString(R.string.User_agreement));
        } else {
            VB vb5 = this.f14772x;
            d0.d(vb5);
            ((g) vb5).f17170c.setText(getString(R.string.Help_Center));
        }
        if (!j.o(h().f4187b)) {
            VB vb6 = this.f14772x;
            d0.d(vb6);
            ((g) vb6).f17170c.setText(h().f4187b);
        }
        VB vb7 = this.f14772x;
        d0.d(vb7);
        ((g) vb7).f17171d.getSettings().setUseWideViewPort(true);
        VB vb8 = this.f14772x;
        d0.d(vb8);
        ((g) vb8).f17171d.getSettings().setSupportZoom(true);
        VB vb9 = this.f14772x;
        d0.d(vb9);
        ((g) vb9).f17171d.getSettings().setBuiltInZoomControls(true);
        VB vb10 = this.f14772x;
        d0.d(vb10);
        ((g) vb10).f17171d.getSettings().setDisplayZoomControls(false);
        VB vb11 = this.f14772x;
        d0.d(vb11);
        ((g) vb11).f17171d.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        VB vb12 = this.f14772x;
        d0.d(vb12);
        ((g) vb12).f17171d.getSettings().setDomStorageEnabled(true);
        VB vb13 = this.f14772x;
        d0.d(vb13);
        ((g) vb13).f17171d.getSettings().setDatabaseEnabled(true);
        VB vb14 = this.f14772x;
        d0.d(vb14);
        ((g) vb14).f17171d.getSettings().setJavaScriptEnabled(true);
        VB vb15 = this.f14772x;
        d0.d(vb15);
        ((g) vb15).f17171d.getSettings().setCacheMode(2);
        VB vb16 = this.f14772x;
        d0.d(vb16);
        ((g) vb16).f17171d.setInitialScale(25);
        VB vb17 = this.f14772x;
        d0.d(vb17);
        ((g) vb17).f17171d.loadUrl(h().f4186a);
        VB vb18 = this.f14772x;
        d0.d(vb18);
        WebView webView = ((g) vb18).f17171d;
        androidx.fragment.app.m requireActivity = requireActivity();
        d0.f(requireActivity, "requireActivity()");
        webView.setWebViewClient(new b(requireActivity, WebViewFragment$setupWebView$1.INSTANCE));
    }
}
