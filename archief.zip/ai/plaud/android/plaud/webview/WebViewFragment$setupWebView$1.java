package ai.plaud.android.plaud.webview;

import b0.e;
import ci.a;
import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import xf.g;

/* compiled from: WebViewFragment.kt */
public final class WebViewFragment$setupWebView$1 extends Lambda implements l<e, g> {
    public static final WebViewFragment$setupWebView$1 INSTANCE = new WebViewFragment$setupWebView$1();

    public WebViewFragment$setupWebView$1() {
        super(1);
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((e) obj);
        return g.f19030a;
    }

    public final void invoke(e eVar) {
        d0.g(eVar, "state");
        a.C0057a aVar = a.f4931a;
        aVar.a("state " + eVar, new Object[0]);
    }
}
