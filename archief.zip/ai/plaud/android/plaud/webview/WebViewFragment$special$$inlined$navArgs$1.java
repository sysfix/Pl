package ai.plaud.android.plaud.webview;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import gg.a;
import kotlin.jvm.internal.Lambda;

/* compiled from: FragmentNavArgsLazy.kt */
public final class WebViewFragment$special$$inlined$navArgs$1 extends Lambda implements a<Bundle> {
    public final /* synthetic */ Fragment $this_navArgs;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public WebViewFragment$special$$inlined$navArgs$1(Fragment fragment) {
        super(0);
        this.$this_navArgs = fragment;
    }

    public final Bundle invoke() {
        Bundle arguments = this.$this_navArgs.getArguments();
        if (arguments != null) {
            return arguments;
        }
        StringBuilder a10 = f.a.a("Fragment ");
        a10.append(this.$this_navArgs);
        a10.append(" has null arguments");
        throw new IllegalStateException(a10.toString());
    }
}
