package ai.plaud.android.plaud.common.util;

import gg.a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Lambda;

/* compiled from: PreferencesUtil.kt */
public final class PreferencesUtil$Companion$INSTANCE$2 extends Lambda implements a<PreferencesUtil> {
    public static final PreferencesUtil$Companion$INSTANCE$2 INSTANCE = new PreferencesUtil$Companion$INSTANCE$2();

    public PreferencesUtil$Companion$INSTANCE$2() {
        super(0);
    }

    public final PreferencesUtil invoke() {
        return new PreferencesUtil((DefaultConstructorMarker) null);
    }
}
