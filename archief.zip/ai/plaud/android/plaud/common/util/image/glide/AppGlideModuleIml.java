package ai.plaud.android.plaud.common.util.image.glide;

import android.content.Context;
import com.bumptech.glide.Registry;
import com.bumptech.glide.c;
import com.bumptech.glide.d;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import m5.f;
import m5.n;
import m5.o;
import m5.q;
import okhttp3.OkHttpClient;
import rg.d0;
import s.b;
import w5.a;

/* compiled from: AppGlideModuleIml.kt */
public final class AppGlideModuleIml extends a {
    public void a(Context context, d dVar) {
        d0.g(context, "context");
        d0.g(dVar, "builder");
    }

    public void b(Context context, c cVar, Registry registry) {
        List<n<? extends Model, ? extends Data>> f10;
        d0.g(context, "context");
        d0.g(cVar, "glide");
        d0.g(registry, "registry");
        Class<f> cls = f.class;
        Class<InputStream> cls2 = InputStream.class;
        t.a aVar = t.a.f16785a;
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        d0.g(builder, "<this>");
        b.a aVar2 = new b.a(builder.addNetworkInterceptor(new t.b()).build());
        o oVar = registry.f5630a;
        synchronized (oVar) {
            q qVar = oVar.f14254a;
            synchronized (qVar) {
                f10 = qVar.f(cls, cls2);
                qVar.a(cls, cls2, aVar2);
            }
            Iterator it = ((ArrayList) f10).iterator();
            while (it.hasNext()) {
                ((n) it.next()).c();
            }
            oVar.f14255b.f14256a.clear();
        }
    }

    public boolean c() {
        return false;
    }
}
