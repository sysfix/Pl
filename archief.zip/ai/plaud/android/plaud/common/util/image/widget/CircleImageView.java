package ai.plaud.android.plaud.common.util.image.widget;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.MotionEvent;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;

public class CircleImageView extends AppCompatImageView {
    public static final ImageView.ScaleType C = ImageView.ScaleType.CENTER_CROP;
    public static final Bitmap.Config D = Bitmap.Config.ARGB_8888;
    public boolean A;
    public boolean B;

    /* renamed from: s  reason: collision with root package name */
    public int f1011s;

    /* renamed from: t  reason: collision with root package name */
    public int f1012t;

    /* renamed from: u  reason: collision with root package name */
    public int f1013u;

    /* renamed from: v  reason: collision with root package name */
    public int f1014v;

    /* renamed from: w  reason: collision with root package name */
    public Bitmap f1015w;

    /* renamed from: x  reason: collision with root package name */
    public Canvas f1016x;

    /* renamed from: y  reason: collision with root package name */
    public ColorFilter f1017y;

    /* renamed from: z  reason: collision with root package name */
    public boolean f1018z;

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0052  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x005c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c() {
        /*
            r7 = this;
            android.graphics.drawable.Drawable r0 = r7.getDrawable()
            r1 = 0
            if (r0 != 0) goto L_0x0008
            goto L_0x0047
        L_0x0008:
            boolean r2 = r0 instanceof android.graphics.drawable.BitmapDrawable
            if (r2 == 0) goto L_0x0013
            android.graphics.drawable.BitmapDrawable r0 = (android.graphics.drawable.BitmapDrawable) r0
            android.graphics.Bitmap r0 = r0.getBitmap()
            goto L_0x0048
        L_0x0013:
            boolean r2 = r0 instanceof android.graphics.drawable.ColorDrawable     // Catch:{ Exception -> 0x0043 }
            if (r2 == 0) goto L_0x001f
            android.graphics.Bitmap$Config r2 = D     // Catch:{ Exception -> 0x0043 }
            r3 = 2
            android.graphics.Bitmap r2 = android.graphics.Bitmap.createBitmap(r3, r3, r2)     // Catch:{ Exception -> 0x0043 }
            goto L_0x002d
        L_0x001f:
            int r2 = r0.getIntrinsicWidth()     // Catch:{ Exception -> 0x0043 }
            int r3 = r0.getIntrinsicHeight()     // Catch:{ Exception -> 0x0043 }
            android.graphics.Bitmap$Config r4 = D     // Catch:{ Exception -> 0x0043 }
            android.graphics.Bitmap r2 = android.graphics.Bitmap.createBitmap(r2, r3, r4)     // Catch:{ Exception -> 0x0043 }
        L_0x002d:
            android.graphics.Canvas r3 = new android.graphics.Canvas     // Catch:{ Exception -> 0x0043 }
            r3.<init>(r2)     // Catch:{ Exception -> 0x0043 }
            int r4 = r3.getWidth()     // Catch:{ Exception -> 0x0043 }
            int r5 = r3.getHeight()     // Catch:{ Exception -> 0x0043 }
            r6 = 0
            r0.setBounds(r6, r6, r4, r5)     // Catch:{ Exception -> 0x0043 }
            r0.draw(r3)     // Catch:{ Exception -> 0x0043 }
            r0 = r2
            goto L_0x0048
        L_0x0043:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0047:
            r0 = r1
        L_0x0048:
            r7.f1015w = r0
            if (r0 == 0) goto L_0x005c
            boolean r0 = r0.isMutable()
            if (r0 == 0) goto L_0x005c
            android.graphics.Canvas r0 = new android.graphics.Canvas
            android.graphics.Bitmap r1 = r7.f1015w
            r0.<init>(r1)
            r7.f1016x = r0
            goto L_0x005e
        L_0x005c:
            r7.f1016x = r1
        L_0x005e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.common.util.image.widget.CircleImageView.c():void");
    }

    public final void d() {
        int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
        int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
        int min = Math.min(width, height);
        float paddingLeft = (((float) (width - min)) / 2.0f) + ((float) getPaddingLeft());
        float paddingTop = (((float) (height - min)) / 2.0f) + ((float) getPaddingTop());
        float f10 = (float) min;
        new RectF(paddingLeft, paddingTop, paddingLeft + f10, f10 + paddingTop);
        throw null;
    }

    public int getBorderColor() {
        return this.f1011s;
    }

    public int getBorderWidth() {
        return this.f1012t;
    }

    public int getCircleBackgroundColor() {
        return this.f1013u;
    }

    public ColorFilter getColorFilter() {
        return this.f1017y;
    }

    public int getImageAlpha() {
        return this.f1014v;
    }

    public void invalidateDrawable(Drawable drawable) {
        this.f1018z = true;
        invalidate();
    }

    @SuppressLint({"CanvasSize"})
    public void onDraw(Canvas canvas) {
        if (this.B) {
            super.onDraw(canvas);
        } else if (this.f1013u != 0) {
            throw null;
        } else if (this.f1015w != null) {
            if (this.f1018z && this.f1016x != null) {
                this.f1018z = false;
                Drawable drawable = getDrawable();
                drawable.setBounds(0, 0, this.f1016x.getWidth(), this.f1016x.getHeight());
                drawable.draw(this.f1016x);
            }
            throw null;
        } else if (this.f1012t > 0) {
            throw null;
        }
    }

    public void onSizeChanged(int i10, int i11, int i12, int i13) {
        super.onSizeChanged(i10, i11, i12, i13);
        d();
        throw null;
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.B) {
            return super.onTouchEvent(motionEvent);
        }
        motionEvent.getX();
        motionEvent.getY();
        throw null;
    }

    public void setAdjustViewBounds(boolean z10) {
        if (z10) {
            throw new IllegalArgumentException("adjustViewBounds not supported.");
        }
    }

    public void setBorderColor(int i10) {
        if (i10 != this.f1011s) {
            this.f1011s = i10;
            throw null;
        }
    }

    public void setBorderOverlay(boolean z10) {
        if (z10 != this.A) {
            this.A = z10;
            d();
            throw null;
        }
    }

    public void setBorderWidth(int i10) {
        if (i10 != this.f1012t) {
            this.f1012t = i10;
            throw null;
        }
    }

    public void setCircleBackgroundColor(int i10) {
        if (i10 != this.f1013u) {
            this.f1013u = i10;
            throw null;
        }
    }

    @Deprecated
    public void setCircleBackgroundColorResource(int i10) {
        setCircleBackgroundColor(getContext().getResources().getColor(i10));
    }

    public void setColorFilter(ColorFilter colorFilter) {
        if (colorFilter != this.f1017y) {
            this.f1017y = colorFilter;
        }
    }

    public void setDisableCircularTransformation(boolean z10) {
        if (z10 != this.B) {
            this.B = z10;
            if (!z10) {
                c();
                invalidate();
                return;
            }
            this.f1015w = null;
            this.f1016x = null;
            throw null;
        }
    }

    public void setImageAlpha(int i10) {
        int i11 = i10 & 255;
        if (i11 != this.f1014v) {
            this.f1014v = i11;
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        c();
        invalidate();
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        c();
        invalidate();
    }

    public void setImageResource(int i10) {
        super.setImageResource(i10);
        c();
        invalidate();
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        c();
        invalidate();
    }

    public void setPadding(int i10, int i11, int i12, int i13) {
        super.setPadding(i10, i11, i12, i13);
        d();
        throw null;
    }

    public void setPaddingRelative(int i10, int i11, int i12, int i13) {
        super.setPaddingRelative(i10, i11, i12, i13);
        d();
        throw null;
    }

    public void setScaleType(ImageView.ScaleType scaleType) {
        if (scaleType != C) {
            throw new IllegalArgumentException(String.format("ScaleType %s not supported.", new Object[]{scaleType}));
        }
    }
}
