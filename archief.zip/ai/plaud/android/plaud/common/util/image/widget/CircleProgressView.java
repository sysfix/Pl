package ai.plaud.android.plaud.common.util.image.widget;

import ai.plaud.android.plaud.anew.flutter.audio.f;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.ProgressBar;
import rg.d0;

/* compiled from: CircleProgressView.kt */
public final class CircleProgressView extends ProgressBar {
    public int A;
    public int B;
    public int C;
    public int D;
    public int E;
    public int F;
    public RectF G;
    public RectF H;
    public int I;
    public Paint J;
    public Paint K;
    public Paint L;
    public Paint M;
    public int N;
    public int O;

    /* renamed from: p  reason: collision with root package name */
    public int f1019p;

    /* renamed from: q  reason: collision with root package name */
    public int f1020q;

    /* renamed from: r  reason: collision with root package name */
    public int f1021r;

    /* renamed from: s  reason: collision with root package name */
    public int f1022s;

    /* renamed from: t  reason: collision with root package name */
    public int f1023t;

    /* renamed from: u  reason: collision with root package name */
    public int f1024u;

    /* renamed from: v  reason: collision with root package name */
    public float f1025v;

    /* renamed from: w  reason: collision with root package name */
    public String f1026w;

    /* renamed from: x  reason: collision with root package name */
    public String f1027x;

    /* renamed from: y  reason: collision with root package name */
    public boolean f1028y;

    /* renamed from: z  reason: collision with root package name */
    public boolean f1029z;

    public final int a(Context context, float f10) {
        return (int) ((context.getResources().getDisplayMetrics().density * f10) + 0.5f);
    }

    public final void b(Canvas canvas) {
        canvas.save();
        canvas.translate(((float) this.N) / 2.0f, ((float) this.O) / 2.0f);
        RectF rectF = this.G;
        d0.d(rectF);
        Paint paint = this.M;
        d0.d(paint);
        canvas.drawArc(rectF, 0.0f, 360.0f, false, paint);
        float f10 = (float) 360;
        float progress = ((((float) getProgress()) * 1.0f) / ((float) getMax())) * f10;
        RectF rectF2 = this.H;
        d0.d(rectF2);
        float f11 = (float) this.B;
        Paint paint2 = this.L;
        d0.d(paint2);
        canvas.drawArc(rectF2, f11, progress, true, paint2);
        if (!(progress == 360.0f)) {
            RectF rectF3 = this.H;
            d0.d(rectF3);
            Paint paint3 = this.K;
            d0.d(paint3);
            canvas.drawArc(rectF3, progress + ((float) this.B), f10 - progress, true, paint3);
        }
        canvas.restore();
    }

    public final void c(Canvas canvas) {
        canvas.save();
        canvas.translate(((float) this.N) / 2.0f, ((float) this.O) / 2.0f);
        float progress = (((float) getProgress()) * 1.0f) / ((float) getMax());
        int i10 = this.A;
        float acos = (float) ((Math.acos(((double) (((float) i10) - (progress * ((float) (i10 * 2))))) / ((double) i10)) * ((double) 180)) / 3.141592653589793d);
        float f10 = (float) 2;
        float f11 = acos * f10;
        int i11 = this.A;
        float f12 = (float) (-i11);
        float f13 = (float) i11;
        this.G = new RectF(f12, f12, f13, f13);
        Paint paint = this.K;
        d0.d(paint);
        paint.setStyle(Paint.Style.FILL);
        RectF rectF = this.G;
        d0.d(rectF);
        Paint paint2 = this.K;
        d0.d(paint2);
        canvas.drawArc(rectF, ((float) 90) + acos, ((float) 360) - f11, false, paint2);
        canvas.rotate(180.0f);
        Paint paint3 = this.L;
        d0.d(paint3);
        paint3.setStyle(Paint.Style.FILL);
        RectF rectF2 = this.G;
        d0.d(rectF2);
        Paint paint4 = this.L;
        d0.d(paint4);
        canvas.drawArc(rectF2, ((float) 270) - acos, f11, false, paint4);
        canvas.rotate(180.0f);
        if (this.f1028y) {
            String a10 = f.a(this.f1027x, getProgress(), this.f1026w);
            Paint paint5 = this.J;
            d0.d(paint5);
            float measureText = paint5.measureText(a10);
            Paint paint6 = this.J;
            d0.d(paint6);
            float descent = paint6.descent();
            Paint paint7 = this.J;
            d0.d(paint7);
            Paint paint8 = this.J;
            d0.d(paint8);
            canvas.drawText(a10, (-measureText) / f10, (-(paint7.ascent() + descent)) / f10, paint8);
        }
    }

    public final void d(Canvas canvas) {
        canvas.save();
        canvas.translate(((float) this.N) / 2.0f, ((float) this.O) / 2.0f);
        if (this.f1028y) {
            String a10 = f.a(this.f1027x, getProgress(), this.f1026w);
            Paint paint = this.J;
            d0.d(paint);
            float measureText = paint.measureText(a10);
            Paint paint2 = this.J;
            d0.d(paint2);
            float descent = paint2.descent();
            Paint paint3 = this.J;
            d0.d(paint3);
            float ascent = paint3.ascent() + descent;
            float f10 = (float) 2;
            float f11 = (-measureText) / f10;
            float f12 = (-ascent) / f10;
            Paint paint4 = this.J;
            d0.d(paint4);
            canvas.drawText(a10, f11, f12, paint4);
        }
        float f13 = (float) 360;
        float progress = ((((float) getProgress()) * 1.0f) / ((float) getMax())) * f13;
        if (!(progress == 360.0f)) {
            RectF rectF = this.G;
            d0.d(rectF);
            Paint paint5 = this.K;
            d0.d(paint5);
            canvas.drawArc(rectF, progress + ((float) this.B), f13 - progress, false, paint5);
        }
        RectF rectF2 = this.G;
        d0.d(rectF2);
        Paint paint6 = this.L;
        d0.d(paint6);
        canvas.drawArc(rectF2, (float) this.B, progress, false, paint6);
        canvas.restore();
    }

    public final void e() {
        Paint paint = new Paint();
        this.J = paint;
        d0.d(paint);
        paint.setColor(this.f1024u);
        Paint paint2 = this.J;
        d0.d(paint2);
        paint2.setStyle(Paint.Style.FILL);
        Paint paint3 = this.J;
        d0.d(paint3);
        paint3.setTextSize((float) this.f1023t);
        Paint paint4 = this.J;
        d0.d(paint4);
        paint4.setTextSkewX(this.f1025v);
        Paint paint5 = this.J;
        d0.d(paint5);
        paint5.setAntiAlias(true);
        Paint paint6 = new Paint();
        this.K = paint6;
        d0.d(paint6);
        paint6.setColor(this.f1022s);
        Paint paint7 = this.K;
        d0.d(paint7);
        paint7.setStyle(this.D == 2 ? Paint.Style.FILL : Paint.Style.STROKE);
        Paint paint8 = this.K;
        d0.d(paint8);
        paint8.setAntiAlias(true);
        Paint paint9 = this.K;
        d0.d(paint9);
        paint9.setStrokeWidth((float) this.f1020q);
        Paint paint10 = new Paint();
        this.L = paint10;
        d0.d(paint10);
        paint10.setColor(this.f1021r);
        Paint paint11 = this.L;
        d0.d(paint11);
        paint11.setStyle(this.D == 2 ? Paint.Style.FILL : Paint.Style.STROKE);
        Paint paint12 = this.L;
        d0.d(paint12);
        paint12.setAntiAlias(true);
        Paint paint13 = this.L;
        d0.d(paint13);
        paint13.setStrokeCap(this.f1029z ? Paint.Cap.ROUND : Paint.Cap.BUTT);
        Paint paint14 = this.L;
        d0.d(paint14);
        paint14.setStrokeWidth((float) this.f1019p);
        if (this.D == 2) {
            Paint paint15 = new Paint();
            this.M = paint15;
            d0.d(paint15);
            paint15.setStyle(Paint.Style.STROKE);
            Paint paint16 = this.M;
            d0.d(paint16);
            paint16.setColor(this.F);
            Paint paint17 = this.M;
            d0.d(paint17);
            paint17.setStrokeWidth((float) this.I);
            Paint paint18 = this.M;
            d0.d(paint18);
            paint18.setAntiAlias(true);
        }
    }

    public final int getInnerBackgroundColor() {
        return this.C;
    }

    public final int getInnerPadding() {
        return this.E;
    }

    public final int getNormalBarColor() {
        return this.f1022s;
    }

    public final int getNormalBarSize() {
        return this.f1020q;
    }

    public final int getOuterColor() {
        return this.F;
    }

    public final int getOuterSize() {
        return this.I;
    }

    public final int getProgressStyle() {
        return this.D;
    }

    public final int getRadius() {
        return this.A;
    }

    public final int getReachBarColor() {
        return this.f1021r;
    }

    public final int getReachBarSize() {
        return this.f1019p;
    }

    public final int getStartArc() {
        return this.B;
    }

    public final int getTextColor() {
        return this.f1024u;
    }

    public final String getTextPrefix() {
        return this.f1027x;
    }

    public final int getTextSize() {
        return this.f1023t;
    }

    public final float getTextSkewX() {
        return this.f1025v;
    }

    public final String getTextSuffix() {
        return this.f1026w;
    }

    public void invalidate() {
        e();
        super.invalidate();
    }

    public synchronized void onDraw(Canvas canvas) {
        d0.g(canvas, "canvas");
        int i10 = this.D;
        if (i10 == 0) {
            d(canvas);
        } else if (i10 == 1) {
            c(canvas);
        } else if (i10 == 2) {
            b(canvas);
        }
    }

    public synchronized void onMeasure(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        int i15;
        int max = Math.max(this.f1019p, this.f1020q);
        int max2 = Math.max(max, this.I);
        int i16 = this.D;
        int i17 = 0;
        if (i16 != 0) {
            if (i16 == 1) {
                i13 = getPaddingTop() + getPaddingBottom() + Math.abs(this.A * 2);
                i15 = getPaddingLeft() + getPaddingRight();
                max2 = Math.abs(this.A * 2);
            } else if (i16 != 2) {
                i12 = 0;
                this.N = View.resolveSize(i17, i10);
                int resolveSize = View.resolveSize(i12, i11);
                this.O = resolveSize;
                setMeasuredDimension(this.N, resolveSize);
            } else {
                i13 = getPaddingTop() + getPaddingBottom() + Math.abs(this.A * 2) + max2;
                i15 = getPaddingLeft() + getPaddingRight() + Math.abs(this.A * 2);
            }
            i14 = i15 + max2;
        } else {
            i13 = getPaddingTop() + getPaddingBottom() + Math.abs(this.A * 2) + max;
            i14 = max + getPaddingLeft() + getPaddingRight() + Math.abs(this.A * 2);
        }
        int i18 = i13;
        i17 = i14;
        i12 = i18;
        this.N = View.resolveSize(i17, i10);
        int resolveSize2 = View.resolveSize(i12, i11);
        this.O = resolveSize2;
        setMeasuredDimension(this.N, resolveSize2);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        d0.g(parcelable, "state");
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            this.D = bundle.getInt("progressStyle");
            this.A = bundle.getInt("radius");
            this.f1029z = bundle.getBoolean("isReachCapRound");
            this.B = bundle.getInt("startArc");
            this.C = bundle.getInt("innerBgColor");
            this.E = bundle.getInt("innerPadding");
            this.F = bundle.getInt("outerColor");
            this.I = bundle.getInt("outerSize");
            this.f1024u = bundle.getInt("textColor");
            this.f1023t = bundle.getInt("textSize");
            this.f1025v = bundle.getFloat("textSkewX");
            this.f1028y = bundle.getBoolean("textVisible");
            String string = bundle.getString("textSuffix");
            d0.d(string);
            this.f1026w = string;
            String string2 = bundle.getString("textPrefix");
            d0.d(string2);
            this.f1027x = string2;
            this.f1021r = bundle.getInt("reachBarColor");
            this.f1019p = bundle.getInt("reachBarSize");
            this.f1022s = bundle.getInt("normalBarColor");
            this.f1020q = bundle.getInt("normalBarSize");
            e();
            super.onRestoreInstanceState(bundle.getParcelable("state"));
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("state", super.onSaveInstanceState());
        bundle.putInt("progressStyle", getProgressStyle());
        bundle.putInt("radius", getRadius());
        bundle.putBoolean("isReachCapRound", this.f1029z);
        bundle.putInt("startArc", getStartArc());
        bundle.putInt("innerBgColor", getInnerBackgroundColor());
        bundle.putInt("innerPadding", getInnerPadding());
        bundle.putInt("outerColor", getOuterColor());
        bundle.putInt("outerSize", getOuterSize());
        bundle.putInt("textColor", getTextColor());
        bundle.putInt("textSize", getTextSize());
        bundle.putFloat("textSkewX", getTextSkewX());
        bundle.putBoolean("textVisible", this.f1028y);
        bundle.putString("textSuffix", getTextSuffix());
        bundle.putString("textPrefix", getTextPrefix());
        bundle.putInt("reachBarColor", getReachBarColor());
        bundle.putInt("reachBarSize", getReachBarSize());
        bundle.putInt("normalBarColor", getNormalBarColor());
        bundle.putInt("normalBarSize", getNormalBarSize());
        return bundle;
    }

    public final void setInnerBackgroundColor(int i10) {
        this.C = i10;
        e();
        super.invalidate();
    }

    public final void setInnerPadding(int i10) {
        Context context = getContext();
        d0.f(context, "context");
        int a10 = a(context, (float) i10);
        this.E = a10;
        int i11 = (this.A - (this.I / 2)) - a10;
        float f10 = (float) (-i11);
        float f11 = (float) i11;
        this.H = new RectF(f10, f10, f11, f11);
        e();
        super.invalidate();
    }

    public final void setNormalBarColor(int i10) {
        this.f1022s = i10;
        e();
        super.invalidate();
    }

    public final void setNormalBarSize(int i10) {
        Context context = getContext();
        d0.f(context, "context");
        this.f1020q = a(context, (float) i10);
        e();
        super.invalidate();
    }

    public final void setOuterColor(int i10) {
        this.F = i10;
        e();
        super.invalidate();
    }

    public final void setOuterSize(int i10) {
        Context context = getContext();
        d0.f(context, "context");
        this.I = a(context, (float) i10);
        e();
        super.invalidate();
    }

    public final void setProgressStyle(int i10) {
        this.D = i10;
        e();
        super.invalidate();
    }

    public final void setRadius(int i10) {
        Context context = getContext();
        d0.f(context, "context");
        this.A = a(context, (float) i10);
        e();
        super.invalidate();
    }

    public final void setReachBarColor(int i10) {
        this.f1021r = i10;
        e();
        super.invalidate();
    }

    public final void setReachBarSize(int i10) {
        Context context = getContext();
        d0.f(context, "context");
        this.f1019p = a(context, (float) i10);
        e();
        super.invalidate();
    }

    public final void setReachCapRound(boolean z10) {
        this.f1029z = z10;
        e();
        super.invalidate();
    }

    public final void setStartArc(int i10) {
        this.B = i10;
        e();
        super.invalidate();
    }

    public final void setTextColor(int i10) {
        this.f1024u = i10;
        e();
        super.invalidate();
    }

    public final void setTextPrefix(String str) {
        d0.g(str, "textPrefix");
        this.f1027x = str;
        e();
        super.invalidate();
    }

    public final void setTextSize(int i10) {
        Context context = getContext();
        d0.f(context, "context");
        d0.g(context, "context");
        d0.g(context, "context");
        this.f1023t = (int) ((context.getResources().getDisplayMetrics().scaledDensity * ((float) i10)) + 0.5f);
        e();
        super.invalidate();
    }

    public final void setTextSkewX(float f10) {
        this.f1025v = f10;
        e();
        super.invalidate();
    }

    public final void setTextSuffix(String str) {
        d0.g(str, "textSuffix");
        this.f1026w = str;
        e();
        super.invalidate();
    }

    public final void setTextVisible(boolean z10) {
        this.f1028y = z10;
        e();
        super.invalidate();
    }
}
