package ai.plaud.android.plaud.common.util.image.widget;

import androidx.appcompat.widget.AppCompatImageView;

/* compiled from: SelectImageView.kt */
public final class SelectImageView extends AppCompatImageView {
    public void drawableStateChanged() {
        super.drawableStateChanged();
    }
}
