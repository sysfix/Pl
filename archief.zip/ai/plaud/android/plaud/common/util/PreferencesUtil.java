package ai.plaud.android.plaud.common.util;

import com.tencent.mmkv.MMKV;
import kotlin.jvm.internal.DefaultConstructorMarker;
import okhttp3.HttpUrl;
import rg.d0;
import xf.d;
import xf.e;

/* compiled from: PreferencesUtil.kt */
public final class PreferencesUtil {

    /* renamed from: b  reason: collision with root package name */
    public static final PreferencesUtil f1008b = null;

    /* renamed from: c  reason: collision with root package name */
    public static final d<PreferencesUtil> f1009c = e.a(PreferencesUtil$Companion$INSTANCE$2.INSTANCE);

    /* renamed from: a  reason: collision with root package name */
    public MMKV f1010a = MMKV.e();

    public PreferencesUtil() {
        MMKV.h(AppProvider.a());
    }

    public static final PreferencesUtil d() {
        return f1009c.getValue();
    }

    public final boolean a(String str) {
        return this.f1010a.b(str);
    }

    public final String b(String str) {
        String d10 = this.f1010a.d(str);
        return d10 == null ? HttpUrl.FRAGMENT_ENCODE_SET : d10;
    }

    public final void c(String str, String str2) {
        d0.g(str2, "value");
        this.f1010a.f(str, str2);
    }

    public PreferencesUtil(DefaultConstructorMarker defaultConstructorMarker) {
        MMKV.h(AppProvider.a());
    }
}
