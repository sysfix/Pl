package ai.plaud.android.plaud.common.util;

import android.content.Context;
import xf.d;
import xf.e;

/* compiled from: AppProvider.kt */
public final class AppProvider {

    /* renamed from: a  reason: collision with root package name */
    public static final d f1007a = e.a(AppProvider$instance$2.INSTANCE);

    public static final Context a() {
        return (Context) f1007a.getValue();
    }
}
