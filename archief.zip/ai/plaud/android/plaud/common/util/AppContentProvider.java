package ai.plaud.android.plaud.common.util;

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import rg.d0;

/* compiled from: AppContentProvider.kt */
public final class AppContentProvider extends ContentProvider {
    @SuppressLint({"StaticFieldLeak"})

    /* renamed from: p  reason: collision with root package name */
    public static Context f1006p;

    public int delete(Uri uri, String str, String[] strArr) {
        d0.g(uri, "p0");
        return 0;
    }

    public String getType(Uri uri) {
        d0.g(uri, "p0");
        return null;
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        d0.g(uri, "p0");
        return null;
    }

    public boolean onCreate() {
        f1006p = getContext();
        return true;
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        d0.g(uri, "p0");
        return null;
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        d0.g(uri, "p0");
        return 0;
    }
}
