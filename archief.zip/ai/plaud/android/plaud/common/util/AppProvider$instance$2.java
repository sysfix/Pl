package ai.plaud.android.plaud.common.util;

import android.content.Context;
import gg.a;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: AppProvider.kt */
public final class AppProvider$instance$2 extends Lambda implements a<Context> {
    public static final AppProvider$instance$2 INSTANCE = new AppProvider$instance$2();

    public AppProvider$instance$2() {
        super(0);
    }

    public final Context invoke() {
        Context context = AppContentProvider.f1006p;
        d0.d(context);
        return context;
    }
}
