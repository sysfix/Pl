package ai.plaud.android.plaud.base.extension;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;

/* compiled from: Viewbinding.kt */
public final class ViewbindingKt$doOnDestroyView$1 implements LifecycleObserver {
    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    public final void onDestroyView() {
        throw null;
    }
}
