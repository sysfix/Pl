package ai.plaud.android.plaud.base.component;

import ai.plaud.android.plaud.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import b1.a;
import p.a;

/* compiled from: LoadingOverlay.kt */
public final class LoadingOverlay extends RelativeLayout {

    /* renamed from: p  reason: collision with root package name */
    public final AppCompatTextView f977p;

    public LoadingOverlay(Context context, AttributeSet attributeSet, int i10) {
        super(context, (AttributeSet) null, R.style.LoadingOverlay);
        View view = new View(context, (AttributeSet) null);
        AppCompatImageView appCompatImageView = new AppCompatImageView(context, (AttributeSet) null);
        AppCompatTextView appCompatTextView = new AppCompatTextView(context, (AttributeSet) null, 2131951873);
        this.f977p = appCompatTextView;
        setGravity(17);
        setClickable(true);
        setFocusable(true);
        view.setId(View.generateViewId());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((int) a.b(120), (int) a.b(120));
        layoutParams.addRule(13);
        view.setLayoutParams(layoutParams);
        Object obj = b1.a.f4191a;
        view.setBackground(a.c.b(context, R.drawable.shape_toast_bg));
        addView(view);
        appCompatImageView.setId(View.generateViewId());
        RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams((int) p.a.b(42), (int) p.a.b(42));
        layoutParams2.addRule(13);
        appCompatImageView.setLayoutParams(layoutParams2);
        appCompatImageView.setAdjustViewBounds(true);
        appCompatImageView.setImageDrawable(a.c.b(context, R.drawable.ic_loading));
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(appCompatImageView, "rotation", new float[]{0.0f, 360.0f});
        ofFloat.setDuration(1000);
        ofFloat.setRepeatCount(-1);
        ofFloat.setRepeatMode(1);
        ofFloat.start();
        addView(appCompatImageView);
        appCompatTextView.setId(View.generateViewId());
        RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams3.addRule(13);
        layoutParams3.addRule(18, view.getId());
        layoutParams3.addRule(19, view.getId());
        layoutParams3.addRule(3, appCompatImageView.getId());
        layoutParams3.setMargins((int) p.a.b(10), (int) p.a.b(10), (int) p.a.b(10), 0);
        appCompatTextView.setGravity(17);
        appCompatTextView.setLayoutParams(layoutParams3);
        appCompatTextView.setTextColor(a.d.a(context, 17170443));
        addView(appCompatTextView);
        setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        setBackgroundColor(a.d.a(context, 17170445));
        setElevation(p.a.b(80));
    }

    public final void setFocus(boolean z10) {
        setFocusable(z10);
        setFocusableInTouchMode(z10);
        if (z10) {
            requestFocus();
            requestFocusFromTouch();
        }
    }
}
