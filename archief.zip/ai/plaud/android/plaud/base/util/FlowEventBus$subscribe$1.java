package ai.plaud.android.plaud.base.util;

import ag.c;
import gg.l;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.a;

@a(c = "ai.plaud.android.plaud.base.util.FlowEventBus", f = "FlowEventBus.kt", l = {46}, m = "subscribe")
/* compiled from: FlowEventBus.kt */
public final class FlowEventBus$subscribe$1<T> extends ContinuationImpl {
    public int label;
    public /* synthetic */ Object result;
    public final /* synthetic */ FlowEventBus this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlowEventBus$subscribe$1(FlowEventBus flowEventBus, c<? super FlowEventBus$subscribe$1> cVar) {
        super(cVar);
        this.this$0 = flowEventBus;
    }

    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= CellBase.GROUP_ID_SYSTEM_MESSAGE;
        return this.this$0.a((String) null, (l) null, this);
    }
}
