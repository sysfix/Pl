package ai.plaud.android.plaud.base.util;

/* compiled from: StatusBarTextColor.kt */
public enum StatusBarTextColor {
    LIGHT,
    DARK
}
