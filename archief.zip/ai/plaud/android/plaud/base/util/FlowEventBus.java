package ai.plaud.android.plaud.base.util;

import gg.l;
import java.util.HashMap;
import kotlinx.coroutines.channels.BufferOverflow;
import rg.d0;
import ug.c;
import ug.f;
import ug.k;
import xf.g;

/* compiled from: FlowEventBus.kt */
public final class FlowEventBus {

    /* renamed from: a  reason: collision with root package name */
    public static final FlowEventBus f1002a = new FlowEventBus();

    /* renamed from: b  reason: collision with root package name */
    public static final HashMap<String, f<? extends Object>> f1003b = new HashMap<>();

    /* compiled from: FlowEventBus.kt */
    public static final class a<T> implements c {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ l<T, g> f1004p;

        public a(l<? super T, g> lVar) {
            this.f1004p = lVar;
        }

        public final Object emit(T t10, ag.c<? super g> cVar) {
            this.f1004p.invoke(t10);
            return g.f19030a;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final <T> java.lang.Object a(java.lang.String r5, gg.l<? super T, xf.g> r6, ag.c<? super xf.g> r7) {
        /*
            r4 = this;
            boolean r0 = r7 instanceof ai.plaud.android.plaud.base.util.FlowEventBus$subscribe$1
            if (r0 == 0) goto L_0x0013
            r0 = r7
            ai.plaud.android.plaud.base.util.FlowEventBus$subscribe$1 r0 = (ai.plaud.android.plaud.base.util.FlowEventBus$subscribe$1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.label = r1
            goto L_0x0018
        L_0x0013:
            ai.plaud.android.plaud.base.util.FlowEventBus$subscribe$1 r0 = new ai.plaud.android.plaud.base.util.FlowEventBus$subscribe$1
            r0.<init>(r4, r7)
        L_0x0018:
            java.lang.Object r7 = r0.result
            kotlin.coroutines.intrinsics.CoroutineSingletons r1 = kotlin.coroutines.intrinsics.CoroutineSingletons.COROUTINE_SUSPENDED
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L_0x002f
            if (r2 == r3) goto L_0x002b
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L_0x002b:
            com.google.android.gms.internal.play_billing.x2.s(r7)
            goto L_0x0044
        L_0x002f:
            com.google.android.gms.internal.play_billing.x2.s(r7)
            ug.f r5 = r4.b(r5)
            ai.plaud.android.plaud.base.util.FlowEventBus$a r7 = new ai.plaud.android.plaud.base.util.FlowEventBus$a
            r7.<init>(r6)
            r0.label = r3
            java.lang.Object r5 = r5.collect(r7, r0)
            if (r5 != r1) goto L_0x0044
            return r1
        L_0x0044:
            kotlin.KotlinNothingValueException r5 = new kotlin.KotlinNothingValueException
            r5.<init>()
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.base.util.FlowEventBus.a(java.lang.String, gg.l, ag.c):java.lang.Object");
    }

    public final <T> f<T> b(String str) {
        HashMap<String, f<? extends Object>> hashMap = f1003b;
        if (!hashMap.containsKey(str)) {
            hashMap.put(str, k.a(0, 0, (BufferOverflow) null, 7));
        }
        f<? extends Object> fVar = hashMap.get(str);
        d0.e(fVar, "null cannot be cast to non-null type kotlinx.coroutines.flow.MutableSharedFlow<T of ai.plaud.android.plaud.base.util.FlowEventBus.with>");
        return fVar;
    }
}
