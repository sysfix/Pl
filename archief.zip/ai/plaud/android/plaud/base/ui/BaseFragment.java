package ai.plaud.android.plaud.base.ui;

import ag.c;
import ag.e;
import ai.plaud.android.plaud.base.component.LoadingOverlay;
import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwnerKt;
import java.util.concurrent.CancellationException;
import okhttp3.HttpUrl;
import p.b;
import p000if.a;
import rg.c0;
import rg.d0;
import rg.l0;
import rg.t;
import rg.z0;
import wg.q;
import yf.g;

/* compiled from: BaseFragment.kt */
public class BaseFragment extends Fragment implements c0 {

    /* renamed from: p  reason: collision with root package name */
    public t f993p = g.c((z0) null, 1);

    /* renamed from: q  reason: collision with root package name */
    public a f994q = new a(0);

    /* renamed from: r  reason: collision with root package name */
    public c0 f995r = g.b();

    /* renamed from: s  reason: collision with root package name */
    public n.a f996s;

    /* renamed from: t  reason: collision with root package name */
    public LoadingOverlay f997t;

    /* renamed from: u  reason: collision with root package name */
    public Toast f998u;

    /* renamed from: v  reason: collision with root package name */
    public b f999v;

    public final b c() {
        b bVar = this.f999v;
        if (bVar != null) {
            return bVar;
        }
        d0.q("rxClickHandler");
        throw null;
    }

    public void d() {
        LifecycleOwnerKt.getLifecycleScope(this).launchWhenResumed(new BaseFragment$hideLoadingScreen$1((c<? super BaseFragment$hideLoadingScreen$1>) null));
    }

    public void e() {
        LifecycleOwnerKt.getLifecycleScope(this).launchWhenResumed(new BaseFragment$showLoadingScreenWithNoMessage$1((c<? super BaseFragment$showLoadingScreenWithNoMessage$1>) null));
    }

    public e getCoroutineContext() {
        if (this.f996s != null) {
            l0 l0Var = l0.f16618a;
            return q.f18099a.plus(this.f993p);
        }
        d0.q("mDispatchers");
        throw null;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Context context = getContext();
        if (context != null) {
            LoadingOverlay loadingOverlay = new LoadingOverlay(context, (AttributeSet) null, 2);
            this.f997t = loadingOverlay;
            loadingOverlay.setId(View.generateViewId());
        }
    }

    public void onDestroyView() {
        super.onDestroyView();
        g.d(this.f995r, (CancellationException) null, 1);
        LoadingOverlay loadingOverlay = this.f997t;
        if (loadingOverlay != null) {
            ViewParent parent = loadingOverlay.getParent();
            ViewGroup viewGroup = parent instanceof ViewGroup ? (ViewGroup) parent : null;
            if (viewGroup != null) {
                LoadingOverlay loadingOverlay2 = this.f997t;
                if (loadingOverlay2 != null) {
                    viewGroup.removeView(loadingOverlay2);
                } else {
                    d0.q("mLoadingOverlay");
                    throw null;
                }
            }
        } else {
            d0.q("mLoadingOverlay");
            throw null;
        }
    }

    public void onStart() {
        super.onStart();
        this.f993p = g.c((z0) null, 1);
        this.f994q = new a(0);
        this.f995r = g.b();
    }

    public void onStop() {
        super.onStop();
        this.f993p.d((CancellationException) null);
        this.f994q.c();
        g.d(this.f995r, (CancellationException) null, 1);
    }

    public void onViewCreated(View view, Bundle bundle) {
        d0.g(view, "view");
        super.onViewCreated(view, bundle);
        ViewGroup viewGroup = view instanceof ViewGroup ? (ViewGroup) view : null;
        if (viewGroup != null) {
            LoadingOverlay loadingOverlay = this.f997t;
            if (loadingOverlay != null) {
                viewGroup.addView(loadingOverlay);
            } else {
                d0.q("mLoadingOverlay");
                throw null;
            }
        }
        LoadingOverlay loadingOverlay2 = this.f997t;
        if (loadingOverlay2 != null) {
            loadingOverlay2.f977p.setText(HttpUrl.FRAGMENT_ENCODE_SET);
            loadingOverlay2.setVisibility(8);
            return;
        }
        d0.q("mLoadingOverlay");
        throw null;
    }
}
