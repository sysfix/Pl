package ai.plaud.android.plaud.base.ui;

import ag.c;
import ai.plaud.android.plaud.base.util.FlowEventBus;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.base.ui.BaseFragment$hideLoadingScreen$1", f = "BaseFragment.kt", l = {305}, m = "invokeSuspend")
/* compiled from: BaseFragment.kt */
public final class BaseFragment$hideLoadingScreen$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public int label;

    public BaseFragment$hideLoadingScreen$1(c<? super BaseFragment$hideLoadingScreen$1> cVar) {
        super(2, cVar);
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new BaseFragment$hideLoadingScreen$1(cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((BaseFragment$hideLoadingScreen$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            FlowEventBus flowEventBus = FlowEventBus.f1002a;
            Boolean bool = Boolean.FALSE;
            this.label = 1;
            Object emit = flowEventBus.b("SHOW_LOADING").emit(bool, this);
            if (emit != coroutineSingletons) {
                emit = g.f19030a;
            }
            if (emit == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return g.f19030a;
    }
}
