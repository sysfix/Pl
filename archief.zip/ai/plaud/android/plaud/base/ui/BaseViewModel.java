package ai.plaud.android.plaud.base.ui;

import ag.c;
import ag.e;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import com.google.android.gms.internal.measurement.n8;
import gg.l;
import java.util.Objects;
import java.util.concurrent.CancellationException;
import kotlinx.coroutines.CoroutineStart;
import n.a;
import rg.c0;
import rg.l0;
import rg.t;
import rg.z0;
import wg.q;
import yf.g;

/* compiled from: BaseViewModel.kt */
public class BaseViewModel extends ViewModel implements c0, LifecycleObserver {

    /* renamed from: p  reason: collision with root package name */
    public final a f1000p;

    /* renamed from: q  reason: collision with root package name */
    public final t f1001q = g.c((z0) null, 1);

    public BaseViewModel(a aVar) {
        this.f1000p = aVar;
    }

    public final <T> void c(l<? super c<? super T>, ? extends Object> lVar) {
        c0 viewModelScope = ViewModelKt.getViewModelScope(this);
        Objects.requireNonNull(this.f1000p);
        n8.f(viewModelScope, l0.f16620c, (CoroutineStart) null, new BaseViewModel$launchIo$1(lVar, (c<? super BaseViewModel$launchIo$1>) null), 2, (Object) null);
    }

    public e getCoroutineContext() {
        Objects.requireNonNull(this.f1000p);
        l0 l0Var = l0.f16618a;
        return q.f18099a.plus(this.f1001q);
    }

    public void onCleared() {
        super.onCleared();
        this.f1001q.d((CancellationException) null);
    }
}
