package ai.plaud.android.plaud.base.ui;

import ag.c;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import gg.p;
import kotlin.Result;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.base.ui.BaseViewModel$launchIo$1", f = "BaseViewModel.kt", l = {87}, m = "invokeSuspend")
/* compiled from: BaseViewModel.kt */
public final class BaseViewModel$launchIo$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ l<c<? super T>, Object> $block;
    private /* synthetic */ Object L$0;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public BaseViewModel$launchIo$1(l<? super c<? super T>, ? extends Object> lVar, c<? super BaseViewModel$launchIo$1> cVar) {
        super(2, cVar);
        this.$block = lVar;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        BaseViewModel$launchIo$1 baseViewModel$launchIo$1 = new BaseViewModel$launchIo$1(this.$block, cVar);
        baseViewModel$launchIo$1.L$0 = obj;
        return baseViewModel$launchIo$1;
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((BaseViewModel$launchIo$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        Object obj2;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            c0 c0Var = (c0) this.L$0;
            l<c<? super T>, Object> lVar = this.$block;
            this.label = 1;
            obj = lVar.invoke(this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            try {
                x2.s(obj);
            } catch (Throwable th2) {
                obj2 = Result.m97constructorimpl(x2.k(th2));
            }
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        obj2 = Result.m97constructorimpl(obj);
        Result.m100exceptionOrNullimpl(obj2);
        return g.f19030a;
    }
}
