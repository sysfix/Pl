package ai.plaud.android.plaud.base.navigation;

import ai.plaud.android.plaud.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.a;
import h2.o;
import h2.p;
import h2.v;
import h2.w;

/* compiled from: NavHostFragment */
public class b extends Fragment {

    /* renamed from: t  reason: collision with root package name */
    public static final /* synthetic */ int f988t = 0;

    /* renamed from: p  reason: collision with root package name */
    public o f989p;

    /* renamed from: q  reason: collision with root package name */
    public Boolean f990q = null;

    /* renamed from: r  reason: collision with root package name */
    public int f991r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f992s;

    public void onAttach(Context context) {
        super.onAttach(context);
        if (this.f992s) {
            a aVar = new a(getParentFragmentManager());
            aVar.p(this);
            aVar.e();
        }
    }

    public void onCreate(Bundle bundle) {
        Bundle bundle2;
        super.onCreate(bundle);
        o oVar = new o(requireContext());
        this.f989p = oVar;
        oVar.z(this);
        this.f989p.A(requireActivity().getOnBackPressedDispatcher());
        o oVar2 = this.f989p;
        Boolean bool = this.f990q;
        int i10 = 0;
        oVar2.f3347u = bool != null && bool.booleanValue();
        oVar2.y();
        Bundle bundle3 = null;
        this.f990q = null;
        this.f989p.B(getViewModelStore());
        o oVar3 = this.f989p;
        oVar3.f3348v.a(new DialogFragmentNavigator(requireContext(), getChildFragmentManager()));
        w wVar = oVar3.f3348v;
        Context requireContext = requireContext();
        FragmentManager childFragmentManager = getChildFragmentManager();
        int id2 = getId();
        if (id2 == 0 || id2 == -1) {
            id2 = R.id.nav_host_fragment_container;
        }
        wVar.a(new a(requireContext, childFragmentManager, id2));
        if (bundle != null) {
            bundle2 = bundle.getBundle("android-support-nav:fragment:navControllerState");
            if (bundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
                this.f992s = true;
                a aVar = new a(getParentFragmentManager());
                aVar.p(this);
                aVar.e();
            }
            this.f991r = bundle.getInt("android-support-nav:fragment:graphId");
        } else {
            bundle2 = null;
        }
        if (bundle2 != null) {
            this.f989p.s(bundle2);
        }
        int i11 = this.f991r;
        if (i11 != 0) {
            o oVar4 = this.f989p;
            oVar4.v(((p) oVar4.C.getValue()).c(i11), (Bundle) null);
            return;
        }
        Bundle arguments = getArguments();
        if (arguments != null) {
            i10 = arguments.getInt("android-support-nav:fragment:graphId");
        }
        if (arguments != null) {
            bundle3 = arguments.getBundle("android-support-nav:fragment:startDestinationArgs");
        }
        if (i10 != 0) {
            o oVar5 = this.f989p;
            oVar5.v(((p) oVar5.C.getValue()).c(i10), bundle3);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FragmentContainerView fragmentContainerView = new FragmentContainerView(layoutInflater.getContext());
        int id2 = getId();
        if (id2 == 0 || id2 == -1) {
            id2 = R.id.nav_host_fragment_container;
        }
        fragmentContainerView.setId(id2);
        return fragmentContainerView;
    }

    public void onInflate(Context context, AttributeSet attributeSet, Bundle bundle) {
        super.onInflate(context, attributeSet, bundle);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, m.b.f14124b);
        int resourceId = obtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            this.f991r = resourceId;
        }
        obtainStyledAttributes.recycle();
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, m.b.f14125c);
        if (obtainStyledAttributes2.getBoolean(0, false)) {
            this.f992s = true;
        }
        obtainStyledAttributes2.recycle();
    }

    public void onPrimaryNavigationFragmentChanged(boolean z10) {
        o oVar = this.f989p;
        if (oVar != null) {
            oVar.f3347u = z10;
            oVar.y();
            return;
        }
        this.f990q = Boolean.valueOf(z10);
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        Bundle u10 = this.f989p.u();
        if (u10 != null) {
            bundle.putBundle("android-support-nav:fragment:navControllerState", u10);
        }
        if (this.f992s) {
            bundle.putBoolean("android-support-nav:fragment:defaultHost", true);
        }
        int i10 = this.f991r;
        if (i10 != 0) {
            bundle.putInt("android-support-nav:fragment:graphId", i10);
        }
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        if (view instanceof ViewGroup) {
            v.b(view, this.f989p);
            if (view.getParent() != null) {
                View view2 = (View) view.getParent();
                if (view2.getId() == getId()) {
                    v.b(view2, this.f989p);
                    return;
                }
                return;
            }
            return;
        }
        throw new IllegalStateException("created host view " + view + " is not a ViewGroup");
    }
}
