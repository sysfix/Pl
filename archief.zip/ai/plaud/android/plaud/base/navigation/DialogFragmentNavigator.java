package ai.plaud.android.plaud.base.navigation;

import ai.plaud.android.plaud.anew.flutter.audio.f;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.k;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.navigation.NavController;
import androidx.navigation.Navigator;
import h2.c;
import h2.l;
import h2.q;
import h2.v;
import j2.d;

@Navigator.b("dialog")
public final class DialogFragmentNavigator extends Navigator<a> {

    /* renamed from: c  reason: collision with root package name */
    public final Context f978c;

    /* renamed from: d  reason: collision with root package name */
    public final FragmentManager f979d;

    /* renamed from: e  reason: collision with root package name */
    public int f980e = 0;

    /* renamed from: f  reason: collision with root package name */
    public final LifecycleEventObserver f981f = new LifecycleEventObserver(this) {
        public void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
            NavController a10;
            if (event == Lifecycle.Event.ON_STOP) {
                k kVar = (k) lifecycleOwner;
                if (!kVar.e().isShowing()) {
                    int i10 = b.f988t;
                    Fragment fragment = kVar;
                    while (true) {
                        if (fragment == null) {
                            View view = kVar.getView();
                            if (view != null) {
                                a10 = v.a(view);
                            } else {
                                throw new IllegalStateException("Fragment " + kVar + " does not have a NavController set");
                            }
                        } else if (fragment instanceof b) {
                            a10 = ((b) fragment).f989p;
                            if (a10 == null) {
                                throw new IllegalStateException("NavController is not available before onCreate()");
                            }
                        } else {
                            Fragment fragment2 = fragment.getParentFragmentManager().f3073y;
                            if (fragment2 instanceof b) {
                                a10 = ((b) fragment2).f989p;
                                if (a10 == null) {
                                    throw new IllegalStateException("NavController is not available before onCreate()");
                                }
                            } else {
                                fragment = fragment.getParentFragment();
                            }
                        }
                    }
                    a10.l();
                }
            }
        }
    };

    public static class a extends l implements c {

        /* renamed from: z  reason: collision with root package name */
        public String f982z;

        public a(Navigator<? extends a> navigator) {
            super(navigator);
        }

        public void t(Context context, AttributeSet attributeSet) {
            super.t(context, attributeSet);
            TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, d.f13149a);
            String string = obtainAttributes.getString(0);
            if (string != null) {
                this.f982z = string;
            }
            obtainAttributes.recycle();
        }
    }

    public DialogFragmentNavigator(Context context, FragmentManager fragmentManager) {
        this.f978c = context;
        this.f979d = fragmentManager;
    }

    public l a() {
        return new a(this);
    }

    public l c(l lVar, Bundle bundle, q qVar, Navigator.a aVar) {
        a aVar2 = (a) lVar;
        if (this.f979d.R()) {
            Log.i("DialogFragmentNavigator", "Ignoring navigate() call: FragmentManager has already saved its state");
            return null;
        }
        String str = aVar2.f982z;
        if (str != null) {
            if (str.charAt(0) == '.') {
                str = this.f978c.getPackageName() + str;
            }
            Fragment a10 = this.f979d.J().a(this.f978c.getClassLoader(), str);
            if (!k.class.isAssignableFrom(a10.getClass())) {
                StringBuilder a11 = f.a.a("Dialog destination ");
                String str2 = aVar2.f982z;
                if (str2 != null) {
                    throw new IllegalArgumentException(c.d.a(a11, str2, " is not an instance of DialogFragment"));
                }
                throw new IllegalStateException("DialogFragment class was not set");
            }
            k kVar = (k) a10;
            kVar.setArguments(bundle);
            kVar.getLifecycle().addObserver(this.f981f);
            FragmentManager fragmentManager = this.f979d;
            StringBuilder a12 = f.a.a("androidx-nav-fragment:navigator:dialog:");
            int i10 = this.f980e;
            this.f980e = i10 + 1;
            a12.append(i10);
            kVar.f(fragmentManager, a12.toString());
            return aVar2;
        }
        throw new IllegalStateException("DialogFragment class was not set");
    }

    public void f(Bundle bundle) {
        int i10 = 0;
        this.f980e = bundle.getInt("androidx-nav-dialogfragment:navigator:count", 0);
        while (i10 < this.f980e) {
            FragmentManager fragmentManager = this.f979d;
            k kVar = (k) fragmentManager.G("androidx-nav-fragment:navigator:dialog:" + i10);
            if (kVar != null) {
                kVar.getLifecycle().addObserver(this.f981f);
                i10++;
            } else {
                throw new IllegalStateException(f.a("DialogFragment ", i10, " doesn't exist in the FragmentManager"));
            }
        }
    }

    public Bundle g() {
        if (this.f980e == 0) {
            return null;
        }
        Bundle bundle = new Bundle();
        bundle.putInt("androidx-nav-dialogfragment:navigator:count", this.f980e);
        return bundle;
    }

    public boolean i() {
        if (this.f980e == 0) {
            return false;
        }
        if (this.f979d.R()) {
            Log.i("DialogFragmentNavigator", "Ignoring popBackStack() call: FragmentManager has already saved its state");
            return false;
        }
        FragmentManager fragmentManager = this.f979d;
        StringBuilder a10 = f.a.a("androidx-nav-fragment:navigator:dialog:");
        int i10 = this.f980e - 1;
        this.f980e = i10;
        a10.append(i10);
        Fragment G = fragmentManager.G(a10.toString());
        if (G != null) {
            G.getLifecycle().removeObserver(this.f981f);
            ((k) G).c(false, false, false);
        }
        return true;
    }
}
