package ai.plaud.android.plaud.base.navigation;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.Navigator;
import h2.l;
import java.util.ArrayDeque;
import java.util.Iterator;

@Navigator.b("fragment")
/* compiled from: FragmentNavigator */
public class a extends Navigator<C0014a> {

    /* renamed from: c  reason: collision with root package name */
    public final Context f983c;

    /* renamed from: d  reason: collision with root package name */
    public final FragmentManager f984d;

    /* renamed from: e  reason: collision with root package name */
    public final int f985e;

    /* renamed from: f  reason: collision with root package name */
    public final ArrayDeque<Integer> f986f = new ArrayDeque<>();

    /* renamed from: ai.plaud.android.plaud.base.navigation.a$a  reason: collision with other inner class name */
    /* compiled from: FragmentNavigator */
    public static class C0014a extends l {

        /* renamed from: z  reason: collision with root package name */
        public String f987z;

        public C0014a(Navigator<? extends C0014a> navigator) {
            super(navigator);
        }

        public void t(Context context, AttributeSet attributeSet) {
            super.t(context, attributeSet);
            TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, m.b.f14123a);
            String string = obtainAttributes.getString(0);
            if (string != null) {
                this.f987z = string;
            }
            obtainAttributes.recycle();
        }

        public String toString() {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(super.toString());
            sb2.append(" class=");
            String str = this.f987z;
            if (str == null) {
                sb2.append("null");
            } else {
                sb2.append(str);
            }
            return sb2.toString();
        }
    }

    /* compiled from: FragmentNavigator */
    public static final class b implements Navigator.a {
    }

    public a(Context context, FragmentManager fragmentManager, int i10) {
        this.f983c = context;
        this.f984d = fragmentManager;
        this.f985e = i10;
    }

    public l a() {
        return new C0014a(this);
    }

    /* JADX WARNING: Removed duplicated region for block: B:56:0x0128  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x015c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public h2.l c(h2.l r9, android.os.Bundle r10, h2.q r11, androidx.navigation.Navigator.a r12) {
        /*
            r8 = this;
            ai.plaud.android.plaud.base.navigation.a$a r9 = (ai.plaud.android.plaud.base.navigation.a.C0014a) r9
            androidx.fragment.app.FragmentManager r0 = r8.f984d
            boolean r0 = r0.R()
            r1 = 0
            if (r0 == 0) goto L_0x0014
            java.lang.String r9 = "FragmentNavigator"
            java.lang.String r10 = "Ignoring navigate() call: FragmentManager has already saved its state"
            android.util.Log.i(r9, r10)
            goto L_0x0166
        L_0x0014:
            java.lang.String r0 = r9.f987z
            if (r0 == 0) goto L_0x0168
            r2 = 0
            char r3 = r0.charAt(r2)
            r4 = 46
            if (r3 != r4) goto L_0x0036
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            android.content.Context r4 = r8.f983c
            java.lang.String r4 = r4.getPackageName()
            r3.append(r4)
            r3.append(r0)
            java.lang.String r0 = r3.toString()
        L_0x0036:
            android.content.Context r3 = r8.f983c
            androidx.fragment.app.FragmentManager r4 = r8.f984d
            androidx.fragment.app.q r4 = r4.J()
            java.lang.ClassLoader r3 = r3.getClassLoader()
            androidx.fragment.app.Fragment r0 = r4.a(r3, r0)
            r0.setArguments(r10)
            androidx.fragment.app.FragmentManager r10 = r8.f984d
            androidx.fragment.app.a r3 = new androidx.fragment.app.a
            r3.<init>((androidx.fragment.app.FragmentManager) r10)
            r10 = -1
            if (r11 == 0) goto L_0x0056
            int r4 = r11.f11401f
            goto L_0x0057
        L_0x0056:
            r4 = r10
        L_0x0057:
            if (r11 == 0) goto L_0x005c
            int r5 = r11.f11402g
            goto L_0x005d
        L_0x005c:
            r5 = r10
        L_0x005d:
            if (r11 == 0) goto L_0x0062
            int r6 = r11.f11403h
            goto L_0x0063
        L_0x0062:
            r6 = r10
        L_0x0063:
            if (r11 == 0) goto L_0x0068
            int r7 = r11.f11404i
            goto L_0x0069
        L_0x0068:
            r7 = r10
        L_0x0069:
            if (r4 != r10) goto L_0x0071
            if (r5 != r10) goto L_0x0071
            if (r6 != r10) goto L_0x0071
            if (r7 == r10) goto L_0x0089
        L_0x0071:
            if (r4 == r10) goto L_0x0074
            goto L_0x0075
        L_0x0074:
            r4 = r2
        L_0x0075:
            if (r5 == r10) goto L_0x0078
            goto L_0x0079
        L_0x0078:
            r5 = r2
        L_0x0079:
            if (r6 == r10) goto L_0x007c
            goto L_0x007d
        L_0x007c:
            r6 = r2
        L_0x007d:
            if (r7 == r10) goto L_0x0080
            goto L_0x0081
        L_0x0080:
            r7 = r2
        L_0x0081:
            r3.f3141b = r4
            r3.f3142c = r5
            r3.f3143d = r6
            r3.f3144e = r7
        L_0x0089:
            androidx.fragment.app.FragmentManager r10 = r8.f984d
            java.util.List r10 = r10.K()
            int r10 = r10.size()
            r4 = 1
            if (r10 <= 0) goto L_0x00b6
            androidx.fragment.app.FragmentManager r10 = r8.f984d
            java.util.List r10 = r10.K()
            androidx.fragment.app.FragmentManager r5 = r8.f984d
            java.util.List r5 = r5.K()
            int r5 = r5.size()
            int r5 = r5 - r4
            java.lang.Object r10 = r10.get(r5)
            androidx.fragment.app.Fragment r10 = (androidx.fragment.app.Fragment) r10
            r3.n(r10)
            int r10 = r8.f985e
            r3.f(r10, r0, r1, r4)
            goto L_0x00bb
        L_0x00b6:
            int r10 = r8.f985e
            r3.g(r10, r0)
        L_0x00bb:
            r3.p(r0)
            int r10 = r9.f11382w
            java.util.ArrayDeque<java.lang.Integer> r0 = r8.f986f
            boolean r0 = r0.isEmpty()
            if (r11 == 0) goto L_0x00de
            if (r0 != 0) goto L_0x00de
            boolean r11 = r11.f11396a
            if (r11 == 0) goto L_0x00de
            java.util.ArrayDeque<java.lang.Integer> r11 = r8.f986f
            java.lang.Object r11 = r11.peekLast()
            java.lang.Integer r11 = (java.lang.Integer) r11
            int r11 = r11.intValue()
            if (r11 != r10) goto L_0x00de
            r11 = r4
            goto L_0x00df
        L_0x00de:
            r11 = r2
        L_0x00df:
            if (r0 == 0) goto L_0x00e2
            goto L_0x0123
        L_0x00e2:
            if (r11 == 0) goto L_0x0115
            java.util.ArrayDeque<java.lang.Integer> r11 = r8.f986f
            int r11 = r11.size()
            if (r11 <= r4) goto L_0x0124
            androidx.fragment.app.FragmentManager r11 = r8.f984d
            java.util.ArrayDeque<java.lang.Integer> r0 = r8.f986f
            int r0 = r0.size()
            java.util.ArrayDeque<java.lang.Integer> r5 = r8.f986f
            java.lang.Object r5 = r5.peekLast()
            java.lang.Integer r5 = (java.lang.Integer) r5
            int r5 = r5.intValue()
            java.lang.String r0 = r8.j(r0, r5)
            r11.V(r0, r4)
            java.util.ArrayDeque<java.lang.Integer> r11 = r8.f986f
            int r11 = r11.size()
            java.lang.String r11 = r8.j(r11, r10)
            r3.d(r11)
            goto L_0x0124
        L_0x0115:
            java.util.ArrayDeque<java.lang.Integer> r11 = r8.f986f
            int r11 = r11.size()
            int r11 = r11 + r4
            java.lang.String r11 = r8.j(r11, r10)
            r3.d(r11)
        L_0x0123:
            r2 = r4
        L_0x0124:
            boolean r11 = r12 instanceof ai.plaud.android.plaud.base.navigation.a.b
            if (r11 == 0) goto L_0x0155
            ai.plaud.android.plaud.base.navigation.a$b r12 = (ai.plaud.android.plaud.base.navigation.a.b) r12
            java.util.Objects.requireNonNull(r12)
            java.util.Map r11 = java.util.Collections.unmodifiableMap(r1)
            java.util.Set r11 = r11.entrySet()
            java.util.Iterator r11 = r11.iterator()
        L_0x0139:
            boolean r12 = r11.hasNext()
            if (r12 == 0) goto L_0x0155
            java.lang.Object r12 = r11.next()
            java.util.Map$Entry r12 = (java.util.Map.Entry) r12
            java.lang.Object r0 = r12.getKey()
            android.view.View r0 = (android.view.View) r0
            java.lang.Object r12 = r12.getValue()
            java.lang.String r12 = (java.lang.String) r12
            r3.c(r0, r12)
            goto L_0x0139
        L_0x0155:
            r3.f3155p = r4
            r3.e()
            if (r2 == 0) goto L_0x0166
            java.util.ArrayDeque<java.lang.Integer> r11 = r8.f986f
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)
            r11.add(r10)
            goto L_0x0167
        L_0x0166:
            r9 = r1
        L_0x0167:
            return r9
        L_0x0168:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "Fragment class was not set"
            r9.<init>(r10)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.base.navigation.a.c(h2.l, android.os.Bundle, h2.q, androidx.navigation.Navigator$a):h2.l");
    }

    public void f(Bundle bundle) {
        int[] intArray = bundle.getIntArray("androidx-nav-fragment:navigator:backStackIds");
        if (intArray != null) {
            this.f986f.clear();
            for (int valueOf : intArray) {
                this.f986f.add(Integer.valueOf(valueOf));
            }
        }
    }

    public Bundle g() {
        Bundle bundle = new Bundle();
        int[] iArr = new int[this.f986f.size()];
        Iterator<Integer> it = this.f986f.iterator();
        int i10 = 0;
        while (it.hasNext()) {
            iArr[i10] = it.next().intValue();
            i10++;
        }
        bundle.putIntArray("androidx-nav-fragment:navigator:backStackIds", iArr);
        return bundle;
    }

    public boolean i() {
        if (this.f986f.isEmpty()) {
            return false;
        }
        if (this.f984d.R()) {
            Log.i("FragmentNavigator", "Ignoring popBackStack() call: FragmentManager has already saved its state");
            return false;
        }
        this.f984d.V(j(this.f986f.size(), this.f986f.peekLast().intValue()), 1);
        this.f986f.removeLast();
        return true;
    }

    public final String j(int i10, int i11) {
        return i10 + "-" + i11;
    }
}
