package ai.plaud.android.plaud.soundplus;

/* compiled from: LibSoundPlus.kt */
public final class LibSoundPlus {

    /* renamed from: a  reason: collision with root package name */
    public static final LibSoundPlus f1056a = new LibSoundPlus();

    /* renamed from: b  reason: collision with root package name */
    public static boolean f1057b;

    static {
        System.loadLibrary("SoundPlus");
    }

    public final native int initSoundPlus(int i10);

    public final native void setSoundPlusDrcPregain(float f10);

    public final native void setSoundPlusNoiseFloor(int i10);

    public final native float[] soundplusProcess(float[] fArr);
}
