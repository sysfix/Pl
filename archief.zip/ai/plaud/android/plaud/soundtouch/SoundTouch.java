package ai.plaud.android.plaud.soundtouch;

/* compiled from: SoundTouch.kt */
public final class SoundTouch {

    /* renamed from: a  reason: collision with root package name */
    public long f1058a = newInstance();

    static {
        System.loadLibrary("soundtouch");
    }

    public final native void deleteInstance(long j10);

    public final native int encodeData(long j10, float[] fArr, float[] fArr2);

    public final native long newInstance();

    public final native void setChannels(long j10, int i10);

    public final native void setPitchSemiTones(long j10, float f10);

    public final native void setSampleRate(long j10, int i10);

    public final native void setTempo(long j10, float f10);
}
