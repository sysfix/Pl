package ai.plaud.android.plaud.splash;

import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.base.util.StatusBarTextColor;
import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import androidx.lifecycle.LifecycleOwnerKt;
import l1.a;
import w.b;

@SuppressLint({"CustomSplashScreen"})
/* compiled from: SplashActivity.kt */
public final class SplashActivity extends b {
    public static final /* synthetic */ int A = 0;

    public StatusBarTextColor i() {
        return StatusBarTextColor.LIGHT;
    }

    public void onCreate(Bundle bundle) {
        l1.b bVar;
        if (Build.VERSION.SDK_INT >= 31) {
            bVar = new a(this);
        } else {
            bVar = new l1.b(this);
        }
        bVar.a();
        super.onCreate(bundle);
        int color = getResources().getColor(R.color.ck_161616);
        Window window = getWindow();
        window.addFlags(CellBase.GROUP_ID_SYSTEM_MESSAGE);
        window.setNavigationBarColor(color);
        setContentView((int) R.layout.activity_splash);
        LifecycleOwnerKt.getLifecycleScope(this).launchWhenCreated(new SplashActivity$onCreate$1(this, (c<? super SplashActivity$onCreate$1>) null));
    }

    public void onStop() {
        super.onStop();
        finish();
    }
}
