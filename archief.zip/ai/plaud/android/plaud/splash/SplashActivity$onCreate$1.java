package ai.plaud.android.plaud.splash;

import ag.c;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import ai.plaud.android.plaud.landing.LandingActivity;
import android.content.Intent;
import com.google.android.gms.internal.measurement.n8;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.android.FlutterActivityLaunchConfigs;
import java.util.Objects;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import rg.c0;
import rg.d0;
import rg.l0;
import xf.g;
import yf.h;

@a(c = "ai.plaud.android.plaud.splash.SplashActivity$onCreate$1", f = "SplashActivity.kt", l = {38}, m = "invokeSuspend")
/* compiled from: SplashActivity.kt */
public final class SplashActivity$onCreate$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public int label;
    public final /* synthetic */ SplashActivity this$0;

    @a(c = "ai.plaud.android.plaud.splash.SplashActivity$onCreate$1$1", f = "SplashActivity.kt", l = {39}, m = "invokeSuspend")
    /* renamed from: ai.plaud.android.plaud.splash.SplashActivity$onCreate$1$1  reason: invalid class name */
    /* compiled from: SplashActivity.kt */
    public static final class AnonymousClass1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
        public int label;

        public final c<g> create(Object obj, c<?> cVar) {
            return new AnonymousClass1(cVar);
        }

        public final Object invoke(c0 c0Var, c<? super g> cVar) {
            return ((AnonymousClass1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
        }

        public final Object invokeSuspend(Object obj) {
            CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
            int i10 = this.label;
            if (i10 == 0) {
                x2.s(obj);
                this.label = 1;
                if (h.n(2000, this) == coroutineSingletons) {
                    return coroutineSingletons;
                }
            } else if (i10 == 1) {
                x2.s(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return g.f19030a;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SplashActivity$onCreate$1(SplashActivity splashActivity, c<? super SplashActivity$onCreate$1> cVar) {
        super(2, cVar);
        this.this$0 = splashActivity;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new SplashActivity$onCreate$1(this.this$0, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((SplashActivity$onCreate$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        Intent intent;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        boolean z10 = true;
        if (i10 == 0) {
            x2.s(obj);
            kotlinx.coroutines.a aVar = l0.f16620c;
            AnonymousClass1 r12 = new AnonymousClass1((c<? super AnonymousClass1>) null);
            this.label = 1;
            if (n8.v(aVar, r12, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        SplashActivity splashActivity = this.this$0;
        int i11 = SplashActivity.A;
        Objects.requireNonNull(splashActivity);
        PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
        if (PreferencesUtil.d().b("user_id_key").length() != 0) {
            z10 = false;
        }
        if (z10) {
            intent = new Intent(splashActivity, LandingActivity.class);
        } else {
            int i12 = FlutterActivity.f12131t;
            intent = new Intent(splashActivity, FlutterActivity.class).putExtra("cached_engine_id", "plaud_flutter_engine_id").putExtra("destroy_engine_with_activity", false).putExtra("background_mode", FlutterActivityLaunchConfigs.f12137a);
            d0.f(intent, "{\n        FlutterActivit…his@SplashActivity)\n    }");
        }
        intent.setFlags(268468224);
        splashActivity.startActivity(intent);
        return g.f19030a;
    }
}
