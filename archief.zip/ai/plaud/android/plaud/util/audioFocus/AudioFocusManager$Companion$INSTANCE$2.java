package ai.plaud.android.plaud.util.audioFocus;

import gg.a;
import kotlin.jvm.internal.Lambda;

/* compiled from: AudioFocusManager.kt */
public final class AudioFocusManager$Companion$INSTANCE$2 extends Lambda implements a<AudioFocusManager> {
    public static final AudioFocusManager$Companion$INSTANCE$2 INSTANCE = new AudioFocusManager$Companion$INSTANCE$2();

    public AudioFocusManager$Companion$INSTANCE$2() {
        super(0);
    }

    public final AudioFocusManager invoke() {
        return new AudioFocusManager();
    }
}
