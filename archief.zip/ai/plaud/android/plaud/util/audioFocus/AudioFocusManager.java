package ai.plaud.android.plaud.util.audioFocus;

import ai.plaud.android.plaud.common.util.AppProvider;
import android.media.AudioManager;
import java.util.ArrayList;
import java.util.List;
import rg.d0;
import xf.d;
import xf.e;
import y.a;
import y.b;

/* compiled from: AudioFocusManager.kt */
public final class AudioFocusManager {

    /* renamed from: d  reason: collision with root package name */
    public static final AudioFocusManager f1059d = null;

    /* renamed from: e  reason: collision with root package name */
    public static final d<AudioFocusManager> f1060e = e.a(AudioFocusManager$Companion$INSTANCE$2.INSTANCE);

    /* renamed from: a  reason: collision with root package name */
    public AudioManager f1061a;

    /* renamed from: b  reason: collision with root package name */
    public final AudioManager.OnAudioFocusChangeListener f1062b = new a(this);

    /* renamed from: c  reason: collision with root package name */
    public final List<b> f1063c = new ArrayList();

    public AudioFocusManager() {
        Object systemService = AppProvider.a().getSystemService("audio");
        d0.e(systemService, "null cannot be cast to non-null type android.media.AudioManager");
        this.f1061a = (AudioManager) systemService;
    }

    public final void a() {
        if (!this.f1063c.isEmpty()) {
            for (b pause : this.f1063c) {
                pause.pause();
            }
        }
    }
}
