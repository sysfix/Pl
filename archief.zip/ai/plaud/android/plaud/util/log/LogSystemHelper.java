package ai.plaud.android.plaud.util.log;

import ai.plaud.android.plaud.common.util.AppProvider;
import java.io.File;
import okhttp3.HttpUrl;
import xf.d;
import xf.e;

/* compiled from: LogSystemHelper.kt */
public final class LogSystemHelper {

    /* renamed from: a  reason: collision with root package name */
    public static final d<LogSystemHelper> f1064a = e.a(LogSystemHelper$Companion$INSTANCE$2.INSTANCE);

    /* renamed from: b  reason: collision with root package name */
    public static final String f1065b;

    static {
        File externalFilesDir = AppProvider.a().getExternalFilesDir(HttpUrl.FRAGMENT_ENCODE_SET);
        f1065b = a.d.a(externalFilesDir != null ? externalFilesDir.getAbsolutePath() : null, "/PLAUD_log/");
    }
}
