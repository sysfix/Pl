package ai.plaud.android.plaud.util.log;

import gg.a;
import kotlin.jvm.internal.Lambda;

/* compiled from: LogSystemHelper.kt */
public final class LogSystemHelper$Companion$INSTANCE$2 extends Lambda implements a<LogSystemHelper> {
    public static final LogSystemHelper$Companion$INSTANCE$2 INSTANCE = new LogSystemHelper$Companion$INSTANCE$2();

    public LogSystemHelper$Companion$INSTANCE$2() {
        super(0);
    }

    public final LogSystemHelper invoke() {
        return new LogSystemHelper();
    }
}
