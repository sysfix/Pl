package ai.plaud.android.plaud.util;

import androidx.core.content.FileProvider;

/* compiled from: NiceBuildFileProvider.kt */
public final class NiceBuildFileProvider extends FileProvider {
}
