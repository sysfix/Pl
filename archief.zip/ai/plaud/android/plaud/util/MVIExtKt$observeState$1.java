package ai.plaud.android.plaud.util;

import gg.l;
import kotlin.jvm.internal.Lambda;
import ng.k;
import x.n;

/* compiled from: MVIExt.kt */
public final class MVIExtKt$observeState$1 extends Lambda implements l<T, n<A>> {
    public final /* synthetic */ k<T, A> $prop1;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MVIExtKt$observeState$1(k<T, ? extends A> kVar) {
        super(1);
        this.$prop1 = kVar;
    }

    public final n<A> invoke(T t10) {
        return new n<>(this.$prop1.get(t10));
    }
}
