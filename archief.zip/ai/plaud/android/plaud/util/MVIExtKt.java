package ai.plaud.android.plaud.util;

import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import gg.l;
import ng.k;
import rg.d0;
import x.d;
import xf.g;

/* compiled from: MVIExt.kt */
public final class MVIExtKt {
    public static final <T, A> void a(LiveData<T> liveData, LifecycleOwner lifecycleOwner, k<T, ? extends A> kVar, l<? super A, g> lVar) {
        d0.g(liveData, "<this>");
        d0.g(kVar, "prop1");
        Transformations.distinctUntilChanged(Transformations.map(liveData, new MVIExtKt$observeState$1(kVar))).observe(lifecycleOwner, new d(lVar, 1));
    }

    public static final <T, A> void b(LiveData<T> liveData, LifecycleOwner lifecycleOwner, k<T, ? extends A> kVar, l<? super A, g> lVar) {
        d0.g(kVar, "prop1");
        Transformations.map(liveData, new MVIExtKt$observeStateNoFilter$1(kVar)).observe(lifecycleOwner, new d(lVar, 0));
    }

    public static final <T> void c(x.l<T> lVar, T t10) {
        d0.g(lVar, "<this>");
        lVar.postValue(t10);
    }

    public static final <T> void d(MutableLiveData<T> mutableLiveData, l<? super T, ? extends T> lVar) {
        d0.g(mutableLiveData, "<this>");
        d0.g(lVar, "reducer");
        T value = mutableLiveData.getValue();
        mutableLiveData.postValue(value != null ? lVar.invoke(value) : null);
    }

    public static final <T> void e(x.l<T> lVar, T t10) {
        d0.g(lVar, "<this>");
        lVar.setValue(t10);
    }
}
