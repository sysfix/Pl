package ai.plaud.android.plaud.util.startup;

import android.content.Context;
import com.rousetime.android_startup.AndroidStartup;
import rg.d0;

/* compiled from: SynchronizeAndroidStartup.kt */
public final class SynchronizeAndroidStartup extends AndroidStartup<Void> {
    private final String tag = "SynchronizeAndroid";

    public boolean callCreateOnMainThread() {
        return true;
    }

    public Void create(Context context) {
        d0.g(context, "context");
        return null;
    }

    public boolean waitOnMainThread() {
        return true;
    }
}
