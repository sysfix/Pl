package ai.plaud.android.plaud.component;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.RelativeLayout;
import gg.a;
import gg.l;
import rg.d0;
import xf.g;

/* compiled from: AppBarView.kt */
public final class AppBarView extends RelativeLayout {

    /* renamed from: p  reason: collision with root package name */
    public a<g> f1030p;

    /* renamed from: q  reason: collision with root package name */
    public l<? super View, g> f1031q;

    /* renamed from: r  reason: collision with root package name */
    public a<g> f1032r;

    /* renamed from: s  reason: collision with root package name */
    public a<g> f1033s;

    public final void setLeftIcon(Drawable drawable) {
        d0.g(drawable, "drawable");
        throw null;
    }

    public final void setLeftIconDisplay(boolean z10) {
        throw null;
    }

    public final void setOnClickLeftIconListener(a<g> aVar) {
        d0.g(aVar, "listener");
        this.f1030p = aVar;
    }

    public final void setOnClickRightIconListener(l<? super View, g> lVar) {
        d0.g(lVar, "listener");
        this.f1031q = lVar;
    }

    public final void setOnClickRightTextListener(a<g> aVar) {
        d0.g(aVar, "listener");
        this.f1032r = aVar;
    }

    public final void setOnTitleClickListener(a<g> aVar) {
        d0.g(aVar, "listener");
        this.f1033s = aVar;
    }

    public final void setRightIcon(Drawable drawable) {
        d0.g(drawable, "drawable");
        throw null;
    }

    public final void setRightText(String str) {
        d0.g(str, "text");
        throw null;
    }

    public final void setRightTextColor(int i10) {
        throw null;
    }

    public final void setRightTextSize(float f10) {
        throw null;
    }

    public final void setTitle(String str) {
        d0.g(str, "title");
        throw null;
    }

    public final void setTitleColor(int i10) {
        throw null;
    }

    public final void setTitleSize(float f10) {
        throw null;
    }

    public final void setUnderscoreColor(int i10) {
        throw null;
    }

    public final void setTitle(CharSequence charSequence) {
        d0.g(charSequence, "title");
        throw null;
    }
}
