package ai.plaud.android.plaud.component;

import ai.plaud.android.plaud.R;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.AppCompatTextView;
import b1.a;
import p.a;
import rg.d0;
import x.j;

/* compiled from: VerificationCodeImageButton.kt */
public final class VerificationCodeImageButton extends RelativeLayout {

    /* renamed from: p  reason: collision with root package name */
    public final AppCompatTextView f1041p;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public VerificationCodeImageButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        d0.g(context, "context");
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.f1041p = appCompatTextView;
        d0.g(this, "<this>");
        setClickable(true);
        setFocusable(true);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.setMargins((int) a.b(11), (int) a.b(9), (int) a.b(11), (int) a.b(9));
        appCompatTextView.setLayoutParams(layoutParams);
        appCompatTextView.setText(appCompatTextView.getResources().getString(R.string.register_GetVerificationCode));
        Object obj = b1.a.f4191a;
        appCompatTextView.setTextColor(a.d.a(context, R.color.white));
        addView(appCompatTextView);
        j.a a10 = j.a();
        a10.e(a.d.a(context, R.color.ck_101828_50));
        a10.f18261b = (int) p.a.b(20);
        setBackground(a10.a());
    }

    public final void a() {
        setSelected(false);
        this.f1041p.setText(getResources().getString(R.string.register_GetVerificationCode));
        j.a a10 = j.a();
        Context context = getContext();
        Object obj = b1.a.f4191a;
        a10.e(a.d.a(context, R.color.ck_101828_50));
        a10.f18261b = (int) p.a.b(20);
        setBackground(a10.a());
    }

    public final void b() {
        setSelected(true);
        this.f1041p.setText(getResources().getString(R.string.register_GetVerificationCode));
        j.a a10 = j.a();
        Context context = getContext();
        Object obj = b1.a.f4191a;
        a10.e(a.d.a(context, R.color.ck_101828));
        a10.f18261b = (int) p.a.b(20);
        setBackground(a10.a());
    }

    public final void c(int i10) {
        setSelected(false);
        this.f1041p.setText(getResources().getString(R.string.Android_register_resend, new Object[]{Integer.valueOf(i10)}));
        j.a a10 = j.a();
        Context context = getContext();
        Object obj = b1.a.f4191a;
        a10.e(a.d.a(context, R.color.ck_101828_50));
        a10.f18261b = (int) p.a.b(20);
        setBackground(a10.a());
    }
}
