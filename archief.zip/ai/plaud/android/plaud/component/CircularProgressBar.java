package ai.plaud.android.plaud.component;

import android.graphics.Canvas;
import android.view.View;
import rg.d0;

/* compiled from: CircularProgressBar.kt */
public final class CircularProgressBar extends View {

    /* renamed from: p  reason: collision with root package name */
    public float f1034p;

    /* renamed from: q  reason: collision with root package name */
    public float f1035q;

    /* renamed from: r  reason: collision with root package name */
    public int f1036r;

    /* renamed from: s  reason: collision with root package name */
    public int f1037s;

    /* renamed from: t  reason: collision with root package name */
    public int f1038t;

    /* renamed from: u  reason: collision with root package name */
    public int f1039u;

    public final float getMArcStrokeWidth() {
        return this.f1034p;
    }

    public final int getMBackgroundColor() {
        return this.f1037s;
    }

    public final int getMForegroundColor() {
        return this.f1036r;
    }

    public final float getMOffset() {
        return this.f1035q;
    }

    public final int getProgress() {
        return this.f1039u;
    }

    public final int getSweepAngle() {
        return this.f1038t;
    }

    public void onDraw(Canvas canvas) {
        d0.g(canvas, "canvas");
        throw null;
    }

    public void onSizeChanged(int i10, int i11, int i12, int i13) {
        throw null;
    }

    public final void setMArcStrokeWidth(float f10) {
        if (!(this.f1034p == f10)) {
            this.f1034p = f10;
            throw null;
        }
    }

    public final void setMBackgroundColor(int i10) {
        if (this.f1037s != i10) {
            this.f1037s = i10;
            invalidate();
        }
    }

    public final void setMForegroundColor(int i10) {
        if (this.f1036r != i10) {
            this.f1036r = i10;
            invalidate();
        }
    }

    public final void setMOffset(float f10) {
        if (!(this.f1035q == f10)) {
            this.f1035q = f10;
            invalidate();
        }
    }

    public final void setProgress(int i10) {
        if (this.f1039u != i10) {
            this.f1039u = i10;
            invalidate();
        }
    }

    public final void setShowText(boolean z10) {
    }

    public final void setSweepAngle(int i10) {
        if (this.f1038t != i10) {
            this.f1038t = i10;
            invalidate();
        }
    }
}
