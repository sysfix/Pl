package ai.plaud.android.plaud.component;

import ai.plaud.android.plaud.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.util.AttributeSet;
import com.google.android.material.button.MaterialButton;
import p.a;
import rg.d0;

/* compiled from: CtaButton.kt */
public final class CtaButton extends MaterialButton {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CtaButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        d0.g(context, "context");
        d0.g(context, "context");
        setCornerRadius((int) a.b(8));
    }

    public final void i() {
        setEnabled(false);
        setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.ck_101828_30)));
        setElevation(getResources().getDimension(R.dimen.button_elevation_disabled));
        setTextColor(getResources().getColor(R.color.white));
    }

    public final void j() {
        setEnabled(true);
        setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.ck_1f1f1f)));
        setElevation(getResources().getDimension(R.dimen.button_elevation_disabled));
        setTextColor(getResources().getColor(R.color.white));
    }
}
