package ai.plaud.android.plaud.component;

import ai.plaud.android.plaud.R;
import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatImageView;
import b1.a;
import rg.d0;

/* compiled from: PasswordStateImageButton.kt */
public final class PasswordStateImageButton extends AppCompatImageView {

    /* renamed from: s  reason: collision with root package name */
    public boolean f1040s;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PasswordStateImageButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        d0.g(context, "context");
        setBackgroundColor(getResources().getColor(R.color.transparent));
        Context context2 = getContext();
        Object obj = a.f4191a;
        setImageDrawable(a.c.b(context2, R.drawable.eye_gray));
    }

    public final void setShow(boolean z10) {
        if (this.f1040s != z10) {
            this.f1040s = z10;
            if (z10) {
                Context context = getContext();
                Object obj = a.f4191a;
                setImageDrawable(a.c.b(context, R.drawable.eye_black));
                return;
            }
            Context context2 = getContext();
            Object obj2 = a.f4191a;
            setImageDrawable(a.c.b(context2, R.drawable.eye_gray));
        }
    }
}
