package ai.plaud.android.plaud.component;

import ai.plaud.android.plaud.R;
import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatImageButton;
import rg.d0;

/* compiled from: CtaImageButton.kt */
public final class CtaImageButton extends AppCompatImageButton {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CtaImageButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        d0.g(context, "context");
        setImageResource(R.drawable.icon_privacy_unselected);
    }
}
