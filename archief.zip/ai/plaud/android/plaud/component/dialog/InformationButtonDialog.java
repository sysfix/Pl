package ai.plaud.android.plaud.component.dialog;

import android.content.Context;
import android.os.Bundle;
import i.a;
import o.c;
import u.b;

/* compiled from: InformationButtonDialog.kt */
public final class InformationButtonDialog extends c<b> {

    /* renamed from: r  reason: collision with root package name */
    public static final /* synthetic */ int f1042r = 0;

    public InformationButtonDialog(Context context) {
        super(context, 0, AnonymousClass1.INSTANCE, false, 10);
    }

    public void dismiss() {
        super.dismiss();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ((b) this.f14769q).f17132b.setOnClickListener(new a(this));
    }
}
