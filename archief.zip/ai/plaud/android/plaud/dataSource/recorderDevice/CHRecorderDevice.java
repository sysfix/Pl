package ai.plaud.android.plaud.dataSource.recorderDevice;

import android.os.Parcel;
import android.os.Parcelable;
import c.b;
import c.e;
import rg.d0;

/* compiled from: CHRecorderDevice.kt */
public final class CHRecorderDevice implements Parcelable {
    public static final Parcelable.Creator<CHRecorderDevice> CREATOR = new a();
    public int A;
    public boolean B;
    public boolean C;
    public boolean D;

    /* renamed from: p  reason: collision with root package name */
    public String f1043p;

    /* renamed from: q  reason: collision with root package name */
    public String f1044q;

    /* renamed from: r  reason: collision with root package name */
    public int f1045r;

    /* renamed from: s  reason: collision with root package name */
    public int f1046s;

    /* renamed from: t  reason: collision with root package name */
    public long f1047t;

    /* renamed from: u  reason: collision with root package name */
    public String f1048u;

    /* renamed from: v  reason: collision with root package name */
    public int f1049v;

    /* renamed from: w  reason: collision with root package name */
    public String f1050w;

    /* renamed from: x  reason: collision with root package name */
    public String f1051x;

    /* renamed from: y  reason: collision with root package name */
    public int f1052y;

    /* renamed from: z  reason: collision with root package name */
    public int f1053z;

    /* compiled from: CHRecorderDevice.kt */
    public static final class a implements Parcelable.Creator<CHRecorderDevice> {
        public Object createFromParcel(Parcel parcel) {
            d0.g(parcel, "parcel");
            String readString = parcel.readString();
            String readString2 = parcel.readString();
            int readInt = parcel.readInt();
            int readInt2 = parcel.readInt();
            long readLong = parcel.readLong();
            String readString3 = parcel.readString();
            int readInt3 = parcel.readInt();
            String readString4 = parcel.readString();
            String readString5 = parcel.readString();
            int readInt4 = parcel.readInt();
            int readInt5 = parcel.readInt();
            int readInt6 = parcel.readInt();
            boolean z10 = false;
            boolean z11 = parcel.readInt() != 0;
            boolean z12 = parcel.readInt() != 0;
            if (parcel.readInt() != 0) {
                z10 = true;
            }
            return new CHRecorderDevice(readString, readString2, readInt, readInt2, readLong, readString3, readInt3, readString4, readString5, readInt4, readInt5, readInt6, z11, z12, z10);
        }

        public Object[] newArray(int i10) {
            return new CHRecorderDevice[i10];
        }
    }

    public CHRecorderDevice(String str, String str2, int i10, int i11, long j10, String str3, int i12, String str4, String str5, int i13, int i14, int i15, boolean z10, boolean z11, boolean z12) {
        String str6 = str4;
        String str7 = str5;
        d0.g(str, "name");
        d0.g(str2, "macAddress");
        d0.g(str3, "versionType");
        d0.g(str6, "versionName");
        d0.g(str7, "serialNumber");
        this.f1043p = str;
        this.f1044q = str2;
        this.f1045r = i10;
        this.f1046s = i11;
        this.f1047t = j10;
        this.f1048u = str3;
        this.f1049v = i12;
        this.f1050w = str6;
        this.f1051x = str7;
        this.f1052y = i13;
        this.f1053z = i14;
        this.A = i15;
        this.B = z10;
        this.C = z11;
        this.D = z12;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof CHRecorderDevice)) {
            return false;
        }
        CHRecorderDevice cHRecorderDevice = (CHRecorderDevice) obj;
        return d0.b(this.f1043p, cHRecorderDevice.f1043p) && d0.b(this.f1044q, cHRecorderDevice.f1044q) && this.f1045r == cHRecorderDevice.f1045r && this.f1046s == cHRecorderDevice.f1046s && this.f1047t == cHRecorderDevice.f1047t && d0.b(this.f1048u, cHRecorderDevice.f1048u) && this.f1049v == cHRecorderDevice.f1049v && d0.b(this.f1050w, cHRecorderDevice.f1050w) && d0.b(this.f1051x, cHRecorderDevice.f1051x) && this.f1052y == cHRecorderDevice.f1052y && this.f1053z == cHRecorderDevice.f1053z && this.A == cHRecorderDevice.A && this.B == cHRecorderDevice.B && this.C == cHRecorderDevice.C && this.D == cHRecorderDevice.D;
    }

    public int hashCode() {
        String str = this.f1044q;
        long j10 = this.f1047t;
        int a10 = (((((b.a(this.f1051x, b.a(this.f1050w, (b.a(this.f1048u, (((((b.a(str, this.f1043p.hashCode() * 31, 31) + this.f1045r) * 31) + this.f1046s) * 31) + ((int) (j10 ^ (j10 >>> 32)))) * 31, 31) + this.f1049v) * 31, 31), 31) + this.f1052y) * 31) + this.f1053z) * 31) + this.A) * 31;
        boolean z10 = this.B;
        boolean z11 = true;
        if (z10) {
            z10 = true;
        }
        int i10 = (a10 + (z10 ? 1 : 0)) * 31;
        boolean z12 = this.C;
        if (z12) {
            z12 = true;
        }
        int i11 = (i10 + (z12 ? 1 : 0)) * 31;
        boolean z13 = this.D;
        if (!z13) {
            z11 = z13;
        }
        return i11 + (z11 ? 1 : 0);
    }

    public String toString() {
        String str = this.f1043p;
        String str2 = this.f1044q;
        int i10 = this.f1045r;
        int i11 = this.f1046s;
        long j10 = this.f1047t;
        String str3 = this.f1048u;
        int i12 = this.f1049v;
        String str4 = this.f1050w;
        String str5 = this.f1051x;
        int i13 = this.f1052y;
        int i14 = this.f1053z;
        int i15 = this.A;
        boolean z10 = this.B;
        boolean z11 = this.C;
        StringBuilder a10 = e.a("CHRecorderDevice(name=", str, ", macAddress=", str2, ", rssi=");
        a10.append(i10);
        a10.append(", manufacturerCode=");
        a10.append(i11);
        a10.append(", projectCode=");
        a10.append(j10);
        a10.append(", versionType=");
        a10.append(str3);
        a10.append(", versionCode=");
        a10.append(i12);
        a10.append(", versionName=");
        a10.append(str4);
        a10.append(", serialNumber=");
        a10.append(str5);
        a10.append(", bindInfo=");
        a10.append(i13);
        a10.append(", portVersion=");
        a10.append(i14);
        a10.append(", audioChannel=");
        a10.append(i15);
        a10.append(", isNoNsAgc=");
        a10.append(z10);
        a10.append(", isOggAudio=");
        a10.append(z11);
        a10.append(", isVadOpen=");
        a10.append(this.D);
        a10.append(")");
        return a10.toString();
    }

    public void writeToParcel(Parcel parcel, int i10) {
        d0.g(parcel, "out");
        parcel.writeString(this.f1043p);
        parcel.writeString(this.f1044q);
        parcel.writeInt(this.f1045r);
        parcel.writeInt(this.f1046s);
        parcel.writeLong(this.f1047t);
        parcel.writeString(this.f1048u);
        parcel.writeInt(this.f1049v);
        parcel.writeString(this.f1050w);
        parcel.writeString(this.f1051x);
        parcel.writeInt(this.f1052y);
        parcel.writeInt(this.f1053z);
        parcel.writeInt(this.A);
        parcel.writeInt(this.B ? 1 : 0);
        parcel.writeInt(this.C ? 1 : 0);
        parcel.writeInt(this.D ? 1 : 0);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public CHRecorderDevice() {
        /*
            r17 = this;
            r3 = 0
            r4 = 0
            r5 = 0
            r8 = 0
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
            java.lang.String r2 = ""
            r7 = r2
            r10 = r2
            r9 = r2
            r1 = r2
            r0 = r17
            r0.<init>(r1, r2, r3, r4, r5, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.dataSource.recorderDevice.CHRecorderDevice.<init>():void");
    }
}
