package ai.plaud.android.plaud.dataSource.recorderDevice;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.TreeSet;
import okhttp3.HttpUrl;
import rg.d0;

/* compiled from: CHRecorderStandardWeight.kt */
public final class CHRecorderStandardWeight implements Parcelable {
    public static final Parcelable.Creator<CHRecorderStandardWeight> CREATOR = new a();

    /* renamed from: p  reason: collision with root package name */
    public String f1054p;

    /* renamed from: q  reason: collision with root package name */
    public TreeSet<Long> f1055q;

    /* compiled from: CHRecorderStandardWeight.kt */
    public static final class a implements Parcelable.Creator<CHRecorderStandardWeight> {
        public Object createFromParcel(Parcel parcel) {
            d0.g(parcel, "parcel");
            return new CHRecorderStandardWeight(parcel.readString(), (TreeSet) parcel.readSerializable());
        }

        public Object[] newArray(int i10) {
            return new CHRecorderStandardWeight[i10];
        }
    }

    public CHRecorderStandardWeight(String str, TreeSet<Long> treeSet) {
        d0.g(str, "key");
        d0.g(treeSet, "standardWeights");
        this.f1054p = str;
        this.f1055q = treeSet;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof CHRecorderStandardWeight)) {
            return false;
        }
        CHRecorderStandardWeight cHRecorderStandardWeight = (CHRecorderStandardWeight) obj;
        return d0.b(this.f1054p, cHRecorderStandardWeight.f1054p) && d0.b(this.f1055q, cHRecorderStandardWeight.f1055q);
    }

    public int hashCode() {
        return this.f1055q.hashCode() + (this.f1054p.hashCode() * 31);
    }

    public String toString() {
        String str = this.f1054p;
        TreeSet<Long> treeSet = this.f1055q;
        return "CHRecorderStandardWeight(key=" + str + ", standardWeights=" + treeSet + ")";
    }

    public void writeToParcel(Parcel parcel, int i10) {
        d0.g(parcel, "out");
        parcel.writeString(this.f1054p);
        parcel.writeSerializable(this.f1055q);
    }

    public CHRecorderStandardWeight() {
        TreeSet<Long> treeSet = new TreeSet<>();
        d0.g(HttpUrl.FRAGMENT_ENCODE_SET, "key");
        d0.g(treeSet, "standardWeights");
        this.f1054p = HttpUrl.FRAGMENT_ENCODE_SET;
        this.f1055q = treeSet;
    }
}
