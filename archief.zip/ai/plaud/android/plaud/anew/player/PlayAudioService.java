package ai.plaud.android.plaud.anew.player;

import a1.r;
import ai.plaud.android.plaud.R;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import ci.a;
import rg.d0;

/* compiled from: PlayAudioService.kt */
public final class PlayAudioService extends Service {

    /* renamed from: p  reason: collision with root package name */
    public static boolean f975p;

    public IBinder onBind(Intent intent) {
        a.f4931a.a("PlayAudioService onBind", new Object[0]);
        return null;
    }

    public void onCreate() {
        super.onCreate();
        a.f4931a.a("PlayAudioService onCreate", new Object[0]);
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel("plaud_notification_channel_play_audio", "Plaud Playing", 4);
            notificationChannel.setDescription("Audio Player/Record");
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        PendingIntent activity = PendingIntent.getActivity(this, 1, getPackageManager().getLaunchIntentForPackage("ai.plaud.android.plaud"), 67108864);
        r rVar = new r(this, "plaud_notification_channel_play_audio");
        rVar.f727t.icon = R.mipmap.ic_launcher;
        rVar.d("PLAUD is currently playing audio");
        rVar.c("Tap to return to the app");
        rVar.f727t.when = System.currentTimeMillis();
        rVar.f714g = activity;
        Notification a10 = rVar.a();
        d0.f(a10, "Builder(this, notificati…ent)\n            .build()");
        try {
            startForeground(1994, a10);
        } catch (Exception unused) {
            a.f4931a.a("startForeground Error", new Object[0]);
        }
    }

    public void onDestroy() {
        a.f4931a.a("PlayAudioService onDestroy", new Object[0]);
        f975p = false;
        stopForeground(true);
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i10, int i11) {
        a.f4931a.a("PlayAudioService onStartCommand", new Object[0]);
        f975p = true;
        return super.onStartCommand(intent, i10, i11);
    }
}
