package ai.plaud.android.plaud.anew.player;

/* compiled from: PlayState.kt */
public enum PlayState {
    IDLE(0),
    PLAY(1),
    PAUSE(2),
    END(3);
    
    private final int type;

    /* access modifiers changed from: public */
    PlayState(int i10) {
        this.type = i10;
    }

    public final int getType() {
        return this.type;
    }
}
