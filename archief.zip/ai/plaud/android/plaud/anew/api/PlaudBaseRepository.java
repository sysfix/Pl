package ai.plaud.android.plaud.anew.api;

/* compiled from: PlaudBaseRepository.kt */
public class PlaudBaseRepository {
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x005d  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a(gg.l<? super ag.c<? super ai.plaud.android.plaud.anew.api.ApiResponse>, ? extends java.lang.Object> r5, ag.c<? super ai.plaud.android.plaud.anew.api.ApiResponse> r6) {
        /*
            r4 = this;
            boolean r0 = r6 instanceof ai.plaud.android.plaud.anew.api.PlaudBaseRepository$executeHttp$1
            if (r0 == 0) goto L_0x0013
            r0 = r6
            ai.plaud.android.plaud.anew.api.PlaudBaseRepository$executeHttp$1 r0 = (ai.plaud.android.plaud.anew.api.PlaudBaseRepository$executeHttp$1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.label = r1
            goto L_0x0018
        L_0x0013:
            ai.plaud.android.plaud.anew.api.PlaudBaseRepository$executeHttp$1 r0 = new ai.plaud.android.plaud.anew.api.PlaudBaseRepository$executeHttp$1
            r0.<init>(r4, r6)
        L_0x0018:
            java.lang.Object r6 = r0.result
            kotlin.coroutines.intrinsics.CoroutineSingletons r1 = kotlin.coroutines.intrinsics.CoroutineSingletons.COROUTINE_SUSPENDED
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L_0x0035
            if (r2 != r3) goto L_0x002d
            java.lang.Object r5 = r0.L$0
            ai.plaud.android.plaud.anew.api.PlaudBaseRepository r5 = (ai.plaud.android.plaud.anew.api.PlaudBaseRepository) r5
            com.google.android.gms.internal.play_billing.x2.s(r6)     // Catch:{ all -> 0x002b }
            goto L_0x0044
        L_0x002b:
            r6 = move-exception
            goto L_0x004e
        L_0x002d:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L_0x0035:
            com.google.android.gms.internal.play_billing.x2.s(r6)
            r0.L$0 = r4     // Catch:{ all -> 0x004b }
            r0.label = r3     // Catch:{ all -> 0x004b }
            java.lang.Object r6 = r5.invoke(r0)     // Catch:{ all -> 0x004b }
            if (r6 != r1) goto L_0x0043
            return r1
        L_0x0043:
            r5 = r4
        L_0x0044:
            ai.plaud.android.plaud.anew.api.ApiResponse r6 = (ai.plaud.android.plaud.anew.api.ApiResponse) r6     // Catch:{ all -> 0x002b }
            java.lang.Object r6 = kotlin.Result.m97constructorimpl(r6)     // Catch:{ all -> 0x002b }
            goto L_0x0056
        L_0x004b:
            r5 = move-exception
            r6 = r5
            r5 = r4
        L_0x004e:
            java.lang.Object r6 = com.google.android.gms.internal.play_billing.x2.k(r6)
            java.lang.Object r6 = kotlin.Result.m97constructorimpl(r6)
        L_0x0056:
            boolean r0 = kotlin.Result.m103isSuccessimpl(r6)
            r1 = 0
            if (r0 == 0) goto L_0x0074
            ai.plaud.android.plaud.anew.api.ApiResponse r6 = (ai.plaud.android.plaud.anew.api.ApiResponse) r6
            java.util.Objects.requireNonNull(r5)
            boolean r5 = r6.isRspSuccess()
            if (r5 == 0) goto L_0x0069
            goto L_0x0073
        L_0x0069:
            ai.plaud.android.plaud.anew.api.ApiFailedResponse r5 = new ai.plaud.android.plaud.anew.api.ApiFailedResponse
            java.lang.String r6 = r6.getMsg()
            r5.<init>(r1, r6)
            r6 = r5
        L_0x0073:
            return r6
        L_0x0074:
            java.lang.Throwable r6 = kotlin.Result.m100exceptionOrNullimpl(r6)
            if (r6 == 0) goto L_0x00c8
            ci.a$a r0 = ci.a.f4931a
            java.lang.String r1 = java.lang.String.valueOf(r6)
            r2 = 0
            java.lang.Object[] r3 = new java.lang.Object[r2]
            r0.b(r1, r3)
            java.util.Objects.requireNonNull(r5)
            boolean r5 = r6 instanceof retrofit2.HttpException
            if (r5 == 0) goto L_0x00ad
            retrofit2.HttpException r6 = (retrofit2.HttpException) r6
            ai.plaud.android.plaud.anew.api.ApiFailedResponse r5 = new ai.plaud.android.plaud.anew.api.ApiFailedResponse
            int r6 = r6.code()
            int r2 = r2 - r6
            java.lang.Integer r6 = java.lang.Integer.valueOf(r2)
            android.content.Context r0 = ai.plaud.android.plaud.common.util.AppProvider.a()
            android.content.res.Resources r0 = r0.getResources()
            r1 = 2131886190(0x7f12006e, float:1.9406952E38)
            java.lang.String r0 = r0.getString(r1)
            r5.<init>(r6, r0)
            goto L_0x00c7
        L_0x00ad:
            boolean r5 = r6 instanceof ai.plaud.android.plaud.anew.api.exception.TokenInvalidException
            if (r5 == 0) goto L_0x00c2
            java.lang.String r5 = "token_invalid"
            com.jeremyliao.liveeventbus.core.Observable r5 = com.jeremyliao.liveeventbus.LiveEventBus.get((java.lang.String) r5)
            java.lang.Boolean r0 = java.lang.Boolean.TRUE
            r5.post(r0)
            ai.plaud.android.plaud.anew.api.ApiErrorResponse r5 = new ai.plaud.android.plaud.anew.api.ApiErrorResponse
            r5.<init>(r6)
            goto L_0x00c7
        L_0x00c2:
            ai.plaud.android.plaud.anew.api.ApiErrorResponse r5 = new ai.plaud.android.plaud.anew.api.ApiErrorResponse
            r5.<init>(r6)
        L_0x00c7:
            return r5
        L_0x00c8:
            ai.plaud.android.plaud.anew.api.ApiEmptyResponse r5 = new ai.plaud.android.plaud.anew.api.ApiEmptyResponse
            r6 = 3
            r5.<init>(r1, r1, r6, r1)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.api.PlaudBaseRepository.a(gg.l, ag.c):java.lang.Object");
    }
}
