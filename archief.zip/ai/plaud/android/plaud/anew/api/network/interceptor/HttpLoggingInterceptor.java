package ai.plaud.android.plaud.anew.api.network.interceptor;

import dh.c;
import f.a;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import okhttp3.Connection;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.internal.http.HttpHeaders;

public class HttpLoggingInterceptor implements Interceptor {

    /* renamed from: d  reason: collision with root package name */
    public static final Charset f894d = StandardCharsets.UTF_8;

    /* renamed from: a  reason: collision with root package name */
    public volatile Level f895a = Level.NONE;

    /* renamed from: b  reason: collision with root package name */
    public java.util.logging.Level f896b;

    /* renamed from: c  reason: collision with root package name */
    public Logger f897c;

    public enum Level {
        NONE,
        BASIC,
        HEADERS,
        BODY
    }

    public HttpLoggingInterceptor(String str) {
        this.f897c = Logger.getLogger(str);
    }

    public static boolean b(MediaType mediaType) {
        if (mediaType == null) {
            return false;
        }
        if (mediaType.type() != null && mediaType.type().equals("text")) {
            return true;
        }
        String subtype = mediaType.subtype();
        if (subtype == null) {
            return false;
        }
        String lowerCase = subtype.toLowerCase();
        if (lowerCase.contains("x-www-form-urlencoded") || lowerCase.contains("json") || lowerCase.contains("xml") || lowerCase.contains("html")) {
            return true;
        }
        return false;
    }

    public final void a(Request request) {
        try {
            RequestBody body = request.newBuilder().build().body();
            if (body != null) {
                c cVar = new c();
                body.writeTo(cVar);
                MediaType contentType = body.contentType();
                Charset charset = contentType != null ? contentType.charset(f894d) : f894d;
                if (charset == null) {
                    charset = f894d;
                }
                c("\tbody:" + cVar.m1(charset));
            }
        } catch (Exception e10) {
            e10.printStackTrace();
        }
    }

    public final void c(String str) {
        this.f897c.log(this.f896b, str);
    }

    public Response intercept(Interceptor.Chain chain) {
        StringBuilder sb2;
        Interceptor.Chain chain2 = chain;
        Request request = chain.request();
        if (this.f895a == Level.NONE) {
            return chain2.proceed(request);
        }
        Connection connection = chain.connection();
        Level level = this.f895a;
        Level level2 = Level.BODY;
        boolean z10 = level == level2;
        boolean z11 = this.f895a == level2 || this.f895a == Level.HEADERS;
        RequestBody body = request.body();
        boolean z12 = body != null;
        Protocol protocol = connection != null ? connection.protocol() : Protocol.HTTP_1_1;
        try {
            c("--> " + request.method() + ' ' + request.url() + ' ' + protocol);
            if (z11) {
                if (z12) {
                    if (body.contentType() != null) {
                        c("\tContent-Type: " + body.contentType());
                    }
                    if (body.contentLength() != -1) {
                        c("\tContent-Length: " + body.contentLength());
                    }
                }
                Headers headers = request.headers();
                int size = headers.size();
                for (int i10 = 0; i10 < size; i10++) {
                    String name = headers.name(i10);
                    if (!"Content-Type".equalsIgnoreCase(name) && !"Content-Length".equalsIgnoreCase(name)) {
                        c("\t" + name + ": " + headers.value(i10));
                    }
                }
                this.f897c.log(this.f896b, " ");
                if (z10 && z12) {
                    if (b(body.contentType())) {
                        a(request);
                    } else {
                        this.f897c.log(this.f896b, "\tbody: maybe [binary body], omitted!");
                    }
                }
            }
            sb2 = new StringBuilder();
        } catch (Exception e10) {
            e10.printStackTrace();
            sb2 = new StringBuilder();
        } catch (Throwable th2) {
            StringBuilder a10 = a.a("--> END ");
            a10.append(request.method());
            c(a10.toString());
            throw th2;
        }
        sb2.append("--> END ");
        sb2.append(request.method());
        c(sb2.toString());
        long nanoTime = System.nanoTime();
        try {
            Response proceed = chain2.proceed(request);
            long millis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - nanoTime);
            Response build = proceed.newBuilder().build();
            ResponseBody body2 = build.body();
            Level level3 = this.f895a;
            Level level4 = Level.BODY;
            boolean z13 = level3 == level4;
            boolean z14 = this.f895a == level4 || this.f895a == Level.HEADERS;
            try {
                c("<-- " + build.code() + ' ' + build.message() + ' ' + build.request().url() + " (" + millis + "ms）");
                if (z14) {
                    Headers headers2 = build.headers();
                    int size2 = headers2.size();
                    for (int i11 = 0; i11 < size2; i11++) {
                        c("\t" + headers2.name(i11) + ": " + headers2.value(i11));
                    }
                    this.f897c.log(this.f896b, " ");
                    if (z13 && HttpHeaders.hasBody(build)) {
                        if (body2 != null) {
                            if (b(body2.contentType())) {
                                byte[] h10 = m.a.h(body2.byteStream());
                                MediaType contentType = body2.contentType();
                                Charset charset = contentType != null ? contentType.charset(f894d) : f894d;
                                if (charset == null) {
                                    charset = f894d;
                                }
                                String str = new String(h10, charset);
                                c("\tbody:" + str);
                                proceed = proceed.newBuilder().body(ResponseBody.create(body2.contentType(), h10)).build();
                            } else {
                                this.f897c.log(this.f896b, "\tbody: maybe [binary body], omitted!");
                            }
                        }
                    }
                }
            } catch (Exception e11) {
                e11.printStackTrace();
            } catch (Throwable th3) {
                this.f897c.log(this.f896b, "<-- END HTTP");
                throw th3;
            }
            this.f897c.log(this.f896b, "<-- END HTTP");
            return proceed;
        } catch (Exception e12) {
            Exception exc = e12;
            c("<-- HTTP FAILED: " + exc);
            throw exc;
        }
    }
}
