package ai.plaud.android.plaud.anew.api;

import java.io.Serializable;
import kotlin.jvm.internal.DefaultConstructorMarker;
import rg.d0;

/* compiled from: PlaudApiResponse.kt */
public class ApiResponse implements Serializable {
    private final Throwable error;
    private final String msg;
    private final Integer status;

    public ApiResponse() {
        this((Integer) null, (String) null, (Throwable) null, 7, (DefaultConstructorMarker) null);
    }

    public ApiResponse(Integer num, String str, Throwable th2) {
        this.status = num;
        this.msg = str;
        this.error = th2;
    }

    public Throwable getError() {
        return this.error;
    }

    public String getMsg() {
        return this.msg;
    }

    public Integer getStatus() {
        return this.status;
    }

    public final boolean isRspSuccess() {
        return getStatus() != null;
    }

    public final boolean isSuccess() {
        if (getStatus() != null) {
            Integer status2 = getStatus();
            d0.d(status2);
            if (status2.intValue() >= 0) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ApiResponse(Integer num, String str, Throwable th2, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : num, (i10 & 2) != 0 ? null : str, (i10 & 4) != 0 ? null : th2);
    }
}
