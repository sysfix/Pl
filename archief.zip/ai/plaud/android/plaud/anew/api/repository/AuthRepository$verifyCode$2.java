package ai.plaud.android.plaud.anew.api.repository;

import ag.c;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.bean.AuthBean;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.api.repository.AuthRepository$verifyCode$2", f = "AuthRepository.kt", l = {38}, m = "invokeSuspend")
/* compiled from: AuthRepository.kt */
public final class AuthRepository$verifyCode$2 extends SuspendLambda implements l<c<? super ApiResponse>, Object> {
    public final /* synthetic */ long $code;
    public final /* synthetic */ String $password;
    public final /* synthetic */ String $token;
    public int label;
    public final /* synthetic */ AuthRepository this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AuthRepository$verifyCode$2(AuthRepository authRepository, long j10, String str, String str2, c<? super AuthRepository$verifyCode$2> cVar) {
        super(1, cVar);
        this.this$0 = authRepository;
        this.$code = j10;
        this.$token = str;
        this.$password = str2;
    }

    public final c<g> create(c<?> cVar) {
        return new AuthRepository$verifyCode$2(this.this$0, this.$code, this.$token, this.$password, cVar);
    }

    public final Object invoke(c<? super ApiResponse> cVar) {
        return ((AuthRepository$verifyCode$2) create(cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            b.a aVar = this.this$0.f899a;
            AuthBean.VerifyCodeReq verifyCodeReq = new AuthBean.VerifyCodeReq(this.$code, this.$token, this.$password);
            this.label = 1;
            obj = aVar.d(verifyCodeReq, this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return obj;
    }
}
