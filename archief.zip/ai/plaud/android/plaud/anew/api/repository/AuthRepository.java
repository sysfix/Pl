package ai.plaud.android.plaud.anew.api.repository;

import ag.c;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.PlaudBaseRepository;
import b.a;

/* compiled from: AuthRepository.kt */
public final class AuthRepository extends PlaudBaseRepository {

    /* renamed from: a  reason: collision with root package name */
    public final a f899a;

    public AuthRepository(a aVar) {
        this.f899a = aVar;
    }

    public final Object b(long j10, String str, String str2, c<? super ApiResponse> cVar) {
        return a(new AuthRepository$verifyCode$2(this, j10, str, str2, (c<? super AuthRepository$verifyCode$2>) null), cVar);
    }
}
