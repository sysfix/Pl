package ai.plaud.android.plaud.anew.api.repository;

import ag.c;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.bean.AuthBean;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.api.repository.AuthRepository$sendCode$2", f = "AuthRepository.kt", l = {26}, m = "invokeSuspend")
/* compiled from: AuthRepository.kt */
public final class AuthRepository$sendCode$2 extends SuspendLambda implements l<c<? super ApiResponse>, Object> {
    public final /* synthetic */ String $email;
    public final /* synthetic */ String $type;
    public int label;
    public final /* synthetic */ AuthRepository this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AuthRepository$sendCode$2(AuthRepository authRepository, String str, String str2, c<? super AuthRepository$sendCode$2> cVar) {
        super(1, cVar);
        this.this$0 = authRepository;
        this.$email = str;
        this.$type = str2;
    }

    public final c<g> create(c<?> cVar) {
        return new AuthRepository$sendCode$2(this.this$0, this.$email, this.$type, cVar);
    }

    public final Object invoke(c<? super ApiResponse> cVar) {
        return ((AuthRepository$sendCode$2) create(cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            b.a aVar = this.this$0.f899a;
            AuthBean.SendCodeReq sendCodeReq = new AuthBean.SendCodeReq(this.$email, this.$type);
            this.label = 1;
            obj = aVar.b(sendCodeReq, this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return obj;
    }
}
