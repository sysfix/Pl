package ai.plaud.android.plaud.anew.api;

import kotlin.jvm.internal.DefaultConstructorMarker;
import rg.d0;

/* compiled from: PlaudApiResponse.kt */
public final class ApiFailedResponse extends ApiResponse {
    private final String msg;
    private final Integer status;

    public ApiFailedResponse() {
        this((Integer) null, (String) null, 3, (DefaultConstructorMarker) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ApiFailedResponse(Integer num, String str, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : num, (i10 & 2) != 0 ? null : str);
    }

    public static /* synthetic */ ApiFailedResponse copy$default(ApiFailedResponse apiFailedResponse, Integer num, String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            num = apiFailedResponse.getStatus();
        }
        if ((i10 & 2) != 0) {
            str = apiFailedResponse.getMsg();
        }
        return apiFailedResponse.copy(num, str);
    }

    public final Integer component1() {
        return getStatus();
    }

    public final String component2() {
        return getMsg();
    }

    public final ApiFailedResponse copy(Integer num, String str) {
        return new ApiFailedResponse(num, str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ApiFailedResponse)) {
            return false;
        }
        ApiFailedResponse apiFailedResponse = (ApiFailedResponse) obj;
        return d0.b(getStatus(), apiFailedResponse.getStatus()) && d0.b(getMsg(), apiFailedResponse.getMsg());
    }

    public String getMsg() {
        return this.msg;
    }

    public Integer getStatus() {
        return this.status;
    }

    public int hashCode() {
        int i10 = 0;
        int hashCode = (getStatus() == null ? 0 : getStatus().hashCode()) * 31;
        if (getMsg() != null) {
            i10 = getMsg().hashCode();
        }
        return hashCode + i10;
    }

    public String toString() {
        Integer status2 = getStatus();
        String msg2 = getMsg();
        return "ApiFailedResponse(status=" + status2 + ", msg=" + msg2 + ")";
    }

    public ApiFailedResponse(Integer num, String str) {
        super(num, str, (Throwable) null, 4, (DefaultConstructorMarker) null);
        this.status = num;
        this.msg = str;
    }
}
