package ai.plaud.android.plaud.anew.api.exception;

import java.io.IOException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import rg.d0;

/* compiled from: TokenInvalidException.kt */
public final class TokenInvalidException extends IOException {
    public TokenInvalidException() {
        this((String) null, 1, (DefaultConstructorMarker) null);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TokenInvalidException(String str) {
        super(str);
        d0.g(str, "msg");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ TokenInvalidException(String str, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? "token失效，请重新登录" : str);
    }
}
