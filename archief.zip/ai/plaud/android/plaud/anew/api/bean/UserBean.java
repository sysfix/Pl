package ai.plaud.android.plaud.anew.api.bean;

import ai.plaud.android.plaud.anew.api.ApiResponse;
import androidx.recyclerview.widget.RecyclerView;
import b.b;
import c.a;
import c.c;
import c.d;
import c.e;
import com.google.common.collect.MapMakerInternalMap;
import java.util.List;
import kotlin.jvm.internal.DefaultConstructorMarker;
import okhttp3.internal.http2.Http2;
import rg.d0;

/* compiled from: UserBean.kt */
public final class UserBean {
    public static final UserBean INSTANCE = new UserBean();

    /* compiled from: UserBean.kt */
    public static final class BonusCodeReq {
        private final String code;

        public BonusCodeReq(String str) {
            d0.g(str, "code");
            this.code = str;
        }

        public static /* synthetic */ BonusCodeReq copy$default(BonusCodeReq bonusCodeReq, String str, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = bonusCodeReq.code;
            }
            return bonusCodeReq.copy(str);
        }

        public final String component1() {
            return this.code;
        }

        public final BonusCodeReq copy(String str) {
            d0.g(str, "code");
            return new BonusCodeReq(str);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof BonusCodeReq) && d0.b(this.code, ((BonusCodeReq) obj).code);
        }

        public final String getCode() {
            return this.code;
        }

        public int hashCode() {
            return this.code.hashCode();
        }

        public String toString() {
            return b.a("BonusCodeReq(code=", this.code, ")");
        }
    }

    /* compiled from: UserBean.kt */
    public static final class DeleteUserReq {
        private final String password;
        private final String username;

        public DeleteUserReq(String str, String str2) {
            d0.g(str, "username");
            d0.g(str2, "password");
            this.username = str;
            this.password = str2;
        }

        public static /* synthetic */ DeleteUserReq copy$default(DeleteUserReq deleteUserReq, String str, String str2, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = deleteUserReq.username;
            }
            if ((i10 & 2) != 0) {
                str2 = deleteUserReq.password;
            }
            return deleteUserReq.copy(str, str2);
        }

        public final String component1() {
            return this.username;
        }

        public final String component2() {
            return this.password;
        }

        public final DeleteUserReq copy(String str, String str2) {
            d0.g(str, "username");
            d0.g(str2, "password");
            return new DeleteUserReq(str, str2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DeleteUserReq)) {
                return false;
            }
            DeleteUserReq deleteUserReq = (DeleteUserReq) obj;
            return d0.b(this.username, deleteUserReq.username) && d0.b(this.password, deleteUserReq.password);
        }

        public final String getPassword() {
            return this.password;
        }

        public final String getUsername() {
            return this.username;
        }

        public int hashCode() {
            return this.password.hashCode() + (this.username.hashCode() * 31);
        }

        public String toString() {
            return a.a("DeleteUserReq(username=", this.username, ", password=", this.password, ")");
        }
    }

    /* compiled from: UserBean.kt */
    public static final class FileStatBean {
        private final List<GroupBean> group_result;
        private final int total_days;
        private final long total_duration;
        private final int total_files;

        public FileStatBean(int i10, int i11, long j10, List<GroupBean> list) {
            d0.g(list, "group_result");
            this.total_days = i10;
            this.total_files = i11;
            this.total_duration = j10;
            this.group_result = list;
        }

        public static /* synthetic */ FileStatBean copy$default(FileStatBean fileStatBean, int i10, int i11, long j10, List<GroupBean> list, int i12, Object obj) {
            if ((i12 & 1) != 0) {
                i10 = fileStatBean.total_days;
            }
            if ((i12 & 2) != 0) {
                i11 = fileStatBean.total_files;
            }
            int i13 = i11;
            if ((i12 & 4) != 0) {
                j10 = fileStatBean.total_duration;
            }
            long j11 = j10;
            if ((i12 & 8) != 0) {
                list = fileStatBean.group_result;
            }
            return fileStatBean.copy(i10, i13, j11, list);
        }

        public final int component1() {
            return this.total_days;
        }

        public final int component2() {
            return this.total_files;
        }

        public final long component3() {
            return this.total_duration;
        }

        public final List<GroupBean> component4() {
            return this.group_result;
        }

        public final FileStatBean copy(int i10, int i11, long j10, List<GroupBean> list) {
            d0.g(list, "group_result");
            return new FileStatBean(i10, i11, j10, list);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof FileStatBean)) {
                return false;
            }
            FileStatBean fileStatBean = (FileStatBean) obj;
            return this.total_days == fileStatBean.total_days && this.total_files == fileStatBean.total_files && this.total_duration == fileStatBean.total_duration && d0.b(this.group_result, fileStatBean.group_result);
        }

        public final List<GroupBean> getGroup_result() {
            return this.group_result;
        }

        public final int getTotal_days() {
            return this.total_days;
        }

        public final long getTotal_duration() {
            return this.total_duration;
        }

        public final int getTotal_files() {
            return this.total_files;
        }

        public int hashCode() {
            long j10 = this.total_duration;
            return this.group_result.hashCode() + (((((this.total_days * 31) + this.total_files) * 31) + ((int) (j10 ^ (j10 >>> 32)))) * 31);
        }

        public String toString() {
            int i10 = this.total_days;
            int i11 = this.total_files;
            long j10 = this.total_duration;
            List<GroupBean> list = this.group_result;
            StringBuilder a10 = c.a("FileStatBean(total_days=", i10, ", total_files=", i11, ", total_duration=");
            a10.append(j10);
            a10.append(", group_result=");
            a10.append(list);
            a10.append(")");
            return a10.toString();
        }
    }

    /* compiled from: UserBean.kt */
    public static final class GetFileStatRsp extends ApiResponse {
        private final FileStatBean data_stat;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public GetFileStatRsp(FileStatBean fileStatBean) {
            super((Integer) null, (String) null, (Throwable) null, 7, (DefaultConstructorMarker) null);
            d0.g(fileStatBean, "data_stat");
            this.data_stat = fileStatBean;
        }

        public static /* synthetic */ GetFileStatRsp copy$default(GetFileStatRsp getFileStatRsp, FileStatBean fileStatBean, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                fileStatBean = getFileStatRsp.data_stat;
            }
            return getFileStatRsp.copy(fileStatBean);
        }

        public final FileStatBean component1() {
            return this.data_stat;
        }

        public final GetFileStatRsp copy(FileStatBean fileStatBean) {
            d0.g(fileStatBean, "data_stat");
            return new GetFileStatRsp(fileStatBean);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof GetFileStatRsp) && d0.b(this.data_stat, ((GetFileStatRsp) obj).data_stat);
        }

        public final FileStatBean getData_stat() {
            return this.data_stat;
        }

        public int hashCode() {
            return this.data_stat.hashCode();
        }

        public String toString() {
            FileStatBean fileStatBean = this.data_stat;
            return "GetFileStatRsp(data_stat=" + fileStatBean + ")";
        }
    }

    /* compiled from: UserBean.kt */
    public static final class GetUserRsp extends ApiResponse {
        private final UserState data_state;
        private final UserInfo data_user;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public GetUserRsp(UserInfo userInfo, UserState userState) {
            super((Integer) null, (String) null, (Throwable) null, 7, (DefaultConstructorMarker) null);
            d0.g(userInfo, "data_user");
            d0.g(userState, "data_state");
            this.data_user = userInfo;
            this.data_state = userState;
        }

        public static /* synthetic */ GetUserRsp copy$default(GetUserRsp getUserRsp, UserInfo userInfo, UserState userState, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                userInfo = getUserRsp.data_user;
            }
            if ((i10 & 2) != 0) {
                userState = getUserRsp.data_state;
            }
            return getUserRsp.copy(userInfo, userState);
        }

        public final UserInfo component1() {
            return this.data_user;
        }

        public final UserState component2() {
            return this.data_state;
        }

        public final GetUserRsp copy(UserInfo userInfo, UserState userState) {
            d0.g(userInfo, "data_user");
            d0.g(userState, "data_state");
            return new GetUserRsp(userInfo, userState);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof GetUserRsp)) {
                return false;
            }
            GetUserRsp getUserRsp = (GetUserRsp) obj;
            return d0.b(this.data_user, getUserRsp.data_user) && d0.b(this.data_state, getUserRsp.data_state);
        }

        public final UserState getData_state() {
            return this.data_state;
        }

        public final UserInfo getData_user() {
            return this.data_user;
        }

        public int hashCode() {
            return this.data_state.hashCode() + (this.data_user.hashCode() * 31);
        }

        public String toString() {
            UserInfo userInfo = this.data_user;
            UserState userState = this.data_state;
            return "GetUserRsp(data_user=" + userInfo + ", data_state=" + userState + ")";
        }
    }

    /* compiled from: UserBean.kt */
    public static final class GroupBean {
        private final int count;
        private final String day;
        private final long duration;

        public GroupBean(String str, int i10, long j10) {
            d0.g(str, "day");
            this.day = str;
            this.count = i10;
            this.duration = j10;
        }

        public static /* synthetic */ GroupBean copy$default(GroupBean groupBean, String str, int i10, long j10, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                str = groupBean.day;
            }
            if ((i11 & 2) != 0) {
                i10 = groupBean.count;
            }
            if ((i11 & 4) != 0) {
                j10 = groupBean.duration;
            }
            return groupBean.copy(str, i10, j10);
        }

        public final String component1() {
            return this.day;
        }

        public final int component2() {
            return this.count;
        }

        public final long component3() {
            return this.duration;
        }

        public final GroupBean copy(String str, int i10, long j10) {
            d0.g(str, "day");
            return new GroupBean(str, i10, j10);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof GroupBean)) {
                return false;
            }
            GroupBean groupBean = (GroupBean) obj;
            return d0.b(this.day, groupBean.day) && this.count == groupBean.count && this.duration == groupBean.duration;
        }

        public final int getCount() {
            return this.count;
        }

        public final String getDay() {
            return this.day;
        }

        public final long getDuration() {
            return this.duration;
        }

        public int hashCode() {
            long j10 = this.duration;
            return (((this.day.hashCode() * 31) + this.count) * 31) + ((int) (j10 ^ (j10 >>> 32)));
        }

        public String toString() {
            String str = this.day;
            int i10 = this.count;
            long j10 = this.duration;
            return "GroupBean(day=" + str + ", count=" + i10 + ", duration=" + j10 + ")";
        }
    }

    /* compiled from: UserBean.kt */
    public static final class TransactionData {
        private final String platform;
        private final String token;
        private final String transaction_id;

        public TransactionData(String str, String str2, String str3) {
            d0.g(str, "transaction_id");
            d0.g(str2, "platform");
            d0.g(str3, "token");
            this.transaction_id = str;
            this.platform = str2;
            this.token = str3;
        }

        public static /* synthetic */ TransactionData copy$default(TransactionData transactionData, String str, String str2, String str3, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = transactionData.transaction_id;
            }
            if ((i10 & 2) != 0) {
                str2 = transactionData.platform;
            }
            if ((i10 & 4) != 0) {
                str3 = transactionData.token;
            }
            return transactionData.copy(str, str2, str3);
        }

        public final String component1() {
            return this.transaction_id;
        }

        public final String component2() {
            return this.platform;
        }

        public final String component3() {
            return this.token;
        }

        public final TransactionData copy(String str, String str2, String str3) {
            d0.g(str, "transaction_id");
            d0.g(str2, "platform");
            d0.g(str3, "token");
            return new TransactionData(str, str2, str3);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof TransactionData)) {
                return false;
            }
            TransactionData transactionData = (TransactionData) obj;
            return d0.b(this.transaction_id, transactionData.transaction_id) && d0.b(this.platform, transactionData.platform) && d0.b(this.token, transactionData.token);
        }

        public final String getPlatform() {
            return this.platform;
        }

        public final String getToken() {
            return this.token;
        }

        public final String getTransaction_id() {
            return this.transaction_id;
        }

        public int hashCode() {
            return this.token.hashCode() + c.b.a(this.platform, this.transaction_id.hashCode() * 31, 31);
        }

        public String toString() {
            String str = this.transaction_id;
            String str2 = this.platform;
            return d.a(e.a("TransactionData(transaction_id=", str, ", platform=", str2, ", token="), this.token, ")");
        }
    }

    /* compiled from: UserBean.kt */
    public static final class UpdatePasswordReq {
        private final String password_new;
        private final String password_old;

        public UpdatePasswordReq(String str, String str2) {
            d0.g(str, "password_old");
            d0.g(str2, "password_new");
            this.password_old = str;
            this.password_new = str2;
        }

        public static /* synthetic */ UpdatePasswordReq copy$default(UpdatePasswordReq updatePasswordReq, String str, String str2, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = updatePasswordReq.password_old;
            }
            if ((i10 & 2) != 0) {
                str2 = updatePasswordReq.password_new;
            }
            return updatePasswordReq.copy(str, str2);
        }

        public final String component1() {
            return this.password_old;
        }

        public final String component2() {
            return this.password_new;
        }

        public final UpdatePasswordReq copy(String str, String str2) {
            d0.g(str, "password_old");
            d0.g(str2, "password_new");
            return new UpdatePasswordReq(str, str2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof UpdatePasswordReq)) {
                return false;
            }
            UpdatePasswordReq updatePasswordReq = (UpdatePasswordReq) obj;
            return d0.b(this.password_old, updatePasswordReq.password_old) && d0.b(this.password_new, updatePasswordReq.password_new);
        }

        public final String getPassword_new() {
            return this.password_new;
        }

        public final String getPassword_old() {
            return this.password_old;
        }

        public int hashCode() {
            return this.password_new.hashCode() + (this.password_old.hashCode() * 31);
        }

        public String toString() {
            return a.a("UpdatePasswordReq(password_old=", this.password_old, ", password_new=", this.password_new, ")");
        }
    }

    /* compiled from: UserBean.kt */
    public static final class UpdateUserRsp extends ApiResponse {
        private final UserInfo data_user;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public UpdateUserRsp(UserInfo userInfo) {
            super((Integer) null, (String) null, (Throwable) null, 7, (DefaultConstructorMarker) null);
            d0.g(userInfo, "data_user");
            this.data_user = userInfo;
        }

        public static /* synthetic */ UpdateUserRsp copy$default(UpdateUserRsp updateUserRsp, UserInfo userInfo, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                userInfo = updateUserRsp.data_user;
            }
            return updateUserRsp.copy(userInfo);
        }

        public final UserInfo component1() {
            return this.data_user;
        }

        public final UpdateUserRsp copy(UserInfo userInfo) {
            d0.g(userInfo, "data_user");
            return new UpdateUserRsp(userInfo);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof UpdateUserRsp) && d0.b(this.data_user, ((UpdateUserRsp) obj).data_user);
        }

        public final UserInfo getData_user() {
            return this.data_user;
        }

        public int hashCode() {
            return this.data_user.hashCode();
        }

        public String toString() {
            UserInfo userInfo = this.data_user;
            return "UpdateUserRsp(data_user=" + userInfo + ")";
        }
    }

    private UserBean() {
    }

    /* compiled from: UserBean.kt */
    public static final class UserState {
        private final Boolean autorenew_status_android;
        private final Integer is_bind;
        private final Integer is_membership;
        private final String membership_type;

        public UserState() {
            this((Integer) null, (Integer) null, (Boolean) null, (String) null, 15, (DefaultConstructorMarker) null);
        }

        public UserState(Integer num, Integer num2, Boolean bool, String str) {
            this.is_bind = num;
            this.is_membership = num2;
            this.autorenew_status_android = bool;
            this.membership_type = str;
        }

        public static /* synthetic */ UserState copy$default(UserState userState, Integer num, Integer num2, Boolean bool, String str, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                num = userState.is_bind;
            }
            if ((i10 & 2) != 0) {
                num2 = userState.is_membership;
            }
            if ((i10 & 4) != 0) {
                bool = userState.autorenew_status_android;
            }
            if ((i10 & 8) != 0) {
                str = userState.membership_type;
            }
            return userState.copy(num, num2, bool, str);
        }

        public final Integer component1() {
            return this.is_bind;
        }

        public final Integer component2() {
            return this.is_membership;
        }

        public final Boolean component3() {
            return this.autorenew_status_android;
        }

        public final String component4() {
            return this.membership_type;
        }

        public final UserState copy(Integer num, Integer num2, Boolean bool, String str) {
            return new UserState(num, num2, bool, str);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof UserState)) {
                return false;
            }
            UserState userState = (UserState) obj;
            return d0.b(this.is_bind, userState.is_bind) && d0.b(this.is_membership, userState.is_membership) && d0.b(this.autorenew_status_android, userState.autorenew_status_android) && d0.b(this.membership_type, userState.membership_type);
        }

        public final Boolean getAutorenew_status_android() {
            return this.autorenew_status_android;
        }

        public final String getMembership_type() {
            return this.membership_type;
        }

        public int hashCode() {
            Integer num = this.is_bind;
            int i10 = 0;
            int hashCode = (num == null ? 0 : num.hashCode()) * 31;
            Integer num2 = this.is_membership;
            int hashCode2 = (hashCode + (num2 == null ? 0 : num2.hashCode())) * 31;
            Boolean bool = this.autorenew_status_android;
            int hashCode3 = (hashCode2 + (bool == null ? 0 : bool.hashCode())) * 31;
            String str = this.membership_type;
            if (str != null) {
                i10 = str.hashCode();
            }
            return hashCode3 + i10;
        }

        public final Integer is_bind() {
            return this.is_bind;
        }

        public final Integer is_membership() {
            return this.is_membership;
        }

        public String toString() {
            Integer num = this.is_bind;
            Integer num2 = this.is_membership;
            Boolean bool = this.autorenew_status_android;
            String str = this.membership_type;
            return "UserState(is_bind=" + num + ", is_membership=" + num2 + ", autorenew_status_android=" + bool + ", membership_type=" + str + ")";
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        public /* synthetic */ UserState(Integer num, Integer num2, Boolean bool, String str, int i10, DefaultConstructorMarker defaultConstructorMarker) {
            this((i10 & 1) != 0 ? null : num, (i10 & 2) != 0 ? null : num2, (i10 & 4) != 0 ? null : bool, (i10 & 8) != 0 ? null : str);
        }
    }

    /* compiled from: UserBean.kt */
    public static final class UpdateUserReq {
        private final String address;
        private final String birthday;
        private final String country;
        private final Integer gender;
        private final String nickname;
        private final String push_token;

        public UpdateUserReq() {
            this((String) null, (String) null, (Integer) null, (String) null, (String) null, (String) null, 63, (DefaultConstructorMarker) null);
        }

        public UpdateUserReq(String str, String str2, Integer num, String str3, String str4, String str5) {
            this.nickname = str;
            this.birthday = str2;
            this.gender = num;
            this.country = str3;
            this.address = str4;
            this.push_token = str5;
        }

        public static /* synthetic */ UpdateUserReq copy$default(UpdateUserReq updateUserReq, String str, String str2, Integer num, String str3, String str4, String str5, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = updateUserReq.nickname;
            }
            if ((i10 & 2) != 0) {
                str2 = updateUserReq.birthday;
            }
            String str6 = str2;
            if ((i10 & 4) != 0) {
                num = updateUserReq.gender;
            }
            Integer num2 = num;
            if ((i10 & 8) != 0) {
                str3 = updateUserReq.country;
            }
            String str7 = str3;
            if ((i10 & 16) != 0) {
                str4 = updateUserReq.address;
            }
            String str8 = str4;
            if ((i10 & 32) != 0) {
                str5 = updateUserReq.push_token;
            }
            return updateUserReq.copy(str, str6, num2, str7, str8, str5);
        }

        public final String component1() {
            return this.nickname;
        }

        public final String component2() {
            return this.birthday;
        }

        public final Integer component3() {
            return this.gender;
        }

        public final String component4() {
            return this.country;
        }

        public final String component5() {
            return this.address;
        }

        public final String component6() {
            return this.push_token;
        }

        public final UpdateUserReq copy(String str, String str2, Integer num, String str3, String str4, String str5) {
            return new UpdateUserReq(str, str2, num, str3, str4, str5);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof UpdateUserReq)) {
                return false;
            }
            UpdateUserReq updateUserReq = (UpdateUserReq) obj;
            return d0.b(this.nickname, updateUserReq.nickname) && d0.b(this.birthday, updateUserReq.birthday) && d0.b(this.gender, updateUserReq.gender) && d0.b(this.country, updateUserReq.country) && d0.b(this.address, updateUserReq.address) && d0.b(this.push_token, updateUserReq.push_token);
        }

        public final String getAddress() {
            return this.address;
        }

        public final String getBirthday() {
            return this.birthday;
        }

        public final String getCountry() {
            return this.country;
        }

        public final Integer getGender() {
            return this.gender;
        }

        public final String getNickname() {
            return this.nickname;
        }

        public final String getPush_token() {
            return this.push_token;
        }

        public int hashCode() {
            String str = this.nickname;
            int i10 = 0;
            int hashCode = (str == null ? 0 : str.hashCode()) * 31;
            String str2 = this.birthday;
            int hashCode2 = (hashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
            Integer num = this.gender;
            int hashCode3 = (hashCode2 + (num == null ? 0 : num.hashCode())) * 31;
            String str3 = this.country;
            int hashCode4 = (hashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
            String str4 = this.address;
            int hashCode5 = (hashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31;
            String str5 = this.push_token;
            if (str5 != null) {
                i10 = str5.hashCode();
            }
            return hashCode5 + i10;
        }

        public String toString() {
            String str = this.nickname;
            String str2 = this.birthday;
            Integer num = this.gender;
            String str3 = this.country;
            String str4 = this.address;
            String str5 = this.push_token;
            StringBuilder a10 = e.a("UpdateUserReq(nickname=", str, ", birthday=", str2, ", gender=");
            a10.append(num);
            a10.append(", country=");
            a10.append(str3);
            a10.append(", address=");
            a10.append(str4);
            a10.append(", push_token=");
            a10.append(str5);
            a10.append(")");
            return a10.toString();
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public /* synthetic */ UpdateUserReq(java.lang.String r6, java.lang.String r7, java.lang.Integer r8, java.lang.String r9, java.lang.String r10, java.lang.String r11, int r12, kotlin.jvm.internal.DefaultConstructorMarker r13) {
            /*
                r5 = this;
                r13 = r12 & 1
                r0 = 0
                if (r13 == 0) goto L_0x0007
                r13 = r0
                goto L_0x0008
            L_0x0007:
                r13 = r6
            L_0x0008:
                r6 = r12 & 2
                if (r6 == 0) goto L_0x000e
                r1 = r0
                goto L_0x000f
            L_0x000e:
                r1 = r7
            L_0x000f:
                r6 = r12 & 4
                if (r6 == 0) goto L_0x0015
                r2 = r0
                goto L_0x0016
            L_0x0015:
                r2 = r8
            L_0x0016:
                r6 = r12 & 8
                if (r6 == 0) goto L_0x001c
                r3 = r0
                goto L_0x001d
            L_0x001c:
                r3 = r9
            L_0x001d:
                r6 = r12 & 16
                if (r6 == 0) goto L_0x0023
                r4 = r0
                goto L_0x0024
            L_0x0023:
                r4 = r10
            L_0x0024:
                r6 = r12 & 32
                if (r6 == 0) goto L_0x002a
                r12 = r0
                goto L_0x002b
            L_0x002a:
                r12 = r11
            L_0x002b:
                r6 = r5
                r7 = r13
                r8 = r1
                r9 = r2
                r10 = r3
                r11 = r4
                r6.<init>(r7, r8, r9, r10, r11, r12)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.api.bean.UserBean.UpdateUserReq.<init>(java.lang.String, java.lang.String, java.lang.Integer, java.lang.String, java.lang.String, java.lang.String, int, kotlin.jvm.internal.DefaultConstructorMarker):void");
        }
    }

    /* compiled from: UserBean.kt */
    public static final class UserInfo {
        private final String address;
        private String avatar;
        private final String birthday;
        private final String country;
        private final String email;
        private final boolean email_verified;
        private final Long expire_time;
        private final Long expire_time_traffic;
        private final Integer gender;

        /* renamed from: id  reason: collision with root package name */
        private final String f893id;
        private final Integer membership_id;
        private final Integer membership_id_traffic;
        private final String nickname;
        private final String phone;
        private final boolean phone_verified;
        private final Long reset_time;
        private final Long seconds_left;
        private final Long seconds_left_traffic;
        private final Long seconds_total;
        private final Long seconds_total_traffic;
        private final Long start_time;
        private final Long start_time_traffic;

        public UserInfo(String str, String str2, String str3, String str4, Integer num, String str5, String str6, String str7, boolean z10, String str8, boolean z11, Integer num2, Long l10, Long l11, Long l12, Long l13, Long l14, Integer num3, Long l15, Long l16, Long l17, Long l18) {
            d0.g(str, "id");
            d0.g(str3, "nickname");
            d0.g(str7, "email");
            this.f893id = str;
            this.avatar = str2;
            this.nickname = str3;
            this.birthday = str4;
            this.gender = num;
            this.country = str5;
            this.address = str6;
            this.email = str7;
            this.email_verified = z10;
            this.phone = str8;
            this.phone_verified = z11;
            this.membership_id = num2;
            this.start_time = l10;
            this.expire_time = l11;
            this.reset_time = l12;
            this.seconds_left = l13;
            this.seconds_total = l14;
            this.membership_id_traffic = num3;
            this.start_time_traffic = l15;
            this.expire_time_traffic = l16;
            this.seconds_left_traffic = l17;
            this.seconds_total_traffic = l18;
        }

        public static /* synthetic */ UserInfo copy$default(UserInfo userInfo, String str, String str2, String str3, String str4, Integer num, String str5, String str6, String str7, boolean z10, String str8, boolean z11, Integer num2, Long l10, Long l11, Long l12, Long l13, Long l14, Integer num3, Long l15, Long l16, Long l17, Long l18, int i10, Object obj) {
            UserInfo userInfo2 = userInfo;
            int i11 = i10;
            return userInfo.copy((i11 & 1) != 0 ? userInfo2.f893id : str, (i11 & 2) != 0 ? userInfo2.avatar : str2, (i11 & 4) != 0 ? userInfo2.nickname : str3, (i11 & 8) != 0 ? userInfo2.birthday : str4, (i11 & 16) != 0 ? userInfo2.gender : num, (i11 & 32) != 0 ? userInfo2.country : str5, (i11 & 64) != 0 ? userInfo2.address : str6, (i11 & 128) != 0 ? userInfo2.email : str7, (i11 & 256) != 0 ? userInfo2.email_verified : z10, (i11 & RecyclerView.z.FLAG_ADAPTER_POSITION_UNKNOWN) != 0 ? userInfo2.phone : str8, (i11 & RecyclerView.z.FLAG_ADAPTER_FULLUPDATE) != 0 ? userInfo2.phone_verified : z11, (i11 & 2048) != 0 ? userInfo2.membership_id : num2, (i11 & 4096) != 0 ? userInfo2.start_time : l10, (i11 & 8192) != 0 ? userInfo2.expire_time : l11, (i11 & Http2.INITIAL_MAX_FRAME_SIZE) != 0 ? userInfo2.reset_time : l12, (i11 & 32768) != 0 ? userInfo2.seconds_left : l13, (i11 & MapMakerInternalMap.MAX_SEGMENTS) != 0 ? userInfo2.seconds_total : l14, (i11 & 131072) != 0 ? userInfo2.membership_id_traffic : num3, (i11 & 262144) != 0 ? userInfo2.start_time_traffic : l15, (i11 & 524288) != 0 ? userInfo2.expire_time_traffic : l16, (i11 & 1048576) != 0 ? userInfo2.seconds_left_traffic : l17, (i11 & 2097152) != 0 ? userInfo2.seconds_total_traffic : l18);
        }

        public final String component1() {
            return this.f893id;
        }

        public final String component10() {
            return this.phone;
        }

        public final boolean component11() {
            return this.phone_verified;
        }

        public final Integer component12() {
            return this.membership_id;
        }

        public final Long component13() {
            return this.start_time;
        }

        public final Long component14() {
            return this.expire_time;
        }

        public final Long component15() {
            return this.reset_time;
        }

        public final Long component16() {
            return this.seconds_left;
        }

        public final Long component17() {
            return this.seconds_total;
        }

        public final Integer component18() {
            return this.membership_id_traffic;
        }

        public final Long component19() {
            return this.start_time_traffic;
        }

        public final String component2() {
            return this.avatar;
        }

        public final Long component20() {
            return this.expire_time_traffic;
        }

        public final Long component21() {
            return this.seconds_left_traffic;
        }

        public final Long component22() {
            return this.seconds_total_traffic;
        }

        public final String component3() {
            return this.nickname;
        }

        public final String component4() {
            return this.birthday;
        }

        public final Integer component5() {
            return this.gender;
        }

        public final String component6() {
            return this.country;
        }

        public final String component7() {
            return this.address;
        }

        public final String component8() {
            return this.email;
        }

        public final boolean component9() {
            return this.email_verified;
        }

        public final UserInfo copy(String str, String str2, String str3, String str4, Integer num, String str5, String str6, String str7, boolean z10, String str8, boolean z11, Integer num2, Long l10, Long l11, Long l12, Long l13, Long l14, Integer num3, Long l15, Long l16, Long l17, Long l18) {
            String str9 = str;
            d0.g(str9, "id");
            d0.g(str3, "nickname");
            d0.g(str7, "email");
            return new UserInfo(str9, str2, str3, str4, num, str5, str6, str7, z10, str8, z11, num2, l10, l11, l12, l13, l14, num3, l15, l16, l17, l18);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof UserInfo)) {
                return false;
            }
            UserInfo userInfo = (UserInfo) obj;
            return d0.b(this.f893id, userInfo.f893id) && d0.b(this.avatar, userInfo.avatar) && d0.b(this.nickname, userInfo.nickname) && d0.b(this.birthday, userInfo.birthday) && d0.b(this.gender, userInfo.gender) && d0.b(this.country, userInfo.country) && d0.b(this.address, userInfo.address) && d0.b(this.email, userInfo.email) && this.email_verified == userInfo.email_verified && d0.b(this.phone, userInfo.phone) && this.phone_verified == userInfo.phone_verified && d0.b(this.membership_id, userInfo.membership_id) && d0.b(this.start_time, userInfo.start_time) && d0.b(this.expire_time, userInfo.expire_time) && d0.b(this.reset_time, userInfo.reset_time) && d0.b(this.seconds_left, userInfo.seconds_left) && d0.b(this.seconds_total, userInfo.seconds_total) && d0.b(this.membership_id_traffic, userInfo.membership_id_traffic) && d0.b(this.start_time_traffic, userInfo.start_time_traffic) && d0.b(this.expire_time_traffic, userInfo.expire_time_traffic) && d0.b(this.seconds_left_traffic, userInfo.seconds_left_traffic) && d0.b(this.seconds_total_traffic, userInfo.seconds_total_traffic);
        }

        public final String getAddress() {
            return this.address;
        }

        public final String getAvatar() {
            return this.avatar;
        }

        public final String getBirthday() {
            return this.birthday;
        }

        public final String getCountry() {
            return this.country;
        }

        public final String getEmail() {
            return this.email;
        }

        public final boolean getEmail_verified() {
            return this.email_verified;
        }

        public final Long getExpire_time() {
            return this.expire_time;
        }

        public final Long getExpire_time_traffic() {
            return this.expire_time_traffic;
        }

        public final Integer getGender() {
            return this.gender;
        }

        public final String getId() {
            return this.f893id;
        }

        public final Integer getMembership_id() {
            return this.membership_id;
        }

        public final Integer getMembership_id_traffic() {
            return this.membership_id_traffic;
        }

        public final String getNickname() {
            return this.nickname;
        }

        public final String getPhone() {
            return this.phone;
        }

        public final boolean getPhone_verified() {
            return this.phone_verified;
        }

        public final Long getReset_time() {
            return this.reset_time;
        }

        public final Long getSeconds_left() {
            return this.seconds_left;
        }

        public final Long getSeconds_left_traffic() {
            return this.seconds_left_traffic;
        }

        public final Long getSeconds_total() {
            return this.seconds_total;
        }

        public final Long getSeconds_total_traffic() {
            return this.seconds_total_traffic;
        }

        public final Long getStart_time() {
            return this.start_time;
        }

        public final Long getStart_time_traffic() {
            return this.start_time_traffic;
        }

        public int hashCode() {
            int hashCode = this.f893id.hashCode() * 31;
            String str = this.avatar;
            int i10 = 0;
            int a10 = c.b.a(this.nickname, (hashCode + (str == null ? 0 : str.hashCode())) * 31, 31);
            String str2 = this.birthday;
            int hashCode2 = (a10 + (str2 == null ? 0 : str2.hashCode())) * 31;
            Integer num = this.gender;
            int hashCode3 = (hashCode2 + (num == null ? 0 : num.hashCode())) * 31;
            String str3 = this.country;
            int hashCode4 = (hashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
            String str4 = this.address;
            int a11 = c.b.a(this.email, (hashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31, 31);
            boolean z10 = this.email_verified;
            boolean z11 = true;
            if (z10) {
                z10 = true;
            }
            int i11 = (a11 + (z10 ? 1 : 0)) * 31;
            String str5 = this.phone;
            int hashCode5 = (i11 + (str5 == null ? 0 : str5.hashCode())) * 31;
            boolean z12 = this.phone_verified;
            if (!z12) {
                z11 = z12;
            }
            int i12 = (hashCode5 + (z11 ? 1 : 0)) * 31;
            Integer num2 = this.membership_id;
            int hashCode6 = (i12 + (num2 == null ? 0 : num2.hashCode())) * 31;
            Long l10 = this.start_time;
            int hashCode7 = (hashCode6 + (l10 == null ? 0 : l10.hashCode())) * 31;
            Long l11 = this.expire_time;
            int hashCode8 = (hashCode7 + (l11 == null ? 0 : l11.hashCode())) * 31;
            Long l12 = this.reset_time;
            int hashCode9 = (hashCode8 + (l12 == null ? 0 : l12.hashCode())) * 31;
            Long l13 = this.seconds_left;
            int hashCode10 = (hashCode9 + (l13 == null ? 0 : l13.hashCode())) * 31;
            Long l14 = this.seconds_total;
            int hashCode11 = (hashCode10 + (l14 == null ? 0 : l14.hashCode())) * 31;
            Integer num3 = this.membership_id_traffic;
            int hashCode12 = (hashCode11 + (num3 == null ? 0 : num3.hashCode())) * 31;
            Long l15 = this.start_time_traffic;
            int hashCode13 = (hashCode12 + (l15 == null ? 0 : l15.hashCode())) * 31;
            Long l16 = this.expire_time_traffic;
            int hashCode14 = (hashCode13 + (l16 == null ? 0 : l16.hashCode())) * 31;
            Long l17 = this.seconds_left_traffic;
            int hashCode15 = (hashCode14 + (l17 == null ? 0 : l17.hashCode())) * 31;
            Long l18 = this.seconds_total_traffic;
            if (l18 != null) {
                i10 = l18.hashCode();
            }
            return hashCode15 + i10;
        }

        public final void setAvatar(String str) {
            this.avatar = str;
        }

        public String toString() {
            String str = this.f893id;
            String str2 = this.avatar;
            String str3 = this.nickname;
            String str4 = this.birthday;
            Integer num = this.gender;
            String str5 = this.country;
            String str6 = this.address;
            String str7 = this.email;
            boolean z10 = this.email_verified;
            String str8 = this.phone;
            boolean z11 = this.phone_verified;
            Integer num2 = this.membership_id;
            Long l10 = this.start_time;
            Long l11 = this.expire_time;
            Long l12 = this.reset_time;
            Long l13 = this.seconds_left;
            Long l14 = this.seconds_total;
            Integer num3 = this.membership_id_traffic;
            Long l15 = this.start_time_traffic;
            Long l16 = this.expire_time_traffic;
            Long l17 = this.seconds_left_traffic;
            StringBuilder a10 = e.a("UserInfo(id=", str, ", avatar=", str2, ", nickname=");
            a10.append(str3);
            a10.append(", birthday=");
            a10.append(str4);
            a10.append(", gender=");
            a10.append(num);
            a10.append(", country=");
            a10.append(str5);
            a10.append(", address=");
            a10.append(str6);
            a10.append(", email=");
            a10.append(str7);
            a10.append(", email_verified=");
            a10.append(z10);
            a10.append(", phone=");
            a10.append(str8);
            a10.append(", phone_verified=");
            a10.append(z11);
            a10.append(", membership_id=");
            a10.append(num2);
            a10.append(", start_time=");
            a10.append(l10);
            a10.append(", expire_time=");
            a10.append(l11);
            a10.append(", reset_time=");
            a10.append(l12);
            a10.append(", seconds_left=");
            a10.append(l13);
            a10.append(", seconds_total=");
            a10.append(l14);
            a10.append(", membership_id_traffic=");
            a10.append(num3);
            a10.append(", start_time_traffic=");
            a10.append(l15);
            a10.append(", expire_time_traffic=");
            a10.append(l16);
            a10.append(", seconds_left_traffic=");
            a10.append(l17);
            a10.append(", seconds_total_traffic=");
            a10.append(this.seconds_total_traffic);
            a10.append(")");
            return a10.toString();
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public /* synthetic */ UserInfo(java.lang.String r27, java.lang.String r28, java.lang.String r29, java.lang.String r30, java.lang.Integer r31, java.lang.String r32, java.lang.String r33, java.lang.String r34, boolean r35, java.lang.String r36, boolean r37, java.lang.Integer r38, java.lang.Long r39, java.lang.Long r40, java.lang.Long r41, java.lang.Long r42, java.lang.Long r43, java.lang.Integer r44, java.lang.Long r45, java.lang.Long r46, java.lang.Long r47, java.lang.Long r48, int r49, kotlin.jvm.internal.DefaultConstructorMarker r50) {
            /*
                r26 = this;
                r0 = r49
                r1 = r0 & 2
                r2 = 0
                if (r1 == 0) goto L_0x0009
                r5 = r2
                goto L_0x000b
            L_0x0009:
                r5 = r28
            L_0x000b:
                r1 = r0 & 8
                if (r1 == 0) goto L_0x0011
                r7 = r2
                goto L_0x0013
            L_0x0011:
                r7 = r30
            L_0x0013:
                r1 = r0 & 16
                r3 = 0
                if (r1 == 0) goto L_0x001e
                java.lang.Integer r1 = java.lang.Integer.valueOf(r3)
                r8 = r1
                goto L_0x0020
            L_0x001e:
                r8 = r31
            L_0x0020:
                r1 = r0 & 32
                if (r1 == 0) goto L_0x0026
                r9 = r2
                goto L_0x0028
            L_0x0026:
                r9 = r32
            L_0x0028:
                r1 = r0 & 64
                if (r1 == 0) goto L_0x002e
                r10 = r2
                goto L_0x0030
            L_0x002e:
                r10 = r33
            L_0x0030:
                r1 = r0 & 512(0x200, float:7.175E-43)
                if (r1 == 0) goto L_0x0036
                r13 = r2
                goto L_0x0038
            L_0x0036:
                r13 = r36
            L_0x0038:
                r1 = r0 & 2048(0x800, float:2.87E-42)
                if (r1 == 0) goto L_0x0042
                java.lang.Integer r1 = java.lang.Integer.valueOf(r3)
                r15 = r1
                goto L_0x0044
            L_0x0042:
                r15 = r38
            L_0x0044:
                r1 = r0 & 4096(0x1000, float:5.74E-42)
                if (r1 == 0) goto L_0x004b
                r16 = r2
                goto L_0x004d
            L_0x004b:
                r16 = r39
            L_0x004d:
                r1 = r0 & 8192(0x2000, float:1.14794E-41)
                if (r1 == 0) goto L_0x0054
                r17 = r2
                goto L_0x0056
            L_0x0054:
                r17 = r40
            L_0x0056:
                r1 = r0 & 16384(0x4000, float:2.2959E-41)
                if (r1 == 0) goto L_0x005d
                r18 = r2
                goto L_0x005f
            L_0x005d:
                r18 = r41
            L_0x005f:
                r1 = 32768(0x8000, float:4.5918E-41)
                r1 = r1 & r0
                if (r1 == 0) goto L_0x0068
                r19 = r2
                goto L_0x006a
            L_0x0068:
                r19 = r42
            L_0x006a:
                r1 = 65536(0x10000, float:9.18355E-41)
                r1 = r1 & r0
                if (r1 == 0) goto L_0x0072
                r20 = r2
                goto L_0x0074
            L_0x0072:
                r20 = r43
            L_0x0074:
                r1 = 131072(0x20000, float:1.83671E-40)
                r1 = r1 & r0
                if (r1 == 0) goto L_0x007c
                r21 = r2
                goto L_0x007e
            L_0x007c:
                r21 = r44
            L_0x007e:
                r1 = 262144(0x40000, float:3.67342E-40)
                r1 = r1 & r0
                if (r1 == 0) goto L_0x0086
                r22 = r2
                goto L_0x0088
            L_0x0086:
                r22 = r45
            L_0x0088:
                r1 = 524288(0x80000, float:7.34684E-40)
                r1 = r1 & r0
                if (r1 == 0) goto L_0x0090
                r23 = r2
                goto L_0x0092
            L_0x0090:
                r23 = r46
            L_0x0092:
                r1 = 1048576(0x100000, float:1.469368E-39)
                r1 = r1 & r0
                r2 = 0
                if (r1 == 0) goto L_0x00a0
                java.lang.Long r1 = java.lang.Long.valueOf(r2)
                r24 = r1
                goto L_0x00a2
            L_0x00a0:
                r24 = r47
            L_0x00a2:
                r1 = 2097152(0x200000, float:2.938736E-39)
                r0 = r0 & r1
                if (r0 == 0) goto L_0x00ae
                java.lang.Long r0 = java.lang.Long.valueOf(r2)
                r25 = r0
                goto L_0x00b0
            L_0x00ae:
                r25 = r48
            L_0x00b0:
                r3 = r26
                r4 = r27
                r6 = r29
                r11 = r34
                r12 = r35
                r14 = r37
                r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.api.bean.UserBean.UserInfo.<init>(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.String, java.lang.String, java.lang.String, boolean, java.lang.String, boolean, java.lang.Integer, java.lang.Long, java.lang.Long, java.lang.Long, java.lang.Long, java.lang.Long, java.lang.Integer, java.lang.Long, java.lang.Long, java.lang.Long, java.lang.Long, int, kotlin.jvm.internal.DefaultConstructorMarker):void");
        }
    }
}
