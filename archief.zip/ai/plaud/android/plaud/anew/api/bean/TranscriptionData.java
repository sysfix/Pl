package ai.plaud.android.plaud.anew.api.bean;

import android.os.Parcel;
import android.os.Parcelable;
import ib.a;
import rg.d0;

/* compiled from: TranscriptionData.kt */
public final class TranscriptionData implements Parcelable {
    public static final Parcelable.Creator<TranscriptionData> CREATOR = new Creator();
    @a
    private String content;
    @a
    private final long end_time;
    private boolean selected;
    @a
    private final long start_time;

    /* compiled from: TranscriptionData.kt */
    public static final class Creator implements Parcelable.Creator<TranscriptionData> {
        public final TranscriptionData createFromParcel(Parcel parcel) {
            d0.g(parcel, "parcel");
            return new TranscriptionData(parcel.readString(), parcel.readLong(), parcel.readLong());
        }

        public final TranscriptionData[] newArray(int i10) {
            return new TranscriptionData[i10];
        }
    }

    public TranscriptionData(String str, long j10, long j11) {
        d0.g(str, "content");
        this.content = str;
        this.end_time = j10;
        this.start_time = j11;
    }

    public static /* synthetic */ TranscriptionData copy$default(TranscriptionData transcriptionData, String str, long j10, long j11, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = transcriptionData.content;
        }
        if ((i10 & 2) != 0) {
            j10 = transcriptionData.end_time;
        }
        long j12 = j10;
        if ((i10 & 4) != 0) {
            j11 = transcriptionData.start_time;
        }
        return transcriptionData.copy(str, j12, j11);
    }

    public static /* synthetic */ void getSelected$annotations() {
    }

    public final String component1() {
        return this.content;
    }

    public final long component2() {
        return this.end_time;
    }

    public final long component3() {
        return this.start_time;
    }

    public final TranscriptionData copy(String str, long j10, long j11) {
        d0.g(str, "content");
        return new TranscriptionData(str, j10, j11);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TranscriptionData)) {
            return false;
        }
        TranscriptionData transcriptionData = (TranscriptionData) obj;
        return d0.b(this.content, transcriptionData.content) && this.end_time == transcriptionData.end_time && this.start_time == transcriptionData.start_time;
    }

    public final String getContent() {
        return this.content;
    }

    public final long getEnd_time() {
        return this.end_time;
    }

    public final boolean getSelected() {
        return this.selected;
    }

    public final long getStart_time() {
        return this.start_time;
    }

    public int hashCode() {
        long j10 = this.end_time;
        long j11 = this.start_time;
        return (((this.content.hashCode() * 31) + ((int) (j10 ^ (j10 >>> 32)))) * 31) + ((int) (j11 ^ (j11 >>> 32)));
    }

    public final void setContent(String str) {
        d0.g(str, "<set-?>");
        this.content = str;
    }

    public final void setSelected(boolean z10) {
        this.selected = z10;
    }

    public String toString() {
        String str = this.content;
        long j10 = this.end_time;
        long j11 = this.start_time;
        return "TranscriptionData(content=" + str + ", end_time=" + j10 + ", start_time=" + j11 + ")";
    }

    public void writeToParcel(Parcel parcel, int i10) {
        d0.g(parcel, "out");
        parcel.writeString(this.content);
        parcel.writeLong(this.end_time);
        parcel.writeLong(this.start_time);
    }
}
