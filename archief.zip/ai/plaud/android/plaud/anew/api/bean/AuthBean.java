package ai.plaud.android.plaud.anew.api.bean;

import ai.plaud.android.plaud.anew.api.ApiResponse;
import b.b;
import c.a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import rg.d0;

/* compiled from: AuthBean.kt */
public final class AuthBean {
    public static final AuthBean INSTANCE = new AuthBean();

    /* compiled from: AuthBean.kt */
    public static final class AccessTokenRsq extends ApiResponse {
        private final String access_token;
        private final String token_type;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public AccessTokenRsq(String str, String str2) {
            super((Integer) null, (String) null, (Throwable) null, 7, (DefaultConstructorMarker) null);
            d0.g(str, "access_token");
            d0.g(str2, "token_type");
            this.access_token = str;
            this.token_type = str2;
        }

        public static /* synthetic */ AccessTokenRsq copy$default(AccessTokenRsq accessTokenRsq, String str, String str2, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = accessTokenRsq.access_token;
            }
            if ((i10 & 2) != 0) {
                str2 = accessTokenRsq.token_type;
            }
            return accessTokenRsq.copy(str, str2);
        }

        public final String component1() {
            return this.access_token;
        }

        public final String component2() {
            return this.token_type;
        }

        public final AccessTokenRsq copy(String str, String str2) {
            d0.g(str, "access_token");
            d0.g(str2, "token_type");
            return new AccessTokenRsq(str, str2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof AccessTokenRsq)) {
                return false;
            }
            AccessTokenRsq accessTokenRsq = (AccessTokenRsq) obj;
            return d0.b(this.access_token, accessTokenRsq.access_token) && d0.b(this.token_type, accessTokenRsq.token_type);
        }

        public final String getAccess_token() {
            return this.access_token;
        }

        public final String getToken_type() {
            return this.token_type;
        }

        public int hashCode() {
            return this.token_type.hashCode() + (this.access_token.hashCode() * 31);
        }

        public String toString() {
            return a.a("AccessTokenRsq(access_token=", this.access_token, ", token_type=", this.token_type, ")");
        }
    }

    /* compiled from: AuthBean.kt */
    public static final class SendCodeReq {
        private final String type;
        private final String username;

        public SendCodeReq(String str, String str2) {
            d0.g(str, "username");
            d0.g(str2, "type");
            this.username = str;
            this.type = str2;
        }

        public static /* synthetic */ SendCodeReq copy$default(SendCodeReq sendCodeReq, String str, String str2, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = sendCodeReq.username;
            }
            if ((i10 & 2) != 0) {
                str2 = sendCodeReq.type;
            }
            return sendCodeReq.copy(str, str2);
        }

        public final String component1() {
            return this.username;
        }

        public final String component2() {
            return this.type;
        }

        public final SendCodeReq copy(String str, String str2) {
            d0.g(str, "username");
            d0.g(str2, "type");
            return new SendCodeReq(str, str2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof SendCodeReq)) {
                return false;
            }
            SendCodeReq sendCodeReq = (SendCodeReq) obj;
            return d0.b(this.username, sendCodeReq.username) && d0.b(this.type, sendCodeReq.type);
        }

        public final String getType() {
            return this.type;
        }

        public final String getUsername() {
            return this.username;
        }

        public int hashCode() {
            return this.type.hashCode() + (this.username.hashCode() * 31);
        }

        public String toString() {
            return a.a("SendCodeReq(username=", this.username, ", type=", this.type, ")");
        }
    }

    /* compiled from: AuthBean.kt */
    public static final class SendCodeRsp extends ApiResponse {
        private final String token;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public SendCodeRsp(String str) {
            super((Integer) null, (String) null, (Throwable) null, 7, (DefaultConstructorMarker) null);
            d0.g(str, "token");
            this.token = str;
        }

        public static /* synthetic */ SendCodeRsp copy$default(SendCodeRsp sendCodeRsp, String str, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = sendCodeRsp.token;
            }
            return sendCodeRsp.copy(str);
        }

        public final String component1() {
            return this.token;
        }

        public final SendCodeRsp copy(String str) {
            d0.g(str, "token");
            return new SendCodeRsp(str);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof SendCodeRsp) && d0.b(this.token, ((SendCodeRsp) obj).token);
        }

        public final String getToken() {
            return this.token;
        }

        public int hashCode() {
            return this.token.hashCode();
        }

        public String toString() {
            return b.a("SendCodeRsp(token=", this.token, ")");
        }
    }

    /* compiled from: AuthBean.kt */
    public static final class VerifyCodeReq {
        private final long code;
        private final String password;
        private final String token;

        public VerifyCodeReq(long j10, String str, String str2) {
            d0.g(str, "token");
            d0.g(str2, "password");
            this.code = j10;
            this.token = str;
            this.password = str2;
        }

        public static /* synthetic */ VerifyCodeReq copy$default(VerifyCodeReq verifyCodeReq, long j10, String str, String str2, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                j10 = verifyCodeReq.code;
            }
            if ((i10 & 2) != 0) {
                str = verifyCodeReq.token;
            }
            if ((i10 & 4) != 0) {
                str2 = verifyCodeReq.password;
            }
            return verifyCodeReq.copy(j10, str, str2);
        }

        public final long component1() {
            return this.code;
        }

        public final String component2() {
            return this.token;
        }

        public final String component3() {
            return this.password;
        }

        public final VerifyCodeReq copy(long j10, String str, String str2) {
            d0.g(str, "token");
            d0.g(str2, "password");
            return new VerifyCodeReq(j10, str, str2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof VerifyCodeReq)) {
                return false;
            }
            VerifyCodeReq verifyCodeReq = (VerifyCodeReq) obj;
            return this.code == verifyCodeReq.code && d0.b(this.token, verifyCodeReq.token) && d0.b(this.password, verifyCodeReq.password);
        }

        public final long getCode() {
            return this.code;
        }

        public final String getPassword() {
            return this.password;
        }

        public final String getToken() {
            return this.token;
        }

        public int hashCode() {
            long j10 = this.code;
            return this.password.hashCode() + c.b.a(this.token, ((int) (j10 ^ (j10 >>> 32))) * 31, 31);
        }

        public String toString() {
            long j10 = this.code;
            String str = this.token;
            String str2 = this.password;
            return "VerifyCodeReq(code=" + j10 + ", token=" + str + ", password=" + str2 + ")";
        }
    }

    private AuthBean() {
    }
}
