package ai.plaud.android.plaud.anew.api;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: PlaudApiResponse.kt */
public final class ApiEmptyResponse extends ApiResponse {
    private final String msg;
    private final Integer status;

    public ApiEmptyResponse() {
        this((Integer) null, (String) null, 3, (DefaultConstructorMarker) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ApiEmptyResponse(Integer num, String str, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : num, (i10 & 2) != 0 ? null : str);
    }

    public String getMsg() {
        return this.msg;
    }

    public Integer getStatus() {
        return this.status;
    }

    public String toString() {
        Integer status2 = getStatus();
        String msg2 = getMsg();
        return "status:[" + status2 + "]\nmsg:[" + msg2 + "]";
    }

    public ApiEmptyResponse(Integer num, String str) {
        super((Integer) null, str, (Throwable) null, 5, (DefaultConstructorMarker) null);
        this.status = num;
        this.msg = str;
    }
}
