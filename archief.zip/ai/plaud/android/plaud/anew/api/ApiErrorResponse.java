package ai.plaud.android.plaud.anew.api;

import kotlin.jvm.internal.DefaultConstructorMarker;
import rg.d0;

/* compiled from: PlaudApiResponse.kt */
public final class ApiErrorResponse extends ApiResponse {
    private final Throwable throwable;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ApiErrorResponse(Throwable th2) {
        super((Integer) null, (String) null, th2, 3, (DefaultConstructorMarker) null);
        d0.g(th2, "throwable");
        this.throwable = th2;
    }

    public static /* synthetic */ ApiErrorResponse copy$default(ApiErrorResponse apiErrorResponse, Throwable th2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            th2 = apiErrorResponse.throwable;
        }
        return apiErrorResponse.copy(th2);
    }

    public final Throwable component1() {
        return this.throwable;
    }

    public final ApiErrorResponse copy(Throwable th2) {
        d0.g(th2, "throwable");
        return new ApiErrorResponse(th2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof ApiErrorResponse) && d0.b(this.throwable, ((ApiErrorResponse) obj).throwable);
    }

    public final Throwable getThrowable() {
        return this.throwable;
    }

    public int hashCode() {
        return this.throwable.hashCode();
    }

    public String toString() {
        Throwable th2 = this.throwable;
        return "ApiErrorResponse(throwable=" + th2 + ")";
    }
}
