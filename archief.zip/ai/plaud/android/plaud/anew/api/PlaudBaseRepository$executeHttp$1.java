package ai.plaud.android.plaud.anew.api;

import ag.c;
import gg.l;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.a;

@a(c = "ai.plaud.android.plaud.anew.api.PlaudBaseRepository", f = "PlaudBaseRepository.kt", l = {22}, m = "executeHttp")
/* compiled from: PlaudBaseRepository.kt */
public final class PlaudBaseRepository$executeHttp$1 extends ContinuationImpl {
    public Object L$0;
    public int label;
    public /* synthetic */ Object result;
    public final /* synthetic */ PlaudBaseRepository this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PlaudBaseRepository$executeHttp$1(PlaudBaseRepository plaudBaseRepository, c<? super PlaudBaseRepository$executeHttp$1> cVar) {
        super(cVar);
        this.this$0 = plaudBaseRepository;
    }

    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= CellBase.GROUP_ID_SYSTEM_MESSAGE;
        return this.this$0.a((l<? super c<? super ApiResponse>, ? extends Object>) null, this);
    }
}
