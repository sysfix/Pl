package ai.plaud.android.plaud.anew.database;

import ai.plaud.android.plaud.anew.database.recordfile.RecordFilesDao;
import ai.plaud.android.plaud.anew.database.recordfile.RecordFilesDao_Impl;
import ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao;
import ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao_Impl;
import android.content.Context;
import androidx.room.RoomDatabase;
import androidx.room.d;
import androidx.room.h;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import o2.c;
import o2.f;
import q2.a;
import q2.b;

public final class PlaudDatabase_Impl extends PlaudDatabase {
    private volatile RecordFilesDao _recordFilesDao;
    private volatile TranscriptionDataDao _transcriptionDataDao;

    public void clearAllTables() {
        super.assertNotMainThread();
        a c12 = super.getOpenHelper().c1();
        try {
            super.beginTransaction();
            c12.I("DELETE FROM `record_file_table`");
            c12.I("DELETE FROM `transcription_data`");
            super.setTransactionSuccessful();
        } finally {
            super.endTransaction();
            c12.g1("PRAGMA wal_checkpoint(FULL)").close();
            if (!c12.n0()) {
                c12.I("VACUUM");
            }
        }
    }

    public d createInvalidationTracker() {
        return new d(this, new HashMap(0), new HashMap(0), "record_file_table", "transcription_data");
    }

    public b createOpenHelper(androidx.room.a aVar) {
        h hVar = new h(aVar, new h.a(5) {
            public void createAllTables(a aVar) {
                aVar.I("CREATE TABLE IF NOT EXISTS `record_file_table` (`record_file_key` TEXT NOT NULL, `session_id` INTEGER NOT NULL, `serial_number` TEXT NOT NULL, `is_guide` INTEGER NOT NULL, `cloud_has_trans_file` INTEGER NOT NULL, `duration` INTEGER NOT NULL, `file_size` INTEGER NOT NULL, `audio_channel_count` INTEGER NOT NULL, `file_name` TEXT NOT NULL, `full_name` TEXT NOT NULL DEFAULT '', `file_md5` TEXT NOT NULL DEFAULT '', `file_path` TEXT NOT NULL, `file_opus_path` TEXT NOT NULL, `audio_db_path` TEXT NOT NULL, `is_existing` INTEGER NOT NULL, `cloud_id` TEXT NOT NULL, `timezone` INTEGER NOT NULL, `timezone_min` INTEGER NOT NULL, `transcription` TEXT NOT NULL, `transcription_state` INTEGER NOT NULL, `trans_error_tip` TEXT NOT NULL DEFAULT '', `summary_error_tip` TEXT NOT NULL DEFAULT '', `summary` TEXT NOT NULL, `data_filetag_id_list` TEXT NOT NULL, `keywords` TEXT NOT NULL, `scene` INTEGER NOT NULL, `isNew` INTEGER NOT NULL, `delete_state` INTEGER NOT NULL, `version` INTEGER NOT NULL, `last_edit_time` INTEGER NOT NULL, `has_edit` INTEGER NOT NULL, PRIMARY KEY(`record_file_key`))");
                aVar.I("CREATE TABLE IF NOT EXISTS `transcription_data` (`record_file_key` TEXT NOT NULL, `trans_lan` TEXT NOT NULL, `need_re_trans` INTEGER NOT NULL DEFAULT 0, `trans_summary_type` TEXT NOT NULL, `post_id` INTEGER NOT NULL, `trans_file_id` TEXT NOT NULL DEFAULT '', `summary_file_id` TEXT NOT NULL DEFAULT '', PRIMARY KEY(`record_file_key`))");
                aVar.I("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
                aVar.I("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'a30cef8a9f41425948d3c5b806eb4f86')");
            }

            public void dropAllTables(a aVar) {
                aVar.I("DROP TABLE IF EXISTS `record_file_table`");
                aVar.I("DROP TABLE IF EXISTS `transcription_data`");
                if (PlaudDatabase_Impl.this.mCallbacks != null) {
                    int size = PlaudDatabase_Impl.this.mCallbacks.size();
                    for (int i10 = 0; i10 < size; i10++) {
                        Objects.requireNonNull((RoomDatabase.b) PlaudDatabase_Impl.this.mCallbacks.get(i10));
                    }
                }
            }

            public void onCreate(a aVar) {
                if (PlaudDatabase_Impl.this.mCallbacks != null) {
                    int size = PlaudDatabase_Impl.this.mCallbacks.size();
                    for (int i10 = 0; i10 < size; i10++) {
                        Objects.requireNonNull((RoomDatabase.b) PlaudDatabase_Impl.this.mCallbacks.get(i10));
                    }
                }
            }

            public void onOpen(a aVar) {
                a unused = PlaudDatabase_Impl.this.mDatabase = aVar;
                PlaudDatabase_Impl.this.internalInitInvalidationTracker(aVar);
                if (PlaudDatabase_Impl.this.mCallbacks != null) {
                    int size = PlaudDatabase_Impl.this.mCallbacks.size();
                    for (int i10 = 0; i10 < size; i10++) {
                        ((RoomDatabase.b) PlaudDatabase_Impl.this.mCallbacks.get(i10)).a(aVar);
                    }
                }
            }

            public void onPostMigrate(a aVar) {
            }

            public void onPreMigrate(a aVar) {
                c.a(aVar);
            }

            public h.b onValidateSchema(a aVar) {
                a aVar2 = aVar;
                HashMap hashMap = new HashMap(31);
                hashMap.put("record_file_key", new f.a("record_file_key", "TEXT", true, 1, (String) null, 1));
                hashMap.put("session_id", new f.a("session_id", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("serial_number", new f.a("serial_number", "TEXT", true, 0, (String) null, 1));
                hashMap.put("is_guide", new f.a("is_guide", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("cloud_has_trans_file", new f.a("cloud_has_trans_file", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("duration", new f.a("duration", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("file_size", new f.a("file_size", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("audio_channel_count", new f.a("audio_channel_count", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("file_name", new f.a("file_name", "TEXT", true, 0, (String) null, 1));
                hashMap.put("full_name", new f.a("full_name", "TEXT", true, 0, "''", 1));
                hashMap.put("file_md5", new f.a("file_md5", "TEXT", true, 0, "''", 1));
                hashMap.put("file_path", new f.a("file_path", "TEXT", true, 0, (String) null, 1));
                hashMap.put("file_opus_path", new f.a("file_opus_path", "TEXT", true, 0, (String) null, 1));
                hashMap.put("audio_db_path", new f.a("audio_db_path", "TEXT", true, 0, (String) null, 1));
                hashMap.put("is_existing", new f.a("is_existing", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("cloud_id", new f.a("cloud_id", "TEXT", true, 0, (String) null, 1));
                hashMap.put("timezone", new f.a("timezone", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("timezone_min", new f.a("timezone_min", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("transcription", new f.a("transcription", "TEXT", true, 0, (String) null, 1));
                hashMap.put("transcription_state", new f.a("transcription_state", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("trans_error_tip", new f.a("trans_error_tip", "TEXT", true, 0, "''", 1));
                hashMap.put("summary_error_tip", new f.a("summary_error_tip", "TEXT", true, 0, "''", 1));
                hashMap.put("summary", new f.a("summary", "TEXT", true, 0, (String) null, 1));
                hashMap.put("data_filetag_id_list", new f.a("data_filetag_id_list", "TEXT", true, 0, (String) null, 1));
                hashMap.put("keywords", new f.a("keywords", "TEXT", true, 0, (String) null, 1));
                hashMap.put("scene", new f.a("scene", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("isNew", new f.a("isNew", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("delete_state", new f.a("delete_state", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("version", new f.a("version", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("last_edit_time", new f.a("last_edit_time", "INTEGER", true, 0, (String) null, 1));
                hashMap.put("has_edit", new f.a("has_edit", "INTEGER", true, 0, (String) null, 1));
                f fVar = new f("record_file_table", hashMap, new HashSet(0), new HashSet(0));
                f a10 = f.a(aVar2, "record_file_table");
                if (!fVar.equals(a10)) {
                    return new h.b(false, "record_file_table(ai.plaud.android.plaud.anew.database.recordfile.RecordFileEntity).\n Expected:\n" + fVar + "\n Found:\n" + a10);
                }
                HashMap hashMap2 = new HashMap(7);
                hashMap2.put("record_file_key", new f.a("record_file_key", "TEXT", true, 1, (String) null, 1));
                hashMap2.put("trans_lan", new f.a("trans_lan", "TEXT", true, 0, (String) null, 1));
                hashMap2.put("need_re_trans", new f.a("need_re_trans", "INTEGER", true, 0, "0", 1));
                hashMap2.put("trans_summary_type", new f.a("trans_summary_type", "TEXT", true, 0, (String) null, 1));
                hashMap2.put("post_id", new f.a("post_id", "INTEGER", true, 0, (String) null, 1));
                hashMap2.put("trans_file_id", new f.a("trans_file_id", "TEXT", true, 0, "''", 1));
                hashMap2.put("summary_file_id", new f.a("summary_file_id", "TEXT", true, 0, "''", 1));
                f fVar2 = new f("transcription_data", hashMap2, new HashSet(0), new HashSet(0));
                f a11 = f.a(aVar2, "transcription_data");
                if (fVar2.equals(a11)) {
                    return new h.b(true, (String) null);
                }
                return new h.b(false, "transcription_data(ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionStateData).\n Expected:\n" + fVar2 + "\n Found:\n" + a11);
            }
        }, "a30cef8a9f41425948d3c5b806eb4f86", "ab67f8f5e4e5c92632016c6f3509f2c4");
        Context context = aVar.f3786b;
        String str = aVar.f3787c;
        if (context != null) {
            return aVar.f3785a.a(new b.C0221b(context, str, hVar, false));
        }
        throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
    }

    public List<n2.b> getAutoMigrations(Map<Class<? extends n2.a>, n2.a> map) {
        return Arrays.asList(new n2.b[]{new PlaudDatabase_AutoMigration_1_2_Impl(), new PlaudDatabase_AutoMigration_2_3_Impl(), new PlaudDatabase_AutoMigration_3_4_Impl(), new PlaudDatabase_AutoMigration_4_5_Impl()});
    }

    public Set<Class<? extends n2.a>> getRequiredAutoMigrationSpecs() {
        return new HashSet();
    }

    public Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
        HashMap hashMap = new HashMap();
        hashMap.put(RecordFilesDao.class, RecordFilesDao_Impl.getRequiredConverters());
        hashMap.put(TranscriptionDataDao.class, TranscriptionDataDao_Impl.getRequiredConverters());
        return hashMap;
    }

    public RecordFilesDao recordFilesDao() {
        RecordFilesDao recordFilesDao;
        if (this._recordFilesDao != null) {
            return this._recordFilesDao;
        }
        synchronized (this) {
            if (this._recordFilesDao == null) {
                this._recordFilesDao = new RecordFilesDao_Impl(this);
            }
            recordFilesDao = this._recordFilesDao;
        }
        return recordFilesDao;
    }

    public TranscriptionDataDao transcriptionDataDao() {
        TranscriptionDataDao transcriptionDataDao;
        if (this._transcriptionDataDao != null) {
            return this._transcriptionDataDao;
        }
        synchronized (this) {
            if (this._transcriptionDataDao == null) {
                this._transcriptionDataDao = new TranscriptionDataDao_Impl(this);
            }
            transcriptionDataDao = this._transcriptionDataDao;
        }
        return transcriptionDataDao;
    }
}
