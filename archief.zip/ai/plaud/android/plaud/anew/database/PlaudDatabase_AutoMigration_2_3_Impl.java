package ai.plaud.android.plaud.anew.database;

import n2.b;
import q2.a;

class PlaudDatabase_AutoMigration_2_3_Impl extends b {
    public PlaudDatabase_AutoMigration_2_3_Impl() {
        super(2, 3);
    }

    public void migrate(a aVar) {
        aVar.I("ALTER TABLE `transcription_data` ADD COLUMN `summary_file_id` TEXT NOT NULL DEFAULT ''");
        aVar.I("ALTER TABLE `transcription_data` ADD COLUMN `trans_file_id` TEXT NOT NULL DEFAULT ''");
        aVar.I("ALTER TABLE `record_file_table` ADD COLUMN `full_name` TEXT NOT NULL DEFAULT ''");
    }
}
