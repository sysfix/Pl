package ai.plaud.android.plaud.anew.database.transcriptiondata;

import ag.c;
import ai.plaud.android.plaud.anew.database.PlaudDatabase;
import java.util.Arrays;
import java.util.List;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.jvm.internal.DefaultConstructorMarker;
import xf.d;
import xf.e;
import xf.g;

/* compiled from: TranscriptionDataRepository.kt */
public final class TranscriptionDataRepository {
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
    /* access modifiers changed from: private */
    public static final d<TranscriptionDataRepository> INSTANCE$delegate = e.a(TranscriptionDataRepository$Companion$INSTANCE$2.INSTANCE);

    /* compiled from: TranscriptionDataRepository.kt */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final TranscriptionDataRepository getINSTANCE() {
            return (TranscriptionDataRepository) TranscriptionDataRepository.INSTANCE$delegate.getValue();
        }
    }

    private TranscriptionDataRepository() {
    }

    public /* synthetic */ TranscriptionDataRepository(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    public final Object getAll(c<? super List<TranscriptionStateData>> cVar) {
        return PlaudDatabase.Companion.transcriptionDataDao().loadAll(cVar);
    }

    public final Object getDataByKey(String str, c<? super List<TranscriptionStateData>> cVar) {
        return PlaudDatabase.Companion.transcriptionDataDao().getDataByKey(str, cVar);
    }

    public final Object insertData(TranscriptionStateData[] transcriptionStateDataArr, c<? super g> cVar) {
        Object insertData = PlaudDatabase.Companion.transcriptionDataDao().insertData((TranscriptionStateData[]) Arrays.copyOf(transcriptionStateDataArr, transcriptionStateDataArr.length), cVar);
        if (insertData == CoroutineSingletons.COROUTINE_SUSPENDED) {
            return insertData;
        }
        return g.f19030a;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0081  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0096  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0022  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object updateNeedReTrans(java.lang.String r7, boolean r8, ag.c<? super xf.g> r9) {
        /*
            r6 = this;
            boolean r0 = r9 instanceof ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateNeedReTrans$1
            if (r0 == 0) goto L_0x0013
            r0 = r9
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateNeedReTrans$1 r0 = (ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateNeedReTrans$1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.label = r1
            goto L_0x0018
        L_0x0013:
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateNeedReTrans$1 r0 = new ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateNeedReTrans$1
            r0.<init>(r6, r9)
        L_0x0018:
            java.lang.Object r9 = r0.result
            kotlin.coroutines.intrinsics.CoroutineSingletons r1 = kotlin.coroutines.intrinsics.CoroutineSingletons.COROUTINE_SUSPENDED
            int r2 = r0.label
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L_0x003c
            if (r2 == r4) goto L_0x0032
            if (r2 != r3) goto L_0x002a
            com.google.android.gms.internal.play_billing.x2.s(r9)
            goto L_0x0093
        L_0x002a:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L_0x0032:
            boolean r8 = r0.Z$0
            java.lang.Object r7 = r0.L$0
            java.lang.String r7 = (java.lang.String) r7
            com.google.android.gms.internal.play_billing.x2.s(r9)
            goto L_0x0078
        L_0x003c:
            com.google.android.gms.internal.play_billing.x2.s(r9)
            ci.a$a r9 = ci.a.f4931a
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r5 = "updateNeedReTrans:["
            r2.append(r5)
            r2.append(r7)
            java.lang.String r5 = "] ["
            r2.append(r5)
            r2.append(r8)
            java.lang.String r5 = "]"
            r2.append(r5)
            java.lang.String r2 = r2.toString()
            r5 = 0
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r9.a(r2, r5)
            ai.plaud.android.plaud.anew.database.PlaudDatabase$Companion r9 = ai.plaud.android.plaud.anew.database.PlaudDatabase.Companion
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao r9 = r9.transcriptionDataDao()
            r0.L$0 = r7
            r0.Z$0 = r8
            r0.label = r4
            java.lang.Object r9 = r9.getDataByKey(r7, r0)
            if (r9 != r1) goto L_0x0078
            return r1
        L_0x0078:
            java.util.List r9 = (java.util.List) r9
            boolean r9 = r9.isEmpty()
            r9 = r9 ^ r4
            if (r9 == 0) goto L_0x0096
            ai.plaud.android.plaud.anew.database.PlaudDatabase$Companion r9 = ai.plaud.android.plaud.anew.database.PlaudDatabase.Companion
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao r9 = r9.transcriptionDataDao()
            r2 = 0
            r0.L$0 = r2
            r0.label = r3
            java.lang.Object r7 = r9.updateNeedReTrans(r7, r8, r0)
            if (r7 != r1) goto L_0x0093
            return r1
        L_0x0093:
            xf.g r7 = xf.g.f19030a
            return r7
        L_0x0096:
            xf.g r7 = xf.g.f19030a
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository.updateNeedReTrans(java.lang.String, boolean, ag.c):java.lang.Object");
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0081  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0096  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0022  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object updatePostId(java.lang.String r7, long r8, ag.c<? super xf.g> r10) {
        /*
            r6 = this;
            boolean r0 = r10 instanceof ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updatePostId$1
            if (r0 == 0) goto L_0x0013
            r0 = r10
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updatePostId$1 r0 = (ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updatePostId$1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.label = r1
            goto L_0x0018
        L_0x0013:
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updatePostId$1 r0 = new ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updatePostId$1
            r0.<init>(r6, r10)
        L_0x0018:
            java.lang.Object r10 = r0.result
            kotlin.coroutines.intrinsics.CoroutineSingletons r1 = kotlin.coroutines.intrinsics.CoroutineSingletons.COROUTINE_SUSPENDED
            int r2 = r0.label
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L_0x003c
            if (r2 == r4) goto L_0x0032
            if (r2 != r3) goto L_0x002a
            com.google.android.gms.internal.play_billing.x2.s(r10)
            goto L_0x0093
        L_0x002a:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L_0x0032:
            long r8 = r0.J$0
            java.lang.Object r7 = r0.L$0
            java.lang.String r7 = (java.lang.String) r7
            com.google.android.gms.internal.play_billing.x2.s(r10)
            goto L_0x0078
        L_0x003c:
            com.google.android.gms.internal.play_billing.x2.s(r10)
            ci.a$a r10 = ci.a.f4931a
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r5 = "updatePostId:["
            r2.append(r5)
            r2.append(r7)
            java.lang.String r5 = "] ["
            r2.append(r5)
            r2.append(r8)
            java.lang.String r5 = "]"
            r2.append(r5)
            java.lang.String r2 = r2.toString()
            r5 = 0
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r10.a(r2, r5)
            ai.plaud.android.plaud.anew.database.PlaudDatabase$Companion r10 = ai.plaud.android.plaud.anew.database.PlaudDatabase.Companion
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao r10 = r10.transcriptionDataDao()
            r0.L$0 = r7
            r0.J$0 = r8
            r0.label = r4
            java.lang.Object r10 = r10.getDataByKey(r7, r0)
            if (r10 != r1) goto L_0x0078
            return r1
        L_0x0078:
            java.util.List r10 = (java.util.List) r10
            boolean r10 = r10.isEmpty()
            r10 = r10 ^ r4
            if (r10 == 0) goto L_0x0096
            ai.plaud.android.plaud.anew.database.PlaudDatabase$Companion r10 = ai.plaud.android.plaud.anew.database.PlaudDatabase.Companion
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao r10 = r10.transcriptionDataDao()
            r2 = 0
            r0.L$0 = r2
            r0.label = r3
            java.lang.Object r7 = r10.updatePostId(r7, r8, r0)
            if (r7 != r1) goto L_0x0093
            return r1
        L_0x0093:
            xf.g r7 = xf.g.f19030a
            return r7
        L_0x0096:
            xf.g r7 = xf.g.f19030a
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository.updatePostId(java.lang.String, long, ag.c):java.lang.Object");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v5, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v2, resolved type: java.lang.String} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x003f  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0087  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0022  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object updateSummaryFileId(java.lang.String r8, java.lang.String r9, ag.c<? super xf.g> r10) {
        /*
            r7 = this;
            boolean r0 = r10 instanceof ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateSummaryFileId$1
            if (r0 == 0) goto L_0x0013
            r0 = r10
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateSummaryFileId$1 r0 = (ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateSummaryFileId$1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.label = r1
            goto L_0x0018
        L_0x0013:
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateSummaryFileId$1 r0 = new ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateSummaryFileId$1
            r0.<init>(r7, r10)
        L_0x0018:
            java.lang.Object r10 = r0.result
            kotlin.coroutines.intrinsics.CoroutineSingletons r1 = kotlin.coroutines.intrinsics.CoroutineSingletons.COROUTINE_SUSPENDED
            int r2 = r0.label
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L_0x003f
            if (r2 == r4) goto L_0x0032
            if (r2 != r3) goto L_0x002a
            com.google.android.gms.internal.play_billing.x2.s(r10)
            goto L_0x0084
        L_0x002a:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L_0x0032:
            java.lang.Object r8 = r0.L$1
            r9 = r8
            java.lang.String r9 = (java.lang.String) r9
            java.lang.Object r8 = r0.L$0
            java.lang.String r8 = (java.lang.String) r8
            com.google.android.gms.internal.play_billing.x2.s(r10)
            goto L_0x0067
        L_0x003f:
            com.google.android.gms.internal.play_billing.x2.s(r10)
            ci.a$a r10 = ci.a.f4931a
            java.lang.String r2 = "updateSummaryFileId:["
            java.lang.String r5 = "] ["
            java.lang.String r6 = "]"
            java.lang.String r2 = c.a.a(r2, r8, r5, r9, r6)
            r5 = 0
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r10.a(r2, r5)
            ai.plaud.android.plaud.anew.database.PlaudDatabase$Companion r10 = ai.plaud.android.plaud.anew.database.PlaudDatabase.Companion
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao r10 = r10.transcriptionDataDao()
            r0.L$0 = r8
            r0.L$1 = r9
            r0.label = r4
            java.lang.Object r10 = r10.getDataByKey(r8, r0)
            if (r10 != r1) goto L_0x0067
            return r1
        L_0x0067:
            java.util.List r10 = (java.util.List) r10
            boolean r10 = r10.isEmpty()
            r10 = r10 ^ r4
            if (r10 == 0) goto L_0x0087
            ai.plaud.android.plaud.anew.database.PlaudDatabase$Companion r10 = ai.plaud.android.plaud.anew.database.PlaudDatabase.Companion
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao r10 = r10.transcriptionDataDao()
            r2 = 0
            r0.L$0 = r2
            r0.L$1 = r2
            r0.label = r3
            java.lang.Object r8 = r10.updateSummaryFileId(r8, r9, r0)
            if (r8 != r1) goto L_0x0084
            return r1
        L_0x0084:
            xf.g r8 = xf.g.f19030a
            return r8
        L_0x0087:
            xf.g r8 = xf.g.f19030a
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository.updateSummaryFileId(java.lang.String, java.lang.String, ag.c):java.lang.Object");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v5, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v2, resolved type: java.lang.String} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x003f  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0087  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0022  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object updateTransFileId(java.lang.String r8, java.lang.String r9, ag.c<? super xf.g> r10) {
        /*
            r7 = this;
            boolean r0 = r10 instanceof ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateTransFileId$1
            if (r0 == 0) goto L_0x0013
            r0 = r10
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateTransFileId$1 r0 = (ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateTransFileId$1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.label = r1
            goto L_0x0018
        L_0x0013:
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateTransFileId$1 r0 = new ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository$updateTransFileId$1
            r0.<init>(r7, r10)
        L_0x0018:
            java.lang.Object r10 = r0.result
            kotlin.coroutines.intrinsics.CoroutineSingletons r1 = kotlin.coroutines.intrinsics.CoroutineSingletons.COROUTINE_SUSPENDED
            int r2 = r0.label
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L_0x003f
            if (r2 == r4) goto L_0x0032
            if (r2 != r3) goto L_0x002a
            com.google.android.gms.internal.play_billing.x2.s(r10)
            goto L_0x0084
        L_0x002a:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L_0x0032:
            java.lang.Object r8 = r0.L$1
            r9 = r8
            java.lang.String r9 = (java.lang.String) r9
            java.lang.Object r8 = r0.L$0
            java.lang.String r8 = (java.lang.String) r8
            com.google.android.gms.internal.play_billing.x2.s(r10)
            goto L_0x0067
        L_0x003f:
            com.google.android.gms.internal.play_billing.x2.s(r10)
            ci.a$a r10 = ci.a.f4931a
            java.lang.String r2 = "updateTransFileId:["
            java.lang.String r5 = "] ["
            java.lang.String r6 = "]"
            java.lang.String r2 = c.a.a(r2, r8, r5, r9, r6)
            r5 = 0
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r10.a(r2, r5)
            ai.plaud.android.plaud.anew.database.PlaudDatabase$Companion r10 = ai.plaud.android.plaud.anew.database.PlaudDatabase.Companion
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao r10 = r10.transcriptionDataDao()
            r0.L$0 = r8
            r0.L$1 = r9
            r0.label = r4
            java.lang.Object r10 = r10.getDataByKey(r8, r0)
            if (r10 != r1) goto L_0x0067
            return r1
        L_0x0067:
            java.util.List r10 = (java.util.List) r10
            boolean r10 = r10.isEmpty()
            r10 = r10 ^ r4
            if (r10 == 0) goto L_0x0087
            ai.plaud.android.plaud.anew.database.PlaudDatabase$Companion r10 = ai.plaud.android.plaud.anew.database.PlaudDatabase.Companion
            ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao r10 = r10.transcriptionDataDao()
            r2 = 0
            r0.L$0 = r2
            r0.L$1 = r2
            r0.label = r3
            java.lang.Object r8 = r10.updateTransFileId(r8, r9, r0)
            if (r8 != r1) goto L_0x0084
            return r1
        L_0x0084:
            xf.g r8 = xf.g.f19030a
            return r8
        L_0x0087:
            xf.g r8 = xf.g.f19030a
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository.updateTransFileId(java.lang.String, java.lang.String, ag.c):java.lang.Object");
    }
}
