package ai.plaud.android.plaud.anew.database.transcriptiondata;

import ag.c;
import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.room.RoomDatabase;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import m2.e;
import m2.f;
import m2.i;
import m2.k;
import o2.b;
import xf.g;

public final class TranscriptionDataDao_Impl implements TranscriptionDataDao {
    /* access modifiers changed from: private */
    public final RoomDatabase __db;
    /* access modifiers changed from: private */
    public final f<TranscriptionStateData> __insertionAdapterOfTranscriptionStateData;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateNeedReTrans;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdatePostId;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateSummaryFileId;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateTransFileId;
    /* access modifiers changed from: private */
    public final e<TranscriptionStateData> __updateAdapterOfTranscriptionStateData;

    public TranscriptionDataDao_Impl(RoomDatabase roomDatabase) {
        this.__db = roomDatabase;
        this.__insertionAdapterOfTranscriptionStateData = new f<TranscriptionStateData>(roomDatabase) {
            public String createQuery() {
                return "INSERT OR REPLACE INTO `transcription_data` (`record_file_key`,`trans_lan`,`need_re_trans`,`trans_summary_type`,`post_id`,`trans_file_id`,`summary_file_id`) VALUES (?,?,?,?,?,?,?)";
            }

            public void bind(q2.e eVar, TranscriptionStateData transcriptionStateData) {
                if (transcriptionStateData.getKey() == null) {
                    eVar.Z(1);
                } else {
                    eVar.J(1, transcriptionStateData.getKey());
                }
                if (transcriptionStateData.getTransLan() == null) {
                    eVar.Z(2);
                } else {
                    eVar.J(2, transcriptionStateData.getTransLan());
                }
                eVar.L0(3, transcriptionStateData.getNeedReTrans() ? 1 : 0);
                if (transcriptionStateData.getTransSummaryType() == null) {
                    eVar.Z(4);
                } else {
                    eVar.J(4, transcriptionStateData.getTransSummaryType());
                }
                eVar.L0(5, transcriptionStateData.getSummaryPostId());
                if (transcriptionStateData.getTransFileId() == null) {
                    eVar.Z(6);
                } else {
                    eVar.J(6, transcriptionStateData.getTransFileId());
                }
                if (transcriptionStateData.getSummaryFileId() == null) {
                    eVar.Z(7);
                } else {
                    eVar.J(7, transcriptionStateData.getSummaryFileId());
                }
            }
        };
        this.__updateAdapterOfTranscriptionStateData = new e<TranscriptionStateData>(roomDatabase) {
            public String createQuery() {
                return "UPDATE OR ABORT `transcription_data` SET `record_file_key` = ?,`trans_lan` = ?,`need_re_trans` = ?,`trans_summary_type` = ?,`post_id` = ?,`trans_file_id` = ?,`summary_file_id` = ? WHERE `record_file_key` = ?";
            }

            public void bind(q2.e eVar, TranscriptionStateData transcriptionStateData) {
                if (transcriptionStateData.getKey() == null) {
                    eVar.Z(1);
                } else {
                    eVar.J(1, transcriptionStateData.getKey());
                }
                if (transcriptionStateData.getTransLan() == null) {
                    eVar.Z(2);
                } else {
                    eVar.J(2, transcriptionStateData.getTransLan());
                }
                eVar.L0(3, transcriptionStateData.getNeedReTrans() ? 1 : 0);
                if (transcriptionStateData.getTransSummaryType() == null) {
                    eVar.Z(4);
                } else {
                    eVar.J(4, transcriptionStateData.getTransSummaryType());
                }
                eVar.L0(5, transcriptionStateData.getSummaryPostId());
                if (transcriptionStateData.getTransFileId() == null) {
                    eVar.Z(6);
                } else {
                    eVar.J(6, transcriptionStateData.getTransFileId());
                }
                if (transcriptionStateData.getSummaryFileId() == null) {
                    eVar.Z(7);
                } else {
                    eVar.J(7, transcriptionStateData.getSummaryFileId());
                }
                if (transcriptionStateData.getKey() == null) {
                    eVar.Z(8);
                } else {
                    eVar.J(8, transcriptionStateData.getKey());
                }
            }
        };
        this.__preparedStmtOfUpdatePostId = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE transcription_data SET post_id = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateNeedReTrans = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE transcription_data SET need_re_trans = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateTransFileId = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE transcription_data SET trans_file_id = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateSummaryFileId = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE transcription_data SET summary_file_id = ? WHERE record_file_key = ?";
            }
        };
    }

    public static List<Class<?>> getRequiredConverters() {
        return Collections.emptyList();
    }

    public Object getDataByKey(String str, c<? super List<TranscriptionStateData>> cVar) {
        final i a10 = i.a("SELECT * FROM transcription_data WHERE record_file_key = ?", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<TranscriptionStateData>>() {
            public List<TranscriptionStateData> call() {
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                Cursor b10 = o2.c.b(TranscriptionDataDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "trans_lan");
                    int a12 = b.a(b10, "need_re_trans");
                    int a13 = b.a(b10, "trans_summary_type");
                    int a14 = b.a(b10, "post_id");
                    int a15 = b.a(b10, "trans_file_id");
                    int a16 = b.a(b10, "summary_file_id");
                    ArrayList arrayList = new ArrayList(b10.getCount());
                    while (b10.moveToNext()) {
                        if (b10.isNull(a10)) {
                            str = null;
                        } else {
                            str = b10.getString(a10);
                        }
                        if (b10.isNull(a11)) {
                            str2 = null;
                        } else {
                            str2 = b10.getString(a11);
                        }
                        boolean z10 = b10.getInt(a12) != 0;
                        if (b10.isNull(a13)) {
                            str3 = null;
                        } else {
                            str3 = b10.getString(a13);
                        }
                        long j10 = b10.getLong(a14);
                        if (b10.isNull(a15)) {
                            str4 = null;
                        } else {
                            str4 = b10.getString(a15);
                        }
                        if (b10.isNull(a16)) {
                            str5 = null;
                        } else {
                            str5 = b10.getString(a16);
                        }
                        arrayList.add(new TranscriptionStateData(str, str2, z10, str3, j10, str4, str5));
                    }
                    return arrayList;
                } finally {
                    b10.close();
                    a10.b();
                }
            }
        }, cVar);
    }

    public Object insertData(final TranscriptionStateData[] transcriptionStateDataArr, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                TranscriptionDataDao_Impl.this.__db.beginTransaction();
                try {
                    TranscriptionDataDao_Impl.this.__insertionAdapterOfTranscriptionStateData.insert((T[]) transcriptionStateDataArr);
                    TranscriptionDataDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    TranscriptionDataDao_Impl.this.__db.endTransaction();
                }
            }
        }, cVar);
    }

    public Object loadAll(c<? super List<TranscriptionStateData>> cVar) {
        final i a10 = i.a("SELECT * FROM transcription_data", 0);
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<TranscriptionStateData>>() {
            public List<TranscriptionStateData> call() {
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                Cursor b10 = o2.c.b(TranscriptionDataDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "trans_lan");
                    int a12 = b.a(b10, "need_re_trans");
                    int a13 = b.a(b10, "trans_summary_type");
                    int a14 = b.a(b10, "post_id");
                    int a15 = b.a(b10, "trans_file_id");
                    int a16 = b.a(b10, "summary_file_id");
                    ArrayList arrayList = new ArrayList(b10.getCount());
                    while (b10.moveToNext()) {
                        if (b10.isNull(a10)) {
                            str = null;
                        } else {
                            str = b10.getString(a10);
                        }
                        if (b10.isNull(a11)) {
                            str2 = null;
                        } else {
                            str2 = b10.getString(a11);
                        }
                        boolean z10 = b10.getInt(a12) != 0;
                        if (b10.isNull(a13)) {
                            str3 = null;
                        } else {
                            str3 = b10.getString(a13);
                        }
                        long j10 = b10.getLong(a14);
                        if (b10.isNull(a15)) {
                            str4 = null;
                        } else {
                            str4 = b10.getString(a15);
                        }
                        if (b10.isNull(a16)) {
                            str5 = null;
                        } else {
                            str5 = b10.getString(a16);
                        }
                        arrayList.add(new TranscriptionStateData(str, str2, z10, str3, j10, str4, str5));
                    }
                    return arrayList;
                } finally {
                    b10.close();
                    a10.b();
                }
            }
        }, cVar);
    }

    public Object updateData(final TranscriptionStateData[] transcriptionStateDataArr, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                TranscriptionDataDao_Impl.this.__db.beginTransaction();
                try {
                    TranscriptionDataDao_Impl.this.__updateAdapterOfTranscriptionStateData.handleMultiple((T[]) transcriptionStateDataArr);
                    TranscriptionDataDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    TranscriptionDataDao_Impl.this.__db.endTransaction();
                }
            }
        }, cVar);
    }

    public Object updateNeedReTrans(final String str, final boolean z10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = TranscriptionDataDao_Impl.this.__preparedStmtOfUpdateNeedReTrans.acquire();
                acquire.L0(1, z10 ? 1 : 0);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                TranscriptionDataDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    TranscriptionDataDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    TranscriptionDataDao_Impl.this.__db.endTransaction();
                    TranscriptionDataDao_Impl.this.__preparedStmtOfUpdateNeedReTrans.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updatePostId(final String str, final long j10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = TranscriptionDataDao_Impl.this.__preparedStmtOfUpdatePostId.acquire();
                acquire.L0(1, j10);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                TranscriptionDataDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    TranscriptionDataDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    TranscriptionDataDao_Impl.this.__db.endTransaction();
                    TranscriptionDataDao_Impl.this.__preparedStmtOfUpdatePostId.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateSummaryFileId(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = TranscriptionDataDao_Impl.this.__preparedStmtOfUpdateSummaryFileId.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                TranscriptionDataDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    TranscriptionDataDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    TranscriptionDataDao_Impl.this.__db.endTransaction();
                    TranscriptionDataDao_Impl.this.__preparedStmtOfUpdateSummaryFileId.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateTransFileId(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = TranscriptionDataDao_Impl.this.__preparedStmtOfUpdateTransFileId.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                TranscriptionDataDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    TranscriptionDataDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    TranscriptionDataDao_Impl.this.__db.endTransaction();
                    TranscriptionDataDao_Impl.this.__preparedStmtOfUpdateTransFileId.release(acquire);
                }
            }
        }, cVar);
    }
}
