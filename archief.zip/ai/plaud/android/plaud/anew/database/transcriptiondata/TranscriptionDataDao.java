package ai.plaud.android.plaud.anew.database.transcriptiondata;

import ag.c;
import java.util.List;
import xf.g;

/* compiled from: TranscriptionDataDao.kt */
public interface TranscriptionDataDao {
    Object getDataByKey(String str, c<? super List<TranscriptionStateData>> cVar);

    Object insertData(TranscriptionStateData[] transcriptionStateDataArr, c<? super g> cVar);

    Object loadAll(c<? super List<TranscriptionStateData>> cVar);

    Object updateData(TranscriptionStateData[] transcriptionStateDataArr, c<? super g> cVar);

    Object updateNeedReTrans(String str, boolean z10, c<? super g> cVar);

    Object updatePostId(String str, long j10, c<? super g> cVar);

    Object updateSummaryFileId(String str, String str2, c<? super g> cVar);

    Object updateTransFileId(String str, String str2, c<? super g> cVar);
}
