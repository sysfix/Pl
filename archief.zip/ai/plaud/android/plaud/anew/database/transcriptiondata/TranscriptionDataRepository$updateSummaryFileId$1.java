package ai.plaud.android.plaud.anew.database.transcriptiondata;

import ag.c;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.a;

@a(c = "ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository", f = "TranscriptionDataRepository.kt", l = {42, 44}, m = "updateSummaryFileId")
/* compiled from: TranscriptionDataRepository.kt */
public final class TranscriptionDataRepository$updateSummaryFileId$1 extends ContinuationImpl {
    public Object L$0;
    public Object L$1;
    public int label;
    public /* synthetic */ Object result;
    public final /* synthetic */ TranscriptionDataRepository this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public TranscriptionDataRepository$updateSummaryFileId$1(TranscriptionDataRepository transcriptionDataRepository, c<? super TranscriptionDataRepository$updateSummaryFileId$1> cVar) {
        super(cVar);
        this.this$0 = transcriptionDataRepository;
    }

    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= CellBase.GROUP_ID_SYSTEM_MESSAGE;
        return this.this$0.updateSummaryFileId((String) null, (String) null, this);
    }
}
