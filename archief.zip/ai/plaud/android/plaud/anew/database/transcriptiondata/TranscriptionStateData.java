package ai.plaud.android.plaud.anew.database.transcriptiondata;

import android.os.Parcel;
import android.os.Parcelable;
import c.b;
import c.e;
import kotlin.jvm.internal.DefaultConstructorMarker;
import okhttp3.HttpUrl;
import rg.d0;

/* compiled from: TranscriptionStateData.kt */
public final class TranscriptionStateData implements Parcelable {
    public static final Parcelable.Creator<TranscriptionStateData> CREATOR = new Creator();
    private String key;
    private boolean needReTrans;
    private final String summaryFileId;
    private long summaryPostId;
    private final String transFileId;
    private String transLan;
    private String transSummaryType;

    /* compiled from: TranscriptionStateData.kt */
    public static final class Creator implements Parcelable.Creator<TranscriptionStateData> {
        public final TranscriptionStateData createFromParcel(Parcel parcel) {
            d0.g(parcel, "parcel");
            return new TranscriptionStateData(parcel.readString(), parcel.readString(), parcel.readInt() != 0, parcel.readString(), parcel.readLong(), parcel.readString(), parcel.readString());
        }

        public final TranscriptionStateData[] newArray(int i10) {
            return new TranscriptionStateData[i10];
        }
    }

    public TranscriptionStateData(String str, String str2, boolean z10, String str3, long j10, String str4, String str5) {
        d0.g(str, "key");
        d0.g(str2, "transLan");
        d0.g(str3, "transSummaryType");
        d0.g(str4, "transFileId");
        d0.g(str5, "summaryFileId");
        this.key = str;
        this.transLan = str2;
        this.needReTrans = z10;
        this.transSummaryType = str3;
        this.summaryPostId = j10;
        this.transFileId = str4;
        this.summaryFileId = str5;
    }

    public static /* synthetic */ TranscriptionStateData copy$default(TranscriptionStateData transcriptionStateData, String str, String str2, boolean z10, String str3, long j10, String str4, String str5, int i10, Object obj) {
        TranscriptionStateData transcriptionStateData2 = transcriptionStateData;
        return transcriptionStateData.copy((i10 & 1) != 0 ? transcriptionStateData2.key : str, (i10 & 2) != 0 ? transcriptionStateData2.transLan : str2, (i10 & 4) != 0 ? transcriptionStateData2.needReTrans : z10, (i10 & 8) != 0 ? transcriptionStateData2.transSummaryType : str3, (i10 & 16) != 0 ? transcriptionStateData2.summaryPostId : j10, (i10 & 32) != 0 ? transcriptionStateData2.transFileId : str4, (i10 & 64) != 0 ? transcriptionStateData2.summaryFileId : str5);
    }

    public final String component1() {
        return this.key;
    }

    public final String component2() {
        return this.transLan;
    }

    public final boolean component3() {
        return this.needReTrans;
    }

    public final String component4() {
        return this.transSummaryType;
    }

    public final long component5() {
        return this.summaryPostId;
    }

    public final String component6() {
        return this.transFileId;
    }

    public final String component7() {
        return this.summaryFileId;
    }

    public final TranscriptionStateData copy(String str, String str2, boolean z10, String str3, long j10, String str4, String str5) {
        d0.g(str, "key");
        d0.g(str2, "transLan");
        d0.g(str3, "transSummaryType");
        String str6 = str4;
        d0.g(str6, "transFileId");
        String str7 = str5;
        d0.g(str7, "summaryFileId");
        return new TranscriptionStateData(str, str2, z10, str3, j10, str6, str7);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TranscriptionStateData)) {
            return false;
        }
        TranscriptionStateData transcriptionStateData = (TranscriptionStateData) obj;
        return d0.b(this.key, transcriptionStateData.key) && d0.b(this.transLan, transcriptionStateData.transLan) && this.needReTrans == transcriptionStateData.needReTrans && d0.b(this.transSummaryType, transcriptionStateData.transSummaryType) && this.summaryPostId == transcriptionStateData.summaryPostId && d0.b(this.transFileId, transcriptionStateData.transFileId) && d0.b(this.summaryFileId, transcriptionStateData.summaryFileId);
    }

    public final String getKey() {
        return this.key;
    }

    public final boolean getNeedReTrans() {
        return this.needReTrans;
    }

    public final String getSummaryFileId() {
        return this.summaryFileId;
    }

    public final long getSummaryPostId() {
        return this.summaryPostId;
    }

    public final String getTransFileId() {
        return this.transFileId;
    }

    public final String getTransLan() {
        return this.transLan;
    }

    public final String getTransSummaryType() {
        return this.transSummaryType;
    }

    public int hashCode() {
        int a10 = b.a(this.transLan, this.key.hashCode() * 31, 31);
        boolean z10 = this.needReTrans;
        if (z10) {
            z10 = true;
        }
        int a11 = b.a(this.transSummaryType, (a10 + (z10 ? 1 : 0)) * 31, 31);
        long j10 = this.summaryPostId;
        return this.summaryFileId.hashCode() + b.a(this.transFileId, (a11 + ((int) (j10 ^ (j10 >>> 32)))) * 31, 31);
    }

    public final void setKey(String str) {
        d0.g(str, "<set-?>");
        this.key = str;
    }

    public final void setNeedReTrans(boolean z10) {
        this.needReTrans = z10;
    }

    public final void setSummaryPostId(long j10) {
        this.summaryPostId = j10;
    }

    public final void setTransLan(String str) {
        d0.g(str, "<set-?>");
        this.transLan = str;
    }

    public final void setTransSummaryType(String str) {
        d0.g(str, "<set-?>");
        this.transSummaryType = str;
    }

    public String toString() {
        String str = this.key;
        String str2 = this.transLan;
        boolean z10 = this.needReTrans;
        String str3 = this.transSummaryType;
        long j10 = this.summaryPostId;
        String str4 = this.transFileId;
        String str5 = this.summaryFileId;
        StringBuilder a10 = e.a("TranscriptionStateData(key=", str, ", transLan=", str2, ", needReTrans=");
        a10.append(z10);
        a10.append(", transSummaryType=");
        a10.append(str3);
        a10.append(", summaryPostId=");
        a10.append(j10);
        a10.append(", transFileId=");
        a10.append(str4);
        a10.append(", summaryFileId=");
        a10.append(str5);
        a10.append(")");
        return a10.toString();
    }

    public void writeToParcel(Parcel parcel, int i10) {
        d0.g(parcel, "out");
        parcel.writeString(this.key);
        parcel.writeString(this.transLan);
        parcel.writeInt(this.needReTrans ? 1 : 0);
        parcel.writeString(this.transSummaryType);
        parcel.writeLong(this.summaryPostId);
        parcel.writeString(this.transFileId);
        parcel.writeString(this.summaryFileId);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ TranscriptionStateData(String str, String str2, boolean z10, String str3, long j10, String str4, String str5, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, z10, str3, j10, (i10 & 32) != 0 ? HttpUrl.FRAGMENT_ENCODE_SET : str4, (i10 & 64) != 0 ? HttpUrl.FRAGMENT_ENCODE_SET : str5);
    }
}
