package ai.plaud.android.plaud.anew.database.transcriptiondata;

import gg.a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Lambda;

/* compiled from: TranscriptionDataRepository.kt */
public final class TranscriptionDataRepository$Companion$INSTANCE$2 extends Lambda implements a<TranscriptionDataRepository> {
    public static final TranscriptionDataRepository$Companion$INSTANCE$2 INSTANCE = new TranscriptionDataRepository$Companion$INSTANCE$2();

    public TranscriptionDataRepository$Companion$INSTANCE$2() {
        super(0);
    }

    public final TranscriptionDataRepository invoke() {
        return new TranscriptionDataRepository((DefaultConstructorMarker) null);
    }
}
