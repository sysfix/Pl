package ai.plaud.android.plaud.anew.database;

import n2.b;
import q2.a;

class PlaudDatabase_AutoMigration_4_5_Impl extends b {
    public PlaudDatabase_AutoMigration_4_5_Impl() {
        super(4, 5);
    }

    public void migrate(a aVar) {
        aVar.I("ALTER TABLE `record_file_table` ADD COLUMN `summary_error_tip` TEXT NOT NULL DEFAULT ''");
        aVar.I("ALTER TABLE `record_file_table` ADD COLUMN `trans_error_tip` TEXT NOT NULL DEFAULT ''");
    }
}
