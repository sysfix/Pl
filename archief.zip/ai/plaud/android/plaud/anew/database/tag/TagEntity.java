package ai.plaud.android.plaud.anew.database.tag;

import android.os.Parcel;
import android.os.Parcelable;
import c.b;
import c.d;
import c.e;
import kotlin.jvm.internal.DefaultConstructorMarker;
import rg.d0;

/* compiled from: TagEntity.kt */
public final class TagEntity implements Parcelable {
    public static final Parcelable.Creator<TagEntity> CREATOR = new Creator();
    private String color;
    private String icon;

    /* renamed from: id  reason: collision with root package name */
    private String f900id;
    private String name;
    private String type;

    /* compiled from: TagEntity.kt */
    public static final class Creator implements Parcelable.Creator<TagEntity> {
        public final TagEntity createFromParcel(Parcel parcel) {
            d0.g(parcel, "parcel");
            return new TagEntity(parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readString());
        }

        public final TagEntity[] newArray(int i10) {
            return new TagEntity[i10];
        }
    }

    public TagEntity() {
        this((String) null, (String) null, (String) null, (String) null, (String) null, 31, (DefaultConstructorMarker) null);
    }

    public TagEntity(String str, String str2, String str3, String str4, String str5) {
        d0.g(str, "id");
        d0.g(str2, "name");
        d0.g(str3, "color");
        this.f900id = str;
        this.name = str2;
        this.color = str3;
        this.icon = str4;
        this.type = str5;
    }

    public static /* synthetic */ TagEntity copy$default(TagEntity tagEntity, String str, String str2, String str3, String str4, String str5, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = tagEntity.f900id;
        }
        if ((i10 & 2) != 0) {
            str2 = tagEntity.name;
        }
        String str6 = str2;
        if ((i10 & 4) != 0) {
            str3 = tagEntity.color;
        }
        String str7 = str3;
        if ((i10 & 8) != 0) {
            str4 = tagEntity.icon;
        }
        String str8 = str4;
        if ((i10 & 16) != 0) {
            str5 = tagEntity.type;
        }
        return tagEntity.copy(str, str6, str7, str8, str5);
    }

    public final String component1() {
        return this.f900id;
    }

    public final String component2() {
        return this.name;
    }

    public final String component3() {
        return this.color;
    }

    public final String component4() {
        return this.icon;
    }

    public final String component5() {
        return this.type;
    }

    public final TagEntity copy(String str, String str2, String str3, String str4, String str5) {
        d0.g(str, "id");
        d0.g(str2, "name");
        d0.g(str3, "color");
        return new TagEntity(str, str2, str3, str4, str5);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TagEntity)) {
            return false;
        }
        TagEntity tagEntity = (TagEntity) obj;
        return d0.b(this.f900id, tagEntity.f900id) && d0.b(this.name, tagEntity.name) && d0.b(this.color, tagEntity.color) && d0.b(this.icon, tagEntity.icon) && d0.b(this.type, tagEntity.type);
    }

    public final String getColor() {
        return this.color;
    }

    public final String getIcon() {
        return this.icon;
    }

    public final String getId() {
        return this.f900id;
    }

    public final String getName() {
        return this.name;
    }

    public final String getType() {
        return this.type;
    }

    public int hashCode() {
        int a10 = b.a(this.color, b.a(this.name, this.f900id.hashCode() * 31, 31), 31);
        String str = this.icon;
        int i10 = 0;
        int hashCode = (a10 + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.type;
        if (str2 != null) {
            i10 = str2.hashCode();
        }
        return hashCode + i10;
    }

    public final void setColor(String str) {
        d0.g(str, "<set-?>");
        this.color = str;
    }

    public final void setIcon(String str) {
        this.icon = str;
    }

    public final void setId(String str) {
        d0.g(str, "<set-?>");
        this.f900id = str;
    }

    public final void setName(String str) {
        d0.g(str, "<set-?>");
        this.name = str;
    }

    public final void setType(String str) {
        this.type = str;
    }

    public String toString() {
        String str = this.f900id;
        String str2 = this.name;
        String str3 = this.color;
        String str4 = this.icon;
        String str5 = this.type;
        StringBuilder a10 = e.a("TagEntity(id=", str, ", name=", str2, ", color=");
        a10.append(str3);
        a10.append(", icon=");
        a10.append(str4);
        a10.append(", type=");
        return d.a(a10, str5, ")");
    }

    public void writeToParcel(Parcel parcel, int i10) {
        d0.g(parcel, "out");
        parcel.writeString(this.f900id);
        parcel.writeString(this.name);
        parcel.writeString(this.color);
        parcel.writeString(this.icon);
        parcel.writeString(this.type);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public /* synthetic */ TagEntity(java.lang.String r4, java.lang.String r5, java.lang.String r6, java.lang.String r7, java.lang.String r8, int r9, kotlin.jvm.internal.DefaultConstructorMarker r10) {
        /*
            r3 = this;
            r10 = r9 & 1
            java.lang.String r0 = ""
            if (r10 == 0) goto L_0x0008
            r10 = r0
            goto L_0x0009
        L_0x0008:
            r10 = r4
        L_0x0009:
            r4 = r9 & 2
            if (r4 == 0) goto L_0x000e
            goto L_0x000f
        L_0x000e:
            r0 = r5
        L_0x000f:
            r4 = r9 & 4
            if (r4 == 0) goto L_0x0015
            java.lang.String r6 = "#175cd3"
        L_0x0015:
            r1 = r6
            r4 = r9 & 8
            r5 = 0
            if (r4 == 0) goto L_0x001d
            r2 = r5
            goto L_0x001e
        L_0x001d:
            r2 = r7
        L_0x001e:
            r4 = r9 & 16
            if (r4 == 0) goto L_0x0024
            r9 = r5
            goto L_0x0025
        L_0x0024:
            r9 = r8
        L_0x0025:
            r4 = r3
            r5 = r10
            r6 = r0
            r7 = r1
            r8 = r2
            r4.<init>(r5, r6, r7, r8, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.database.tag.TagEntity.<init>(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, kotlin.jvm.internal.DefaultConstructorMarker):void");
    }
}
