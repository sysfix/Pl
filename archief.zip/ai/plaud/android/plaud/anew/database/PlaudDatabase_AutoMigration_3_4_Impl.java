package ai.plaud.android.plaud.anew.database;

import n2.b;
import q2.a;

class PlaudDatabase_AutoMigration_3_4_Impl extends b {
    public PlaudDatabase_AutoMigration_3_4_Impl() {
        super(3, 4);
    }

    public void migrate(a aVar) {
        aVar.I("ALTER TABLE `transcription_data` ADD COLUMN `need_re_trans` INTEGER NOT NULL DEFAULT 0");
        aVar.I("ALTER TABLE `record_file_table` ADD COLUMN `file_md5` TEXT NOT NULL DEFAULT ''");
    }
}
