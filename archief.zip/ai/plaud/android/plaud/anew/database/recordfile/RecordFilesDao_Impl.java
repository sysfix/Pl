package ai.plaud.android.plaud.anew.database.recordfile;

import ag.c;
import ai.plaud.android.plaud.anew.api.bean.TranscriptionData;
import ai.plaud.android.plaud.anew.database.recordfile.RecordFileEntity;
import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.lifecycle.LiveData;
import androidx.room.RoomDatabase;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import m2.e;
import m2.f;
import m2.i;
import m2.k;
import o2.b;
import o2.d;
import xf.g;

public final class RecordFilesDao_Impl implements RecordFilesDao {
    /* access modifiers changed from: private */
    public final RoomDatabase __db;
    /* access modifiers changed from: private */
    public final e<RecordFileEntity> __deletionAdapterOfRecordFileEntity;
    /* access modifiers changed from: private */
    public final f<RecordFileEntity> __insertionAdapterOfRecordFileEntity;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfDeleteAllRecordFiles;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfDeleteAllUserRecordFiles;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateCloudHasRaw;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateCloudId;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateDeleteState;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateFileMD5;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateFileName;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateFilePath;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateFullName;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateHasEdit;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateHasTransFile;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateIsExist;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateIsNew;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateKeywords;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateLastEditTime;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateSummary;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateSummaryErrorTip;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateTagIdList;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateTransContent;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateTransErrorTip;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateTransState;
    /* access modifiers changed from: private */
    public final k __preparedStmtOfUpdateVersion;
    /* access modifiers changed from: private */
    public final RecordFileEntity.StringListConverter __stringListConverter = new RecordFileEntity.StringListConverter();
    /* access modifiers changed from: private */
    public final RecordFileEntity.TranscriptionDataListConverter __transcriptionDataListConverter = new RecordFileEntity.TranscriptionDataListConverter();
    /* access modifiers changed from: private */
    public final e<RecordFileEntity> __updateAdapterOfRecordFileEntity;

    public RecordFilesDao_Impl(RoomDatabase roomDatabase) {
        this.__db = roomDatabase;
        this.__insertionAdapterOfRecordFileEntity = new f<RecordFileEntity>(roomDatabase) {
            public String createQuery() {
                return "INSERT OR REPLACE INTO `record_file_table` (`record_file_key`,`session_id`,`serial_number`,`is_guide`,`cloud_has_trans_file`,`duration`,`file_size`,`audio_channel_count`,`file_name`,`full_name`,`file_md5`,`file_path`,`file_opus_path`,`audio_db_path`,`is_existing`,`cloud_id`,`timezone`,`timezone_min`,`transcription`,`transcription_state`,`trans_error_tip`,`summary_error_tip`,`summary`,`data_filetag_id_list`,`keywords`,`scene`,`isNew`,`delete_state`,`version`,`last_edit_time`,`has_edit`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            }

            public void bind(q2.e eVar, RecordFileEntity recordFileEntity) {
                if (recordFileEntity.getKey() == null) {
                    eVar.Z(1);
                } else {
                    eVar.J(1, recordFileEntity.getKey());
                }
                eVar.L0(2, recordFileEntity.getSessionId());
                if (recordFileEntity.getSn() == null) {
                    eVar.Z(3);
                } else {
                    eVar.J(3, recordFileEntity.getSn());
                }
                eVar.L0(4, recordFileEntity.isGuide() ? 1 : 0);
                eVar.L0(5, recordFileEntity.getCloudHasTransFile() ? 1 : 0);
                eVar.L0(6, recordFileEntity.getDuration());
                eVar.L0(7, recordFileEntity.getFileSize());
                eVar.L0(8, (long) recordFileEntity.getAudioChannelCount());
                if (recordFileEntity.getFileName() == null) {
                    eVar.Z(9);
                } else {
                    eVar.J(9, recordFileEntity.getFileName());
                }
                if (recordFileEntity.getFullName() == null) {
                    eVar.Z(10);
                } else {
                    eVar.J(10, recordFileEntity.getFullName());
                }
                if (recordFileEntity.getFileMD5() == null) {
                    eVar.Z(11);
                } else {
                    eVar.J(11, recordFileEntity.getFileMD5());
                }
                if (recordFileEntity.getFilePath() == null) {
                    eVar.Z(12);
                } else {
                    eVar.J(12, recordFileEntity.getFilePath());
                }
                if (recordFileEntity.getOpusPath() == null) {
                    eVar.Z(13);
                } else {
                    eVar.J(13, recordFileEntity.getOpusPath());
                }
                if (recordFileEntity.getAudioDbPath() == null) {
                    eVar.Z(14);
                } else {
                    eVar.J(14, recordFileEntity.getAudioDbPath());
                }
                eVar.L0(15, recordFileEntity.isExisting() ? 1 : 0);
                if (recordFileEntity.getCloudId() == null) {
                    eVar.Z(16);
                } else {
                    eVar.J(16, recordFileEntity.getCloudId());
                }
                eVar.L0(17, (long) recordFileEntity.getTimeZone());
                eVar.L0(18, (long) recordFileEntity.getTimezoneMin());
                String fromList = RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromList(recordFileEntity.getTranscription());
                if (fromList == null) {
                    eVar.Z(19);
                } else {
                    eVar.J(19, fromList);
                }
                eVar.L0(20, (long) recordFileEntity.getTranscriptionState());
                if (recordFileEntity.getTranscriptionErrorTip() == null) {
                    eVar.Z(21);
                } else {
                    eVar.J(21, recordFileEntity.getTranscriptionErrorTip());
                }
                if (recordFileEntity.getSummaryErrorTip() == null) {
                    eVar.Z(22);
                } else {
                    eVar.J(22, recordFileEntity.getSummaryErrorTip());
                }
                if (recordFileEntity.getSummary() == null) {
                    eVar.Z(23);
                } else {
                    eVar.J(23, recordFileEntity.getSummary());
                }
                String fromList2 = RecordFilesDao_Impl.this.__stringListConverter.fromList(recordFileEntity.getTagIdList());
                if (fromList2 == null) {
                    eVar.Z(24);
                } else {
                    eVar.J(24, fromList2);
                }
                String fromList3 = RecordFilesDao_Impl.this.__stringListConverter.fromList(recordFileEntity.getKeywords());
                if (fromList3 == null) {
                    eVar.Z(25);
                } else {
                    eVar.J(25, fromList3);
                }
                eVar.L0(26, (long) recordFileEntity.getScene());
                eVar.L0(27, recordFileEntity.isNew() ? 1 : 0);
                eVar.L0(28, (long) recordFileEntity.getDeleteState());
                eVar.L0(29, recordFileEntity.getVersion());
                eVar.L0(30, recordFileEntity.getLastEditTime());
                eVar.L0(31, recordFileEntity.getHasEdit() ? 1 : 0);
            }
        };
        this.__deletionAdapterOfRecordFileEntity = new e<RecordFileEntity>(roomDatabase) {
            public String createQuery() {
                return "DELETE FROM `record_file_table` WHERE `record_file_key` = ?";
            }

            public void bind(q2.e eVar, RecordFileEntity recordFileEntity) {
                if (recordFileEntity.getKey() == null) {
                    eVar.Z(1);
                } else {
                    eVar.J(1, recordFileEntity.getKey());
                }
            }
        };
        this.__updateAdapterOfRecordFileEntity = new e<RecordFileEntity>(roomDatabase) {
            public String createQuery() {
                return "UPDATE OR ABORT `record_file_table` SET `record_file_key` = ?,`session_id` = ?,`serial_number` = ?,`is_guide` = ?,`cloud_has_trans_file` = ?,`duration` = ?,`file_size` = ?,`audio_channel_count` = ?,`file_name` = ?,`full_name` = ?,`file_md5` = ?,`file_path` = ?,`file_opus_path` = ?,`audio_db_path` = ?,`is_existing` = ?,`cloud_id` = ?,`timezone` = ?,`timezone_min` = ?,`transcription` = ?,`transcription_state` = ?,`trans_error_tip` = ?,`summary_error_tip` = ?,`summary` = ?,`data_filetag_id_list` = ?,`keywords` = ?,`scene` = ?,`isNew` = ?,`delete_state` = ?,`version` = ?,`last_edit_time` = ?,`has_edit` = ? WHERE `record_file_key` = ?";
            }

            public void bind(q2.e eVar, RecordFileEntity recordFileEntity) {
                if (recordFileEntity.getKey() == null) {
                    eVar.Z(1);
                } else {
                    eVar.J(1, recordFileEntity.getKey());
                }
                eVar.L0(2, recordFileEntity.getSessionId());
                if (recordFileEntity.getSn() == null) {
                    eVar.Z(3);
                } else {
                    eVar.J(3, recordFileEntity.getSn());
                }
                eVar.L0(4, recordFileEntity.isGuide() ? 1 : 0);
                eVar.L0(5, recordFileEntity.getCloudHasTransFile() ? 1 : 0);
                eVar.L0(6, recordFileEntity.getDuration());
                eVar.L0(7, recordFileEntity.getFileSize());
                eVar.L0(8, (long) recordFileEntity.getAudioChannelCount());
                if (recordFileEntity.getFileName() == null) {
                    eVar.Z(9);
                } else {
                    eVar.J(9, recordFileEntity.getFileName());
                }
                if (recordFileEntity.getFullName() == null) {
                    eVar.Z(10);
                } else {
                    eVar.J(10, recordFileEntity.getFullName());
                }
                if (recordFileEntity.getFileMD5() == null) {
                    eVar.Z(11);
                } else {
                    eVar.J(11, recordFileEntity.getFileMD5());
                }
                if (recordFileEntity.getFilePath() == null) {
                    eVar.Z(12);
                } else {
                    eVar.J(12, recordFileEntity.getFilePath());
                }
                if (recordFileEntity.getOpusPath() == null) {
                    eVar.Z(13);
                } else {
                    eVar.J(13, recordFileEntity.getOpusPath());
                }
                if (recordFileEntity.getAudioDbPath() == null) {
                    eVar.Z(14);
                } else {
                    eVar.J(14, recordFileEntity.getAudioDbPath());
                }
                eVar.L0(15, recordFileEntity.isExisting() ? 1 : 0);
                if (recordFileEntity.getCloudId() == null) {
                    eVar.Z(16);
                } else {
                    eVar.J(16, recordFileEntity.getCloudId());
                }
                eVar.L0(17, (long) recordFileEntity.getTimeZone());
                eVar.L0(18, (long) recordFileEntity.getTimezoneMin());
                String fromList = RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromList(recordFileEntity.getTranscription());
                if (fromList == null) {
                    eVar.Z(19);
                } else {
                    eVar.J(19, fromList);
                }
                eVar.L0(20, (long) recordFileEntity.getTranscriptionState());
                if (recordFileEntity.getTranscriptionErrorTip() == null) {
                    eVar.Z(21);
                } else {
                    eVar.J(21, recordFileEntity.getTranscriptionErrorTip());
                }
                if (recordFileEntity.getSummaryErrorTip() == null) {
                    eVar.Z(22);
                } else {
                    eVar.J(22, recordFileEntity.getSummaryErrorTip());
                }
                if (recordFileEntity.getSummary() == null) {
                    eVar.Z(23);
                } else {
                    eVar.J(23, recordFileEntity.getSummary());
                }
                String fromList2 = RecordFilesDao_Impl.this.__stringListConverter.fromList(recordFileEntity.getTagIdList());
                if (fromList2 == null) {
                    eVar.Z(24);
                } else {
                    eVar.J(24, fromList2);
                }
                String fromList3 = RecordFilesDao_Impl.this.__stringListConverter.fromList(recordFileEntity.getKeywords());
                if (fromList3 == null) {
                    eVar.Z(25);
                } else {
                    eVar.J(25, fromList3);
                }
                eVar.L0(26, (long) recordFileEntity.getScene());
                eVar.L0(27, recordFileEntity.isNew() ? 1 : 0);
                eVar.L0(28, (long) recordFileEntity.getDeleteState());
                eVar.L0(29, recordFileEntity.getVersion());
                eVar.L0(30, recordFileEntity.getLastEditTime());
                eVar.L0(31, recordFileEntity.getHasEdit() ? 1 : 0);
                if (recordFileEntity.getKey() == null) {
                    eVar.Z(32);
                } else {
                    eVar.J(32, recordFileEntity.getKey());
                }
            }
        };
        this.__preparedStmtOfUpdateTransContent = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET transcription = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateTransErrorTip = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET trans_error_tip = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateSummaryErrorTip = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET summary_error_tip = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateIsExist = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET is_existing = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateKeywords = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET keywords = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateDeleteState = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET delete_state = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateSummary = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET summary = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateTagIdList = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET data_filetag_id_list = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateFileName = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET file_name = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateFullName = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET full_name = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateFileMD5 = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET file_md5 = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateFilePath = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET file_path = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateTransState = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET transcription_state = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateVersion = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET version = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateHasEdit = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET has_edit = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateLastEditTime = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET last_edit_time = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateCloudHasRaw = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET cloud_has_trans_file = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateCloudId = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET cloud_id = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateHasTransFile = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET cloud_has_trans_file = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfUpdateIsNew = new k(roomDatabase) {
            public String createQuery() {
                return "UPDATE record_file_table SET isNew = ? WHERE record_file_key = ?";
            }
        };
        this.__preparedStmtOfDeleteAllRecordFiles = new k(roomDatabase) {
            public String createQuery() {
                return "DELETE FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND record_file_key=?";
            }
        };
        this.__preparedStmtOfDeleteAllUserRecordFiles = new k(roomDatabase) {
            public String createQuery() {
                return "DELETE FROM record_file_table WHERE file_path LIKE '%' || ? || '%'";
            }
        };
    }

    public static List<Class<?>> getRequiredConverters() {
        return Collections.emptyList();
    }

    public Object deleteAllRecordFiles(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfDeleteAllRecordFiles.acquire();
                String str = str;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str2;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfDeleteAllRecordFiles.release(acquire);
                }
            }
        }, cVar);
    }

    public Object deleteAllUserRecordFiles(final String str, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfDeleteAllUserRecordFiles.acquire();
                String str = str;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfDeleteAllUserRecordFiles.release(acquire);
                }
            }
        }, cVar);
    }

    public Object deleteRecordFiles(final RecordFileEntity[] recordFileEntityArr, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    RecordFilesDao_Impl.this.__deletionAdapterOfRecordFileEntity.handleMultiple((T[]) recordFileEntityArr);
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                }
            }
        }, cVar);
    }

    public Object getAllRecordFilesQuantity(c<? super Integer> cVar) {
        final i a10 = i.a("SELECT COUNT(*) FROM record_file_table", 0);
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<Integer>() {
            public Integer call() {
                Integer num = null;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    if (b10.moveToFirst()) {
                        if (!b10.isNull(0)) {
                            num = Integer.valueOf(b10.getInt(0));
                        }
                    }
                    return num;
                } finally {
                    b10.close();
                    a10.b();
                }
            }
        }, cVar);
    }

    public Object getAllRecordFilesQuantityByUser(String str, c<? super Integer> cVar) {
        final i a10 = i.a("SELECT COUNT(*) FROM record_file_table WHERE file_path LIKE '%' || ? || '%'", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<Integer>() {
            public Integer call() {
                Integer num = null;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    if (b10.moveToFirst()) {
                        if (!b10.isNull(0)) {
                            num = Integer.valueOf(b10.getInt(0));
                        }
                    }
                    return num;
                } finally {
                    b10.close();
                    a10.b();
                }
            }
        }, cVar);
    }

    public Object getFileByFileId(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE cloud_id=?", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass67 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object getRecordFileByKey(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE record_file_key=?", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass66 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object getSpecifyAllRecordFilesQuantityByUser(String str, String str2, c<? super Integer> cVar) {
        final i a10 = i.a("SELECT COUNT(*) FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND record_file_key=?", 2);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        if (str2 == null) {
            a10.Z(2);
        } else {
            a10.J(2, str2);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<Integer>() {
            public Integer call() {
                Integer num = null;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    if (b10.moveToFirst()) {
                        if (!b10.isNull(0)) {
                            num = Integer.valueOf(b10.getInt(0));
                        }
                    }
                    return num;
                } finally {
                    b10.close();
                    a10.b();
                }
            }
        }, cVar);
    }

    public Object insertRecordFiles(final RecordFileEntity[] recordFileEntityArr, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    RecordFilesDao_Impl.this.__insertionAdapterOfRecordFileEntity.insert((T[]) recordFileEntityArr);
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                }
            }
        }, cVar);
    }

    public Object loadAllCloudRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND cloud_id != '' ORDER BY session_id DESC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass55 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object loadAllRecordFiles(c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table", 0);
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass53 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object loadAllRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' ORDER BY session_id DESC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass54 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object loadDeleteRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND delete_state = 2 ORDER BY session_id DESC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass62 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object loadNormalRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND delete_state = 0 ORDER BY session_id DESC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass57 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object loadNormalRecordFilesByUserASC(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND delete_state = 0 ORDER BY session_id ASC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass58 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object loadNormalRecordFilesOrderByEdited(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND delete_state = 0 ORDER BY last_edit_time DESC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass59 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object loadNormalRecordFilesOrderByEditedASC(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND delete_state = 0 ORDER BY last_edit_time ASC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass60 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object loadTrashRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND delete_state = 1 ORDER BY session_id DESC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass61 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public LiveData<List<RecordFileEntity>> observedAllRecordFiles() {
        final i a10 = i.a("SELECT * FROM record_file_table ORDER BY session_id DESC", 0);
        return this.__db.getInvalidationTracker().b(new String[]{"record_file_table"}, false, new Callable<List<RecordFileEntity>>() {
            public void finalize() {
                a10.b();
            }

            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    int a24 = b.a(b10, "is_existing");
                    int a25 = b.a(b10, "cloud_id");
                    int a26 = b.a(b10, "timezone");
                    int a27 = b.a(b10, "timezone_min");
                    int a28 = b.a(b10, "transcription");
                    int a29 = b.a(b10, "transcription_state");
                    int a30 = b.a(b10, "trans_error_tip");
                    int a31 = b.a(b10, "summary_error_tip");
                    int a32 = b.a(b10, "summary");
                    int a33 = b.a(b10, "data_filetag_id_list");
                    int a34 = b.a(b10, "keywords");
                    int a35 = b.a(b10, "scene");
                    int a36 = b.a(b10, "isNew");
                    int a37 = b.a(b10, "delete_state");
                    int a38 = b.a(b10, "version");
                    int a39 = b.a(b10, "last_edit_time");
                    int a40 = b.a(b10, "has_edit");
                    int i14 = a23;
                    ArrayList arrayList = new ArrayList(b10.getCount());
                    while (b10.moveToNext()) {
                        RecordFileEntity recordFileEntity = new RecordFileEntity();
                        if (b10.isNull(a10)) {
                            i10 = a10;
                            str = null;
                        } else {
                            i10 = a10;
                            str = b10.getString(a10);
                        }
                        recordFileEntity.setKey(str);
                        ArrayList arrayList2 = arrayList;
                        recordFileEntity.setSessionId(b10.getLong(a11));
                        if (b10.isNull(a12)) {
                            str2 = null;
                        } else {
                            str2 = b10.getString(a12);
                        }
                        recordFileEntity.setSn(str2);
                        recordFileEntity.setGuide(b10.getInt(a13) != 0);
                        recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                        recordFileEntity.setDuration(b10.getLong(a15));
                        recordFileEntity.setFileSize(b10.getLong(a16));
                        recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                        if (b10.isNull(a18)) {
                            str3 = null;
                        } else {
                            str3 = b10.getString(a18);
                        }
                        recordFileEntity.setFileName(str3);
                        if (b10.isNull(a19)) {
                            str4 = null;
                        } else {
                            str4 = b10.getString(a19);
                        }
                        recordFileEntity.setFullName(str4);
                        if (b10.isNull(a20)) {
                            str5 = null;
                        } else {
                            str5 = b10.getString(a20);
                        }
                        recordFileEntity.setFileMD5(str5);
                        if (b10.isNull(a21)) {
                            str6 = null;
                        } else {
                            str6 = b10.getString(a21);
                        }
                        recordFileEntity.setFilePath(str6);
                        if (b10.isNull(a22)) {
                            str7 = null;
                        } else {
                            str7 = b10.getString(a22);
                        }
                        recordFileEntity.setOpusPath(str7);
                        int i15 = i14;
                        if (b10.isNull(i15)) {
                            str8 = null;
                        } else {
                            str8 = b10.getString(i15);
                        }
                        recordFileEntity.setAudioDbPath(str8);
                        int i16 = a24;
                        i14 = i15;
                        recordFileEntity.setExisting(b10.getInt(i16) != 0);
                        int i17 = a25;
                        if (b10.isNull(i17)) {
                            a25 = i17;
                            str9 = null;
                        } else {
                            a25 = i17;
                            str9 = b10.getString(i17);
                        }
                        recordFileEntity.setCloudId(str9);
                        a24 = i16;
                        int i18 = a26;
                        recordFileEntity.setTimeZone(b10.getInt(i18));
                        a26 = i18;
                        int i19 = a27;
                        recordFileEntity.setTimezoneMin(b10.getInt(i19));
                        int i20 = a28;
                        if (b10.isNull(i20)) {
                            a28 = i20;
                            a27 = i19;
                            i11 = a22;
                            string = null;
                        } else {
                            a28 = i20;
                            i11 = a22;
                            string = b10.getString(i20);
                            a27 = i19;
                        }
                        recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                        int i21 = a29;
                        recordFileEntity.setTranscriptionState(b10.getInt(i21));
                        int i22 = a30;
                        if (b10.isNull(i22)) {
                            i12 = i21;
                            str10 = null;
                        } else {
                            i12 = i21;
                            str10 = b10.getString(i22);
                        }
                        recordFileEntity.setTranscriptionErrorTip(str10);
                        int i23 = a31;
                        if (b10.isNull(i23)) {
                            a31 = i23;
                            str11 = null;
                        } else {
                            a31 = i23;
                            str11 = b10.getString(i23);
                        }
                        recordFileEntity.setSummaryErrorTip(str11);
                        int i24 = a32;
                        if (b10.isNull(i24)) {
                            a32 = i24;
                            str12 = null;
                        } else {
                            a32 = i24;
                            str12 = b10.getString(i24);
                        }
                        recordFileEntity.setSummary(str12);
                        int i25 = a33;
                        if (b10.isNull(i25)) {
                            a33 = i25;
                            i13 = i22;
                            str13 = null;
                        } else {
                            a33 = i25;
                            str13 = b10.getString(i25);
                            i13 = i22;
                        }
                        recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                        int i26 = a34;
                        if (b10.isNull(i26)) {
                            a34 = i26;
                            str14 = null;
                        } else {
                            str14 = b10.getString(i26);
                            a34 = i26;
                        }
                        recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                        int i27 = a35;
                        recordFileEntity.setScene(b10.getInt(i27));
                        int i28 = a36;
                        if (b10.getInt(i28) != 0) {
                            a35 = i27;
                            z10 = true;
                        } else {
                            a35 = i27;
                            z10 = false;
                        }
                        recordFileEntity.setNew(z10);
                        int i29 = a37;
                        recordFileEntity.setDeleteState(b10.getInt(i29));
                        int i30 = a11;
                        int i31 = a12;
                        int i32 = a38;
                        recordFileEntity.setVersion(b10.getLong(i32));
                        int i33 = i29;
                        a38 = i32;
                        int i34 = a39;
                        recordFileEntity.setLastEditTime(b10.getLong(i34));
                        int i35 = a40;
                        recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                        arrayList = arrayList2;
                        arrayList.add(recordFileEntity);
                        a40 = i35;
                        a39 = i34;
                        a11 = i30;
                        a10 = i10;
                        a36 = i28;
                        a22 = i11;
                        int i36 = i31;
                        a37 = i33;
                        a12 = i36;
                        int i37 = i12;
                        a30 = i13;
                        a29 = i37;
                    }
                    return arrayList;
                } finally {
                    b10.close();
                }
            }
        });
    }

    public LiveData<List<RecordFileEntity>> observedAllRecordFilesByUser(String str) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' ORDER BY session_id DESC", 1);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        return this.__db.getInvalidationTracker().b(new String[]{"record_file_table"}, false, new Callable<List<RecordFileEntity>>() {
            public void finalize() {
                a10.b();
            }

            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    int a24 = b.a(b10, "is_existing");
                    int a25 = b.a(b10, "cloud_id");
                    int a26 = b.a(b10, "timezone");
                    int a27 = b.a(b10, "timezone_min");
                    int a28 = b.a(b10, "transcription");
                    int a29 = b.a(b10, "transcription_state");
                    int a30 = b.a(b10, "trans_error_tip");
                    int a31 = b.a(b10, "summary_error_tip");
                    int a32 = b.a(b10, "summary");
                    int a33 = b.a(b10, "data_filetag_id_list");
                    int a34 = b.a(b10, "keywords");
                    int a35 = b.a(b10, "scene");
                    int a36 = b.a(b10, "isNew");
                    int a37 = b.a(b10, "delete_state");
                    int a38 = b.a(b10, "version");
                    int a39 = b.a(b10, "last_edit_time");
                    int a40 = b.a(b10, "has_edit");
                    int i14 = a23;
                    ArrayList arrayList = new ArrayList(b10.getCount());
                    while (b10.moveToNext()) {
                        RecordFileEntity recordFileEntity = new RecordFileEntity();
                        if (b10.isNull(a10)) {
                            i10 = a10;
                            str = null;
                        } else {
                            i10 = a10;
                            str = b10.getString(a10);
                        }
                        recordFileEntity.setKey(str);
                        ArrayList arrayList2 = arrayList;
                        recordFileEntity.setSessionId(b10.getLong(a11));
                        if (b10.isNull(a12)) {
                            str2 = null;
                        } else {
                            str2 = b10.getString(a12);
                        }
                        recordFileEntity.setSn(str2);
                        recordFileEntity.setGuide(b10.getInt(a13) != 0);
                        recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                        recordFileEntity.setDuration(b10.getLong(a15));
                        recordFileEntity.setFileSize(b10.getLong(a16));
                        recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                        if (b10.isNull(a18)) {
                            str3 = null;
                        } else {
                            str3 = b10.getString(a18);
                        }
                        recordFileEntity.setFileName(str3);
                        if (b10.isNull(a19)) {
                            str4 = null;
                        } else {
                            str4 = b10.getString(a19);
                        }
                        recordFileEntity.setFullName(str4);
                        if (b10.isNull(a20)) {
                            str5 = null;
                        } else {
                            str5 = b10.getString(a20);
                        }
                        recordFileEntity.setFileMD5(str5);
                        if (b10.isNull(a21)) {
                            str6 = null;
                        } else {
                            str6 = b10.getString(a21);
                        }
                        recordFileEntity.setFilePath(str6);
                        if (b10.isNull(a22)) {
                            str7 = null;
                        } else {
                            str7 = b10.getString(a22);
                        }
                        recordFileEntity.setOpusPath(str7);
                        int i15 = i14;
                        if (b10.isNull(i15)) {
                            str8 = null;
                        } else {
                            str8 = b10.getString(i15);
                        }
                        recordFileEntity.setAudioDbPath(str8);
                        int i16 = a24;
                        i14 = i15;
                        recordFileEntity.setExisting(b10.getInt(i16) != 0);
                        int i17 = a25;
                        if (b10.isNull(i17)) {
                            a25 = i17;
                            str9 = null;
                        } else {
                            a25 = i17;
                            str9 = b10.getString(i17);
                        }
                        recordFileEntity.setCloudId(str9);
                        a24 = i16;
                        int i18 = a26;
                        recordFileEntity.setTimeZone(b10.getInt(i18));
                        a26 = i18;
                        int i19 = a27;
                        recordFileEntity.setTimezoneMin(b10.getInt(i19));
                        int i20 = a28;
                        if (b10.isNull(i20)) {
                            a28 = i20;
                            a27 = i19;
                            i11 = a22;
                            string = null;
                        } else {
                            a28 = i20;
                            i11 = a22;
                            string = b10.getString(i20);
                            a27 = i19;
                        }
                        recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                        int i21 = a29;
                        recordFileEntity.setTranscriptionState(b10.getInt(i21));
                        int i22 = a30;
                        if (b10.isNull(i22)) {
                            i12 = i21;
                            str10 = null;
                        } else {
                            i12 = i21;
                            str10 = b10.getString(i22);
                        }
                        recordFileEntity.setTranscriptionErrorTip(str10);
                        int i23 = a31;
                        if (b10.isNull(i23)) {
                            a31 = i23;
                            str11 = null;
                        } else {
                            a31 = i23;
                            str11 = b10.getString(i23);
                        }
                        recordFileEntity.setSummaryErrorTip(str11);
                        int i24 = a32;
                        if (b10.isNull(i24)) {
                            a32 = i24;
                            str12 = null;
                        } else {
                            a32 = i24;
                            str12 = b10.getString(i24);
                        }
                        recordFileEntity.setSummary(str12);
                        int i25 = a33;
                        if (b10.isNull(i25)) {
                            a33 = i25;
                            i13 = i22;
                            str13 = null;
                        } else {
                            a33 = i25;
                            str13 = b10.getString(i25);
                            i13 = i22;
                        }
                        recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                        int i26 = a34;
                        if (b10.isNull(i26)) {
                            a34 = i26;
                            str14 = null;
                        } else {
                            str14 = b10.getString(i26);
                            a34 = i26;
                        }
                        recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                        int i27 = a35;
                        recordFileEntity.setScene(b10.getInt(i27));
                        int i28 = a36;
                        if (b10.getInt(i28) != 0) {
                            a35 = i27;
                            z10 = true;
                        } else {
                            a35 = i27;
                            z10 = false;
                        }
                        recordFileEntity.setNew(z10);
                        int i29 = a37;
                        recordFileEntity.setDeleteState(b10.getInt(i29));
                        int i30 = a11;
                        int i31 = a12;
                        int i32 = a38;
                        recordFileEntity.setVersion(b10.getLong(i32));
                        int i33 = i29;
                        a38 = i32;
                        int i34 = a39;
                        recordFileEntity.setLastEditTime(b10.getLong(i34));
                        int i35 = a40;
                        recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                        arrayList = arrayList2;
                        arrayList.add(recordFileEntity);
                        a40 = i35;
                        a39 = i34;
                        a11 = i30;
                        a10 = i10;
                        a36 = i28;
                        a22 = i11;
                        int i36 = i31;
                        a37 = i33;
                        a12 = i36;
                        int i37 = i12;
                        a30 = i13;
                        a29 = i37;
                    }
                    return arrayList;
                } finally {
                    b10.close();
                }
            }
        });
    }

    public Object searchAllRecordFilesByContent(String str, String str2, c<? super List<RecordFileEntity>> cVar) {
        final i a10 = i.a("SELECT * FROM record_file_table WHERE file_path LIKE '%' || ? || '%' AND (file_name LIKE '%' || ? || '%' OR transcription LIKE '%' || ? || '%' OR summary LIKE '%' || ? || '%' OR keywords LIKE '%' || ? || '%' OR data_filetag_id_list LIKE '%' || ? || '%') ORDER BY session_id DESC", 6);
        if (str == null) {
            a10.Z(1);
        } else {
            a10.J(1, str);
        }
        if (str2 == null) {
            a10.Z(2);
        } else {
            a10.J(2, str2);
        }
        if (str2 == null) {
            a10.Z(3);
        } else {
            a10.J(3, str2);
        }
        if (str2 == null) {
            a10.Z(4);
        } else {
            a10.J(4, str2);
        }
        if (str2 == null) {
            a10.Z(5);
        } else {
            a10.J(5, str2);
        }
        if (str2 == null) {
            a10.Z(6);
        } else {
            a10.J(6, str2);
        }
        return m2.c.a(this.__db, false, new CancellationSignal(), new Callable<List<RecordFileEntity>>() {
            public List<RecordFileEntity> call() {
                int i10;
                String str;
                String str2;
                String str3;
                String str4;
                String str5;
                String str6;
                String str7;
                String str8;
                String str9;
                int i11;
                String string;
                int i12;
                String str10;
                String str11;
                String str12;
                int i13;
                String str13;
                String str14;
                boolean z10;
                AnonymousClass56 r12 = this;
                Cursor b10 = o2.c.b(RecordFilesDao_Impl.this.__db, a10, false, (CancellationSignal) null);
                try {
                    int a10 = b.a(b10, "record_file_key");
                    int a11 = b.a(b10, "session_id");
                    int a12 = b.a(b10, "serial_number");
                    int a13 = b.a(b10, "is_guide");
                    int a14 = b.a(b10, "cloud_has_trans_file");
                    int a15 = b.a(b10, "duration");
                    int a16 = b.a(b10, "file_size");
                    int a17 = b.a(b10, "audio_channel_count");
                    int a18 = b.a(b10, "file_name");
                    int a19 = b.a(b10, "full_name");
                    int a20 = b.a(b10, "file_md5");
                    int a21 = b.a(b10, "file_path");
                    int a22 = b.a(b10, "file_opus_path");
                    int a23 = b.a(b10, "audio_db_path");
                    try {
                        int a24 = b.a(b10, "is_existing");
                        int a25 = b.a(b10, "cloud_id");
                        int a26 = b.a(b10, "timezone");
                        int a27 = b.a(b10, "timezone_min");
                        int a28 = b.a(b10, "transcription");
                        int a29 = b.a(b10, "transcription_state");
                        int a30 = b.a(b10, "trans_error_tip");
                        int a31 = b.a(b10, "summary_error_tip");
                        int a32 = b.a(b10, "summary");
                        int a33 = b.a(b10, "data_filetag_id_list");
                        int a34 = b.a(b10, "keywords");
                        int a35 = b.a(b10, "scene");
                        int a36 = b.a(b10, "isNew");
                        int a37 = b.a(b10, "delete_state");
                        int a38 = b.a(b10, "version");
                        int a39 = b.a(b10, "last_edit_time");
                        int a40 = b.a(b10, "has_edit");
                        int i14 = a23;
                        ArrayList arrayList = new ArrayList(b10.getCount());
                        while (b10.moveToNext()) {
                            RecordFileEntity recordFileEntity = new RecordFileEntity();
                            if (b10.isNull(a10)) {
                                i10 = a10;
                                str = null;
                            } else {
                                i10 = a10;
                                str = b10.getString(a10);
                            }
                            recordFileEntity.setKey(str);
                            ArrayList arrayList2 = arrayList;
                            recordFileEntity.setSessionId(b10.getLong(a11));
                            if (b10.isNull(a12)) {
                                str2 = null;
                            } else {
                                str2 = b10.getString(a12);
                            }
                            recordFileEntity.setSn(str2);
                            recordFileEntity.setGuide(b10.getInt(a13) != 0);
                            recordFileEntity.setCloudHasTransFile(b10.getInt(a14) != 0);
                            recordFileEntity.setDuration(b10.getLong(a15));
                            recordFileEntity.setFileSize(b10.getLong(a16));
                            recordFileEntity.setAudioChannelCount(b10.getInt(a17));
                            if (b10.isNull(a18)) {
                                str3 = null;
                            } else {
                                str3 = b10.getString(a18);
                            }
                            recordFileEntity.setFileName(str3);
                            if (b10.isNull(a19)) {
                                str4 = null;
                            } else {
                                str4 = b10.getString(a19);
                            }
                            recordFileEntity.setFullName(str4);
                            if (b10.isNull(a20)) {
                                str5 = null;
                            } else {
                                str5 = b10.getString(a20);
                            }
                            recordFileEntity.setFileMD5(str5);
                            if (b10.isNull(a21)) {
                                str6 = null;
                            } else {
                                str6 = b10.getString(a21);
                            }
                            recordFileEntity.setFilePath(str6);
                            if (b10.isNull(a22)) {
                                str7 = null;
                            } else {
                                str7 = b10.getString(a22);
                            }
                            recordFileEntity.setOpusPath(str7);
                            int i15 = i14;
                            if (b10.isNull(i15)) {
                                str8 = null;
                            } else {
                                str8 = b10.getString(i15);
                            }
                            recordFileEntity.setAudioDbPath(str8);
                            int i16 = a24;
                            i14 = i15;
                            recordFileEntity.setExisting(b10.getInt(i16) != 0);
                            int i17 = a25;
                            if (b10.isNull(i17)) {
                                a25 = i17;
                                str9 = null;
                            } else {
                                a25 = i17;
                                str9 = b10.getString(i17);
                            }
                            recordFileEntity.setCloudId(str9);
                            a24 = i16;
                            int i18 = a26;
                            recordFileEntity.setTimeZone(b10.getInt(i18));
                            a26 = i18;
                            int i19 = a27;
                            recordFileEntity.setTimezoneMin(b10.getInt(i19));
                            int i20 = a28;
                            if (b10.isNull(i20)) {
                                a28 = i20;
                                a27 = i19;
                                i11 = a22;
                                string = null;
                            } else {
                                a28 = i20;
                                i11 = a22;
                                string = b10.getString(i20);
                                a27 = i19;
                            }
                            r12 = this;
                            recordFileEntity.setTranscription(RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromString(string));
                            int i21 = a29;
                            recordFileEntity.setTranscriptionState(b10.getInt(i21));
                            int i22 = a30;
                            if (b10.isNull(i22)) {
                                i12 = i21;
                                str10 = null;
                            } else {
                                i12 = i21;
                                str10 = b10.getString(i22);
                            }
                            recordFileEntity.setTranscriptionErrorTip(str10);
                            int i23 = a31;
                            if (b10.isNull(i23)) {
                                a31 = i23;
                                str11 = null;
                            } else {
                                a31 = i23;
                                str11 = b10.getString(i23);
                            }
                            recordFileEntity.setSummaryErrorTip(str11);
                            int i24 = a32;
                            if (b10.isNull(i24)) {
                                a32 = i24;
                                str12 = null;
                            } else {
                                a32 = i24;
                                str12 = b10.getString(i24);
                            }
                            recordFileEntity.setSummary(str12);
                            int i25 = a33;
                            if (b10.isNull(i25)) {
                                a33 = i25;
                                i13 = i22;
                                str13 = null;
                            } else {
                                a33 = i25;
                                str13 = b10.getString(i25);
                                i13 = i22;
                            }
                            recordFileEntity.setTagIdList(RecordFilesDao_Impl.this.__stringListConverter.fromString(str13));
                            int i26 = a34;
                            if (b10.isNull(i26)) {
                                a34 = i26;
                                str14 = null;
                            } else {
                                str14 = b10.getString(i26);
                                a34 = i26;
                            }
                            recordFileEntity.setKeywords(RecordFilesDao_Impl.this.__stringListConverter.fromString(str14));
                            int i27 = a35;
                            recordFileEntity.setScene(b10.getInt(i27));
                            int i28 = a36;
                            if (b10.getInt(i28) != 0) {
                                a35 = i27;
                                z10 = true;
                            } else {
                                a35 = i27;
                                z10 = false;
                            }
                            recordFileEntity.setNew(z10);
                            a36 = i28;
                            int i29 = a37;
                            recordFileEntity.setDeleteState(b10.getInt(i29));
                            int i30 = a11;
                            int i31 = a38;
                            int i32 = a12;
                            recordFileEntity.setVersion(b10.getLong(i31));
                            int i33 = a39;
                            int i34 = a13;
                            recordFileEntity.setLastEditTime(b10.getLong(i33));
                            int i35 = a40;
                            recordFileEntity.setHasEdit(b10.getInt(i35) != 0);
                            ArrayList arrayList3 = arrayList2;
                            arrayList3.add(recordFileEntity);
                            a40 = i35;
                            arrayList = arrayList3;
                            a12 = i32;
                            a13 = i34;
                            a38 = i31;
                            a39 = i33;
                            a11 = i30;
                            a22 = i11;
                            a37 = i29;
                            a10 = i10;
                            int i36 = i12;
                            a30 = i13;
                            a29 = i36;
                        }
                        ArrayList arrayList4 = arrayList;
                        b10.close();
                        a10.b();
                        return arrayList4;
                    } catch (Throwable th2) {
                        th = th2;
                        r12 = this;
                        b10.close();
                        a10.b();
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    b10.close();
                    a10.b();
                    throw th;
                }
            }
        }, cVar);
    }

    public Object updateCloudHasRaw(final String str, final boolean z10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateCloudHasRaw.acquire();
                acquire.L0(1, z10 ? 1 : 0);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateCloudHasRaw.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateCloudId(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateCloudId.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateCloudId.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateDeleteState(final String str, final int i10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateDeleteState.acquire();
                acquire.L0(1, (long) i10);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateDeleteState.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateFileMD5(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateFileMD5.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateFileMD5.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateFileName(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateFileName.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateFileName.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateFilePath(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateFilePath.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateFilePath.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateFullName(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateFullName.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateFullName.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateHasEdit(final String str, final boolean z10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateHasEdit.acquire();
                acquire.L0(1, z10 ? 1 : 0);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateHasEdit.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateHasTransFile(final String str, final boolean z10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateHasTransFile.acquire();
                acquire.L0(1, z10 ? 1 : 0);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateHasTransFile.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateIsExist(final String str, final boolean z10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateIsExist.acquire();
                acquire.L0(1, z10 ? 1 : 0);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateIsExist.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateIsNew(final String str, final boolean z10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateIsNew.acquire();
                acquire.L0(1, z10 ? 1 : 0);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateIsNew.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateKeywords(final String str, final List<String> list, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateKeywords.acquire();
                String fromList = RecordFilesDao_Impl.this.__stringListConverter.fromList(list);
                if (fromList == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, fromList);
                }
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateKeywords.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateLastEditTime(final String str, final long j10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateLastEditTime.acquire();
                acquire.L0(1, j10);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateLastEditTime.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateRecordFiles(final RecordFileEntity[] recordFileEntityArr, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    RecordFilesDao_Impl.this.__updateAdapterOfRecordFileEntity.handleMultiple((T[]) recordFileEntityArr);
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                }
            }
        }, cVar);
    }

    public Object updateSummary(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateSummary.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateSummary.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateSummaryErrorTip(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateSummaryErrorTip.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateSummaryErrorTip.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateTagIdList(final String str, final List<String> list, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateTagIdList.acquire();
                String fromList = RecordFilesDao_Impl.this.__stringListConverter.fromList(list);
                if (fromList == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, fromList);
                }
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateTagIdList.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateTransContent(final String str, final List<TranscriptionData> list, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateTransContent.acquire();
                String fromList = RecordFilesDao_Impl.this.__transcriptionDataListConverter.fromList(list);
                if (fromList == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, fromList);
                }
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateTransContent.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateTransErrorTip(final String str, final String str2, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateTransErrorTip.acquire();
                String str = str2;
                if (str == null) {
                    acquire.Z(1);
                } else {
                    acquire.J(1, str);
                }
                String str2 = str;
                if (str2 == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str2);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateTransErrorTip.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateTransState(final String str, final int i10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateTransState.acquire();
                acquire.L0(1, (long) i10);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateTransState.release(acquire);
                }
            }
        }, cVar);
    }

    public Object updateVersion(final String str, final long j10, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                q2.e acquire = RecordFilesDao_Impl.this.__preparedStmtOfUpdateVersion.acquire();
                acquire.L0(1, j10);
                String str = str;
                if (str == null) {
                    acquire.Z(2);
                } else {
                    acquire.J(2, str);
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    acquire.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                    RecordFilesDao_Impl.this.__preparedStmtOfUpdateVersion.release(acquire);
                }
            }
        }, cVar);
    }

    public Object deleteAllRecordFiles(final String str, final List<String> list, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("DELETE FROM record_file_table WHERE file_path LIKE '%' || ");
                sb2.append("?");
                sb2.append(" || '%' AND record_file_key IN (");
                d.a(sb2, list.size());
                sb2.append(")");
                q2.e compileStatement = RecordFilesDao_Impl.this.__db.compileStatement(sb2.toString());
                String str = str;
                if (str == null) {
                    compileStatement.Z(1);
                } else {
                    compileStatement.J(1, str);
                }
                int i10 = 2;
                for (String str2 : list) {
                    if (str2 == null) {
                        compileStatement.Z(i10);
                    } else {
                        compileStatement.J(i10, str2);
                    }
                    i10++;
                }
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    compileStatement.T();
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                }
            }
        }, cVar);
    }

    public Object deleteRecordFiles(final List<RecordFileEntity> list, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    RecordFilesDao_Impl.this.__deletionAdapterOfRecordFileEntity.handleMultiple(list);
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                }
            }
        }, cVar);
    }

    public Object insertRecordFiles(final List<RecordFileEntity> list, c<? super g> cVar) {
        return m2.c.b(this.__db, true, new Callable<g>() {
            public g call() {
                RecordFilesDao_Impl.this.__db.beginTransaction();
                try {
                    RecordFilesDao_Impl.this.__insertionAdapterOfRecordFileEntity.insert(list);
                    RecordFilesDao_Impl.this.__db.setTransactionSuccessful();
                    return g.f19030a;
                } finally {
                    RecordFilesDao_Impl.this.__db.endTransaction();
                }
            }
        }, cVar);
    }
}
