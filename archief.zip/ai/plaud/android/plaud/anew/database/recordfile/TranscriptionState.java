package ai.plaud.android.plaud.anew.database.recordfile;

/* compiled from: RecordFileEntity.kt */
public enum TranscriptionState {
    IDLE(0),
    CLOUD_ING(1),
    CLOUD_SUMMARY(3),
    CLOUD_FINISH(4),
    UPLOAD_MP3(5),
    CONVERTING_WAV(6),
    UPLOAD_WAV(7),
    WAITING_START_TRANS(8),
    CLOUD_FINISH_TOO_SHORT(9),
    CLOUD_FINISH_NO_VOICE(10),
    CLOUD_TRANS_FAIL(-1),
    CLOUD_SUMMARY_FAIL(-2),
    CLOUD_TRANS_MEMBER_SHIP_FAIL(-3),
    CLOUD_UPLOAD_MP3_FAIL(-4),
    CLOUD_UPLOAD_WAV_FAIL(-5),
    CLOUD_CONVERTING_WAV_FAIL(-6);
    
    private final int value;

    private TranscriptionState(int i10) {
        this.value = i10;
    }

    public final int getValue() {
        return this.value;
    }
}
