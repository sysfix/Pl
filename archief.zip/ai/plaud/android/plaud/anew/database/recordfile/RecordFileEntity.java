package ai.plaud.android.plaud.anew.database.recordfile;

import ai.plaud.android.plaud.anew.api.bean.TranscriptionData;
import ai.plaud.android.plaud.anew.database.tag.TagEntity;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.recyclerview.widget.RecyclerView;
import c.b;
import com.blankj.utilcode.util.e;
import com.google.common.collect.MapMakerInternalMap;
import hb.h;
import hb.i;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import jb.n;
import kotlin.jvm.internal.DefaultConstructorMarker;
import okhttp3.internal.http2.Http2;
import okhttp3.internal.http2.Http2Connection;
import rg.d0;

/* compiled from: RecordFileEntity.kt */
public final class RecordFileEntity implements Parcelable {
    public static final Parcelable.Creator<RecordFileEntity> CREATOR = new Creator();
    private int audioChannelCount;
    private String audioDbPath;
    private boolean cloudHasTransFile;
    private String cloudId;
    private int deleteState;
    private long duration;
    private String fileMD5;
    private String fileName;
    private String filePath;
    private long fileSize;
    private String fullName;
    private boolean hasEdit;
    private boolean isExisting;
    private boolean isGuide;
    private boolean isNew;
    private String key;
    private List<String> keywords;
    private long lastEditTime;
    private String opusPath;
    private int scene;
    private long sessionId;
    private String sn;
    private String summary;
    private String summaryErrorTip;
    private int syncFailCount;
    private List<TagEntity> tagEntityList;
    private List<String> tagIdList;
    private int timeZone;
    private int timezoneMin;
    private List<TranscriptionData> transcription;
    private String transcriptionErrorTip;
    private int transcriptionState;
    private long version;

    /* compiled from: RecordFileEntity.kt */
    public static final class Creator implements Parcelable.Creator<RecordFileEntity> {
        public final RecordFileEntity createFromParcel(Parcel parcel) {
            Parcel parcel2 = parcel;
            d0.g(parcel2, "parcel");
            String readString = parcel.readString();
            long readLong = parcel.readLong();
            String readString2 = parcel.readString();
            boolean z10 = parcel.readInt() != 0;
            boolean z11 = parcel.readInt() != 0;
            long readLong2 = parcel.readLong();
            long readLong3 = parcel.readLong();
            int readInt = parcel.readInt();
            String readString3 = parcel.readString();
            String readString4 = parcel.readString();
            String readString5 = parcel.readString();
            String readString6 = parcel.readString();
            String readString7 = parcel.readString();
            String readString8 = parcel.readString();
            boolean z12 = parcel.readInt() != 0;
            String readString9 = parcel.readString();
            int readInt2 = parcel.readInt();
            int readInt3 = parcel.readInt();
            int readInt4 = parcel.readInt();
            String str = readString4;
            ArrayList arrayList = new ArrayList(readInt4);
            int i10 = 0;
            while (i10 != readInt4) {
                arrayList.add(TranscriptionData.CREATOR.createFromParcel(parcel2));
                i10++;
                readInt4 = readInt4;
            }
            int readInt5 = parcel.readInt();
            String readString10 = parcel.readString();
            String readString11 = parcel.readString();
            String readString12 = parcel.readString();
            ArrayList<String> createStringArrayList = parcel.createStringArrayList();
            ArrayList<String> createStringArrayList2 = parcel.createStringArrayList();
            int readInt6 = parcel.readInt();
            boolean z13 = parcel.readInt() != 0;
            int readInt7 = parcel.readInt();
            long readLong4 = parcel.readLong();
            long readLong5 = parcel.readLong();
            boolean z14 = parcel.readInt() != 0;
            int readInt8 = parcel.readInt();
            ArrayList arrayList2 = new ArrayList(readInt8);
            ArrayList arrayList3 = arrayList;
            int i11 = 0;
            while (i11 != readInt8) {
                arrayList2.add(TagEntity.CREATOR.createFromParcel(parcel2));
                i11++;
                readInt8 = readInt8;
            }
            ArrayList arrayList4 = arrayList2;
            boolean z15 = z10;
            ArrayList arrayList5 = arrayList3;
            return new RecordFileEntity(readString, readLong, readString2, z15, z11, readLong2, readLong3, readInt, readString3, str, readString5, readString6, readString7, readString8, z12, readString9, readInt2, readInt3, arrayList3, readInt5, readString10, readString11, readString12, createStringArrayList, createStringArrayList2, readInt6, z13, readInt7, readLong4, readLong5, z14, arrayList4, parcel.readInt());
        }

        public final RecordFileEntity[] newArray(int i10) {
            return new RecordFileEntity[i10];
        }
    }

    /* compiled from: RecordFileEntity.kt */
    public static final class StringListConverter {
        public final String fromList(List<String> list) {
            d0.g(list, "list");
            String i10 = new h().i(list);
            d0.f(i10, "Gson().toJson(list)");
            return i10;
        }

        public final List<String> fromString(String str) {
            d0.g(str, "value");
            Object d10 = new h().d(str, new RecordFileEntity$StringListConverter$fromString$listType$1().getType());
            d0.f(d10, "Gson().fromJson(value, listType)");
            return (List) d10;
        }
    }

    /* compiled from: RecordFileEntity.kt */
    public static final class TranscriptionDataListConverter {
        public final String fromList(List<TranscriptionData> list) {
            d0.g(list, "list");
            i iVar = new i();
            n b10 = iVar.f11587a.clone();
            b10.f13430q = true;
            iVar.f11587a = b10;
            String i10 = iVar.a().i(list);
            d0.f(i10, "GsonBuilder().excludeFie…n().create().toJson(list)");
            return i10;
        }

        public final List<TranscriptionData> fromString(String str) {
            d0.g(str, "value");
            Type type = new RecordFileEntity$TranscriptionDataListConverter$fromString$listType$1().getType();
            i iVar = new i();
            n b10 = iVar.f11587a.clone();
            b10.f13430q = true;
            iVar.f11587a = b10;
            Object d10 = iVar.a().d(str, type);
            d0.f(d10, "GsonBuilder().excludeFie…fromJson(value, listType)");
            return (List) d10;
        }
    }

    public RecordFileEntity() {
        this((String) null, 0, (String) null, false, false, 0, 0, 0, (String) null, (String) null, (String) null, (String) null, (String) null, (String) null, false, (String) null, 0, 0, (List) null, 0, (String) null, (String) null, (String) null, (List) null, (List) null, 0, false, 0, 0, 0, false, (List) null, 0, -1, 1, (DefaultConstructorMarker) null);
    }

    public RecordFileEntity(String str, long j10, String str2, boolean z10, boolean z11, long j11, long j12, int i10, String str3, String str4, String str5, String str6, String str7, String str8, boolean z12, String str9, int i11, int i12, List<TranscriptionData> list, int i13, String str10, String str11, String str12, List<String> list2, List<String> list3, int i14, boolean z13, int i15, long j13, long j14, boolean z14, List<TagEntity> list4, int i16) {
        String str13 = str;
        String str14 = str2;
        String str15 = str3;
        String str16 = str4;
        String str17 = str5;
        String str18 = str6;
        String str19 = str7;
        String str20 = str8;
        String str21 = str9;
        List<TranscriptionData> list5 = list;
        String str22 = str10;
        String str23 = str11;
        String str24 = str12;
        List<TagEntity> list6 = list4;
        d0.g(str13, "key");
        d0.g(str14, "sn");
        d0.g(str15, "fileName");
        d0.g(str16, "fullName");
        d0.g(str17, "fileMD5");
        d0.g(str18, "filePath");
        d0.g(str19, "opusPath");
        d0.g(str20, "audioDbPath");
        d0.g(str21, "cloudId");
        d0.g(list5, "transcription");
        d0.g(str22, "transcriptionErrorTip");
        d0.g(str23, "summaryErrorTip");
        d0.g(str24, "summary");
        d0.g(list2, "tagIdList");
        d0.g(list3, "keywords");
        d0.g(list4, "tagEntityList");
        this.key = str13;
        this.sessionId = j10;
        this.sn = str14;
        this.isGuide = z10;
        this.cloudHasTransFile = z11;
        this.duration = j11;
        this.fileSize = j12;
        this.audioChannelCount = i10;
        this.fileName = str15;
        this.fullName = str16;
        this.fileMD5 = str17;
        this.filePath = str18;
        this.opusPath = str19;
        this.audioDbPath = str20;
        this.isExisting = z12;
        this.cloudId = str21;
        this.timeZone = i11;
        this.timezoneMin = i12;
        this.transcription = list5;
        this.transcriptionState = i13;
        this.transcriptionErrorTip = str22;
        this.summaryErrorTip = str23;
        this.summary = str24;
        this.tagIdList = list2;
        this.keywords = list3;
        this.scene = i14;
        this.isNew = z13;
        this.deleteState = i15;
        this.version = j13;
        this.lastEditTime = j14;
        this.hasEdit = z14;
        this.tagEntityList = list4;
        this.syncFailCount = i16;
    }

    public static /* synthetic */ RecordFileEntity copy$default(RecordFileEntity recordFileEntity, String str, long j10, String str2, boolean z10, boolean z11, long j11, long j12, int i10, String str3, String str4, String str5, String str6, String str7, String str8, boolean z12, String str9, int i11, int i12, List list, int i13, String str10, String str11, String str12, List list2, List list3, int i14, boolean z13, int i15, long j13, long j14, boolean z14, List list4, int i16, int i17, int i18, Object obj) {
        RecordFileEntity recordFileEntity2 = recordFileEntity;
        int i19 = i17;
        return recordFileEntity.copy((i19 & 1) != 0 ? recordFileEntity2.key : str, (i19 & 2) != 0 ? recordFileEntity2.sessionId : j10, (i19 & 4) != 0 ? recordFileEntity2.sn : str2, (i19 & 8) != 0 ? recordFileEntity2.isGuide : z10, (i19 & 16) != 0 ? recordFileEntity2.cloudHasTransFile : z11, (i19 & 32) != 0 ? recordFileEntity2.duration : j11, (i19 & 64) != 0 ? recordFileEntity2.fileSize : j12, (i19 & 128) != 0 ? recordFileEntity2.audioChannelCount : i10, (i19 & 256) != 0 ? recordFileEntity2.fileName : str3, (i19 & RecyclerView.z.FLAG_ADAPTER_POSITION_UNKNOWN) != 0 ? recordFileEntity2.fullName : str4, (i19 & RecyclerView.z.FLAG_ADAPTER_FULLUPDATE) != 0 ? recordFileEntity2.fileMD5 : str5, (i19 & 2048) != 0 ? recordFileEntity2.filePath : str6, (i19 & 4096) != 0 ? recordFileEntity2.opusPath : str7, (i19 & 8192) != 0 ? recordFileEntity2.audioDbPath : str8, (i19 & Http2.INITIAL_MAX_FRAME_SIZE) != 0 ? recordFileEntity2.isExisting : z12, (i19 & 32768) != 0 ? recordFileEntity2.cloudId : str9, (i19 & MapMakerInternalMap.MAX_SEGMENTS) != 0 ? recordFileEntity2.timeZone : i11, (i19 & 131072) != 0 ? recordFileEntity2.timezoneMin : i12, (i19 & 262144) != 0 ? recordFileEntity2.transcription : list, (i19 & 524288) != 0 ? recordFileEntity2.transcriptionState : i13, (i19 & 1048576) != 0 ? recordFileEntity2.transcriptionErrorTip : str10, (i19 & 2097152) != 0 ? recordFileEntity2.summaryErrorTip : str11, (i19 & 4194304) != 0 ? recordFileEntity2.summary : str12, (i19 & 8388608) != 0 ? recordFileEntity2.tagIdList : list2, (i19 & Http2Connection.OKHTTP_CLIENT_WINDOW_SIZE) != 0 ? recordFileEntity2.keywords : list3, (i19 & 33554432) != 0 ? recordFileEntity2.scene : i14, (i19 & 67108864) != 0 ? recordFileEntity2.isNew : z13, (i19 & 134217728) != 0 ? recordFileEntity2.deleteState : i15, (i19 & 268435456) != 0 ? recordFileEntity2.version : j13, (i19 & 536870912) != 0 ? recordFileEntity2.lastEditTime : j14, (i19 & 1073741824) != 0 ? recordFileEntity2.hasEdit : z14, (i19 & CellBase.GROUP_ID_SYSTEM_MESSAGE) != 0 ? recordFileEntity2.tagEntityList : list4, (i18 & 1) != 0 ? recordFileEntity2.syncFailCount : i16);
    }

    public final String component1() {
        return this.key;
    }

    public final String component10() {
        return this.fullName;
    }

    public final String component11() {
        return this.fileMD5;
    }

    public final String component12() {
        return this.filePath;
    }

    public final String component13() {
        return this.opusPath;
    }

    public final String component14() {
        return this.audioDbPath;
    }

    public final boolean component15() {
        return this.isExisting;
    }

    public final String component16() {
        return this.cloudId;
    }

    public final int component17() {
        return this.timeZone;
    }

    public final int component18() {
        return this.timezoneMin;
    }

    public final List<TranscriptionData> component19() {
        return this.transcription;
    }

    public final long component2() {
        return this.sessionId;
    }

    public final int component20() {
        return this.transcriptionState;
    }

    public final String component21() {
        return this.transcriptionErrorTip;
    }

    public final String component22() {
        return this.summaryErrorTip;
    }

    public final String component23() {
        return this.summary;
    }

    public final List<String> component24() {
        return this.tagIdList;
    }

    public final List<String> component25() {
        return this.keywords;
    }

    public final int component26() {
        return this.scene;
    }

    public final boolean component27() {
        return this.isNew;
    }

    public final int component28() {
        return this.deleteState;
    }

    public final long component29() {
        return this.version;
    }

    public final String component3() {
        return this.sn;
    }

    public final long component30() {
        return this.lastEditTime;
    }

    public final boolean component31() {
        return this.hasEdit;
    }

    public final List<TagEntity> component32() {
        return this.tagEntityList;
    }

    public final int component33() {
        return this.syncFailCount;
    }

    public final boolean component4() {
        return this.isGuide;
    }

    public final boolean component5() {
        return this.cloudHasTransFile;
    }

    public final long component6() {
        return this.duration;
    }

    public final long component7() {
        return this.fileSize;
    }

    public final int component8() {
        return this.audioChannelCount;
    }

    public final String component9() {
        return this.fileName;
    }

    public final RecordFileEntity copy(String str, long j10, String str2, boolean z10, boolean z11, long j11, long j12, int i10, String str3, String str4, String str5, String str6, String str7, String str8, boolean z12, String str9, int i11, int i12, List<TranscriptionData> list, int i13, String str10, String str11, String str12, List<String> list2, List<String> list3, int i14, boolean z13, int i15, long j13, long j14, boolean z14, List<TagEntity> list4, int i16) {
        String str13 = str;
        d0.g(str13, "key");
        d0.g(str2, "sn");
        d0.g(str3, "fileName");
        d0.g(str4, "fullName");
        d0.g(str5, "fileMD5");
        d0.g(str6, "filePath");
        d0.g(str7, "opusPath");
        d0.g(str8, "audioDbPath");
        d0.g(str9, "cloudId");
        d0.g(list, "transcription");
        d0.g(str10, "transcriptionErrorTip");
        d0.g(str11, "summaryErrorTip");
        d0.g(str12, "summary");
        d0.g(list2, "tagIdList");
        d0.g(list3, "keywords");
        d0.g(list4, "tagEntityList");
        return new RecordFileEntity(str13, j10, str2, z10, z11, j11, j12, i10, str3, str4, str5, str6, str7, str8, z12, str9, i11, i12, list, i13, str10, str11, str12, list2, list3, i14, z13, i15, j13, j14, z14, list4, i16);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof RecordFileEntity)) {
            return false;
        }
        RecordFileEntity recordFileEntity = (RecordFileEntity) obj;
        return d0.b(this.key, recordFileEntity.key) && this.sessionId == recordFileEntity.sessionId && d0.b(this.sn, recordFileEntity.sn) && this.isGuide == recordFileEntity.isGuide && this.cloudHasTransFile == recordFileEntity.cloudHasTransFile && this.duration == recordFileEntity.duration && this.fileSize == recordFileEntity.fileSize && this.audioChannelCount == recordFileEntity.audioChannelCount && d0.b(this.fileName, recordFileEntity.fileName) && d0.b(this.fullName, recordFileEntity.fullName) && d0.b(this.fileMD5, recordFileEntity.fileMD5) && d0.b(this.filePath, recordFileEntity.filePath) && d0.b(this.opusPath, recordFileEntity.opusPath) && d0.b(this.audioDbPath, recordFileEntity.audioDbPath) && this.isExisting == recordFileEntity.isExisting && d0.b(this.cloudId, recordFileEntity.cloudId) && this.timeZone == recordFileEntity.timeZone && this.timezoneMin == recordFileEntity.timezoneMin && d0.b(this.transcription, recordFileEntity.transcription) && this.transcriptionState == recordFileEntity.transcriptionState && d0.b(this.transcriptionErrorTip, recordFileEntity.transcriptionErrorTip) && d0.b(this.summaryErrorTip, recordFileEntity.summaryErrorTip) && d0.b(this.summary, recordFileEntity.summary) && d0.b(this.tagIdList, recordFileEntity.tagIdList) && d0.b(this.keywords, recordFileEntity.keywords) && this.scene == recordFileEntity.scene && this.isNew == recordFileEntity.isNew && this.deleteState == recordFileEntity.deleteState && this.version == recordFileEntity.version && this.lastEditTime == recordFileEntity.lastEditTime && this.hasEdit == recordFileEntity.hasEdit && d0.b(this.tagEntityList, recordFileEntity.tagEntityList) && this.syncFailCount == recordFileEntity.syncFailCount;
    }

    public final int getAudioChannelCount() {
        return this.audioChannelCount;
    }

    public final String getAudioDbPath() {
        return this.audioDbPath;
    }

    public final int getChannel() {
        int i10 = this.audioChannelCount;
        if (i10 <= 0) {
            return 1;
        }
        return i10;
    }

    public final boolean getCloudHasTransFile() {
        return this.cloudHasTransFile;
    }

    public final String getCloudId() {
        return this.cloudId;
    }

    public final int getDeleteState() {
        return this.deleteState;
    }

    public final long getDuration() {
        return this.duration;
    }

    public final String getFileMD5() {
        return this.fileMD5;
    }

    public final String getFileName() {
        return this.fileName;
    }

    public final String getFilePath() {
        return this.filePath;
    }

    public final long getFileSize() {
        return this.fileSize;
    }

    public final String getFullName() {
        return this.fullName;
    }

    public final boolean getHasEdit() {
        return this.hasEdit;
    }

    public final String getKey() {
        return this.key;
    }

    public final List<String> getKeywords() {
        return this.keywords;
    }

    public final long getLastEditTime() {
        return this.lastEditTime;
    }

    public final String getOpusPath() {
        return this.opusPath;
    }

    public final String getPath() {
        return e.c(this.opusPath) ? this.opusPath : this.filePath;
    }

    public final int getScene() {
        return this.scene;
    }

    public final long getSessionId() {
        return this.sessionId;
    }

    public final String getSn() {
        return this.sn;
    }

    public final String getSummary() {
        return this.summary;
    }

    public final String getSummaryErrorTip() {
        return this.summaryErrorTip;
    }

    public final int getSyncFailCount() {
        return this.syncFailCount;
    }

    public final List<TagEntity> getTagEntityList() {
        return this.tagEntityList;
    }

    public final List<String> getTagIdList() {
        return this.tagIdList;
    }

    public final int getTimeZone() {
        return this.timeZone;
    }

    public final int getTimezoneMin() {
        return this.timezoneMin;
    }

    public final List<TranscriptionData> getTranscription() {
        return this.transcription;
    }

    public final String getTranscriptionErrorTip() {
        return this.transcriptionErrorTip;
    }

    public final int getTranscriptionState() {
        return this.transcriptionState;
    }

    public final long getVersion() {
        return this.version;
    }

    public int hashCode() {
        long j10 = this.sessionId;
        int a10 = b.a(this.sn, ((this.key.hashCode() * 31) + ((int) (j10 ^ (j10 >>> 32)))) * 31, 31);
        boolean z10 = this.isGuide;
        boolean z11 = true;
        if (z10) {
            z10 = true;
        }
        int i10 = (a10 + (z10 ? 1 : 0)) * 31;
        boolean z12 = this.cloudHasTransFile;
        if (z12) {
            z12 = true;
        }
        long j11 = this.duration;
        long j12 = this.fileSize;
        int a11 = b.a(this.audioDbPath, b.a(this.opusPath, b.a(this.filePath, b.a(this.fileMD5, b.a(this.fullName, b.a(this.fileName, (((((((i10 + (z12 ? 1 : 0)) * 31) + ((int) (j11 ^ (j11 >>> 32)))) * 31) + ((int) (j12 ^ (j12 >>> 32)))) * 31) + this.audioChannelCount) * 31, 31), 31), 31), 31), 31), 31);
        boolean z13 = this.isExisting;
        if (z13) {
            z13 = true;
        }
        String str = this.cloudId;
        int a12 = (a.a(this.keywords, a.a(this.tagIdList, b.a(this.summary, b.a(this.summaryErrorTip, b.a(this.transcriptionErrorTip, (a.a(this.transcription, (((b.a(str, (a11 + (z13 ? 1 : 0)) * 31, 31) + this.timeZone) * 31) + this.timezoneMin) * 31, 31) + this.transcriptionState) * 31, 31), 31), 31), 31), 31) + this.scene) * 31;
        boolean z14 = this.isNew;
        if (z14) {
            z14 = true;
        }
        long j13 = this.version;
        long j14 = this.lastEditTime;
        int i11 = (((((((a12 + (z14 ? 1 : 0)) * 31) + this.deleteState) * 31) + ((int) (j13 ^ (j13 >>> 32)))) * 31) + ((int) (j14 ^ (j14 >>> 32)))) * 31;
        boolean z15 = this.hasEdit;
        if (!z15) {
            z11 = z15;
        }
        return a.a(this.tagEntityList, (i11 + (z11 ? 1 : 0)) * 31, 31) + this.syncFailCount;
    }

    public final boolean isExisting() {
        return this.isExisting;
    }

    public final boolean isGuide() {
        return this.isGuide;
    }

    public final boolean isNew() {
        return this.isNew;
    }

    public final boolean isRecording() {
        PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
        PreferencesUtil d10 = PreferencesUtil.d();
        Objects.requireNonNull(d10);
        d0.g("recording_session_key", "key");
        long c10 = d10.f1010a.c("recording_session_key");
        long j10 = this.sessionId;
        return c10 == j10 && j10 != 0;
    }

    public final RecordFileEntity makeNew() {
        String str = this.key;
        long j10 = this.sessionId;
        String str2 = this.sn;
        long j11 = this.duration;
        int i10 = this.audioChannelCount;
        String str3 = this.fileName;
        String str4 = this.filePath;
        String str5 = this.opusPath;
        String str6 = this.audioDbPath;
        boolean z10 = this.isExisting;
        String str7 = this.cloudId;
        List<TranscriptionData> list = this.transcription;
        int i11 = this.transcriptionState;
        String str8 = this.summary;
        List<String> list2 = this.tagIdList;
        List<TagEntity> list3 = this.tagEntityList;
        List<String> list4 = this.keywords;
        int i12 = this.timeZone;
        int i13 = this.timezoneMin;
        int i14 = this.deleteState;
        long j12 = this.fileSize;
        long j13 = this.lastEditTime;
        return new RecordFileEntity(str, j10, str2, this.isGuide, this.cloudHasTransFile, j11, j12, i10, str3, this.fullName, (String) null, str4, str5, str6, z10, str7, i12, i13, list, i11, (String) null, (String) null, str8, list2, list4, this.scene, this.isNew, i14, this.version, j13, this.hasEdit, list3, 0, 3146752, 1, (DefaultConstructorMarker) null);
    }

    public final void setAudioChannelCount(int i10) {
        this.audioChannelCount = i10;
    }

    public final void setAudioDbPath(String str) {
        d0.g(str, "<set-?>");
        this.audioDbPath = str;
    }

    public final void setCloudHasTransFile(boolean z10) {
        this.cloudHasTransFile = z10;
    }

    public final void setCloudId(String str) {
        d0.g(str, "<set-?>");
        this.cloudId = str;
    }

    public final void setDeleteState(int i10) {
        this.deleteState = i10;
    }

    public final void setDuration(long j10) {
        this.duration = j10;
    }

    public final void setExisting(boolean z10) {
        this.isExisting = z10;
    }

    public final void setFileMD5(String str) {
        d0.g(str, "<set-?>");
        this.fileMD5 = str;
    }

    public final void setFileName(String str) {
        d0.g(str, "<set-?>");
        this.fileName = str;
    }

    public final void setFilePath(String str) {
        d0.g(str, "<set-?>");
        this.filePath = str;
    }

    public final void setFileSize(long j10) {
        this.fileSize = j10;
    }

    public final void setFullName(String str) {
        d0.g(str, "<set-?>");
        this.fullName = str;
    }

    public final void setGuide(boolean z10) {
        this.isGuide = z10;
    }

    public final void setHasEdit(boolean z10) {
        this.hasEdit = z10;
    }

    public final void setKey(String str) {
        d0.g(str, "<set-?>");
        this.key = str;
    }

    public final void setKeywords(List<String> list) {
        d0.g(list, "<set-?>");
        this.keywords = list;
    }

    public final void setLastEditTime(long j10) {
        this.lastEditTime = j10;
    }

    public final void setNew(boolean z10) {
        this.isNew = z10;
    }

    public final void setOpusPath(String str) {
        d0.g(str, "<set-?>");
        this.opusPath = str;
    }

    public final void setScene(int i10) {
        this.scene = i10;
    }

    public final void setSessionId(long j10) {
        this.sessionId = j10;
    }

    public final void setSn(String str) {
        d0.g(str, "<set-?>");
        this.sn = str;
    }

    public final void setSummary(String str) {
        d0.g(str, "<set-?>");
        this.summary = str;
    }

    public final void setSummaryErrorTip(String str) {
        d0.g(str, "<set-?>");
        this.summaryErrorTip = str;
    }

    public final void setSyncFailCount(int i10) {
        this.syncFailCount = i10;
    }

    public final void setTagEntityList(List<TagEntity> list) {
        d0.g(list, "<set-?>");
        this.tagEntityList = list;
    }

    public final void setTagIdList(List<String> list) {
        d0.g(list, "<set-?>");
        this.tagIdList = list;
    }

    public final void setTimeZone(int i10) {
        this.timeZone = i10;
    }

    public final void setTimezoneMin(int i10) {
        this.timezoneMin = i10;
    }

    public final void setTranscription(List<TranscriptionData> list) {
        d0.g(list, "<set-?>");
        this.transcription = list;
    }

    public final void setTranscriptionErrorTip(String str) {
        d0.g(str, "<set-?>");
        this.transcriptionErrorTip = str;
    }

    public final void setTranscriptionState(int i10) {
        this.transcriptionState = i10;
    }

    public final void setVersion(long j10) {
        this.version = j10;
    }

    public String toString() {
        String str = this.key;
        long j10 = this.sessionId;
        String str2 = this.sn;
        boolean z10 = this.isGuide;
        boolean z11 = this.cloudHasTransFile;
        long j11 = this.duration;
        long j12 = this.fileSize;
        int i10 = this.audioChannelCount;
        String str3 = this.fileName;
        String str4 = this.fullName;
        String str5 = this.fileMD5;
        String str6 = this.filePath;
        String str7 = this.opusPath;
        String str8 = this.audioDbPath;
        boolean z12 = this.isExisting;
        String str9 = this.cloudId;
        int i11 = this.timeZone;
        int i12 = this.timezoneMin;
        List<TranscriptionData> list = this.transcription;
        int i13 = this.transcriptionState;
        String str10 = this.transcriptionErrorTip;
        String str11 = this.summaryErrorTip;
        String str12 = this.summary;
        List<String> list2 = this.tagIdList;
        List<String> list3 = this.keywords;
        int i14 = this.scene;
        boolean z13 = this.isNew;
        String str13 = str5;
        int i15 = this.deleteState;
        long j13 = this.version;
        long j14 = this.lastEditTime;
        boolean z14 = this.hasEdit;
        List<TagEntity> list4 = this.tagEntityList;
        int i16 = this.syncFailCount;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("RecordFileEntity(key=");
        sb2.append(str);
        sb2.append(", sessionId=");
        sb2.append(j10);
        sb2.append(", sn=");
        sb2.append(str2);
        sb2.append(", isGuide=");
        sb2.append(z10);
        sb2.append(", cloudHasTransFile=");
        sb2.append(z11);
        sb2.append(", duration=");
        sb2.append(j11);
        sb2.append(", fileSize=");
        sb2.append(j12);
        sb2.append(", audioChannelCount=");
        sb2.append(i10);
        sb2.append(", fileName=");
        sb2.append(str3);
        sb2.append(", fullName=");
        sb2.append(str4);
        sb2.append(", fileMD5=");
        sb2.append(str13);
        sb2.append(", filePath=");
        sb2.append(str6);
        sb2.append(", opusPath=");
        sb2.append(str7);
        sb2.append(", audioDbPath=");
        sb2.append(str8);
        sb2.append(", isExisting=");
        sb2.append(z12);
        sb2.append(", cloudId=");
        sb2.append(str9);
        sb2.append(", timeZone=");
        sb2.append(i11);
        sb2.append(", timezoneMin=");
        sb2.append(i12);
        sb2.append(", transcription=");
        sb2.append(list);
        sb2.append(", transcriptionState=");
        sb2.append(i13);
        sb2.append(", transcriptionErrorTip=");
        sb2.append(str10);
        sb2.append(", summaryErrorTip=");
        sb2.append(str11);
        sb2.append(", summary=");
        sb2.append(str12);
        sb2.append(", tagIdList=");
        sb2.append(list2);
        sb2.append(", keywords=");
        sb2.append(list3);
        sb2.append(", scene=");
        sb2.append(i14);
        sb2.append(", isNew=");
        sb2.append(z13);
        sb2.append(", deleteState=");
        sb2.append(i15);
        sb2.append(", version=");
        sb2.append(j13);
        sb2.append(", lastEditTime=");
        sb2.append(j14);
        sb2.append(", hasEdit=");
        sb2.append(z14);
        sb2.append(", tagEntityList=");
        sb2.append(list4);
        sb2.append(", syncFailCount=");
        return b.a(sb2, i16, ")");
    }

    public void writeToParcel(Parcel parcel, int i10) {
        d0.g(parcel, "out");
        parcel.writeString(this.key);
        parcel.writeLong(this.sessionId);
        parcel.writeString(this.sn);
        parcel.writeInt(this.isGuide ? 1 : 0);
        parcel.writeInt(this.cloudHasTransFile ? 1 : 0);
        parcel.writeLong(this.duration);
        parcel.writeLong(this.fileSize);
        parcel.writeInt(this.audioChannelCount);
        parcel.writeString(this.fileName);
        parcel.writeString(this.fullName);
        parcel.writeString(this.fileMD5);
        parcel.writeString(this.filePath);
        parcel.writeString(this.opusPath);
        parcel.writeString(this.audioDbPath);
        parcel.writeInt(this.isExisting ? 1 : 0);
        parcel.writeString(this.cloudId);
        parcel.writeInt(this.timeZone);
        parcel.writeInt(this.timezoneMin);
        List<TranscriptionData> list = this.transcription;
        parcel.writeInt(list.size());
        for (TranscriptionData writeToParcel : list) {
            writeToParcel.writeToParcel(parcel, i10);
        }
        parcel.writeInt(this.transcriptionState);
        parcel.writeString(this.transcriptionErrorTip);
        parcel.writeString(this.summaryErrorTip);
        parcel.writeString(this.summary);
        parcel.writeStringList(this.tagIdList);
        parcel.writeStringList(this.keywords);
        parcel.writeInt(this.scene);
        parcel.writeInt(this.isNew ? 1 : 0);
        parcel.writeInt(this.deleteState);
        parcel.writeLong(this.version);
        parcel.writeLong(this.lastEditTime);
        parcel.writeInt(this.hasEdit ? 1 : 0);
        List<TagEntity> list2 = this.tagEntityList;
        parcel.writeInt(list2.size());
        for (TagEntity writeToParcel2 : list2) {
            writeToParcel2.writeToParcel(parcel, i10);
        }
        parcel.writeInt(this.syncFailCount);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public RecordFileEntity(java.lang.String r38, long r39, java.lang.String r41, boolean r42, boolean r43, long r44, long r46, int r48, java.lang.String r49, java.lang.String r50, java.lang.String r51, java.lang.String r52, java.lang.String r53, java.lang.String r54, boolean r55, java.lang.String r56, int r57, int r58, java.util.List r59, int r60, java.lang.String r61, java.lang.String r62, java.lang.String r63, java.util.List r64, java.util.List r65, int r66, boolean r67, int r68, long r69, long r71, boolean r73, java.util.List r74, int r75, int r76, int r77, kotlin.jvm.internal.DefaultConstructorMarker r78) {
        /*
            r37 = this;
            r0 = r76
            java.lang.Class<x.a> r1 = x.a.class
            r2 = r0 & 1
            if (r2 == 0) goto L_0x000b
            java.lang.String r2 = ""
            goto L_0x000d
        L_0x000b:
            r2 = r38
        L_0x000d:
            r3 = r0 & 2
            if (r3 == 0) goto L_0x0014
            r3 = 0
            goto L_0x0016
        L_0x0014:
            r3 = r39
        L_0x0016:
            r5 = r0 & 4
            if (r5 == 0) goto L_0x001d
            java.lang.String r5 = ""
            goto L_0x001f
        L_0x001d:
            r5 = r41
        L_0x001f:
            r6 = r0 & 8
            if (r6 == 0) goto L_0x0025
            r6 = 0
            goto L_0x0027
        L_0x0025:
            r6 = r42
        L_0x0027:
            r7 = r0 & 16
            if (r7 == 0) goto L_0x002d
            r7 = 0
            goto L_0x002f
        L_0x002d:
            r7 = r43
        L_0x002f:
            r8 = r0 & 32
            if (r8 == 0) goto L_0x0036
            r8 = 0
            goto L_0x0038
        L_0x0036:
            r8 = r44
        L_0x0038:
            r10 = r0 & 64
            if (r10 == 0) goto L_0x003f
            r10 = 0
            goto L_0x0041
        L_0x003f:
            r10 = r46
        L_0x0041:
            r12 = r0 & 128(0x80, float:1.794E-43)
            if (r12 == 0) goto L_0x0047
            r12 = 1
            goto L_0x0049
        L_0x0047:
            r12 = r48
        L_0x0049:
            r13 = r0 & 256(0x100, float:3.59E-43)
            r14 = 0
            if (r13 == 0) goto L_0x0084
            x.a r13 = x.a.f18241b
            if (r13 != 0) goto L_0x0063
            monitor-enter(r1)
            x.a r13 = x.a.f18241b     // Catch:{ all -> 0x0060 }
            if (r13 != 0) goto L_0x005e
            x.a r13 = new x.a     // Catch:{ all -> 0x0060 }
            r13.<init>(r14)     // Catch:{ all -> 0x0060 }
            x.a.f18241b = r13     // Catch:{ all -> 0x0060 }
        L_0x005e:
            monitor-exit(r1)
            goto L_0x0063
        L_0x0060:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
        L_0x0063:
            x.a r13 = x.a.f18241b
            rg.d0.d(r13)
            java.text.SimpleDateFormat r14 = r13.f18242a
            java.util.TimeZone r15 = java.util.TimeZone.getDefault()
            r14.setTimeZone(r15)
            java.text.SimpleDateFormat r13 = r13.f18242a
            r14 = 1000(0x3e8, double:4.94E-321)
            long r14 = r14 * r3
            java.lang.Long r14 = java.lang.Long.valueOf(r14)
            java.lang.String r13 = r13.format(r14)
            java.lang.String r14 = "defaultDateFormat.format(sessionId * 1000L)"
            rg.d0.f(r13, r14)
            goto L_0x0086
        L_0x0084:
            r13 = r49
        L_0x0086:
            r14 = r0 & 512(0x200, float:7.175E-43)
            if (r14 == 0) goto L_0x008d
            java.lang.String r14 = ""
            goto L_0x008f
        L_0x008d:
            r14 = r50
        L_0x008f:
            r15 = r0 & 1024(0x400, float:1.435E-42)
            if (r15 == 0) goto L_0x0096
            java.lang.String r15 = ""
            goto L_0x0098
        L_0x0096:
            r15 = r51
        L_0x0098:
            r78 = r15
            r15 = r0 & 2048(0x800, float:2.87E-42)
            if (r15 == 0) goto L_0x00c5
            x.a r15 = x.a.f18241b
            if (r15 != 0) goto L_0x00b9
            monitor-enter(r1)
            x.a r15 = x.a.f18241b     // Catch:{ all -> 0x00b6 }
            if (r15 != 0) goto L_0x00b2
            x.a r15 = new x.a     // Catch:{ all -> 0x00b6 }
            r16 = r14
            r14 = 0
            r15.<init>(r14)     // Catch:{ all -> 0x00b6 }
            x.a.f18241b = r15     // Catch:{ all -> 0x00b6 }
            goto L_0x00b4
        L_0x00b2:
            r16 = r14
        L_0x00b4:
            monitor-exit(r1)
            goto L_0x00bb
        L_0x00b6:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
        L_0x00b9:
            r16 = r14
        L_0x00bb:
            x.a r14 = x.a.f18241b
            rg.d0.d(r14)
            java.lang.String r14 = r14.a(r5, r3)
            goto L_0x00c9
        L_0x00c5:
            r16 = r14
            r14 = r52
        L_0x00c9:
            r15 = r0 & 4096(0x1000, float:5.74E-42)
            if (r15 == 0) goto L_0x00f4
            x.a r15 = x.a.f18241b
            if (r15 != 0) goto L_0x00e8
            monitor-enter(r1)
            x.a r15 = x.a.f18241b     // Catch:{ all -> 0x00e5 }
            if (r15 != 0) goto L_0x00e1
            x.a r15 = new x.a     // Catch:{ all -> 0x00e5 }
            r17 = r14
            r14 = 0
            r15.<init>(r14)     // Catch:{ all -> 0x00e5 }
            x.a.f18241b = r15     // Catch:{ all -> 0x00e5 }
            goto L_0x00e3
        L_0x00e1:
            r17 = r14
        L_0x00e3:
            monitor-exit(r1)
            goto L_0x00ea
        L_0x00e5:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
        L_0x00e8:
            r17 = r14
        L_0x00ea:
            x.a r14 = x.a.f18241b
            rg.d0.d(r14)
            java.lang.String r14 = r14.a(r5, r3)
            goto L_0x00f8
        L_0x00f4:
            r17 = r14
            r14 = r53
        L_0x00f8:
            r15 = r0 & 8192(0x2000, float:1.14794E-41)
            if (r15 == 0) goto L_0x014e
            x.a r15 = x.a.f18241b
            if (r15 != 0) goto L_0x0117
            monitor-enter(r1)
            x.a r15 = x.a.f18241b     // Catch:{ all -> 0x0114 }
            if (r15 != 0) goto L_0x0110
            x.a r15 = new x.a     // Catch:{ all -> 0x0114 }
            r18 = r14
            r14 = 0
            r15.<init>(r14)     // Catch:{ all -> 0x0114 }
            x.a.f18241b = r15     // Catch:{ all -> 0x0114 }
            goto L_0x0112
        L_0x0110:
            r18 = r14
        L_0x0112:
            monitor-exit(r1)
            goto L_0x0119
        L_0x0114:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
        L_0x0117:
            r18 = r14
        L_0x0119:
            x.a r1 = x.a.f18241b
            rg.d0.d(r1)
            java.lang.String r1 = "sn"
            rg.d0.g(r5, r1)
            x.f r1 = x.f.f18251a
            java.lang.String r1 = x.f.a()
            java.lang.String r14 = java.io.File.separator
            java.lang.String r15 = "recordDbFiles"
            java.lang.String r1 = b.b.a(r1, r15, r14)
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            r14.append(r1)
            r14.append(r5)
            java.lang.String r1 = "_"
            r14.append(r1)
            r14.append(r3)
            java.lang.String r1 = "_audio.db"
            r14.append(r1)
            java.lang.String r1 = r14.toString()
            goto L_0x0152
        L_0x014e:
            r18 = r14
            r1 = r54
        L_0x0152:
            r14 = r0 & 16384(0x4000, float:2.2959E-41)
            if (r14 == 0) goto L_0x0158
            r14 = 0
            goto L_0x015a
        L_0x0158:
            r14 = r55
        L_0x015a:
            r15 = 32768(0x8000, float:4.5918E-41)
            r15 = r15 & r0
            if (r15 == 0) goto L_0x0163
            java.lang.String r15 = ""
            goto L_0x0165
        L_0x0163:
            r15 = r56
        L_0x0165:
            r19 = 65536(0x10000, float:9.18355E-41)
            r19 = r0 & r19
            if (r19 == 0) goto L_0x016e
            r19 = 8
            goto L_0x0170
        L_0x016e:
            r19 = r57
        L_0x0170:
            r20 = 131072(0x20000, float:1.83671E-40)
            r20 = r0 & r20
            if (r20 == 0) goto L_0x0179
            r20 = 0
            goto L_0x017b
        L_0x0179:
            r20 = r58
        L_0x017b:
            r21 = 262144(0x40000, float:3.67342E-40)
            r21 = r0 & r21
            if (r21 == 0) goto L_0x0187
            java.util.ArrayList r21 = new java.util.ArrayList
            r21.<init>()
            goto L_0x0189
        L_0x0187:
            r21 = r59
        L_0x0189:
            r22 = 524288(0x80000, float:7.34684E-40)
            r22 = r0 & r22
            if (r22 == 0) goto L_0x0196
            ai.plaud.android.plaud.anew.database.recordfile.TranscriptionState r22 = ai.plaud.android.plaud.anew.database.recordfile.TranscriptionState.IDLE
            int r22 = r22.getValue()
            goto L_0x0198
        L_0x0196:
            r22 = r60
        L_0x0198:
            r23 = 1048576(0x100000, float:1.469368E-39)
            r23 = r0 & r23
            if (r23 == 0) goto L_0x01a1
            java.lang.String r23 = ""
            goto L_0x01a3
        L_0x01a1:
            r23 = r61
        L_0x01a3:
            r24 = 2097152(0x200000, float:2.938736E-39)
            r24 = r0 & r24
            if (r24 == 0) goto L_0x01ac
            java.lang.String r24 = ""
            goto L_0x01ae
        L_0x01ac:
            r24 = r62
        L_0x01ae:
            r25 = 4194304(0x400000, float:5.877472E-39)
            r25 = r0 & r25
            if (r25 == 0) goto L_0x01b7
            java.lang.String r25 = ""
            goto L_0x01b9
        L_0x01b7:
            r25 = r63
        L_0x01b9:
            r26 = 8388608(0x800000, float:1.17549435E-38)
            r26 = r0 & r26
            if (r26 == 0) goto L_0x01c5
            java.util.ArrayList r26 = new java.util.ArrayList
            r26.<init>()
            goto L_0x01c7
        L_0x01c5:
            r26 = r64
        L_0x01c7:
            r27 = 16777216(0x1000000, float:2.3509887E-38)
            r27 = r0 & r27
            if (r27 == 0) goto L_0x01d3
            java.util.ArrayList r27 = new java.util.ArrayList
            r27.<init>()
            goto L_0x01d5
        L_0x01d3:
            r27 = r65
        L_0x01d5:
            r28 = 33554432(0x2000000, float:9.403955E-38)
            r28 = r0 & r28
            if (r28 == 0) goto L_0x01de
            r28 = 1
            goto L_0x01e0
        L_0x01de:
            r28 = r66
        L_0x01e0:
            r29 = 67108864(0x4000000, float:1.5046328E-36)
            r29 = r0 & r29
            if (r29 == 0) goto L_0x01e9
            r29 = 1
            goto L_0x01eb
        L_0x01e9:
            r29 = r67
        L_0x01eb:
            r30 = 134217728(0x8000000, float:3.85186E-34)
            r30 = r0 & r30
            if (r30 == 0) goto L_0x01f8
            ai.plaud.android.plaud.anew.database.recordfile.DeleteState r30 = ai.plaud.android.plaud.anew.database.recordfile.DeleteState.NONE
            int r30 = r30.getValue()
            goto L_0x01fa
        L_0x01f8:
            r30 = r68
        L_0x01fa:
            r31 = 268435456(0x10000000, float:2.5243549E-29)
            r31 = r0 & r31
            if (r31 == 0) goto L_0x0203
            r31 = 0
            goto L_0x0205
        L_0x0203:
            r31 = r69
        L_0x0205:
            r33 = 536870912(0x20000000, float:1.0842022E-19)
            r33 = r0 & r33
            if (r33 == 0) goto L_0x0210
            r33 = 1000(0x3e8, double:4.94E-321)
            long r33 = r33 * r3
            goto L_0x0212
        L_0x0210:
            r33 = r71
        L_0x0212:
            r35 = 1073741824(0x40000000, float:2.0)
            r35 = r0 & r35
            if (r35 == 0) goto L_0x021b
            r35 = 0
            goto L_0x021d
        L_0x021b:
            r35 = r73
        L_0x021d:
            r36 = -2147483648(0xffffffff80000000, float:-0.0)
            r0 = r0 & r36
            if (r0 == 0) goto L_0x0229
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            goto L_0x022b
        L_0x0229:
            r0 = r74
        L_0x022b:
            r36 = r77 & 1
            if (r36 == 0) goto L_0x0232
            r36 = 0
            goto L_0x0234
        L_0x0232:
            r36 = r75
        L_0x0234:
            r38 = r37
            r39 = r2
            r40 = r3
            r42 = r5
            r43 = r6
            r44 = r7
            r45 = r8
            r47 = r10
            r49 = r12
            r50 = r13
            r51 = r16
            r52 = r78
            r53 = r17
            r54 = r18
            r55 = r1
            r56 = r14
            r57 = r15
            r58 = r19
            r59 = r20
            r60 = r21
            r61 = r22
            r62 = r23
            r63 = r24
            r64 = r25
            r65 = r26
            r66 = r27
            r67 = r28
            r68 = r29
            r69 = r30
            r70 = r31
            r72 = r33
            r74 = r35
            r75 = r0
            r76 = r36
            r38.<init>(r39, r40, r42, r43, r44, r45, r47, r49, r50, r51, r52, r53, r54, r55, r56, r57, r58, r59, r60, r61, r62, r63, r64, r65, r66, r67, r68, r69, r70, r72, r74, r75, r76)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.database.recordfile.RecordFileEntity.<init>(java.lang.String, long, java.lang.String, boolean, boolean, long, long, int, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, boolean, java.lang.String, int, int, java.util.List, int, java.lang.String, java.lang.String, java.lang.String, java.util.List, java.util.List, int, boolean, int, long, long, boolean, java.util.List, int, int, int, kotlin.jvm.internal.DefaultConstructorMarker):void");
    }
}
