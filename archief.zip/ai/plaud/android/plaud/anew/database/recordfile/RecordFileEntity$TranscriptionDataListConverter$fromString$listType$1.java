package ai.plaud.android.plaud.anew.database.recordfile;

import ai.plaud.android.plaud.anew.api.bean.TranscriptionData;
import com.google.common.reflect.TypeToken;
import java.util.List;

/* compiled from: RecordFileEntity.kt */
public final class RecordFileEntity$TranscriptionDataListConverter$fromString$listType$1 extends TypeToken<List<? extends TranscriptionData>> {
}
