package ai.plaud.android.plaud.anew.database.recordfile;

import java.util.List;

public final /* synthetic */ class a {
    public static int a(List list, int i10, int i11) {
        return (list.hashCode() + i10) * i11;
    }
}
