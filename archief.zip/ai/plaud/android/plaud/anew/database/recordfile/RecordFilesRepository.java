package ai.plaud.android.plaud.anew.database.recordfile;

import ag.c;
import ai.plaud.android.plaud.anew.database.PlaudDatabase;
import ci.a;
import java.util.List;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.DefaultConstructorMarker;
import xf.d;
import xf.e;

/* compiled from: RecordFilesRepository.kt */
public final class RecordFilesRepository {
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
    /* access modifiers changed from: private */
    public static final d<RecordFilesRepository> INSTANCE$delegate = e.a(RecordFilesRepository$Companion$INSTANCE$2.INSTANCE);
    private static final String USER_ID_WARN = "username 是空的，请检查代码是否正确";

    /* compiled from: RecordFilesRepository.kt */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final RecordFilesRepository getINSTANCE() {
            return (RecordFilesRepository) RecordFilesRepository.INSTANCE$delegate.getValue();
        }
    }

    private RecordFilesRepository() {
    }

    public /* synthetic */ RecordFilesRepository(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    public final Object getFileByKey(String str, c<? super List<RecordFileEntity>> cVar) {
        return PlaudDatabase.Companion.recordFilesDao().getRecordFileByKey(str, cVar);
    }

    public final Object loadAllRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar) {
        if (str.length() > 0) {
            return PlaudDatabase.Companion.recordFilesDao().loadAllRecordFilesByUser(str, cVar);
        }
        a.f4931a.g(USER_ID_WARN, new Object[0]);
        return EmptyList.INSTANCE;
    }
}
