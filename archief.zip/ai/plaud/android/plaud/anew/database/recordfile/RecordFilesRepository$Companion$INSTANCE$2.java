package ai.plaud.android.plaud.anew.database.recordfile;

import gg.a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Lambda;

/* compiled from: RecordFilesRepository.kt */
public final class RecordFilesRepository$Companion$INSTANCE$2 extends Lambda implements a<RecordFilesRepository> {
    public static final RecordFilesRepository$Companion$INSTANCE$2 INSTANCE = new RecordFilesRepository$Companion$INSTANCE$2();

    public RecordFilesRepository$Companion$INSTANCE$2() {
        super(0);
    }

    public final RecordFilesRepository invoke() {
        return new RecordFilesRepository((DefaultConstructorMarker) null);
    }
}
