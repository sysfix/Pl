package ai.plaud.android.plaud.anew.database.recordfile;

import ag.c;
import ai.plaud.android.plaud.anew.api.bean.TranscriptionData;
import androidx.lifecycle.LiveData;
import java.util.List;
import xf.g;

/* compiled from: RecordFilesDao.kt */
public interface RecordFilesDao {
    Object deleteAllRecordFiles(String str, String str2, c<? super g> cVar);

    Object deleteAllRecordFiles(String str, List<String> list, c<? super g> cVar);

    Object deleteAllUserRecordFiles(String str, c<? super g> cVar);

    Object deleteRecordFiles(List<RecordFileEntity> list, c<? super g> cVar);

    Object deleteRecordFiles(RecordFileEntity[] recordFileEntityArr, c<? super g> cVar);

    Object getAllRecordFilesQuantity(c<? super Integer> cVar);

    Object getAllRecordFilesQuantityByUser(String str, c<? super Integer> cVar);

    Object getFileByFileId(String str, c<? super List<RecordFileEntity>> cVar);

    Object getRecordFileByKey(String str, c<? super List<RecordFileEntity>> cVar);

    Object getSpecifyAllRecordFilesQuantityByUser(String str, String str2, c<? super Integer> cVar);

    Object insertRecordFiles(List<RecordFileEntity> list, c<? super g> cVar);

    Object insertRecordFiles(RecordFileEntity[] recordFileEntityArr, c<? super g> cVar);

    Object loadAllCloudRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar);

    Object loadAllRecordFiles(c<? super List<RecordFileEntity>> cVar);

    Object loadAllRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar);

    Object loadDeleteRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar);

    Object loadNormalRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar);

    Object loadNormalRecordFilesByUserASC(String str, c<? super List<RecordFileEntity>> cVar);

    Object loadNormalRecordFilesOrderByEdited(String str, c<? super List<RecordFileEntity>> cVar);

    Object loadNormalRecordFilesOrderByEditedASC(String str, c<? super List<RecordFileEntity>> cVar);

    Object loadTrashRecordFilesByUser(String str, c<? super List<RecordFileEntity>> cVar);

    LiveData<List<RecordFileEntity>> observedAllRecordFiles();

    LiveData<List<RecordFileEntity>> observedAllRecordFilesByUser(String str);

    Object searchAllRecordFilesByContent(String str, String str2, c<? super List<RecordFileEntity>> cVar);

    Object updateCloudHasRaw(String str, boolean z10, c<? super g> cVar);

    Object updateCloudId(String str, String str2, c<? super g> cVar);

    Object updateDeleteState(String str, int i10, c<? super g> cVar);

    Object updateFileMD5(String str, String str2, c<? super g> cVar);

    Object updateFileName(String str, String str2, c<? super g> cVar);

    Object updateFilePath(String str, String str2, c<? super g> cVar);

    Object updateFullName(String str, String str2, c<? super g> cVar);

    Object updateHasEdit(String str, boolean z10, c<? super g> cVar);

    Object updateHasTransFile(String str, boolean z10, c<? super g> cVar);

    Object updateIsExist(String str, boolean z10, c<? super g> cVar);

    Object updateIsNew(String str, boolean z10, c<? super g> cVar);

    Object updateKeywords(String str, List<String> list, c<? super g> cVar);

    Object updateLastEditTime(String str, long j10, c<? super g> cVar);

    Object updateRecordFiles(RecordFileEntity[] recordFileEntityArr, c<? super g> cVar);

    Object updateSummary(String str, String str2, c<? super g> cVar);

    Object updateSummaryErrorTip(String str, String str2, c<? super g> cVar);

    Object updateTagIdList(String str, List<String> list, c<? super g> cVar);

    Object updateTransContent(String str, List<TranscriptionData> list, c<? super g> cVar);

    Object updateTransErrorTip(String str, String str2, c<? super g> cVar);

    Object updateTransState(String str, int i10, c<? super g> cVar);

    Object updateVersion(String str, long j10, c<? super g> cVar);
}
