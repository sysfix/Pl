package ai.plaud.android.plaud.anew.database.recordfile;

public final /* synthetic */ class b {
    public static String a(StringBuilder sb2, int i10, String str) {
        sb2.append(i10);
        sb2.append(str);
        return sb2.toString();
    }
}
