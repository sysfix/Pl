package ai.plaud.android.plaud.anew.database.recordfile;

import com.google.common.reflect.TypeToken;
import java.util.List;

/* compiled from: RecordFileEntity.kt */
public final class RecordFileEntity$StringListConverter$fromString$listType$1 extends TypeToken<List<? extends String>> {
}
