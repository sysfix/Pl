package ai.plaud.android.plaud.anew.database.recordfile;

/* compiled from: RecordFileEntity.kt */
public enum DeleteState {
    NONE(0),
    IN_TRASH(1),
    GONE(2);
    
    private final int value;

    private DeleteState(int i10) {
        this.value = i10;
    }

    public final int getValue() {
        return this.value;
    }
}
