package ai.plaud.android.plaud.anew.database;

import ai.plaud.android.plaud.anew.database.recordfile.RecordFilesDao;
import ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataDao;
import ai.plaud.android.plaud.common.util.AppProvider;
import androidx.room.RoomDatabase;
import androidx.room.g;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* compiled from: PlaudDatabase.kt */
public abstract class PlaudDatabase extends RoomDatabase {
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
    /* access modifiers changed from: private */
    public static final PlaudDatabase DB;

    /* compiled from: PlaudDatabase.kt */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final RecordFilesDao recordFilesDao() {
            return PlaudDatabase.DB.recordFilesDao();
        }

        public final TranscriptionDataDao transcriptionDataDao() {
            return PlaudDatabase.DB.transcriptionDataDao();
        }
    }

    static {
        RoomDatabase.a<PlaudDatabase> a10 = g.a(AppProvider.a(), PlaudDatabase.class, "plaud-database");
        a10.f3780j = false;
        a10.f3781k = true;
        DB = a10.b();
    }

    public abstract RecordFilesDao recordFilesDao();

    public abstract TranscriptionDataDao transcriptionDataDao();
}
