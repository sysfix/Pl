package ai.plaud.android.plaud.anew.database;

import n2.b;
import q2.a;

class PlaudDatabase_AutoMigration_1_2_Impl extends b {
    public PlaudDatabase_AutoMigration_1_2_Impl() {
        super(1, 2);
    }

    public void migrate(a aVar) {
        aVar.I("CREATE TABLE IF NOT EXISTS `transcription_data` (`record_file_key` TEXT NOT NULL, `trans_lan` TEXT NOT NULL, `trans_summary_type` TEXT NOT NULL, `post_id` INTEGER NOT NULL, PRIMARY KEY(`record_file_key`))");
    }
}
