package ai.plaud.android.plaud.anew.flutter.bean;

import c.b;
import h.a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import rg.d0;

/* compiled from: FlutterResultData.kt */
public final class FlutterResultData {
    private Object data;
    private String msg;
    private int status;

    public FlutterResultData() {
        this(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null);
    }

    public FlutterResultData(int i10, String str, Object obj) {
        d0.g(str, "msg");
        this.status = i10;
        this.msg = str;
        this.data = obj;
    }

    public static /* synthetic */ FlutterResultData copy$default(FlutterResultData flutterResultData, int i10, String str, Object obj, int i11, Object obj2) {
        if ((i11 & 1) != 0) {
            i10 = flutterResultData.status;
        }
        if ((i11 & 2) != 0) {
            str = flutterResultData.msg;
        }
        if ((i11 & 4) != 0) {
            obj = flutterResultData.data;
        }
        return flutterResultData.copy(i10, str, obj);
    }

    public final int component1() {
        return this.status;
    }

    public final String component2() {
        return this.msg;
    }

    public final Object component3() {
        return this.data;
    }

    public final FlutterResultData copy(int i10, String str, Object obj) {
        d0.g(str, "msg");
        return new FlutterResultData(i10, str, obj);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FlutterResultData)) {
            return false;
        }
        FlutterResultData flutterResultData = (FlutterResultData) obj;
        return this.status == flutterResultData.status && d0.b(this.msg, flutterResultData.msg) && d0.b(this.data, flutterResultData.data);
    }

    public final Object getData() {
        return this.data;
    }

    public final String getMsg() {
        return this.msg;
    }

    public final int getStatus() {
        return this.status;
    }

    public int hashCode() {
        int a10 = b.a(this.msg, this.status * 31, 31);
        Object obj = this.data;
        return a10 + (obj == null ? 0 : obj.hashCode());
    }

    public final void setData(Object obj) {
        this.data = obj;
    }

    public final void setMsg(String str) {
        d0.g(str, "<set-?>");
        this.msg = str;
    }

    public final void setStatus(int i10) {
        this.status = i10;
    }

    public String toString() {
        int i10 = this.status;
        String str = this.msg;
        Object obj = this.data;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("FlutterResultData(status=");
        sb2.append(i10);
        sb2.append(", msg=");
        sb2.append(str);
        sb2.append(", data=");
        return a.a(sb2, obj, ")");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ FlutterResultData(int i10, String str, Object obj, int i11, DefaultConstructorMarker defaultConstructorMarker) {
        this((i11 & 1) != 0 ? 0 : i10, (i11 & 2) != 0 ? "success" : str, (i11 & 4) != 0 ? null : obj);
    }
}
