package ai.plaud.android.plaud.anew.flutter.bean;

import c.b;
import c.e;
import rg.d0;

/* compiled from: FlutterAudioData.kt */
public final class FlutterAudioData {
    private String audioPath;
    private String audioType;
    private int duration;
    private String fileKey;

    public FlutterAudioData(String str, String str2, String str3, int i10) {
        d0.g(str, "fileKey");
        d0.g(str2, "audioPath");
        d0.g(str3, "audioType");
        this.fileKey = str;
        this.audioPath = str2;
        this.audioType = str3;
        this.duration = i10;
    }

    public static /* synthetic */ FlutterAudioData copy$default(FlutterAudioData flutterAudioData, String str, String str2, String str3, int i10, int i11, Object obj) {
        if ((i11 & 1) != 0) {
            str = flutterAudioData.fileKey;
        }
        if ((i11 & 2) != 0) {
            str2 = flutterAudioData.audioPath;
        }
        if ((i11 & 4) != 0) {
            str3 = flutterAudioData.audioType;
        }
        if ((i11 & 8) != 0) {
            i10 = flutterAudioData.duration;
        }
        return flutterAudioData.copy(str, str2, str3, i10);
    }

    public final String component1() {
        return this.fileKey;
    }

    public final String component2() {
        return this.audioPath;
    }

    public final String component3() {
        return this.audioType;
    }

    public final int component4() {
        return this.duration;
    }

    public final FlutterAudioData copy(String str, String str2, String str3, int i10) {
        d0.g(str, "fileKey");
        d0.g(str2, "audioPath");
        d0.g(str3, "audioType");
        return new FlutterAudioData(str, str2, str3, i10);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FlutterAudioData)) {
            return false;
        }
        FlutterAudioData flutterAudioData = (FlutterAudioData) obj;
        return d0.b(this.fileKey, flutterAudioData.fileKey) && d0.b(this.audioPath, flutterAudioData.audioPath) && d0.b(this.audioType, flutterAudioData.audioType) && this.duration == flutterAudioData.duration;
    }

    public final String getAudioPath() {
        return this.audioPath;
    }

    public final String getAudioType() {
        return this.audioType;
    }

    public final int getDuration() {
        return this.duration;
    }

    public final String getFileKey() {
        return this.fileKey;
    }

    public int hashCode() {
        return b.a(this.audioType, b.a(this.audioPath, this.fileKey.hashCode() * 31, 31), 31) + this.duration;
    }

    public final void setAudioPath(String str) {
        d0.g(str, "<set-?>");
        this.audioPath = str;
    }

    public final void setAudioType(String str) {
        d0.g(str, "<set-?>");
        this.audioType = str;
    }

    public final void setDuration(int i10) {
        this.duration = i10;
    }

    public final void setFileKey(String str) {
        d0.g(str, "<set-?>");
        this.fileKey = str;
    }

    public String toString() {
        String str = this.fileKey;
        String str2 = this.audioPath;
        String str3 = this.audioType;
        int i10 = this.duration;
        StringBuilder a10 = e.a("FlutterAudioData(fileKey=", str, ", audioPath=", str2, ", audioType=");
        a10.append(str3);
        a10.append(", duration=");
        a10.append(i10);
        a10.append(")");
        return a10.toString();
    }
}
