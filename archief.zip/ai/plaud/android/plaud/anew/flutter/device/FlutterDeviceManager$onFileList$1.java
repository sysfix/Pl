package ai.plaud.android.plaud.anew.flutter.device;

import ag.c;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import java.util.List;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager$onFileList$1", f = "FlutterDeviceManager.kt", l = {}, m = "invokeSuspend")
/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$onFileList$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ List<FlutterDeviceManager.DeviceFile> $deviceList;
    public final /* synthetic */ int $total;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterDeviceManager$onFileList$1(int i10, List<FlutterDeviceManager.DeviceFile> list, c<? super FlutterDeviceManager$onFileList$1> cVar) {
        super(2, cVar);
        this.$total = i10;
        this.$deviceList = list;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterDeviceManager$onFileList$1(this.$total, this.$deviceList, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterDeviceManager$onFileList$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            j access$getMethodChannel$p = FlutterDeviceManager.methodChannel;
            if (access$getMethodChannel$p != null) {
                access$getMethodChannel$p.a("listener/onFileList", q.a.a(new FlutterDeviceManager.GetFileListRsp(this.$total, this.$deviceList)), (j.d) null);
            }
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
