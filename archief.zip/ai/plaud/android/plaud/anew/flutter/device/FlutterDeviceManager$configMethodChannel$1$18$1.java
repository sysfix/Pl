package ai.plaud.android.plaud.anew.flutter.device;

import ag.c;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import com.google.android.gms.internal.play_billing.x2;
import dd.j;
import gg.p;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager$configMethodChannel$1$18$1", f = "FlutterDeviceManager.kt", l = {}, m = "invokeSuspend")
/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$configMethodChannel$1$18$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ j $it;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterDeviceManager$configMethodChannel$1$18$1(j jVar, c<? super FlutterDeviceManager$configMethodChannel$1$18$1> cVar) {
        super(2, cVar);
        this.$it = jVar;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterDeviceManager$configMethodChannel$1$18$1(this.$it, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterDeviceManager$configMethodChannel$1$18$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            re.j access$getMethodChannel$p = FlutterDeviceManager.methodChannel;
            if (access$getMethodChannel$p != null) {
                access$getMethodChannel$p.a("listener/onMicGain", q.a.a(new FlutterDeviceManager.DeviceValueRsp((int) this.$it.f10050c)), (j.d) null);
            }
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
