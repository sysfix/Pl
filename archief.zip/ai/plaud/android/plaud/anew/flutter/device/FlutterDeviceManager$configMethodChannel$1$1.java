package ai.plaud.android.plaud.anew.flutter.device;

import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.common.util.AppProvider;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import com.blankj.utilcode.util.a;
import com.blankj.utilcode.util.i;
import com.google.common.collect.MapMakerInternalMap;
import com.hjq.permissions.OnPermissionCallback;
import java.util.List;
import rg.d0;

/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$configMethodChannel$1$1 implements OnPermissionCallback {
    public void onDenied(List<String> list, boolean z10) {
        d0.g(list, "permissions");
        if (z10) {
            boolean z11 = false;
            Toast.makeText(a.a(), AppProvider.a().getString(R.string.no_permission_tip), 0).show();
            String packageName = i.a().getPackageName();
            Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.parse("package:" + packageName));
            Intent addFlags = intent.addFlags(268435456);
            if (i.a().getPackageManager().queryIntentActivities(addFlags, MapMakerInternalMap.MAX_SEGMENTS).size() > 0) {
                z11 = true;
            }
            if (z11) {
                i.a().startActivity(addFlags);
            }
        }
    }

    public void onGranted(List<String> list, boolean z10) {
        d0.g(list, "permissions");
    }
}
