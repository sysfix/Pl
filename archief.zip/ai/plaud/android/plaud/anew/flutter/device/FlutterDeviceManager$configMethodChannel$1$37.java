package ai.plaud.android.plaud.anew.flutter.device;

import ad.a;
import ci.a;
import com.tinnotech.penblesdk.Constants$OtaPushError;

/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$configMethodChannel$1$37 implements a {
    public void otaPushError(Constants$OtaPushError constants$OtaPushError) {
        a.C0057a aVar = ci.a.f4931a;
        aVar.b("Push出错 " + constants$OtaPushError, new Object[0]);
        FlutterDeviceManager flutterDeviceManager = FlutterDeviceManager.INSTANCE;
        String errMsg = constants$OtaPushError != null ? constants$OtaPushError.getErrMsg() : null;
        if (errMsg == null) {
            errMsg = "null error";
        }
        flutterDeviceManager.onFotaState(-1, (Integer) null, errMsg);
    }

    public void otaPushFinish() {
        ci.a.f4931a.a("Ota包发送完成，等待设备升级", new Object[0]);
        FlutterDeviceManager.INSTANCE.onFotaState(2, (Integer) null, (String) null);
    }

    public void otaPushProgress(double d10) {
        a.C0057a aVar = ci.a.f4931a;
        aVar.a("推送进度 " + d10, new Object[0]);
        FlutterDeviceManager.INSTANCE.onFotaState(1, Integer.valueOf((int) d10), (String) null);
    }

    public void otaPushSpeed(double d10, double d11) {
        a.C0057a aVar = ci.a.f4931a;
        aVar.a("推送速度 KB/s " + d10 + " " + d11, new Object[0]);
    }
}
