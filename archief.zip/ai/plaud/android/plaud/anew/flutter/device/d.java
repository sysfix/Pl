package ai.plaud.android.plaud.anew.flutter.device;

import ad.c;
import dd.z;
import jd.a;

public final /* synthetic */ class d implements jd.d, a, c {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ Boolean f934p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Integer f935q;

    public /* synthetic */ d(Boolean bool, Integer num) {
        this.f934p = bool;
        this.f935q = num;
    }

    public /* synthetic */ d(Integer num, Boolean bool, int i10) {
        this.f935q = num;
        this.f934p = bool;
    }

    public void a(int i10) {
        FlutterDeviceManager.m66syncBleFile$lambda53(this.f935q, this.f934p, i10);
    }

    public void d(Object obj, long j10) {
        FlutterDeviceManager.m64syncBleFile$lambda50(this.f934p, this.f935q, (short[]) obj, j10);
    }

    public void f(z1.c cVar) {
        FlutterDeviceManager.m68syncBleFile$lambda55(this.f935q, this.f934p, (z) cVar);
    }
}
