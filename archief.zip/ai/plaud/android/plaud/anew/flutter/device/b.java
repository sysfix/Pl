package ai.plaud.android.plaud.anew.flutter.device;

import ad.c;
import ad.d;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Base64;
import android.util.JsonReader;
import android.view.View;
import androidx.arch.core.util.Function;
import dd.a0;
import dd.k;
import dd.t;
import df.p;
import ef.c;
import f6.f;
import i6.j;
import i6.r;
import io.flutter.plugins.webviewflutter.GeneratedAndroidWebView;
import io.flutter.plugins.webviewflutter.s;
import io.flutter.plugins.webviewflutter.w;
import java.util.ArrayList;
import p6.n;
import q2.e;
import r9.a;

public final /* synthetic */ class b implements c, ad.b, d, Function, f, n.b, a.C0242a, GeneratedAndroidWebView.d.a, df.n, GeneratedAndroidWebView.o.a, GeneratedAndroidWebView.z.a, p, GeneratedAndroidWebView.w.a, c.b {
    public static final /* synthetic */ b A = new b(10);
    public static final /* synthetic */ b B = new b(11);
    public static final /* synthetic */ b C = new b(12);
    public static final /* synthetic */ b D = new b(13);
    public static final /* synthetic */ b E = new b(16);
    public static final /* synthetic */ b F = new b(17);
    public static final /* synthetic */ b G = new b(18);
    public static final /* synthetic */ b H = new b(19);
    public static final /* synthetic */ b I = new b(20);
    public static final /* synthetic */ b J = new b(21);
    public static final /* synthetic */ b K = new b(22);
    public static final /* synthetic */ b L = new b(23);
    public static final /* synthetic */ b M = new b(24);

    /* renamed from: q  reason: collision with root package name */
    public static final /* synthetic */ b f921q = new b(0);

    /* renamed from: r  reason: collision with root package name */
    public static final /* synthetic */ b f922r = new b(1);

    /* renamed from: s  reason: collision with root package name */
    public static final /* synthetic */ b f923s = new b(2);

    /* renamed from: t  reason: collision with root package name */
    public static final /* synthetic */ b f924t = new b(3);

    /* renamed from: u  reason: collision with root package name */
    public static final /* synthetic */ b f925u = new b(4);

    /* renamed from: v  reason: collision with root package name */
    public static final /* synthetic */ b f926v = new b(5);

    /* renamed from: w  reason: collision with root package name */
    public static final /* synthetic */ b f927w = new b(6);

    /* renamed from: x  reason: collision with root package name */
    public static final /* synthetic */ b f928x = new b(7);

    /* renamed from: y  reason: collision with root package name */
    public static final /* synthetic */ b f929y = new b(8);

    /* renamed from: z  reason: collision with root package name */
    public static final /* synthetic */ b f930z = new b(9);

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f931p;

    public /* synthetic */ b(int i10) {
        this.f931p = i10;
    }

    public void a(Object obj) {
        switch (this.f931p) {
            case 16:
                Void voidR = (Void) obj;
                return;
            case AndroidVersion.ANDROID_4_2 /*17*/:
                Void voidR2 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_4_3 /*18*/:
                Void voidR3 = (Void) obj;
                int i10 = s.c.f12900h;
                return;
            case AndroidVersion.ANDROID_4_4 /*19*/:
                Void voidR4 = (Void) obj;
                return;
            case 20:
                Void voidR5 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_5 /*21*/:
                Void voidR6 = (Void) obj;
                int i11 = w.a.f12917d;
                return;
            case AndroidVersion.ANDROID_5_1 /*22*/:
                Void voidR7 = (Void) obj;
                int i12 = w.c.f12920c;
                return;
            default:
                Void voidR8 = (Void) obj;
                int i13 = w.c.f12920c;
                return;
        }
    }

    public Object apply(Object obj) {
        byte[] bArr;
        switch (this.f931p) {
            case 10:
                return Long.valueOf(((e) obj).d1());
            case 12:
                f6.b bVar = n.f15429u;
                Cursor rawQuery = ((SQLiteDatabase) obj).rawQuery("SELECT distinct t._id, t.backend_name, t.priority, t.extras FROM transport_contexts AS t, events AS e WHERE e.context_id = t._id", new String[0]);
                try {
                    ArrayList arrayList = new ArrayList();
                    while (rawQuery.moveToNext()) {
                        r.a a10 = r.a();
                        a10.b(rawQuery.getString(1));
                        a10.c(s6.a.b(rawQuery.getInt(2)));
                        String string = rawQuery.getString(3);
                        if (string == null) {
                            bArr = null;
                        } else {
                            bArr = Base64.decode(string, 0);
                        }
                        j.b bVar2 = (j.b) a10;
                        bVar2.f11875b = bArr;
                        arrayList.add(bVar2.a());
                    }
                    return arrayList;
                } finally {
                    rawQuery.close();
                }
            default:
                return Boolean.valueOf(((Cursor) obj).moveToNext());
        }
    }

    public void b(fd.a aVar) {
        FlutterDeviceManager.m47configMethodChannel$lambda48$lambda46((fd.e) aVar);
    }

    public boolean c(View view) {
        return view.hasFocus();
    }

    public Object d(JsonReader jsonReader) {
        switch (this.f931p) {
            case AndroidVersion.ANDROID_4_0 /*14*/:
                return a.b(jsonReader);
            default:
                return a.a(jsonReader);
        }
    }

    public void e(Exception exc) {
    }

    public void f(z1.c cVar) {
        switch (this.f931p) {
            case 0:
                FlutterDeviceManager.m69syncBleFile$lambda56((a0) cVar);
                return;
            case 1:
                FlutterDeviceManager.m55depairDevice$lambda63((k) cVar);
                return;
            case 4:
                FlutterDeviceManager.m23configMethodChannel$lambda48$lambda24((dd.j) cVar);
                return;
            default:
                FlutterDeviceManager.m30configMethodChannel$lambda48$lambda30((t) cVar);
                return;
        }
    }

    public void g(boolean z10) {
        switch (this.f931p) {
            case 2:
                FlutterDeviceManager.m12configMethodChannel$lambda48$lambda13(z10);
                return;
            case 3:
                FlutterDeviceManager.m18configMethodChannel$lambda48$lambda19(z10);
                return;
            case 6:
                FlutterDeviceManager.m35configMethodChannel$lambda48$lambda35(z10);
                return;
            case 7:
                FlutterDeviceManager.m42configMethodChannel$lambda48$lambda41(z10);
                return;
            default:
                FlutterDeviceManager.m10configMethodChannel$lambda48$lambda11(z10);
                return;
        }
    }
}
