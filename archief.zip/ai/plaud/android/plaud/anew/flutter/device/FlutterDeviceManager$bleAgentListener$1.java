package ai.plaud.android.plaud.anew.flutter.device;

import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import ci.a;
import com.tinnotech.penblesdk.Constants$ConnectBleFailed;
import com.tinnotech.penblesdk.Constants$ScanFailed;
import com.tinnotech.penblesdk.entity.BleDevice;
import com.tinnotech.penblesdk.entity.BluetoothStatus;
import dd.b;
import dd.e;
import dd.h;
import dd.p;
import dd.v;
import dd.w;
import dd.y;
import gd.o;
import okhttp3.HttpUrl;
import rg.d0;

/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$bleAgentListener$1 implements o {

    /* compiled from: FlutterDeviceManager.kt */
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] iArr = new int[BluetoothStatus.values().length];
            iArr[BluetoothStatus.CONNECTED.ordinal()] = 1;
            iArr[BluetoothStatus.OFF.ordinal()] = 2;
            iArr[BluetoothStatus.ON.ordinal()] = 3;
            iArr[BluetoothStatus.CONNECTING.ordinal()] = 4;
            iArr[BluetoothStatus.DISCONNECTING.ordinal()] = 5;
            iArr[BluetoothStatus.DISCONNECTED.ordinal()] = 6;
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[Constants$ConnectBleFailed.values().length];
            iArr2[Constants$ConnectBleFailed.TOKEN_NOT_MARCH.ordinal()] = 1;
            iArr2[Constants$ConnectBleFailed.TIME_OUT.ordinal()] = 2;
            $EnumSwitchMapping$1 = iArr2;
        }
    }

    public void batteryLevelUpdate(String str, int i10) {
        a.C0057a aVar = a.f4931a;
        aVar.a("batteryLevelUpdate:[" + str + "] [" + i10 + "]", new Object[0]);
        FlutterDeviceManager flutterDeviceManager = FlutterDeviceManager.INSTANCE;
        flutterDeviceManager.onBatteryState(flutterDeviceManager.getBleAgent().c(), i10);
    }

    public void bleConnectFail(String str, Constants$ConnectBleFailed constants$ConnectBleFailed) {
        d0.g(constants$ConnectBleFailed, "p1");
        a.C0057a aVar = a.f4931a;
        aVar.a("sn: " + str + " ConnectBleFailed: " + constants$ConnectBleFailed, new Object[0]);
        int i10 = WhenMappings.$EnumSwitchMapping$1[constants$ConnectBleFailed.ordinal()];
        if (i10 == 1) {
            FlutterDeviceManager.INSTANCE.onDeviceConnectResult(str, 1);
        } else if (i10 != 2) {
            FlutterDeviceManager.INSTANCE.onDeviceConnectResult(str, -1);
        } else {
            FlutterDeviceManager.INSTANCE.onDeviceConnectResult(str, -2);
        }
    }

    public void btStatusChange(String str, BluetoothStatus bluetoothStatus) {
        d0.g(bluetoothStatus, "p1");
        a.C0057a aVar = a.f4931a;
        aVar.a("蓝牙连接状态--- sn: " + str + " BluetoothStatus: " + bluetoothStatus, new Object[0]);
        switch (WhenMappings.$EnumSwitchMapping$0[bluetoothStatus.ordinal()]) {
            case 1:
                FlutterDeviceManager flutterDeviceManager = FlutterDeviceManager.INSTANCE;
                FlutterDeviceManager.curDeviceSn = str == null ? HttpUrl.FRAGMENT_ENCODE_SET : str;
                FlutterDeviceManager.curAudioChannel = flutterDeviceManager.getBleAgent().X();
                flutterDeviceManager.onDeviceConnectResult(str, 0);
                flutterDeviceManager.onBleStateChange(str, 3);
                flutterDeviceManager.syncTime();
                return;
            case 2:
                FlutterDeviceManager.INSTANCE.onBleStateChange(str, 0);
                return;
            case 3:
                FlutterDeviceManager.INSTANCE.onBleStateChange(str, 1);
                return;
            case 4:
                FlutterDeviceManager.INSTANCE.onBleStateChange(str, 2);
                return;
            case 5:
                FlutterDeviceManager.INSTANCE.onBleStateChange(str, 4);
                return;
            case 6:
                FlutterDeviceManager.INSTANCE.onBleStateChange(str, 5);
                return;
            default:
                FlutterDeviceManager.INSTANCE.onBleStateChange(str, -1);
                return;
        }
    }

    public void chargingStatusChange(String str, boolean z10) {
        a.C0057a aVar = a.f4931a;
        aVar.a("chargingStatusChange:[" + str + "] [" + z10 + "]", new Object[0]);
        FlutterDeviceManager flutterDeviceManager = FlutterDeviceManager.INSTANCE;
        flutterDeviceManager.onBatteryState(z10, flutterDeviceManager.getBleAgent().f());
    }

    public void deviceFotaResult(String str, e eVar) {
        d0.g(eVar, "p1");
        a.C0057a aVar = a.f4931a;
        aVar.a("设备升级结果回调（升级后第一次连接返回） sn " + str + " AppFotaPushRsp " + eVar, new Object[0]);
    }

    public void deviceFotaThirdVersion(String str, p pVar) {
        d0.g(pVar, "p1");
    }

    public void deviceOpRecordStart(String str, v vVar) {
        d0.g(vVar, "p1");
        a.C0057a aVar = a.f4931a;
        aVar.a("设备发起录音 " + str + " " + vVar, new Object[0]);
        FlutterDeviceManager flutterDeviceManager = FlutterDeviceManager.INSTANCE;
        if (str == null) {
            str = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        flutterDeviceManager.onRecordState(5, str, new FlutterDeviceManager.StartRecordRsp(vVar.f10084c, vVar.f10085d, vVar.f10086e, vVar.f10083b));
    }

    public void deviceOpRecordStop(String str, w wVar) {
        d0.g(wVar, "p1");
        a.C0057a aVar = a.f4931a;
        aVar.a("设备结束录音 " + str + " " + wVar, new Object[0]);
        FlutterDeviceManager flutterDeviceManager = FlutterDeviceManager.INSTANCE;
        if (str == null) {
            str = HttpUrl.FRAGMENT_ENCODE_SET;
        }
        flutterDeviceManager.onRecordState(6, str, new FlutterDeviceManager.StopRecordRsp(wVar.f10091e, wVar.f10089c, wVar.f10088b));
    }

    public void deviceOpStorageRsp(String str, y yVar) {
        d0.g(yVar, "p1");
        a.C0057a aVar = a.f4931a;
        aVar.a("设备内存不足时主动发起存储空间返回（剩余空间 < 5M） " + str + " " + yVar, new Object[0]);
    }

    public void deviceStatusRsp(String str, dd.o oVar) {
        d0.g(oVar, "p1");
        a.C0057a aVar = a.f4931a;
        aVar.d("设备的状态发生变化 sn " + str + " GetStateRsp " + oVar, new Object[0]);
        FlutterDeviceManager.INSTANCE.onDeviceState(oVar);
    }

    public void deviceSwitchWifiMode(String str, h hVar) {
        d0.g(hVar, "p1");
        a.C0057a aVar = a.f4931a;
        aVar.d("sn " + str + " BtCloseRsp " + hVar, new Object[0]);
    }

    public void handshakeWaitSure(String str, long j10) {
        a.C0057a aVar = a.f4931a;
        aVar.a("mac: " + str + " timeout: " + j10, new Object[0]);
    }

    public void motorStatus(String str, int i10) {
    }

    public void mtuChange(String str, int i10, boolean z10) {
    }

    public void rssiChange(String str, int i10) {
    }

    public void scanBleDeviceReceiver(BleDevice bleDevice) {
        d0.g(bleDevice, "p0");
        FlutterDeviceManager.INSTANCE.addBleDevice(bleDevice);
    }

    public void scanFail(Constants$ScanFailed constants$ScanFailed) {
        d0.g(constants$ScanFailed, "p0");
        a.C0057a aVar = a.f4931a;
        aVar.a("ScanFailed: " + constants$ScanFailed, new Object[0]);
    }

    public void sendMoreFailDisconnect(String str) {
    }

    public void stickAngles(String str, b bVar) {
    }
}
