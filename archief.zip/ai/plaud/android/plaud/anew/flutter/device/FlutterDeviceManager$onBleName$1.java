package ai.plaud.android.plaud.anew.flutter.device;

import ag.c;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager$onBleName$1", f = "FlutterDeviceManager.kt", l = {}, m = "invokeSuspend")
/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$onBleName$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ String $name;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterDeviceManager$onBleName$1(String str, c<? super FlutterDeviceManager$onBleName$1> cVar) {
        super(2, cVar);
        this.$name = str;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterDeviceManager$onBleName$1(this.$name, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterDeviceManager$onBleName$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            j access$getMethodChannel$p = FlutterDeviceManager.methodChannel;
            if (access$getMethodChannel$p != null) {
                access$getMethodChannel$p.a("listener/onDeviceName", q.a.a(new FlutterDeviceManager.BleNameResult(this.$name)), (j.d) null);
            }
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
