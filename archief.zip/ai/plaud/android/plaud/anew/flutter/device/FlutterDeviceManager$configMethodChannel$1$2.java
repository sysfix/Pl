package ai.plaud.android.plaud.anew.flutter.device;

import ag.c;
import android.net.wifi.WifiManager;
import ci.a;
import com.google.android.gms.internal.measurement.n8;
import com.google.android.gms.internal.play_billing.x2;
import com.liulishuo.okdownload.OkDownloadProvider;
import gg.p;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import rg.g1;
import rg.l0;
import wg.q;
import xf.g;

@kotlin.coroutines.jvm.internal.a(c = "ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager$configMethodChannel$1$2", f = "FlutterDeviceManager.kt", l = {431}, m = "invokeSuspend")
/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$configMethodChannel$1$2 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ j.d $result;
    public int label;

    @kotlin.coroutines.jvm.internal.a(c = "ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager$configMethodChannel$1$2$1", f = "FlutterDeviceManager.kt", l = {}, m = "invokeSuspend")
    /* renamed from: ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager$configMethodChannel$1$2$1  reason: invalid class name */
    /* compiled from: FlutterDeviceManager.kt */
    public static final class AnonymousClass1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
        public int label;

        public final c<g> create(Object obj, c<?> cVar) {
            return new AnonymousClass1(dVar, z10, cVar);
        }

        public final Object invoke(c0 c0Var, c<? super g> cVar) {
            return ((AnonymousClass1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
        }

        public final Object invokeSuspend(Object obj) {
            if (this.label == 0) {
                x2.s(obj);
                dVar.a(Boolean.valueOf(z10));
                return g.f19030a;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterDeviceManager$configMethodChannel$1$2(j.d dVar, c<? super FlutterDeviceManager$configMethodChannel$1$2> cVar) {
        super(2, cVar);
        this.$result = dVar;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterDeviceManager$configMethodChannel$1$2(this.$result, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterDeviceManager$configMethodChannel$1$2) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            Object systemService = OkDownloadProvider.f9442p.getApplicationContext().getSystemService("wifi");
            WifiManager wifiManager = systemService instanceof WifiManager ? (WifiManager) systemService : null;
            final boolean z10 = wifiManager != null && wifiManager.isWifiEnabled();
            a.C0057a aVar = ci.a.f4931a;
            aVar.a("isWifiOpen:[" + z10 + "]", new Object[0]);
            l0 l0Var = l0.f16618a;
            g1 g1Var = q.f18099a;
            final j.d dVar = this.$result;
            AnonymousClass1 r42 = new AnonymousClass1((c<? super AnonymousClass1>) null);
            this.label = 1;
            if (n8.v(g1Var, r42, this) == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return g.f19030a;
    }
}
