package ai.plaud.android.plaud.anew.flutter.device;

public final /* synthetic */ class f {
    public static String a(String str, boolean z10) {
        return str + z10;
    }
}
