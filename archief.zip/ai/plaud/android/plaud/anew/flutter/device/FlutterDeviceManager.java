package ai.plaud.android.plaud.anew.flutter.device;

import a.w;
import a.x;
import ai.plaud.android.plaud.anew.flutter.audio.f;
import ai.plaud.android.plaud.common.util.AppProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import b.b;
import c.c;
import c.d;
import c.e;
import ci.a;
import com.google.android.gms.internal.measurement.n8;
import com.hjq.permissions.Permission;
import com.hjq.permissions.XXPermissions;
import com.tinnotech.penblesdk.Constants$AutoPowerOffType;
import com.tinnotech.penblesdk.Constants$SaveRAWFile;
import com.tinnotech.penblesdk.entity.BleDevice;
import com.tinnotech.penblesdk.entity.BleFile;
import com.tinnotech.penblesdk.entity.BluetoothStatus;
import dd.a0;
import dd.b0;
import dd.c0;
import dd.e0;
import dd.g;
import dd.m;
import dd.o;
import dd.r;
import dd.s;
import dd.t;
import dd.u;
import dd.v;
import dd.y;
import dd.z;
import h.a;
import id.h;
import id.k;
import id.l;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.ThreadPoolExecutor;
import kotlin.Pair;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.CoroutineStart;
import okhttp3.HttpUrl;
import re.i;
import re.j;
import rg.d0;
import rg.l0;
import rg.s0;
import wg.q;
import yf.p;

/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager {
    private static final String CHANNEL = "plaud.flutter/deviceManager";
    public static final FlutterDeviceManager INSTANCE;
    private static final FlutterDeviceManager$bleAgentListener$1 bleAgentListener;
    private static final List<BleDevice> bleDeviceList = new ArrayList();
    /* access modifiers changed from: private */
    public static int curAudioChannel = 1;
    /* access modifiers changed from: private */
    public static String curDeviceSn = HttpUrl.FRAGMENT_ENCODE_SET;
    private static int curTimeZoneHour;
    private static int curTimeZoneMin;
    private static String curWiFiSN = HttpUrl.FRAGMENT_ENCODE_SET;
    /* access modifiers changed from: private */
    public static j methodChannel;
    private static final FlutterDeviceManager$wifiAgentListener$1 wifiAgentListener;

    /* compiled from: FlutterDeviceManager.kt */
    public static final class BatteryState {
        private final boolean isCharging;
        private final int level;

        public BatteryState(boolean z10, int i10) {
            this.isCharging = z10;
            this.level = i10;
        }

        public static /* synthetic */ BatteryState copy$default(BatteryState batteryState, boolean z10, int i10, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                z10 = batteryState.isCharging;
            }
            if ((i11 & 2) != 0) {
                i10 = batteryState.level;
            }
            return batteryState.copy(z10, i10);
        }

        public final boolean component1() {
            return this.isCharging;
        }

        public final int component2() {
            return this.level;
        }

        public final BatteryState copy(boolean z10, int i10) {
            return new BatteryState(z10, i10);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof BatteryState)) {
                return false;
            }
            BatteryState batteryState = (BatteryState) obj;
            return this.isCharging == batteryState.isCharging && this.level == batteryState.level;
        }

        public final int getLevel() {
            return this.level;
        }

        public int hashCode() {
            boolean z10 = this.isCharging;
            if (z10) {
                z10 = true;
            }
            return ((z10 ? 1 : 0) * true) + this.level;
        }

        public final boolean isCharging() {
            return this.isCharging;
        }

        public String toString() {
            boolean z10 = this.isCharging;
            int i10 = this.level;
            return "BatteryState(isCharging=" + z10 + ", level=" + i10 + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class BleNameResult {
        private final String name;

        public BleNameResult(String str) {
            d0.g(str, "name");
            this.name = str;
        }

        public static /* synthetic */ BleNameResult copy$default(BleNameResult bleNameResult, String str, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = bleNameResult.name;
            }
            return bleNameResult.copy(str);
        }

        public final String component1() {
            return this.name;
        }

        public final BleNameResult copy(String str) {
            d0.g(str, "name");
            return new BleNameResult(str);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof BleNameResult) && d0.b(this.name, ((BleNameResult) obj).name);
        }

        public final String getName() {
            return this.name;
        }

        public int hashCode() {
            return this.name.hashCode();
        }

        public String toString() {
            return b.a("BleNameResult(name=", this.name, ")");
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class DeviceFile {
        private final int channel;
        private final long fileSize;
        private final int scene;
        private final String serialNumber;
        private final long sessionId;
        private final int timeZoneHour;
        private final int timeZoneMin;

        public DeviceFile(String str, long j10, long j11, int i10, int i11, int i12, int i13) {
            d0.g(str, "serialNumber");
            this.serialNumber = str;
            this.sessionId = j10;
            this.fileSize = j11;
            this.scene = i10;
            this.channel = i11;
            this.timeZoneHour = i12;
            this.timeZoneMin = i13;
        }

        public static /* synthetic */ DeviceFile copy$default(DeviceFile deviceFile, String str, long j10, long j11, int i10, int i11, int i12, int i13, int i14, Object obj) {
            DeviceFile deviceFile2 = deviceFile;
            return deviceFile.copy((i14 & 1) != 0 ? deviceFile2.serialNumber : str, (i14 & 2) != 0 ? deviceFile2.sessionId : j10, (i14 & 4) != 0 ? deviceFile2.fileSize : j11, (i14 & 8) != 0 ? deviceFile2.scene : i10, (i14 & 16) != 0 ? deviceFile2.channel : i11, (i14 & 32) != 0 ? deviceFile2.timeZoneHour : i12, (i14 & 64) != 0 ? deviceFile2.timeZoneMin : i13);
        }

        public final String component1() {
            return this.serialNumber;
        }

        public final long component2() {
            return this.sessionId;
        }

        public final long component3() {
            return this.fileSize;
        }

        public final int component4() {
            return this.scene;
        }

        public final int component5() {
            return this.channel;
        }

        public final int component6() {
            return this.timeZoneHour;
        }

        public final int component7() {
            return this.timeZoneMin;
        }

        public final DeviceFile copy(String str, long j10, long j11, int i10, int i11, int i12, int i13) {
            d0.g(str, "serialNumber");
            return new DeviceFile(str, j10, j11, i10, i11, i12, i13);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DeviceFile)) {
                return false;
            }
            DeviceFile deviceFile = (DeviceFile) obj;
            return d0.b(this.serialNumber, deviceFile.serialNumber) && this.sessionId == deviceFile.sessionId && this.fileSize == deviceFile.fileSize && this.scene == deviceFile.scene && this.channel == deviceFile.channel && this.timeZoneHour == deviceFile.timeZoneHour && this.timeZoneMin == deviceFile.timeZoneMin;
        }

        public final int getChannel() {
            return this.channel;
        }

        public final long getFileSize() {
            return this.fileSize;
        }

        public final int getScene() {
            return this.scene;
        }

        public final String getSerialNumber() {
            return this.serialNumber;
        }

        public final long getSessionId() {
            return this.sessionId;
        }

        public final int getTimeZoneHour() {
            return this.timeZoneHour;
        }

        public final int getTimeZoneMin() {
            return this.timeZoneMin;
        }

        public int hashCode() {
            long j10 = this.sessionId;
            long j11 = this.fileSize;
            return (((((((((((this.serialNumber.hashCode() * 31) + ((int) (j10 ^ (j10 >>> 32)))) * 31) + ((int) (j11 ^ (j11 >>> 32)))) * 31) + this.scene) * 31) + this.channel) * 31) + this.timeZoneHour) * 31) + this.timeZoneMin;
        }

        public String toString() {
            String str = this.serialNumber;
            long j10 = this.sessionId;
            long j11 = this.fileSize;
            int i10 = this.scene;
            int i11 = this.channel;
            int i12 = this.timeZoneHour;
            int i13 = this.timeZoneMin;
            return "DeviceFile(serialNumber=" + str + ", sessionId=" + j10 + ", fileSize=" + j11 + ", scene=" + i10 + ", channel=" + i11 + ", timeZoneHour=" + i12 + ", timeZoneMin=" + i13 + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class DeviceInfoEntity {
        private final int channel;
        private final String name;
        private final long projectCode;
        private final String serialNumber;
        private final int timeZoneHour;
        private final int timeZoneMin;
        private final int versionCode;
        private final String versionType;
        private final String wholeVersion;

        public DeviceInfoEntity(String str, String str2, String str3, int i10, String str4, long j10, int i11, int i12, int i13) {
            d0.g(str, "name");
            d0.g(str2, "serialNumber");
            d0.g(str3, "versionType");
            d0.g(str4, "wholeVersion");
            this.name = str;
            this.serialNumber = str2;
            this.versionType = str3;
            this.versionCode = i10;
            this.wholeVersion = str4;
            this.projectCode = j10;
            this.channel = i11;
            this.timeZoneHour = i12;
            this.timeZoneMin = i13;
        }

        public static /* synthetic */ DeviceInfoEntity copy$default(DeviceInfoEntity deviceInfoEntity, String str, String str2, String str3, int i10, String str4, long j10, int i11, int i12, int i13, int i14, Object obj) {
            DeviceInfoEntity deviceInfoEntity2 = deviceInfoEntity;
            int i15 = i14;
            return deviceInfoEntity.copy((i15 & 1) != 0 ? deviceInfoEntity2.name : str, (i15 & 2) != 0 ? deviceInfoEntity2.serialNumber : str2, (i15 & 4) != 0 ? deviceInfoEntity2.versionType : str3, (i15 & 8) != 0 ? deviceInfoEntity2.versionCode : i10, (i15 & 16) != 0 ? deviceInfoEntity2.wholeVersion : str4, (i15 & 32) != 0 ? deviceInfoEntity2.projectCode : j10, (i15 & 64) != 0 ? deviceInfoEntity2.channel : i11, (i15 & 128) != 0 ? deviceInfoEntity2.timeZoneHour : i12, (i15 & 256) != 0 ? deviceInfoEntity2.timeZoneMin : i13);
        }

        public final String component1() {
            return this.name;
        }

        public final String component2() {
            return this.serialNumber;
        }

        public final String component3() {
            return this.versionType;
        }

        public final int component4() {
            return this.versionCode;
        }

        public final String component5() {
            return this.wholeVersion;
        }

        public final long component6() {
            return this.projectCode;
        }

        public final int component7() {
            return this.channel;
        }

        public final int component8() {
            return this.timeZoneHour;
        }

        public final int component9() {
            return this.timeZoneMin;
        }

        public final DeviceInfoEntity copy(String str, String str2, String str3, int i10, String str4, long j10, int i11, int i12, int i13) {
            d0.g(str, "name");
            d0.g(str2, "serialNumber");
            d0.g(str3, "versionType");
            String str5 = str4;
            d0.g(str5, "wholeVersion");
            return new DeviceInfoEntity(str, str2, str3, i10, str5, j10, i11, i12, i13);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DeviceInfoEntity)) {
                return false;
            }
            DeviceInfoEntity deviceInfoEntity = (DeviceInfoEntity) obj;
            return d0.b(this.name, deviceInfoEntity.name) && d0.b(this.serialNumber, deviceInfoEntity.serialNumber) && d0.b(this.versionType, deviceInfoEntity.versionType) && this.versionCode == deviceInfoEntity.versionCode && d0.b(this.wholeVersion, deviceInfoEntity.wholeVersion) && this.projectCode == deviceInfoEntity.projectCode && this.channel == deviceInfoEntity.channel && this.timeZoneHour == deviceInfoEntity.timeZoneHour && this.timeZoneMin == deviceInfoEntity.timeZoneMin;
        }

        public final int getChannel() {
            return this.channel;
        }

        public final String getName() {
            return this.name;
        }

        public final long getProjectCode() {
            return this.projectCode;
        }

        public final String getSerialNumber() {
            return this.serialNumber;
        }

        public final int getTimeZoneHour() {
            return this.timeZoneHour;
        }

        public final int getTimeZoneMin() {
            return this.timeZoneMin;
        }

        public final int getVersionCode() {
            return this.versionCode;
        }

        public final String getVersionType() {
            return this.versionType;
        }

        public final String getWholeVersion() {
            return this.wholeVersion;
        }

        public int hashCode() {
            int a10 = c.b.a(this.serialNumber, this.name.hashCode() * 31, 31);
            int a11 = c.b.a(this.wholeVersion, (c.b.a(this.versionType, a10, 31) + this.versionCode) * 31, 31);
            long j10 = this.projectCode;
            return ((((((a11 + ((int) (j10 ^ (j10 >>> 32)))) * 31) + this.channel) * 31) + this.timeZoneHour) * 31) + this.timeZoneMin;
        }

        public String toString() {
            String str = this.name;
            String str2 = this.serialNumber;
            String str3 = this.versionType;
            int i10 = this.versionCode;
            String str4 = this.wholeVersion;
            long j10 = this.projectCode;
            int i11 = this.channel;
            int i12 = this.timeZoneHour;
            int i13 = this.timeZoneMin;
            StringBuilder a10 = e.a("DeviceInfoEntity(name=", str, ", serialNumber=", str2, ", versionType=");
            a10.append(str3);
            a10.append(", versionCode=");
            a10.append(i10);
            a10.append(", wholeVersion=");
            a10.append(str4);
            a10.append(", projectCode=");
            a10.append(j10);
            a10.append(", channel=");
            a10.append(i11);
            a10.append(", timeZoneHour=");
            a10.append(i12);
            a10.append(", timeZoneMin=");
            a10.append(i13);
            a10.append(")");
            return a10.toString();
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class DeviceStateResult {
        private final String sn;
        private final int state;

        public DeviceStateResult(String str, int i10) {
            d0.g(str, "sn");
            this.sn = str;
            this.state = i10;
        }

        public static /* synthetic */ DeviceStateResult copy$default(DeviceStateResult deviceStateResult, String str, int i10, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                str = deviceStateResult.sn;
            }
            if ((i11 & 2) != 0) {
                i10 = deviceStateResult.state;
            }
            return deviceStateResult.copy(str, i10);
        }

        public final String component1() {
            return this.sn;
        }

        public final int component2() {
            return this.state;
        }

        public final DeviceStateResult copy(String str, int i10) {
            d0.g(str, "sn");
            return new DeviceStateResult(str, i10);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DeviceStateResult)) {
                return false;
            }
            DeviceStateResult deviceStateResult = (DeviceStateResult) obj;
            return d0.b(this.sn, deviceStateResult.sn) && this.state == deviceStateResult.state;
        }

        public final String getSn() {
            return this.sn;
        }

        public final int getState() {
            return this.state;
        }

        public int hashCode() {
            return (this.sn.hashCode() * 31) + this.state;
        }

        public String toString() {
            String str = this.sn;
            int i10 = this.state;
            return "DeviceStateResult(sn=" + str + ", state=" + i10 + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class DeviceValueRsp {
        private final int value;

        public DeviceValueRsp(int i10) {
            this.value = i10;
        }

        public static /* synthetic */ DeviceValueRsp copy$default(DeviceValueRsp deviceValueRsp, int i10, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                i10 = deviceValueRsp.value;
            }
            return deviceValueRsp.copy(i10);
        }

        public final int component1() {
            return this.value;
        }

        public final DeviceValueRsp copy(int i10) {
            return new DeviceValueRsp(i10);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof DeviceValueRsp) && this.value == ((DeviceValueRsp) obj).value;
        }

        public final int getValue() {
            return this.value;
        }

        public int hashCode() {
            return this.value;
        }

        public String toString() {
            return f.a("DeviceValueRsp(value=", this.value, ")");
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class FotaStateRsp {
        private final String errmsg;
        private final Integer progress;
        private final int state;

        public FotaStateRsp(int i10, Integer num, String str) {
            this.state = i10;
            this.progress = num;
            this.errmsg = str;
        }

        public static /* synthetic */ FotaStateRsp copy$default(FotaStateRsp fotaStateRsp, int i10, Integer num, String str, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                i10 = fotaStateRsp.state;
            }
            if ((i11 & 2) != 0) {
                num = fotaStateRsp.progress;
            }
            if ((i11 & 4) != 0) {
                str = fotaStateRsp.errmsg;
            }
            return fotaStateRsp.copy(i10, num, str);
        }

        public final int component1() {
            return this.state;
        }

        public final Integer component2() {
            return this.progress;
        }

        public final String component3() {
            return this.errmsg;
        }

        public final FotaStateRsp copy(int i10, Integer num, String str) {
            return new FotaStateRsp(i10, num, str);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof FotaStateRsp)) {
                return false;
            }
            FotaStateRsp fotaStateRsp = (FotaStateRsp) obj;
            return this.state == fotaStateRsp.state && d0.b(this.progress, fotaStateRsp.progress) && d0.b(this.errmsg, fotaStateRsp.errmsg);
        }

        public final String getErrmsg() {
            return this.errmsg;
        }

        public final Integer getProgress() {
            return this.progress;
        }

        public final int getState() {
            return this.state;
        }

        public int hashCode() {
            int i10 = this.state * 31;
            Integer num = this.progress;
            int i11 = 0;
            int hashCode = (i10 + (num == null ? 0 : num.hashCode())) * 31;
            String str = this.errmsg;
            if (str != null) {
                i11 = str.hashCode();
            }
            return hashCode + i11;
        }

        public String toString() {
            int i10 = this.state;
            Integer num = this.progress;
            String str = this.errmsg;
            StringBuilder sb2 = new StringBuilder();
            sb2.append("FotaStateRsp(state=");
            sb2.append(i10);
            sb2.append(", progress=");
            sb2.append(num);
            sb2.append(", errmsg=");
            return d.a(sb2, str, ")");
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class GetFileListRsp {
        private final List<DeviceFile> fileList;
        private final int total;

        public GetFileListRsp(int i10, List<DeviceFile> list) {
            d0.g(list, "fileList");
            this.total = i10;
            this.fileList = list;
        }

        public static /* synthetic */ GetFileListRsp copy$default(GetFileListRsp getFileListRsp, int i10, List<DeviceFile> list, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                i10 = getFileListRsp.total;
            }
            if ((i11 & 2) != 0) {
                list = getFileListRsp.fileList;
            }
            return getFileListRsp.copy(i10, list);
        }

        public final int component1() {
            return this.total;
        }

        public final List<DeviceFile> component2() {
            return this.fileList;
        }

        public final GetFileListRsp copy(int i10, List<DeviceFile> list) {
            d0.g(list, "fileList");
            return new GetFileListRsp(i10, list);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof GetFileListRsp)) {
                return false;
            }
            GetFileListRsp getFileListRsp = (GetFileListRsp) obj;
            return this.total == getFileListRsp.total && d0.b(this.fileList, getFileListRsp.fileList);
        }

        public final List<DeviceFile> getFileList() {
            return this.fileList;
        }

        public final int getTotal() {
            return this.total;
        }

        public int hashCode() {
            return this.fileList.hashCode() + (this.total * 31);
        }

        public String toString() {
            int i10 = this.total;
            List<DeviceFile> list = this.fileList;
            return "GetFileListRsp(total=" + i10 + ", fileList=" + list + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class GetStateResult {
        private final int keyState;
        private final int privacy;
        private final int sessionId;
        private final int state;
        private final int uDisk;

        public GetStateResult(int i10, int i11, int i12, int i13, int i14) {
            this.sessionId = i10;
            this.state = i11;
            this.keyState = i12;
            this.privacy = i13;
            this.uDisk = i14;
        }

        public static /* synthetic */ GetStateResult copy$default(GetStateResult getStateResult, int i10, int i11, int i12, int i13, int i14, int i15, Object obj) {
            if ((i15 & 1) != 0) {
                i10 = getStateResult.sessionId;
            }
            if ((i15 & 2) != 0) {
                i11 = getStateResult.state;
            }
            int i16 = i11;
            if ((i15 & 4) != 0) {
                i12 = getStateResult.keyState;
            }
            int i17 = i12;
            if ((i15 & 8) != 0) {
                i13 = getStateResult.privacy;
            }
            int i18 = i13;
            if ((i15 & 16) != 0) {
                i14 = getStateResult.uDisk;
            }
            return getStateResult.copy(i10, i16, i17, i18, i14);
        }

        public final int component1() {
            return this.sessionId;
        }

        public final int component2() {
            return this.state;
        }

        public final int component3() {
            return this.keyState;
        }

        public final int component4() {
            return this.privacy;
        }

        public final int component5() {
            return this.uDisk;
        }

        public final GetStateResult copy(int i10, int i11, int i12, int i13, int i14) {
            return new GetStateResult(i10, i11, i12, i13, i14);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof GetStateResult)) {
                return false;
            }
            GetStateResult getStateResult = (GetStateResult) obj;
            return this.sessionId == getStateResult.sessionId && this.state == getStateResult.state && this.keyState == getStateResult.keyState && this.privacy == getStateResult.privacy && this.uDisk == getStateResult.uDisk;
        }

        public final int getKeyState() {
            return this.keyState;
        }

        public final int getPrivacy() {
            return this.privacy;
        }

        public final int getSessionId() {
            return this.sessionId;
        }

        public final int getState() {
            return this.state;
        }

        public final int getUDisk() {
            return this.uDisk;
        }

        public int hashCode() {
            return (((((((this.sessionId * 31) + this.state) * 31) + this.keyState) * 31) + this.privacy) * 31) + this.uDisk;
        }

        public String toString() {
            int i10 = this.sessionId;
            int i11 = this.state;
            int i12 = this.keyState;
            int i13 = this.privacy;
            int i14 = this.uDisk;
            StringBuilder a10 = c.a("GetStateResult(sessionId=", i10, ", state=", i11, ", keyState=");
            a10.append(i12);
            a10.append(", privacy=");
            a10.append(i13);
            a10.append(", uDisk=");
            return ai.plaud.android.plaud.anew.database.recordfile.b.a(a10, i14, ")");
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class GetStorageRsp {
        private final long duration;
        private final long free;
        private final long total;

        public GetStorageRsp(long j10, long j11, long j12) {
            this.total = j10;
            this.free = j11;
            this.duration = j12;
        }

        public static /* synthetic */ GetStorageRsp copy$default(GetStorageRsp getStorageRsp, long j10, long j11, long j12, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                j10 = getStorageRsp.total;
            }
            long j13 = j10;
            if ((i10 & 2) != 0) {
                j11 = getStorageRsp.free;
            }
            long j14 = j11;
            if ((i10 & 4) != 0) {
                j12 = getStorageRsp.duration;
            }
            return getStorageRsp.copy(j13, j14, j12);
        }

        public final long component1() {
            return this.total;
        }

        public final long component2() {
            return this.free;
        }

        public final long component3() {
            return this.duration;
        }

        public final GetStorageRsp copy(long j10, long j11, long j12) {
            return new GetStorageRsp(j10, j11, j12);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof GetStorageRsp)) {
                return false;
            }
            GetStorageRsp getStorageRsp = (GetStorageRsp) obj;
            return this.total == getStorageRsp.total && this.free == getStorageRsp.free && this.duration == getStorageRsp.duration;
        }

        public final long getDuration() {
            return this.duration;
        }

        public final long getFree() {
            return this.free;
        }

        public final long getTotal() {
            return this.total;
        }

        public int hashCode() {
            long j10 = this.total;
            long j11 = this.free;
            long j12 = this.duration;
            return (((((int) (j10 ^ (j10 >>> 32))) * 31) + ((int) (j11 ^ (j11 >>> 32)))) * 31) + ((int) ((j12 >>> 32) ^ j12));
        }

        public String toString() {
            long j10 = this.total;
            long j11 = this.free;
            long j12 = this.duration;
            return "GetStorageRsp(total=" + j10 + ", free=" + j11 + ", duration=" + j12 + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class PauseRecordRsp {
        private final long fileSize;
        private final int reason;
        private final long sessionId;

        public PauseRecordRsp(long j10, int i10, long j11) {
            this.fileSize = j10;
            this.reason = i10;
            this.sessionId = j11;
        }

        public static /* synthetic */ PauseRecordRsp copy$default(PauseRecordRsp pauseRecordRsp, long j10, int i10, long j11, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                j10 = pauseRecordRsp.fileSize;
            }
            long j12 = j10;
            if ((i11 & 2) != 0) {
                i10 = pauseRecordRsp.reason;
            }
            int i12 = i10;
            if ((i11 & 4) != 0) {
                j11 = pauseRecordRsp.sessionId;
            }
            return pauseRecordRsp.copy(j12, i12, j11);
        }

        public final long component1() {
            return this.fileSize;
        }

        public final int component2() {
            return this.reason;
        }

        public final long component3() {
            return this.sessionId;
        }

        public final PauseRecordRsp copy(long j10, int i10, long j11) {
            return new PauseRecordRsp(j10, i10, j11);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof PauseRecordRsp)) {
                return false;
            }
            PauseRecordRsp pauseRecordRsp = (PauseRecordRsp) obj;
            return this.fileSize == pauseRecordRsp.fileSize && this.reason == pauseRecordRsp.reason && this.sessionId == pauseRecordRsp.sessionId;
        }

        public final long getFileSize() {
            return this.fileSize;
        }

        public final int getReason() {
            return this.reason;
        }

        public final long getSessionId() {
            return this.sessionId;
        }

        public int hashCode() {
            long j10 = this.fileSize;
            long j11 = this.sessionId;
            return (((((int) (j10 ^ (j10 >>> 32))) * 31) + this.reason) * 31) + ((int) ((j11 >>> 32) ^ j11));
        }

        public String toString() {
            long j10 = this.fileSize;
            int i10 = this.reason;
            long j11 = this.sessionId;
            return "PauseRecordRsp(fileSize=" + j10 + ", reason=" + i10 + ", sessionId=" + j11 + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class RecordStateRsp {
        private final int action;
        private final Object info;
        private final String sn;

        public RecordStateRsp(int i10, String str, Object obj) {
            d0.g(str, "sn");
            d0.g(obj, "info");
            this.action = i10;
            this.sn = str;
            this.info = obj;
        }

        public static /* synthetic */ RecordStateRsp copy$default(RecordStateRsp recordStateRsp, int i10, String str, Object obj, int i11, Object obj2) {
            if ((i11 & 1) != 0) {
                i10 = recordStateRsp.action;
            }
            if ((i11 & 2) != 0) {
                str = recordStateRsp.sn;
            }
            if ((i11 & 4) != 0) {
                obj = recordStateRsp.info;
            }
            return recordStateRsp.copy(i10, str, obj);
        }

        public final int component1() {
            return this.action;
        }

        public final String component2() {
            return this.sn;
        }

        public final Object component3() {
            return this.info;
        }

        public final RecordStateRsp copy(int i10, String str, Object obj) {
            d0.g(str, "sn");
            d0.g(obj, "info");
            return new RecordStateRsp(i10, str, obj);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof RecordStateRsp)) {
                return false;
            }
            RecordStateRsp recordStateRsp = (RecordStateRsp) obj;
            return this.action == recordStateRsp.action && d0.b(this.sn, recordStateRsp.sn) && d0.b(this.info, recordStateRsp.info);
        }

        public final int getAction() {
            return this.action;
        }

        public final Object getInfo() {
            return this.info;
        }

        public final String getSn() {
            return this.sn;
        }

        public int hashCode() {
            return this.info.hashCode() + c.b.a(this.sn, this.action * 31, 31);
        }

        public String toString() {
            int i10 = this.action;
            String str = this.sn;
            Object obj = this.info;
            StringBuilder sb2 = new StringBuilder();
            sb2.append("RecordStateRsp(action=");
            sb2.append(i10);
            sb2.append(", sn=");
            sb2.append(str);
            sb2.append(", info=");
            return a.a(sb2, obj, ")");
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class ResumeRecordRsp {
        private final int scene;
        private final long sessionId;
        private final long start;
        private final int status;

        public ResumeRecordRsp(long j10, long j11, int i10, int i11) {
            this.sessionId = j10;
            this.start = j11;
            this.status = i10;
            this.scene = i11;
        }

        public static /* synthetic */ ResumeRecordRsp copy$default(ResumeRecordRsp resumeRecordRsp, long j10, long j11, int i10, int i11, int i12, Object obj) {
            if ((i12 & 1) != 0) {
                j10 = resumeRecordRsp.sessionId;
            }
            long j12 = j10;
            if ((i12 & 2) != 0) {
                j11 = resumeRecordRsp.start;
            }
            long j13 = j11;
            if ((i12 & 4) != 0) {
                i10 = resumeRecordRsp.status;
            }
            int i13 = i10;
            if ((i12 & 8) != 0) {
                i11 = resumeRecordRsp.scene;
            }
            return resumeRecordRsp.copy(j12, j13, i13, i11);
        }

        public final long component1() {
            return this.sessionId;
        }

        public final long component2() {
            return this.start;
        }

        public final int component3() {
            return this.status;
        }

        public final int component4() {
            return this.scene;
        }

        public final ResumeRecordRsp copy(long j10, long j11, int i10, int i11) {
            return new ResumeRecordRsp(j10, j11, i10, i11);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof ResumeRecordRsp)) {
                return false;
            }
            ResumeRecordRsp resumeRecordRsp = (ResumeRecordRsp) obj;
            return this.sessionId == resumeRecordRsp.sessionId && this.start == resumeRecordRsp.start && this.status == resumeRecordRsp.status && this.scene == resumeRecordRsp.scene;
        }

        public final int getScene() {
            return this.scene;
        }

        public final long getSessionId() {
            return this.sessionId;
        }

        public final long getStart() {
            return this.start;
        }

        public final int getStatus() {
            return this.status;
        }

        public int hashCode() {
            long j10 = this.sessionId;
            long j11 = this.start;
            return (((((((int) (j10 ^ (j10 >>> 32))) * 31) + ((int) ((j11 >>> 32) ^ j11))) * 31) + this.status) * 31) + this.scene;
        }

        public String toString() {
            long j10 = this.sessionId;
            long j11 = this.start;
            int i10 = this.status;
            int i11 = this.scene;
            return "ResumeRecordRsp(sessionId=" + j10 + ", start=" + j11 + ", status=" + i10 + ", scene=" + i11 + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class StartRecordRsp {
        private final int scene;
        private final long sessionId;
        private final long start;
        private final int status;

        public StartRecordRsp(long j10, int i10, int i11, long j11) {
            this.start = j10;
            this.status = i10;
            this.scene = i11;
            this.sessionId = j11;
        }

        public static /* synthetic */ StartRecordRsp copy$default(StartRecordRsp startRecordRsp, long j10, int i10, int i11, long j11, int i12, Object obj) {
            if ((i12 & 1) != 0) {
                j10 = startRecordRsp.start;
            }
            long j12 = j10;
            if ((i12 & 2) != 0) {
                i10 = startRecordRsp.status;
            }
            int i13 = i10;
            if ((i12 & 4) != 0) {
                i11 = startRecordRsp.scene;
            }
            int i14 = i11;
            if ((i12 & 8) != 0) {
                j11 = startRecordRsp.sessionId;
            }
            return startRecordRsp.copy(j12, i13, i14, j11);
        }

        public final long component1() {
            return this.start;
        }

        public final int component2() {
            return this.status;
        }

        public final int component3() {
            return this.scene;
        }

        public final long component4() {
            return this.sessionId;
        }

        public final StartRecordRsp copy(long j10, int i10, int i11, long j11) {
            return new StartRecordRsp(j10, i10, i11, j11);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof StartRecordRsp)) {
                return false;
            }
            StartRecordRsp startRecordRsp = (StartRecordRsp) obj;
            return this.start == startRecordRsp.start && this.status == startRecordRsp.status && this.scene == startRecordRsp.scene && this.sessionId == startRecordRsp.sessionId;
        }

        public final int getScene() {
            return this.scene;
        }

        public final long getSessionId() {
            return this.sessionId;
        }

        public final long getStart() {
            return this.start;
        }

        public final int getStatus() {
            return this.status;
        }

        public int hashCode() {
            long j10 = this.start;
            long j11 = this.sessionId;
            return (((((((int) (j10 ^ (j10 >>> 32))) * 31) + this.status) * 31) + this.scene) * 31) + ((int) ((j11 >>> 32) ^ j11));
        }

        public String toString() {
            long j10 = this.start;
            int i10 = this.status;
            int i11 = this.scene;
            long j11 = this.sessionId;
            return "StartRecordRsp(start=" + j10 + ", status=" + i10 + ", scene=" + i11 + ", sessionId=" + j11 + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class StopRecordRsp {
        private final long fileSize;
        private final int reason;
        private final long sessionId;

        public StopRecordRsp(long j10, int i10, long j11) {
            this.fileSize = j10;
            this.reason = i10;
            this.sessionId = j11;
        }

        public static /* synthetic */ StopRecordRsp copy$default(StopRecordRsp stopRecordRsp, long j10, int i10, long j11, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                j10 = stopRecordRsp.fileSize;
            }
            long j12 = j10;
            if ((i11 & 2) != 0) {
                i10 = stopRecordRsp.reason;
            }
            int i12 = i10;
            if ((i11 & 4) != 0) {
                j11 = stopRecordRsp.sessionId;
            }
            return stopRecordRsp.copy(j12, i12, j11);
        }

        public final long component1() {
            return this.fileSize;
        }

        public final int component2() {
            return this.reason;
        }

        public final long component3() {
            return this.sessionId;
        }

        public final StopRecordRsp copy(long j10, int i10, long j11) {
            return new StopRecordRsp(j10, i10, j11);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof StopRecordRsp)) {
                return false;
            }
            StopRecordRsp stopRecordRsp = (StopRecordRsp) obj;
            return this.fileSize == stopRecordRsp.fileSize && this.reason == stopRecordRsp.reason && this.sessionId == stopRecordRsp.sessionId;
        }

        public final long getFileSize() {
            return this.fileSize;
        }

        public final int getReason() {
            return this.reason;
        }

        public final long getSessionId() {
            return this.sessionId;
        }

        public int hashCode() {
            long j10 = this.fileSize;
            long j11 = this.sessionId;
            return (((((int) (j10 ^ (j10 >>> 32))) * 31) + this.reason) * 31) + ((int) ((j11 >>> 32) ^ j11));
        }

        public String toString() {
            long j10 = this.fileSize;
            int i10 = this.reason;
            long j11 = this.sessionId;
            return "StopRecordRsp(fileSize=" + j10 + ", reason=" + i10 + ", sessionId=" + j11 + ")";
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class WifiOpenRsp {
        private final String wifiName;
        private final String wifiPass;

        public WifiOpenRsp(String str, String str2) {
            d0.g(str, "wifiName");
            d0.g(str2, "wifiPass");
            this.wifiName = str;
            this.wifiPass = str2;
        }

        public static /* synthetic */ WifiOpenRsp copy$default(WifiOpenRsp wifiOpenRsp, String str, String str2, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = wifiOpenRsp.wifiName;
            }
            if ((i10 & 2) != 0) {
                str2 = wifiOpenRsp.wifiPass;
            }
            return wifiOpenRsp.copy(str, str2);
        }

        public final String component1() {
            return this.wifiName;
        }

        public final String component2() {
            return this.wifiPass;
        }

        public final WifiOpenRsp copy(String str, String str2) {
            d0.g(str, "wifiName");
            d0.g(str2, "wifiPass");
            return new WifiOpenRsp(str, str2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof WifiOpenRsp)) {
                return false;
            }
            WifiOpenRsp wifiOpenRsp = (WifiOpenRsp) obj;
            return d0.b(this.wifiName, wifiOpenRsp.wifiName) && d0.b(this.wifiPass, wifiOpenRsp.wifiPass);
        }

        public final String getWifiName() {
            return this.wifiName;
        }

        public final String getWifiPass() {
            return this.wifiPass;
        }

        public int hashCode() {
            return this.wifiPass.hashCode() + (this.wifiName.hashCode() * 31);
        }

        public String toString() {
            return c.a.a("WifiOpenRsp(wifiName=", this.wifiName, ", wifiPass=", this.wifiPass, ")");
        }
    }

    /* compiled from: FlutterDeviceManager.kt */
    public static final class WifiStateRsp {
        private final int state;

        public WifiStateRsp(int i10) {
            this.state = i10;
        }

        public static /* synthetic */ WifiStateRsp copy$default(WifiStateRsp wifiStateRsp, int i10, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                i10 = wifiStateRsp.state;
            }
            return wifiStateRsp.copy(i10);
        }

        public final int component1() {
            return this.state;
        }

        public final WifiStateRsp copy(int i10) {
            return new WifiStateRsp(i10);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            return (obj instanceof WifiStateRsp) && this.state == ((WifiStateRsp) obj).state;
        }

        public final int getState() {
            return this.state;
        }

        public int hashCode() {
            return this.state;
        }

        public String toString() {
            return f.a("WifiStateRsp(state=", this.state, ")");
        }
    }

    static {
        FlutterDeviceManager flutterDeviceManager = new FlutterDeviceManager();
        INSTANCE = flutterDeviceManager;
        FlutterDeviceManager$bleAgentListener$1 flutterDeviceManager$bleAgentListener$1 = new FlutterDeviceManager$bleAgentListener$1();
        bleAgentListener = flutterDeviceManager$bleAgentListener$1;
        FlutterDeviceManager$wifiAgentListener$1 flutterDeviceManager$wifiAgentListener$1 = new FlutterDeviceManager$wifiAgentListener$1();
        wifiAgentListener = flutterDeviceManager$wifiAgentListener$1;
        k.f12044a = 2;
        k.f12045b = true;
        yc.a tntAgent = flutterDeviceManager.getTntAgent();
        if (tntAgent.f19188a == null) {
            tntAgent.f19188a = new ArrayList();
        }
        if (!tntAgent.f19188a.contains(flutterDeviceManager$bleAgentListener$1)) {
            tntAgent.f19188a.add(flutterDeviceManager$bleAgentListener$1);
        }
        yc.a tntAgent2 = flutterDeviceManager.getTntAgent();
        if (tntAgent2.f19189b == null) {
            tntAgent2.f19189b = new ArrayList();
        }
        if (!tntAgent2.f19189b.contains(flutterDeviceManager$wifiAgentListener$1)) {
            tntAgent2.f19189b.add(flutterDeviceManager$wifiAgentListener$1);
        }
    }

    private FlutterDeviceManager() {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48  reason: not valid java name */
    public static final void m8configMethodChannel$lambda48(i iVar, j.d dVar) {
        String[] strArr;
        i iVar2 = iVar;
        j.d dVar2 = dVar;
        d0.g(iVar2, "call");
        d0.g(dVar2, "result");
        a.C0057a aVar = ci.a.f4931a;
        boolean z10 = false;
        aVar.a(b.a("setMethodCallHandler:[", iVar2.f16444a, "]"), new Object[0]);
        String str = iVar2.f16444a;
        if (str != null) {
            switch (str.hashCode()) {
                case -1890938347:
                    if (str.equals("action/deleteWiFiFile")) {
                        Integer num = (Integer) iVar2.a("sessionId");
                        if (num == null) {
                            dVar2.b("-1", "sessionId is null", (Object) null);
                            return;
                        }
                        zc.b wifiAgent = INSTANCE.getWifiAgent();
                        long intValue = (long) num.intValue();
                        a.a aVar2 = a.a.A;
                        hd.i iVar3 = (hd.i) wifiAgent;
                        Objects.requireNonNull(iVar3);
                        iVar3.f11644b.f11612d.add(new bd.b(new int[]{14}, new ed.b(intValue, 0, 0).a(), true, new hd.d(iVar3, aVar2, 1)));
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -1720465687:
                    if (str.equals("action/clearAllFile")) {
                        INSTANCE.getBleAgent().U(w.f647z, x.f658z);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -1713142445:
                    if (str.equals("action/getBluetoothPowerOn")) {
                        if (Build.VERSION.SDK_INT >= 31) {
                            strArr = new String[]{Permission.BLUETOOTH_SCAN, Permission.BLUETOOTH_ADVERTISE, Permission.BLUETOOTH_CONNECT, Permission.ACCESS_COARSE_LOCATION, Permission.ACCESS_FINE_LOCATION};
                        } else {
                            strArr = new String[]{"android.permission.BLUETOOTH", "android.permission.BLUETOOTH_ADMIN", Permission.ACCESS_COARSE_LOCATION, Permission.ACCESS_FINE_LOCATION};
                        }
                        if (!INSTANCE.getBleAgent().K()) {
                            com.blankj.utilcode.util.a.b(new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE"));
                            dVar2.b("-1", "Bluetooth is not turn on", (Object) null);
                            return;
                        }
                        if (!XXPermissions.isGranted((Context) com.blankj.utilcode.util.a.a(), strArr)) {
                            XXPermissions.with((Context) com.blankj.utilcode.util.a.a()).permission(strArr).request(new FlutterDeviceManager$configMethodChannel$1$1());
                            dVar2.b("-1", "No permission", (Object) null);
                            return;
                        }
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -1619880128:
                    if (str.equals("action/deleteFile")) {
                        Integer num2 = (Integer) iVar2.a("sessionId");
                        if (num2 == null) {
                            dVar2.b("-1", "sessionId is null", (Object) null);
                            return;
                        }
                        INSTANCE.getBleAgent().w((long) num2.intValue(), b.f928x, a.a.f580z);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -1593181171:
                    if (str.equals("action/setVPUSensitivity")) {
                        Integer num3 = (Integer) iVar2.a("value");
                        if (num3 == null) {
                            dVar2.b("-1", "setVPUSensitivity is null", (Object) null);
                            return;
                        }
                        INSTANCE.getBleAgent().u(num3.intValue(), b.f923s, a.a.f575u);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -1574083606:
                    if (str.equals("action/setDeviceName")) {
                        INSTANCE.setDeviceName(iVar2, dVar2);
                        return;
                    }
                    return;
                case -1293837399:
                    if (str.equals("action/getMicGain")) {
                        INSTANCE.getBleAgent().h(a.b.f586u, w.f642u);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -1223109694:
                    if (str.equals("action/isWifiOpen")) {
                        n8.f(s0.f16640p, l0.f16620c, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$2(dVar2, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$2>) null), 2, (Object) null);
                        return;
                    }
                    return;
                case -949678353:
                    if (str.equals("action/startBleScan")) {
                        FlutterDeviceManager flutterDeviceManager = INSTANCE;
                        if (!flutterDeviceManager.getBleAgent().m()) {
                            boolean i10 = flutterDeviceManager.getBleAgent().i(true);
                            aVar.a("BLE 扫描结果:[" + i10 + "]", new Object[0]);
                            if (i10) {
                                List<BleDevice> list = bleDeviceList;
                                list.clear();
                                flutterDeviceManager.onBleScan(list);
                                dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                                return;
                            }
                            dVar2.b("-1", "startBleScan fail", (Object) null);
                            return;
                        }
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -877707664:
                    if (str.equals("action/syncFile")) {
                        INSTANCE.syncBleFile(iVar2, dVar2);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -728438124:
                    if (str.equals("action/getState")) {
                        INSTANCE.getState(iVar2, dVar2);
                        return;
                    }
                    return;
                case -724884929:
                    if (str.equals("action/setPrivacy")) {
                        Integer num4 = (Integer) iVar2.a("value");
                        zc.a bleAgent = INSTANCE.getBleAgent();
                        if (num4 != null && num4.intValue() == 1) {
                            z10 = true;
                        }
                        bleAgent.a(z10, a.f912s, x.f654v);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -653028351:
                    if (str.equals("action/getVPUSensitivity")) {
                        INSTANCE.getBleAgent().n(b.f930z, a.a.B);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -484281513:
                    if (str.equals("action/getFileList")) {
                        Integer num5 = (Integer) iVar2.a("sessionId");
                        if (num5 == null) {
                            dVar2.b("-1", "sessionId is null", (Object) null);
                            return;
                        }
                        INSTANCE.getBleAgent().s((long) num5.intValue(), a.b.f590y, w.f646y);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -481080212:
                    if (str.equals("action/stopRecord")) {
                        INSTANCE.getBleAgent().N(0, x.f656x, a.f916w);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -312956207:
                    if (str.equals("action/isDeviceConnect")) {
                        INSTANCE.isDeviceConnect(iVar2, dVar2);
                        return;
                    }
                    return;
                case -259414228:
                    if (str.equals("action/getWiFiFileList")) {
                        Integer num6 = (Integer) iVar2.a("sessionId");
                        if (num6 == null) {
                            dVar2.b("-1", "sessionId is null", (Object) null);
                            return;
                        }
                        zc.b wifiAgent2 = INSTANCE.getWifiAgent();
                        long intValue2 = (long) num6.intValue();
                        a aVar3 = a.f918y;
                        hd.i iVar4 = (hd.i) wifiAgent2;
                        Objects.requireNonNull(iVar4);
                        h a10 = h.a();
                        int i11 = hd.i.f11642n;
                        Objects.requireNonNull(a10);
                        long currentTimeMillis = System.currentTimeMillis() / 1000;
                        a10.f12036a = currentTimeMillis;
                        a10.f12037b = null;
                        a10.f12038c = null;
                        a10.f12039d = i11;
                        iVar4.f11644b.f11612d.add(new bd.b(new int[]{11}, new ed.d(currentTimeMillis, intValue2, false).a(), false, new a5.e(iVar4, a10, (ad.d) aVar3)));
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -251194839:
                    if (str.equals("action/setRawWaveEnabled")) {
                        Integer num7 = (Integer) iVar2.a("value");
                        if (num7 == null) {
                            dVar2.b("-1", "setRawWaveEnabled is null", (Object) null);
                            return;
                        }
                        INSTANCE.getBleAgent().D(Constants$SaveRAWFile.find(num7.intValue()), a.a.f577w, a.b.f588w);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -141032430:
                    if (str.equals("action/stopSyncFile")) {
                        INSTANCE.getBleAgent().Q(x.f657y, a.f917x);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -117958713:
                    if (str.equals("action/connectDevice")) {
                        INSTANCE.connectBle(iVar2, dVar2);
                        return;
                    }
                    return;
                case -102347546:
                    if (str.equals("action/connectWiFi")) {
                        aVar.a("connectWiFi:get In", new Object[0]);
                        String str2 = (String) iVar2.a("token");
                        String str3 = (String) iVar2.a("wifiName");
                        String str4 = (String) iVar2.a("wifiPass");
                        String str5 = curWiFiSN;
                        StringBuilder a11 = e.a("connectWiFi:[", str2, "] [", str3, "] [");
                        a11.append(str4);
                        a11.append("] [");
                        a11.append(str5);
                        a11.append("]");
                        aVar.a(a11.toString(), new Object[0]);
                        if (str2 == null || str3 == null || str4 == null) {
                            dVar2.b("-1", d.a(e.a("argument is null token:[", str2, "] wifiName:[", str3, "] wifiPass:["), str4, "]"), (Object) null);
                            return;
                        }
                        zc.b wifiAgent3 = INSTANCE.getWifiAgent();
                        String str6 = curWiFiSN;
                        hd.i iVar5 = (hd.i) wifiAgent3;
                        Objects.requireNonNull(iVar5);
                        iVar5.f11653k = yc.a.f19187l.f19194g.f();
                        if (iVar5.f11645c) {
                            k.g("WifiAgentImpl", "frequently connectionWifi ignore!!!", new Object[0]);
                        } else {
                            k.e("WifiAgentImpl", String.format(Locale.getDefault(), "connectWifi sn:%s token:%s ssid:%s passWord:%s connectTimeout:%d", new Object[]{str6, str2, str3, str4, 0}), new Object[0]);
                            iVar5.f11645c = true;
                            ThreadPoolExecutor b10 = id.j.b("connectWifi");
                            b10.execute(new hd.f(iVar5, 0, str6, str2, str3, str4));
                            b10.shutdown();
                        }
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case -76620014:
                    if (str.equals("action/isBleConnect")) {
                        INSTANCE.isBleConnect(iVar2, dVar2);
                        return;
                    }
                    return;
                case -3009130:
                    if (str.equals("action/getAutoPowerOff")) {
                        INSTANCE.getBleAgent().Y(b.f924t, a.a.f576v);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 63501246:
                    if (str.equals("action/getStorage")) {
                        INSTANCE.getStorage(iVar2, dVar2);
                        return;
                    }
                    return;
                case 224454553:
                    if (str.equals("action/getDeviceScene")) {
                        INSTANCE.getBleAgent().z(w.f645x, a.b.f591z);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 559482106:
                    if (str.equals("action/startRecord")) {
                        INSTANCE.getBleAgent().L(0, w.f644w, x.f655w);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 619964302:
                    if (str.equals("action/pauseRecord")) {
                        Integer num8 = (Integer) iVar2.a("sessionId");
                        if (num8 == null) {
                            dVar2.b("-1", "sessionId is null", (Object) null);
                            return;
                        }
                        INSTANCE.getBleAgent().d((long) num8.intValue(), 0, a.f915v, b.f926v);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 642967837:
                    if (str.equals("action/setMicGain")) {
                        Integer num9 = (Integer) iVar2.a("value");
                        if (num9 == null) {
                            dVar2.b("-1", "setMicGain is null", (Object) null);
                            return;
                        }
                        INSTANCE.getBleAgent().o(num9.intValue(), x.f653u, a.f913t);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 675251735:
                    if (str.equals("action/resumeRecord")) {
                        Integer num10 = (Integer) iVar2.a("sessionId");
                        if (num10 == null) {
                            dVar2.b("-1", "sessionId is null", (Object) null);
                            return;
                        }
                        INSTANCE.getBleAgent().e((long) num10.intValue(), 0, a.a.f578x, a.b.f589x);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 688957981:
                    if (str.equals("action/getRawWaveEnabled")) {
                        INSTANCE.getBleAgent().O(a.f914u, b.f925u);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 765286482:
                    if (str.equals("action/isWiFiConnect")) {
                        INSTANCE.isWiFiConnect(iVar2, dVar2);
                        return;
                    }
                    return;
                case 907743394:
                    if (str.equals("action/setAutoPowerOff")) {
                        Integer num11 = (Integer) iVar2.a("value");
                        if (num11 == null) {
                            dVar2.b("-1", "setAutoPowerOff is null", (Object) null);
                            return;
                        }
                        INSTANCE.getBleAgent().q(Constants$AutoPowerOffType.find(num11.intValue()), a.b.f587v, w.f643v);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 1096388696:
                    if (str.equals("action/openWiFi")) {
                        INSTANCE.getBleAgent().P(b.f927w, a.a.f579y);
                        aVar.a("return success", new Object[0]);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 1118075978:
                    if (str.equals("action/depairDevice")) {
                        INSTANCE.depairDevice(iVar2, dVar2);
                        return;
                    }
                    return;
                case 1152628157:
                    if (str.equals("action/stopBleScan")) {
                        boolean i12 = INSTANCE.getBleAgent().i(false);
                        aVar.a("BLE 停止结果:[" + i12 + "]", new Object[0]);
                        if (i12) {
                            dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                            return;
                        } else {
                            dVar2.b("-1", "stopBleScan fail", (Object) null);
                            return;
                        }
                    } else {
                        return;
                    }
                case 1248413159:
                    if (str.equals("action/stopSyncWiFiFile")) {
                        Integer num12 = (Integer) iVar2.a("sessionId");
                        if (num12 == null) {
                            dVar2.b("-1", "sessionId is null", (Object) null);
                            return;
                        }
                        ((hd.i) INSTANCE.getWifiAgent()).c((long) num12.intValue(), 0, b.f929y);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 1461636919:
                    if (str.equals("action/pushFotaInfo")) {
                        String str7 = (String) iVar2.a("path");
                        String str8 = (String) iVar2.a("toVersion");
                        FlutterDeviceManager flutterDeviceManager2 = INSTANCE;
                        BleDevice C = flutterDeviceManager2.getBleAgent().C();
                        String str9 = C != null ? C.f9836w : null;
                        if (str7 == null || str8 == null || str9 == null) {
                            dVar2.b("-1", d.a(e.a("argument has null path:[", str7, "] toVersion:[", str8, "] from:["), str9, "]"), (Object) null);
                            return;
                        }
                        flutterDeviceManager2.getBleAgent().k(str7, str9, str8, 0, new FlutterDeviceManager$configMethodChannel$1$37());
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 1548301515:
                    if (str.equals("action/disconnectDevice")) {
                        INSTANCE.disConnectBle(iVar2, dVar2);
                        return;
                    }
                    return;
                case 1794546031:
                    if (str.equals("action/setLedState")) {
                        Integer num13 = (Integer) iVar2.a("value");
                        aVar.a("setLedState:[" + num13 + "]", new Object[0]);
                        zc.a bleAgent2 = INSTANCE.getBleAgent();
                        if (num13 == null || num13.intValue() != 1) {
                            z10 = true;
                        }
                        bleAgent2.I(z10, x.A, a.f919z);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 1883125859:
                    if (str.equals("action/getLedState")) {
                        INSTANCE.getBleAgent().B(a.b.A, w.A);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 1904222533:
                    if (str.equals("action/syncWiFiFile")) {
                        INSTANCE.syncWifiFile(iVar2, dVar2);
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                case 1905559329:
                    if (str.equals("action/getBatteryState")) {
                        INSTANCE.getBatteryState(iVar2, dVar2);
                        return;
                    }
                    return;
                case 1946752478:
                    if (str.equals("action/getDeviceName")) {
                        INSTANCE.getDeviceName(iVar2, dVar2);
                        return;
                    }
                    return;
                case 1956478002:
                    if (str.equals("action/getCurrentDevice")) {
                        INSTANCE.getCurrentDevice(iVar2, dVar2);
                        return;
                    }
                    return;
                case 2049104618:
                    if (str.equals("action/disconnectWiFi")) {
                        hd.k kVar = ((hd.i) INSTANCE.getWifiAgent()).f11643a;
                        if (kVar.f11675h != -1) {
                            kVar.f11669b.disconnect();
                            boolean removeNetwork = kVar.f11669b.removeNetwork(kVar.f11675h);
                            StringBuilder a12 = f.a.a("disconnect(");
                            a12.append(kVar.f11675h);
                            a12.append(") result：");
                            a12.append(removeNetwork);
                            kVar.d(a12.toString());
                            kVar.f11675h = -1;
                        }
                        dVar2.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-10  reason: not valid java name */
    public static final void m9configMethodChannel$lambda48$lambda10(dd.x xVar) {
        if (xVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$10$1(xVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$10$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-11  reason: not valid java name */
    public static final void m10configMethodChannel$lambda48$lambda11(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-12  reason: not valid java name */
    public static final void m11configMethodChannel$lambda48$lambda12(dd.j jVar) {
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$12$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$12$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-13  reason: not valid java name */
    public static final void m12configMethodChannel$lambda48$lambda13(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-14  reason: not valid java name */
    public static final void m13configMethodChannel$lambda48$lambda14(dd.j jVar) {
        a.C0057a aVar = ci.a.f4931a;
        aVar.a("setVPUSensitivity:[" + jVar + "]", new Object[0]);
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$14$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$14$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-15  reason: not valid java name */
    public static final void m14configMethodChannel$lambda48$lambda15(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-16  reason: not valid java name */
    public static final void m15configMethodChannel$lambda48$lambda16(dd.j jVar) {
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$16$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$16$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-17  reason: not valid java name */
    public static final void m16configMethodChannel$lambda48$lambda17(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-18  reason: not valid java name */
    public static final void m17configMethodChannel$lambda48$lambda18(dd.j jVar) {
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$18$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$18$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-19  reason: not valid java name */
    public static final void m18configMethodChannel$lambda48$lambda19(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-20  reason: not valid java name */
    public static final void m19configMethodChannel$lambda48$lambda20(dd.j jVar) {
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$20$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$20$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-21  reason: not valid java name */
    public static final void m20configMethodChannel$lambda48$lambda21(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-22  reason: not valid java name */
    public static final void m21configMethodChannel$lambda48$lambda22(dd.j jVar) {
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$22$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$22$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-23  reason: not valid java name */
    public static final void m22configMethodChannel$lambda48$lambda23(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-24  reason: not valid java name */
    public static final void m23configMethodChannel$lambda48$lambda24(dd.j jVar) {
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$24$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$24$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-25  reason: not valid java name */
    public static final void m24configMethodChannel$lambda48$lambda25(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-26  reason: not valid java name */
    public static final void m25configMethodChannel$lambda48$lambda26(dd.j jVar) {
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$26$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$26$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-27  reason: not valid java name */
    public static final void m26configMethodChannel$lambda48$lambda27(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-28  reason: not valid java name */
    public static final void m27configMethodChannel$lambda48$lambda28(v vVar) {
        if (vVar != null) {
            FlutterDeviceManager flutterDeviceManager = INSTANCE;
            String t10 = flutterDeviceManager.getBleAgent().t();
            if (t10 == null) {
                t10 = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            flutterDeviceManager.onRecordState(1, t10, new StartRecordRsp(vVar.f10084c, vVar.f10085d, vVar.f10086e, vVar.f10083b));
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-29  reason: not valid java name */
    public static final void m28configMethodChannel$lambda48$lambda29(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-3  reason: not valid java name */
    public static final void m29configMethodChannel$lambda48$lambda3(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-30  reason: not valid java name */
    public static final void m30configMethodChannel$lambda48$lambda30(t tVar) {
        if (tVar != null) {
            FlutterDeviceManager flutterDeviceManager = INSTANCE;
            String t10 = flutterDeviceManager.getBleAgent().t();
            if (t10 == null) {
                t10 = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            flutterDeviceManager.onRecordState(2, t10, new PauseRecordRsp(tVar.f10077e, tVar.f10075c, tVar.f10074b));
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-31  reason: not valid java name */
    public static final void m31configMethodChannel$lambda48$lambda31(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-32  reason: not valid java name */
    public static final void m32configMethodChannel$lambda48$lambda32(u uVar) {
        if (uVar != null) {
            FlutterDeviceManager flutterDeviceManager = INSTANCE;
            String t10 = flutterDeviceManager.getBleAgent().t();
            if (t10 == null) {
                t10 = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            flutterDeviceManager.onRecordState(3, t10, new ResumeRecordRsp(uVar.f10078b, uVar.f10079c, uVar.f10080d, uVar.f10081e));
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-33  reason: not valid java name */
    public static final void m33configMethodChannel$lambda48$lambda33(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-34  reason: not valid java name */
    public static final void m34configMethodChannel$lambda48$lambda34(dd.w wVar) {
        if (wVar != null) {
            FlutterDeviceManager flutterDeviceManager = INSTANCE;
            String t10 = flutterDeviceManager.getBleAgent().t();
            if (t10 == null) {
                t10 = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            flutterDeviceManager.onRecordState(4, t10, new StopRecordRsp(wVar.f10091e, wVar.f10089c, wVar.f10088b));
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-35  reason: not valid java name */
    public static final void m35configMethodChannel$lambda48$lambda35(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-36  reason: not valid java name */
    public static final void m36configMethodChannel$lambda48$lambda36(r rVar) {
        String str;
        String str2;
        FlutterDeviceManager flutterDeviceManager = INSTANCE;
        BleDevice C = flutterDeviceManager.getBleAgent().C();
        if (C != null) {
            str = C.f9829p;
            String str3 = C.f9837x;
            String substring = str3.substring(str3.length() - 4);
            if (!l.f12047b.matcher(str).find()) {
                str = b.a(str, "-", substring);
            }
            if (C.f9833t == 712) {
                if (C.f9835v >= 22) {
                    str = a.d.a("iZYREC", substring);
                } else {
                    str = a.d.a("IzyRec", substring);
                }
            }
            if (C.f9833t == 888) {
                str = a.d.a("PLAUD", substring);
            }
        } else {
            str = null;
        }
        BleDevice C2 = flutterDeviceManager.getBleAgent().C();
        if (C2 != null) {
            String str4 = C2.f9837x;
            str2 = str4.substring(str4.length() - 8);
        } else {
            str2 = null;
        }
        String t10 = flutterDeviceManager.getBleAgent().t();
        d0.f(t10, "getBleAgent().serialNumber");
        curWiFiSN = t10;
        if (rVar != null && str != null && str2 != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$36$1(str, str2, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$36$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-37  reason: not valid java name */
    public static final void m37configMethodChannel$lambda48$lambda37(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-38  reason: not valid java name */
    public static final void m38configMethodChannel$lambda48$lambda38(m mVar) {
        if (mVar != null) {
            FlutterDeviceManager flutterDeviceManager = INSTANCE;
            int i10 = mVar.f10053b;
            ArrayList<BleFile> arrayList = mVar.f10054c;
            d0.f(arrayList, "it.fileList");
            flutterDeviceManager.onFileList(i10, arrayList);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-39  reason: not valid java name */
    public static final void m39configMethodChannel$lambda48$lambda39(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-4  reason: not valid java name */
    public static final void m40configMethodChannel$lambda48$lambda4(s sVar) {
        if (sVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$4$1(sVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$4$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-40  reason: not valid java name */
    public static final void m41configMethodChannel$lambda48$lambda40(c0 c0Var) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$41$1((ag.c<? super FlutterDeviceManager$configMethodChannel$1$41$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-41  reason: not valid java name */
    public static final void m42configMethodChannel$lambda48$lambda41(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-42  reason: not valid java name */
    public static final void m43configMethodChannel$lambda48$lambda42(b0 b0Var) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$43$1((ag.c<? super FlutterDeviceManager$configMethodChannel$1$43$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-43  reason: not valid java name */
    public static final void m44configMethodChannel$lambda48$lambda43(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-44  reason: not valid java name */
    public static final void m45configMethodChannel$lambda48$lambda44(dd.i iVar) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$45$1((ag.c<? super FlutterDeviceManager$configMethodChannel$1$45$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-45  reason: not valid java name */
    public static final void m46configMethodChannel$lambda48$lambda45(fd.f fVar) {
        if (fVar != null) {
            FlutterDeviceManager flutterDeviceManager = INSTANCE;
            int i10 = fVar.f10793h;
            ArrayList<BleFile> arrayList = fVar.f10794i;
            d0.f(arrayList, "it.fileList");
            flutterDeviceManager.onFileList(i10, arrayList);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-46  reason: not valid java name */
    public static final void m47configMethodChannel$lambda48$lambda46(fd.e eVar) {
        if (eVar != null && eVar.f10790f == 0) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$47$1((ag.c<? super FlutterDeviceManager$configMethodChannel$1$47$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-47  reason: not valid java name */
    public static final void m48configMethodChannel$lambda48$lambda47(fd.b bVar) {
        if (bVar != null && bVar.f10782g == 0) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$48$1((ag.c<? super FlutterDeviceManager$configMethodChannel$1$48$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-5  reason: not valid java name */
    public static final void m49configMethodChannel$lambda48$lambda5(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-6  reason: not valid java name */
    public static final void m50configMethodChannel$lambda48$lambda6(dd.j jVar) {
        if (jVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$6$1(jVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$6$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-7  reason: not valid java name */
    public static final void m51configMethodChannel$lambda48$lambda7(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-8  reason: not valid java name */
    public static final void m52configMethodChannel$lambda48$lambda8(dd.l lVar) {
        if (lVar != null) {
            s0 s0Var = s0.f16640p;
            l0 l0Var = l0.f16618a;
            n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$configMethodChannel$1$8$1(lVar, (ag.c<? super FlutterDeviceManager$configMethodChannel$1$8$1>) null), 2, (Object) null);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-48$lambda-9  reason: not valid java name */
    public static final void m53configMethodChannel$lambda48$lambda9(boolean z10) {
    }

    private final void connectBle(i iVar, j.d dVar) {
        BleDevice bleDevice;
        String str = (String) iVar.a("sn");
        String str2 = (String) iVar.a("token");
        if (str == null || str2 == null) {
            dVar.b("-1", "sn == null || token == null", (Object) null);
            return;
        }
        Iterator<BleDevice> it = bleDeviceList.iterator();
        while (true) {
            if (!it.hasNext()) {
                bleDevice = null;
                break;
            }
            bleDevice = it.next();
            if (d0.b(bleDevice.f9837x, str)) {
                break;
            }
        }
        if (bleDevice == null) {
            dVar.b("-2", "can not find this sn", (Object) null);
        } else if (getBleAgent().T() == BluetoothStatus.CONNECTED || getBleAgent().T() == BluetoothStatus.CONNECTING) {
            dVar.b("-3", "device is in CONNECTED/CONNECTING", (Object) null);
        } else {
            boolean i10 = getBleAgent().i(false);
            ci.a.f4931a.a("连接设备前，停止搜索:[" + i10 + "]", new Object[0]);
            getBleAgent().r(bleDevice, str2, (String) null, (String) null, 30000, 60000);
            dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
        }
    }

    private final void depairDevice(i iVar, j.d dVar) {
        getBleAgent().j(d0.b((Boolean) iVar.a("clearStorage"), Boolean.TRUE), a.f911r, b.f922r);
        dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    /* access modifiers changed from: private */
    /* renamed from: depairDevice$lambda-62  reason: not valid java name */
    public static final void m54depairDevice$lambda62(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: depairDevice$lambda-63  reason: not valid java name */
    public static final void m55depairDevice$lambda63(dd.k kVar) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$depairDevice$2$1(kVar, (ag.c<? super FlutterDeviceManager$depairDevice$2$1>) null), 2, (Object) null);
    }

    private final void disConnectBle(i iVar, j.d dVar) {
        getBleAgent().b();
        dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    private final void getBatteryState(i iVar, j.d dVar) {
        int i10;
        dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
        if (getBleAgent().W()) {
            i10 = getBleAgent().f();
        } else {
            i10 = ((hd.i) getWifiAgent()).d() ? ((hd.i) getWifiAgent()).f11653k : 100;
        }
        onBatteryState(getBleAgent().c(), i10);
    }

    private final void getCurrentDevice(i iVar, j.d dVar) {
        BleDevice C = getBleAgent().C();
        if (C == null) {
            dVar.b("-1", "bleDevice is null", (Object) null);
            return;
        }
        String str = C.f9829p;
        d0.f(str, "bleDevice.name");
        String str2 = C.f9837x;
        d0.f(str2, "bleDevice.serialNumber");
        String str3 = C.f9834u;
        d0.f(str3, "bleDevice.versionType");
        int i10 = C.f9835v;
        String str4 = C.f9836w;
        d0.f(str4, "bleDevice.versionName");
        dVar.a(q.a.a(new DeviceInfoEntity(str, str2, str3, i10, str4, C.f9833t, C.A, getBleAgent().Z(), getBleAgent().x())));
    }

    private final void getDeviceName(i iVar, j.d dVar) {
        getBleAgent().R(w.f641t, x.f652t);
        dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    /* access modifiers changed from: private */
    /* renamed from: getDeviceName$lambda-64  reason: not valid java name */
    public static final void m56getDeviceName$lambda64(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: getDeviceName$lambda-65  reason: not valid java name */
    public static final void m57getDeviceName$lambda65(g gVar) {
        if (gVar != null) {
            INSTANCE.onBleName(gVar.g());
        }
    }

    private final void getState(i iVar, j.d dVar) {
        getBleAgent().S(w.f639r, x.f650r);
        dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    /* access modifiers changed from: private */
    /* renamed from: getState$lambda-68  reason: not valid java name */
    public static final void m58getState$lambda68(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: getState$lambda-69  reason: not valid java name */
    public static final void m59getState$lambda69(o oVar) {
        if (oVar != null) {
            INSTANCE.onDeviceState(oVar);
        }
    }

    private final void getStorage(i iVar, j.d dVar) {
        getBleAgent().y(a.a.f573s, a.b.f584s);
        dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    /* access modifiers changed from: private */
    /* renamed from: getStorage$lambda-60  reason: not valid java name */
    public static final void m60getStorage$lambda60(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: getStorage$lambda-61  reason: not valid java name */
    public static final void m61getStorage$lambda61(y yVar) {
        if (yVar != null) {
            INSTANCE.onStorage(yVar.f10094c, yVar.f10093b, yVar.f10095d);
        }
    }

    private final yc.a getTntAgent() {
        yc.a aVar = yc.a.f19187l;
        if (aVar != null) {
            return aVar;
        }
        yc.a b10 = yc.a.b(AppProvider.a(), "0b1ef6247326fc79b200163e0a0431dc");
        d0.f(b10, "init(AppProvider.get(), TNT_PENBLESDK_APPKEY)");
        return b10;
    }

    private final void isBleConnect(i iVar, j.d dVar) {
        dVar.a(Boolean.valueOf(getBleAgent().W()));
    }

    private final void isDeviceConnect(i iVar, j.d dVar) {
        dVar.a(Boolean.valueOf(getBleAgent().W() || ((hd.i) getWifiAgent()).d()));
    }

    private final void isWiFiConnect(i iVar, j.d dVar) {
        dVar.a(Boolean.valueOf(((hd.i) getWifiAgent()).d()));
    }

    /* access modifiers changed from: private */
    public final void onBatteryState(boolean z10, int i10) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onBatteryState$1(z10, i10, (ag.c<? super FlutterDeviceManager$onBatteryState$1>) null), 2, (Object) null);
    }

    private final void onBleName(String str) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onBleName$1(str, (ag.c<? super FlutterDeviceManager$onBleName$1>) null), 2, (Object) null);
    }

    private final void onBleScan(List<? extends BleDevice> list) {
        ArrayList arrayList = new ArrayList();
        for (BleDevice bleDevice : list) {
            String str = bleDevice.f9829p;
            d0.f(str, "device.name");
            String str2 = bleDevice.f9837x;
            d0.f(str2, "device.serialNumber");
            String str3 = bleDevice.f9834u;
            d0.f(str3, "device.versionType");
            int i10 = bleDevice.f9835v;
            String str4 = bleDevice.f9836w;
            d0.f(str4, "device.versionName");
            arrayList.add(new DeviceInfoEntity(str, str2, str3, i10, str4, bleDevice.f9833t, getBleAgent().X(), getBleAgent().Z(), getBleAgent().x()));
        }
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onBleScan$1(arrayList, (ag.c<? super FlutterDeviceManager$onBleScan$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    public final void onBleStateChange(String str, int i10) {
        if (str == null) {
            ci.a.f4931a.a("onBleStateChange sn is null", new Object[0]);
            return;
        }
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onBleStateChange$1(str, i10, (ag.c<? super FlutterDeviceManager$onBleStateChange$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    public final void onDeviceConnectResult(String str, int i10) {
        if (str == null) {
            ci.a.f4931a.a("onDeviceConnectResult sn is null", new Object[0]);
            return;
        }
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onDeviceConnectResult$1(str, i10, (ag.c<? super FlutterDeviceManager$onDeviceConnectResult$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    public final void onDeviceState(o oVar) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onDeviceState$1(oVar, (ag.c<? super FlutterDeviceManager$onDeviceState$1>) null), 2, (Object) null);
    }

    private final void onFileList(int i10, List<? extends BleFile> list) {
        ArrayList arrayList = new ArrayList();
        for (BleFile bleFile : list) {
            arrayList.add(new DeviceFile(curDeviceSn, bleFile.f9840p, bleFile.f9841q, bleFile.f9842r, curAudioChannel, curTimeZoneHour, curTimeZoneMin));
        }
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onFileList$1(i10, arrayList, (ag.c<? super FlutterDeviceManager$onFileList$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    public final void onFotaState(int i10, Integer num, String str) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onFotaState$1(i10, num, str, (ag.c<? super FlutterDeviceManager$onFotaState$1>) null), 2, (Object) null);
    }

    private final void onOpusData(int i10, int i11, long j10, byte[] bArr) {
        Pair[] pairArr = {new Pair("sessionId", Integer.valueOf(i10)), new Pair("state", Integer.valueOf(i11)), new Pair("start", Long.valueOf(j10)), new Pair("bytes", bArr)};
        HashMap hashMap = new HashMap(yf.h.x(4));
        p.T(hashMap, pairArr);
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onOpusData$1(hashMap, (ag.c<? super FlutterDeviceManager$onOpusData$1>) null), 2, (Object) null);
    }

    private final void onPCMData(int i10, int i11, long j10, short[] sArr) {
        Pair[] pairArr = {new Pair("sessionId", Integer.valueOf(i10)), new Pair("state", Integer.valueOf(i11)), new Pair("start", Long.valueOf(j10)), new Pair("bytes", onPCMData$shortArrayToByteArray(sArr))};
        HashMap hashMap = new HashMap(yf.h.x(4));
        p.T(hashMap, pairArr);
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onPCMData$1(hashMap, (ag.c<? super FlutterDeviceManager$onPCMData$1>) null), 2, (Object) null);
    }

    private static final byte[] onPCMData$shortArrayToByteArray(short[] sArr) {
        ByteBuffer allocate = ByteBuffer.allocate(sArr.length * 2);
        allocate.asShortBuffer().put(sArr);
        byte[] array = allocate.array();
        d0.f(array, "buffer.array()");
        return array;
    }

    /* access modifiers changed from: private */
    public final void onRecordState(int i10, String str, Object obj) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onRecordState$1(i10, str, obj, (ag.c<? super FlutterDeviceManager$onRecordState$1>) null), 2, (Object) null);
    }

    private final void onStorage(long j10, long j11, long j12) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onStorage$1(j10, j11, j12, (ag.c<? super FlutterDeviceManager$onStorage$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    public final void onWiFiState(int i10) {
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDeviceManager$onWiFiState$1(i10, (ag.c<? super FlutterDeviceManager$onWiFiState$1>) null), 2, (Object) null);
    }

    private final void setDeviceName(i iVar, j.d dVar) {
        String str = (String) iVar.a("name");
        zc.a bleAgent = getBleAgent();
        if (str == null) {
            str = "PLAUD_NOTE";
        }
        bleAgent.E(str, a.a.f574t, a.b.f585t);
        dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    /* access modifiers changed from: private */
    /* renamed from: setDeviceName$lambda-66  reason: not valid java name */
    public static final void m62setDeviceName$lambda66(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: setDeviceName$lambda-67  reason: not valid java name */
    public static final void m63setDeviceName$lambda67(g gVar) {
        if (gVar != null) {
            INSTANCE.onBleName(gVar.g());
        }
    }

    private final void syncBleFile(i iVar, j.d dVar) {
        i iVar2 = iVar;
        Integer num = (Integer) iVar2.a("sessionId");
        Integer num2 = (Integer) iVar2.a("start");
        Integer num3 = (Integer) iVar2.a("end");
        Boolean bool = (Boolean) iVar2.a("decode");
        if (num == null || num2 == null || num3 == null || bool == null) {
            dVar.b("-1", "argument error sessionId:[" + num + "], start:[" + num2 + "] || end:[" + num3 + "] || decode:[" + bool + "]", (Object) null);
            return;
        }
        d dVar2 = new d(bool, num);
        c cVar = new c(num, 0);
        kd.a aVar = new kd.a(yc.a.f19186k);
        aVar.f13834p = cVar;
        aVar.f13835q = dVar2;
        aVar.f13836r = new d(num, bool, 1);
        getBleAgent().l((long) num.intValue(), (long) num2.intValue(), (long) num3.intValue(), a.f910q, new d(num, bool, 2), b.f921q, aVar);
    }

    /* access modifiers changed from: private */
    /* renamed from: syncBleFile$lambda-50  reason: not valid java name */
    public static final void m64syncBleFile$lambda50(Boolean bool, Integer num, short[] sArr, long j10) {
        if (sArr != null && d0.b(bool, Boolean.TRUE)) {
            INSTANCE.onPCMData(num.intValue(), 1, j10, sArr);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: syncBleFile$lambda-52  reason: not valid java name */
    public static final void m65syncBleFile$lambda52(Integer num, byte[] bArr, long j10) {
        if (bArr != null) {
            INSTANCE.onOpusData(num.intValue(), 1, j10, bArr);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: syncBleFile$lambda-53  reason: not valid java name */
    public static final void m66syncBleFile$lambda53(Integer num, Boolean bool, int i10) {
        FlutterDeviceManager flutterDeviceManager = INSTANCE;
        flutterDeviceManager.onOpusData(num.intValue(), 2, 0, new byte[0]);
        if (d0.b(bool, Boolean.TRUE)) {
            flutterDeviceManager.onPCMData(num.intValue(), 2, 0, new short[0]);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: syncBleFile$lambda-54  reason: not valid java name */
    public static final void m67syncBleFile$lambda54(boolean z10) {
        ci.a.f4931a.a(f.a("syncBleFile 是否发送成功: ", z10), new Object[0]);
    }

    /* access modifiers changed from: private */
    /* renamed from: syncBleFile$lambda-55  reason: not valid java name */
    public static final void m68syncBleFile$lambda55(Integer num, Boolean bool, z zVar) {
        FlutterDeviceManager flutterDeviceManager = INSTANCE;
        flutterDeviceManager.onOpusData(num.intValue(), 0, 0, new byte[0]);
        if (d0.b(bool, Boolean.TRUE)) {
            flutterDeviceManager.onPCMData(num.intValue(), 0, 0, new short[0]);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: syncBleFile$lambda-56  reason: not valid java name */
    public static final void m69syncBleFile$lambda56(a0 a0Var) {
    }

    /* access modifiers changed from: private */
    /* renamed from: syncTime$lambda-0  reason: not valid java name */
    public static final void m70syncTime$lambda0(boolean z10) {
    }

    /* access modifiers changed from: private */
    /* renamed from: syncTime$lambda-2  reason: not valid java name */
    public static final void m71syncTime$lambda2(e0 e0Var) {
        if (e0Var != null) {
            FlutterDeviceManager flutterDeviceManager = INSTANCE;
            curTimeZoneHour = e0Var.f10042c;
            curTimeZoneMin = flutterDeviceManager.getBleAgent().x();
        }
    }

    private final void syncWifiFile(i iVar, j.d dVar) {
        Integer num = (Integer) iVar.a("sessionId");
        Integer num2 = (Integer) iVar.a("start");
        Integer num3 = (Integer) iVar.a("end");
        a.C0057a aVar = ci.a.f4931a;
        aVar.a("sessionId:[" + num + "], start:[" + num2 + "] || end:[" + num3 + "]", new Object[0]);
        if (num == null || num2 == null || num3 == null) {
            dVar.b("-1", "argument error sessionId:[" + num + "], start:[" + num2 + "] || end:[" + num3 + "]", (Object) null);
            return;
        }
        ((hd.i) getWifiAgent()).b((long) num.intValue(), 0, num2.intValue(), num3.intValue(), false, new c(num, 1), new c(num, 2));
    }

    /* access modifiers changed from: private */
    /* renamed from: syncWifiFile$lambda-57  reason: not valid java name */
    public static final void m72syncWifiFile$lambda57(Integer num, fd.d dVar) {
        if (dVar != null && dVar.f10789g == 0) {
            INSTANCE.onOpusData(num.intValue(), 0, 0, new byte[0]);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: syncWifiFile$lambda-59  reason: not valid java name */
    public static final void m73syncWifiFile$lambda59(Integer num, fd.c cVar) {
        if (cVar != null) {
            FlutterDeviceManager flutterDeviceManager = INSTANCE;
            int intValue = num.intValue();
            long j10 = (long) cVar.f10784g;
            byte[] bArr = cVar.f10786i;
            d0.f(bArr, "it.pkgData");
            flutterDeviceManager.onOpusData(intValue, 1, j10, bArr);
            boolean z10 = true;
            if (cVar.f10787j != 1) {
                z10 = false;
            }
            if (z10) {
                flutterDeviceManager.onOpusData(num.intValue(), 2, 0, new byte[0]);
            }
        }
    }

    public final void addBleDevice(BleDevice bleDevice) {
        d0.g(bleDevice, "bleDevice");
        for (BleDevice bleDevice2 : bleDeviceList) {
            if (d0.b(bleDevice.f9837x, bleDevice2.f9837x)) {
                return;
            }
        }
        List<BleDevice> list = bleDeviceList;
        list.add(bleDevice);
        a.C0057a aVar = ci.a.f4931a;
        aVar.a("新增搜索设备:[" + bleDevice + "]", new Object[0]);
        onBleScan(list);
    }

    public final void configMethodChannel(io.flutter.embedding.engine.a aVar) {
        d0.g(aVar, "flutterEngine");
        j jVar = new j(aVar.f12224c.f12051s, CHANNEL);
        methodChannel = jVar;
        jVar.b(e.f936a);
    }

    public final zc.a getBleAgent() {
        zc.a aVar = yc.a.f19187l.f19194g;
        if (aVar != null) {
            return aVar;
        }
        yc.a.b(AppProvider.a(), "0b1ef6247326fc79b200163e0a0431dc");
        zc.a aVar2 = getTntAgent().f19194g;
        d0.f(aVar2, "{\n            TntAgent.i…tAgent.bleAgent\n        }");
        return aVar2;
    }

    public final zc.b getWifiAgent() {
        zc.b bVar = getTntAgent().f19196i;
        if (bVar != null) {
            return bVar;
        }
        yc.a.b(AppProvider.a(), "0b1ef6247326fc79b200163e0a0431dc");
        zc.b bVar2 = getTntAgent().f19196i;
        d0.f(bVar2, "{\n            TntAgent.i…Agent.wiFiAgent\n        }");
        return bVar2;
    }

    public final void syncTime() {
        getBleAgent().g(w.f640s, x.f651s);
    }
}
