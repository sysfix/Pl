package ai.plaud.android.plaud.anew.flutter.device;

import fd.a;
import jd.d;

public final /* synthetic */ class c implements d, ad.d {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f932p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Integer f933q;

    public /* synthetic */ c(Integer num, int i10) {
        this.f932p = i10;
        this.f933q = num;
    }

    public void b(a aVar) {
        switch (this.f932p) {
            case 1:
                FlutterDeviceManager.m72syncWifiFile$lambda57(this.f933q, (fd.d) aVar);
                return;
            default:
                FlutterDeviceManager.m73syncWifiFile$lambda59(this.f933q, (fd.c) aVar);
                return;
        }
    }

    public void d(Object obj, long j10) {
        FlutterDeviceManager.m65syncBleFile$lambda52(this.f933q, (byte[]) obj, j10);
    }
}
