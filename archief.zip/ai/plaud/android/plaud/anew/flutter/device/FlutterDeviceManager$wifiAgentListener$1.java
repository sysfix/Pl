package ai.plaud.android.plaud.anew.flutter.device;

import ci.a;
import com.tinnotech.penblesdk.Constants$ConnectWifiFailed;
import com.tinnotech.penblesdk.entity.WifiStatus;
import fd.l;
import hd.i;
import hd.j;
import rg.d0;

/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$wifiAgentListener$1 implements j {

    /* compiled from: FlutterDeviceManager.kt */
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[WifiStatus.values().length];
            iArr[WifiStatus.NONE.ordinal()] = 1;
            iArr[WifiStatus.OFF.ordinal()] = 2;
            iArr[WifiStatus.TURNING_OFF.ordinal()] = 3;
            iArr[WifiStatus.TURNING_ON.ordinal()] = 4;
            iArr[WifiStatus.ON.ordinal()] = 5;
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public void batteryLevelUpdate(boolean z10, int i10, int i11) {
        a.C0057a aVar = a.f4931a;
        aVar.a("电量改变 " + z10 + " " + i10 + " " + i11, new Object[0]);
        FlutterDeviceManager flutterDeviceManager = FlutterDeviceManager.INSTANCE;
        flutterDeviceManager.onBatteryState(((i) flutterDeviceManager.getWifiAgent()).f11652j, i10);
    }

    public void clientConnected() {
        a.f4931a.a("已完成笔端连接", new Object[0]);
        FlutterDeviceManager.INSTANCE.onWiFiState(6);
    }

    public void clientDisconnect() {
        a.f4931a.a("断开笔端连接", new Object[0]);
        FlutterDeviceManager.INSTANCE.onWiFiState(7);
    }

    public void clientTips(fd.j jVar) {
        d0.g(jVar, "p0");
        a.C0057a aVar = a.f4931a;
        aVar.a("设备提示 " + jVar, new Object[0]);
    }

    public void deviceSwitchBtMode(l lVar) {
        d0.g(lVar, "p0");
        a.C0057a aVar = a.f4931a;
        aVar.d("设备即将切换为蓝牙连接模式 " + lVar, new Object[0]);
    }

    public void wifiConnectFail(Constants$ConnectWifiFailed constants$ConnectWifiFailed) {
        d0.g(constants$ConnectWifiFailed, "p0");
        a.C0057a aVar = a.f4931a;
        aVar.a("WiFi连接失败 " + constants$ConnectWifiFailed, new Object[0]);
        FlutterDeviceManager.INSTANCE.onWiFiState(-2);
    }

    public void wifiConnected() {
        a.f4931a.a("WiFi已连接", new Object[0]);
        FlutterDeviceManager.INSTANCE.onWiFiState(4);
    }

    public void wifiDisconnected() {
        a.f4931a.a("WiFi已断开连接，也可能是连上别的wifi了", new Object[0]);
        FlutterDeviceManager.INSTANCE.onWiFiState(5);
    }

    public void wifiScanFinish() {
    }

    public void wifiStatusChange(WifiStatus wifiStatus, WifiStatus wifiStatus2) {
        d0.g(wifiStatus, "state");
        d0.g(wifiStatus2, "statePrevious");
        a.C0057a aVar = a.f4931a;
        aVar.a("Wifi状态发生改变 " + wifiStatus + " " + wifiStatus2, new Object[0]);
        int i10 = WhenMappings.$EnumSwitchMapping$0[wifiStatus.ordinal()];
        if (i10 == 1) {
            FlutterDeviceManager.INSTANCE.onWiFiState(-1);
        } else if (i10 == 2) {
            FlutterDeviceManager.INSTANCE.onWiFiState(0);
        } else if (i10 == 3) {
            FlutterDeviceManager.INSTANCE.onWiFiState(1);
        } else if (i10 == 4) {
            FlutterDeviceManager.INSTANCE.onWiFiState(3);
        } else if (i10 == 5) {
            FlutterDeviceManager.INSTANCE.onWiFiState(2);
        }
    }
}
