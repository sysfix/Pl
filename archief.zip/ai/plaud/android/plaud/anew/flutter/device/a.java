package ai.plaud.android.plaud.anew.flutter.device;

import ad.b;
import ad.c;
import ad.d;
import android.database.Cursor;
import android.util.Base64;
import android.util.JsonReader;
import androidx.arch.core.util.Function;
import b8.g;
import dd.c0;
import dd.j;
import dd.x;
import fd.f;
import io.flutter.plugins.webviewflutter.GeneratedAndroidWebView;
import io.flutter.plugins.webviewflutter.a;
import io.flutter.plugins.webviewflutter.s;
import io.flutter.plugins.webviewflutter.w;
import java.util.Objects;
import ma.l;
import okhttp3.HttpUrl;
import p6.n;
import q9.b0;
import q9.o;
import r9.a;

public final /* synthetic */ class a implements b, c, d, Function, n.b, a.C0242a, b8.a, a.C0166a, GeneratedAndroidWebView.z.a, GeneratedAndroidWebView.o.a, GeneratedAndroidWebView.w.a {
    public static final /* synthetic */ a A = new a(10);
    public static final /* synthetic */ a B = new a(11);
    public static final /* synthetic */ a C = new a(12);
    public static final /* synthetic */ a D = new a(13);
    public static final /* synthetic */ a E = new a(14);
    public static final /* synthetic */ a F = new a(15);
    public static final /* synthetic */ a G = new a(16);
    public static final /* synthetic */ a H = new a(17);
    public static final /* synthetic */ a I = new a(18);
    public static final /* synthetic */ a J = new a(19);
    public static final /* synthetic */ a K = new a(20);
    public static final /* synthetic */ a L = new a(21);
    public static final /* synthetic */ a M = new a(22);

    /* renamed from: q  reason: collision with root package name */
    public static final /* synthetic */ a f910q = new a(0);

    /* renamed from: r  reason: collision with root package name */
    public static final /* synthetic */ a f911r = new a(1);

    /* renamed from: s  reason: collision with root package name */
    public static final /* synthetic */ a f912s = new a(2);

    /* renamed from: t  reason: collision with root package name */
    public static final /* synthetic */ a f913t = new a(3);

    /* renamed from: u  reason: collision with root package name */
    public static final /* synthetic */ a f914u = new a(4);

    /* renamed from: v  reason: collision with root package name */
    public static final /* synthetic */ a f915v = new a(5);

    /* renamed from: w  reason: collision with root package name */
    public static final /* synthetic */ a f916w = new a(6);

    /* renamed from: x  reason: collision with root package name */
    public static final /* synthetic */ a f917x = new a(7);

    /* renamed from: y  reason: collision with root package name */
    public static final /* synthetic */ a f918y = new a(8);

    /* renamed from: z  reason: collision with root package name */
    public static final /* synthetic */ a f919z = new a(9);

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f920p;

    public /* synthetic */ a(int i10) {
        this.f920p = i10;
    }

    public void a(Object obj) {
        switch (this.f920p) {
            case 16:
                Void voidR = (Void) obj;
                return;
            case AndroidVersion.ANDROID_4_2 /*17*/:
                Void voidR2 = (Void) obj;
                int i10 = s.c.f12900h;
                return;
            case AndroidVersion.ANDROID_4_3 /*18*/:
                Void voidR3 = (Void) obj;
                return;
            case AndroidVersion.ANDROID_4_4 /*19*/:
                Void voidR4 = (Void) obj;
                return;
            case 20:
                Void voidR5 = (Void) obj;
                int i11 = w.a.f12917d;
                return;
            case AndroidVersion.ANDROID_5 /*21*/:
                Void voidR6 = (Void) obj;
                int i12 = w.c.f12920c;
                return;
            default:
                Void voidR7 = (Void) obj;
                int i13 = w.c.f12920c;
                return;
        }
    }

    public Object apply(Object obj) {
        switch (this.f920p) {
            case 10:
                return Boolean.valueOf(((q2.a) obj).F0());
            default:
                f6.b bVar = n.f15429u;
                return Boolean.valueOf(((Cursor) obj).getCount() > 0);
        }
    }

    public void b(fd.a aVar) {
        FlutterDeviceManager.m46configMethodChannel$lambda48$lambda45((f) aVar);
    }

    public Object d(JsonReader jsonReader) {
        switch (this.f920p) {
            case 12:
                return r9.a.b(jsonReader);
            default:
                z9.a aVar = r9.a.f16362a;
                jsonReader.beginObject();
                Long l10 = null;
                Long l11 = null;
                String str = null;
                String str2 = null;
                while (jsonReader.hasNext()) {
                    String a10 = a.c.a(jsonReader);
                    char c10 = 65535;
                    switch (a10.hashCode()) {
                        case 3373707:
                            if (a10.equals("name")) {
                                c10 = 0;
                                break;
                            }
                            break;
                        case 3530753:
                            if (a10.equals("size")) {
                                c10 = 1;
                                break;
                            }
                            break;
                        case 3601339:
                            if (a10.equals(ZendeskIdentityStorage.UUID_KEY)) {
                                c10 = 2;
                                break;
                            }
                            break;
                        case 1153765347:
                            if (a10.equals("baseAddress")) {
                                c10 = 3;
                                break;
                            }
                            break;
                    }
                    switch (c10) {
                        case 0:
                            str = jsonReader.nextString();
                            Objects.requireNonNull(str, "Null name");
                            break;
                        case 1:
                            l11 = Long.valueOf(jsonReader.nextLong());
                            break;
                        case 2:
                            str2 = new String(Base64.decode(jsonReader.nextString(), 2), b0.f15852a);
                            break;
                        case 3:
                            l10 = Long.valueOf(jsonReader.nextLong());
                            break;
                        default:
                            jsonReader.skipValue();
                            break;
                    }
                }
                jsonReader.endObject();
                String str3 = l10 == null ? " baseAddress" : HttpUrl.FRAGMENT_ENCODE_SET;
                if (l11 == null) {
                    str3 = a.d.a(str3, " size");
                }
                if (str == null) {
                    str3 = a.d.a(str3, " name");
                }
                if (str3.isEmpty()) {
                    return new o(l10.longValue(), l11.longValue(), str, str2, (o.a) null);
                }
                throw new IllegalStateException(a.d.a("Missing required properties:", str3));
        }
    }

    public void f(z1.c cVar) {
        switch (this.f920p) {
            case 3:
                FlutterDeviceManager.m17configMethodChannel$lambda48$lambda18((j) cVar);
                return;
            case 6:
                FlutterDeviceManager.m34configMethodChannel$lambda48$lambda34((dd.w) cVar);
                return;
            case 7:
                FlutterDeviceManager.m41configMethodChannel$lambda48$lambda40((c0) cVar);
                return;
            default:
                FlutterDeviceManager.m9configMethodChannel$lambda48$lambda10((x) cVar);
                return;
        }
    }

    public void g(boolean z10) {
        switch (this.f920p) {
            case 0:
                FlutterDeviceManager.m67syncBleFile$lambda54(z10);
                return;
            case 1:
                FlutterDeviceManager.m54depairDevice$lambda62(z10);
                return;
            case 2:
                FlutterDeviceManager.m29configMethodChannel$lambda48$lambda3(z10);
                return;
            case 4:
                FlutterDeviceManager.m22configMethodChannel$lambda48$lambda23(z10);
                return;
            default:
                FlutterDeviceManager.m28configMethodChannel$lambda48$lambda29(z10);
                return;
        }
    }

    public Object k(g gVar) {
        Object obj = l.f14411b;
        return 403;
    }
}
