package ai.plaud.android.plaud.anew.flutter.device;

import ag.c;
import ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager;
import com.google.android.gms.internal.play_billing.x2;
import dd.o;
import gg.p;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.device.FlutterDeviceManager$onDeviceState$1", f = "FlutterDeviceManager.kt", l = {}, m = "invokeSuspend")
/* compiled from: FlutterDeviceManager.kt */
public final class FlutterDeviceManager$onDeviceState$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ o $rsp;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterDeviceManager$onDeviceState$1(o oVar, c<? super FlutterDeviceManager$onDeviceState$1> cVar) {
        super(2, cVar);
        this.$rsp = oVar;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterDeviceManager$onDeviceState$1(this.$rsp, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterDeviceManager$onDeviceState$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            j access$getMethodChannel$p = FlutterDeviceManager.methodChannel;
            if (access$getMethodChannel$p != null) {
                o oVar = this.$rsp;
                access$getMethodChannel$p.a("listener/onDeviceState", q.a.a(new FlutterDeviceManager.GetStateResult((int) oVar.f10063h, (int) oVar.f10057b, (int) ((long) oVar.f10059d), oVar.f10058c ? 1 : 0, oVar.f10061f ? 1 : 0)), (j.d) null);
            }
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
