package ai.plaud.android.plaud.anew.flutter.device;

import re.i;
import re.j;

public final /* synthetic */ class e implements j.c {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ e f936a = new e();

    public final void g(i iVar, j.d dVar) {
        FlutterDeviceManager.m8configMethodChannel$lambda48(iVar, dVar);
    }
}
