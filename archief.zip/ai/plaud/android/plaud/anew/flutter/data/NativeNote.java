package ai.plaud.android.plaud.anew.flutter.data;

import ai.plaud.android.plaud.anew.database.recordfile.a;
import androidx.recyclerview.widget.RecyclerView;
import c.b;
import com.google.common.collect.MapMakerInternalMap;
import java.util.List;
import okhttp3.internal.http2.Http2;
import okhttp3.internal.http2.Http2Connection;
import rg.d0;

/* compiled from: FlutterDatabaseManager.kt */
public final class NativeNote {
    private final long audioDuration;
    private final String audioFileMD5;
    private final String audioFilePath;
    private final long audioFileSize;
    private final String audioFullName;
    private final List<Double> audioWaveList;
    private final String cloudId;
    private final long cloudVersion;
    private final long createTime;
    private final int deleteState;
    private final List<String> folderIdList;
    private final String from;
    private final boolean hasEdit;
    private final boolean isNew;
    private final String keyId;
    private final List<String> keywords;
    private final long lastEditTime;
    private final boolean localAudioFileComplete;
    private final String noteTitle;
    private final int recMode;
    private final String summary;
    private final String summaryErrorTip;
    private final int timeZone;
    private final int timezoneMin;
    private final List<FlutterTranscriptionData> transcription;
    private final String transcriptionErrorTip;
    private final int transcriptionState;

    public NativeNote(String str, long j10, String str2, String str3, long j11, long j12, String str4, String str5, String str6, boolean z10, String str7, int i10, int i11, int i12, String str8, String str9, List<String> list, List<String> list2, int i13, boolean z11, int i14, boolean z12, long j13, long j14, String str10, List<FlutterTranscriptionData> list3, List<Double> list4) {
        String str11 = str;
        String str12 = str2;
        String str13 = str3;
        String str14 = str4;
        String str15 = str5;
        String str16 = str6;
        String str17 = str7;
        String str18 = str8;
        String str19 = str9;
        List<String> list5 = list;
        List<String> list6 = list2;
        String str20 = str10;
        List<FlutterTranscriptionData> list7 = list3;
        d0.g(str11, "keyId");
        d0.g(str12, "from");
        d0.g(str13, "noteTitle");
        d0.g(str14, "audioFullName");
        d0.g(str15, "audioFileMD5");
        d0.g(str16, "audioFilePath");
        d0.g(str17, "cloudId");
        d0.g(str18, "transcriptionErrorTip");
        d0.g(str19, "summaryErrorTip");
        d0.g(list5, "folderIdList");
        d0.g(list6, "keywords");
        d0.g(str20, "summary");
        d0.g(list7, "transcription");
        d0.g(list4, "audioWaveList");
        this.keyId = str11;
        this.createTime = j10;
        this.from = str12;
        this.noteTitle = str13;
        this.audioDuration = j11;
        this.audioFileSize = j12;
        this.audioFullName = str14;
        this.audioFileMD5 = str15;
        this.audioFilePath = str16;
        this.localAudioFileComplete = z10;
        this.cloudId = str17;
        this.timeZone = i10;
        this.timezoneMin = i11;
        this.transcriptionState = i12;
        this.transcriptionErrorTip = str18;
        this.summaryErrorTip = str19;
        this.folderIdList = list5;
        this.keywords = list6;
        this.recMode = i13;
        this.isNew = z11;
        this.deleteState = i14;
        this.hasEdit = z12;
        this.lastEditTime = j13;
        this.cloudVersion = j14;
        this.summary = str20;
        this.transcription = list7;
        this.audioWaveList = list4;
    }

    public static /* synthetic */ NativeNote copy$default(NativeNote nativeNote, String str, long j10, String str2, String str3, long j11, long j12, String str4, String str5, String str6, boolean z10, String str7, int i10, int i11, int i12, String str8, String str9, List list, List list2, int i13, boolean z11, int i14, boolean z12, long j13, long j14, String str10, List list3, List list4, int i15, Object obj) {
        NativeNote nativeNote2 = nativeNote;
        int i16 = i15;
        return nativeNote.copy((i16 & 1) != 0 ? nativeNote2.keyId : str, (i16 & 2) != 0 ? nativeNote2.createTime : j10, (i16 & 4) != 0 ? nativeNote2.from : str2, (i16 & 8) != 0 ? nativeNote2.noteTitle : str3, (i16 & 16) != 0 ? nativeNote2.audioDuration : j11, (i16 & 32) != 0 ? nativeNote2.audioFileSize : j12, (i16 & 64) != 0 ? nativeNote2.audioFullName : str4, (i16 & 128) != 0 ? nativeNote2.audioFileMD5 : str5, (i16 & 256) != 0 ? nativeNote2.audioFilePath : str6, (i16 & RecyclerView.z.FLAG_ADAPTER_POSITION_UNKNOWN) != 0 ? nativeNote2.localAudioFileComplete : z10, (i16 & RecyclerView.z.FLAG_ADAPTER_FULLUPDATE) != 0 ? nativeNote2.cloudId : str7, (i16 & 2048) != 0 ? nativeNote2.timeZone : i10, (i16 & 4096) != 0 ? nativeNote2.timezoneMin : i11, (i16 & 8192) != 0 ? nativeNote2.transcriptionState : i12, (i16 & Http2.INITIAL_MAX_FRAME_SIZE) != 0 ? nativeNote2.transcriptionErrorTip : str8, (i16 & 32768) != 0 ? nativeNote2.summaryErrorTip : str9, (i16 & MapMakerInternalMap.MAX_SEGMENTS) != 0 ? nativeNote2.folderIdList : list, (i16 & 131072) != 0 ? nativeNote2.keywords : list2, (i16 & 262144) != 0 ? nativeNote2.recMode : i13, (i16 & 524288) != 0 ? nativeNote2.isNew : z11, (i16 & 1048576) != 0 ? nativeNote2.deleteState : i14, (i16 & 2097152) != 0 ? nativeNote2.hasEdit : z12, (i16 & 4194304) != 0 ? nativeNote2.lastEditTime : j13, (i16 & 8388608) != 0 ? nativeNote2.cloudVersion : j14, (i16 & Http2Connection.OKHTTP_CLIENT_WINDOW_SIZE) != 0 ? nativeNote2.summary : str10, (33554432 & i16) != 0 ? nativeNote2.transcription : list3, (i16 & 67108864) != 0 ? nativeNote2.audioWaveList : list4);
    }

    public final String component1() {
        return this.keyId;
    }

    public final boolean component10() {
        return this.localAudioFileComplete;
    }

    public final String component11() {
        return this.cloudId;
    }

    public final int component12() {
        return this.timeZone;
    }

    public final int component13() {
        return this.timezoneMin;
    }

    public final int component14() {
        return this.transcriptionState;
    }

    public final String component15() {
        return this.transcriptionErrorTip;
    }

    public final String component16() {
        return this.summaryErrorTip;
    }

    public final List<String> component17() {
        return this.folderIdList;
    }

    public final List<String> component18() {
        return this.keywords;
    }

    public final int component19() {
        return this.recMode;
    }

    public final long component2() {
        return this.createTime;
    }

    public final boolean component20() {
        return this.isNew;
    }

    public final int component21() {
        return this.deleteState;
    }

    public final boolean component22() {
        return this.hasEdit;
    }

    public final long component23() {
        return this.lastEditTime;
    }

    public final long component24() {
        return this.cloudVersion;
    }

    public final String component25() {
        return this.summary;
    }

    public final List<FlutterTranscriptionData> component26() {
        return this.transcription;
    }

    public final List<Double> component27() {
        return this.audioWaveList;
    }

    public final String component3() {
        return this.from;
    }

    public final String component4() {
        return this.noteTitle;
    }

    public final long component5() {
        return this.audioDuration;
    }

    public final long component6() {
        return this.audioFileSize;
    }

    public final String component7() {
        return this.audioFullName;
    }

    public final String component8() {
        return this.audioFileMD5;
    }

    public final String component9() {
        return this.audioFilePath;
    }

    public final NativeNote copy(String str, long j10, String str2, String str3, long j11, long j12, String str4, String str5, String str6, boolean z10, String str7, int i10, int i11, int i12, String str8, String str9, List<String> list, List<String> list2, int i13, boolean z11, int i14, boolean z12, long j13, long j14, String str10, List<FlutterTranscriptionData> list3, List<Double> list4) {
        String str11 = str;
        d0.g(str11, "keyId");
        d0.g(str2, "from");
        d0.g(str3, "noteTitle");
        d0.g(str4, "audioFullName");
        d0.g(str5, "audioFileMD5");
        d0.g(str6, "audioFilePath");
        d0.g(str7, "cloudId");
        d0.g(str8, "transcriptionErrorTip");
        d0.g(str9, "summaryErrorTip");
        d0.g(list, "folderIdList");
        d0.g(list2, "keywords");
        d0.g(str10, "summary");
        d0.g(list3, "transcription");
        d0.g(list4, "audioWaveList");
        return new NativeNote(str11, j10, str2, str3, j11, j12, str4, str5, str6, z10, str7, i10, i11, i12, str8, str9, list, list2, i13, z11, i14, z12, j13, j14, str10, list3, list4);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof NativeNote)) {
            return false;
        }
        NativeNote nativeNote = (NativeNote) obj;
        return d0.b(this.keyId, nativeNote.keyId) && this.createTime == nativeNote.createTime && d0.b(this.from, nativeNote.from) && d0.b(this.noteTitle, nativeNote.noteTitle) && this.audioDuration == nativeNote.audioDuration && this.audioFileSize == nativeNote.audioFileSize && d0.b(this.audioFullName, nativeNote.audioFullName) && d0.b(this.audioFileMD5, nativeNote.audioFileMD5) && d0.b(this.audioFilePath, nativeNote.audioFilePath) && this.localAudioFileComplete == nativeNote.localAudioFileComplete && d0.b(this.cloudId, nativeNote.cloudId) && this.timeZone == nativeNote.timeZone && this.timezoneMin == nativeNote.timezoneMin && this.transcriptionState == nativeNote.transcriptionState && d0.b(this.transcriptionErrorTip, nativeNote.transcriptionErrorTip) && d0.b(this.summaryErrorTip, nativeNote.summaryErrorTip) && d0.b(this.folderIdList, nativeNote.folderIdList) && d0.b(this.keywords, nativeNote.keywords) && this.recMode == nativeNote.recMode && this.isNew == nativeNote.isNew && this.deleteState == nativeNote.deleteState && this.hasEdit == nativeNote.hasEdit && this.lastEditTime == nativeNote.lastEditTime && this.cloudVersion == nativeNote.cloudVersion && d0.b(this.summary, nativeNote.summary) && d0.b(this.transcription, nativeNote.transcription) && d0.b(this.audioWaveList, nativeNote.audioWaveList);
    }

    public final long getAudioDuration() {
        return this.audioDuration;
    }

    public final String getAudioFileMD5() {
        return this.audioFileMD5;
    }

    public final String getAudioFilePath() {
        return this.audioFilePath;
    }

    public final long getAudioFileSize() {
        return this.audioFileSize;
    }

    public final String getAudioFullName() {
        return this.audioFullName;
    }

    public final List<Double> getAudioWaveList() {
        return this.audioWaveList;
    }

    public final String getCloudId() {
        return this.cloudId;
    }

    public final long getCloudVersion() {
        return this.cloudVersion;
    }

    public final long getCreateTime() {
        return this.createTime;
    }

    public final int getDeleteState() {
        return this.deleteState;
    }

    public final List<String> getFolderIdList() {
        return this.folderIdList;
    }

    public final String getFrom() {
        return this.from;
    }

    public final boolean getHasEdit() {
        return this.hasEdit;
    }

    public final String getKeyId() {
        return this.keyId;
    }

    public final List<String> getKeywords() {
        return this.keywords;
    }

    public final long getLastEditTime() {
        return this.lastEditTime;
    }

    public final boolean getLocalAudioFileComplete() {
        return this.localAudioFileComplete;
    }

    public final String getNoteTitle() {
        return this.noteTitle;
    }

    public final int getRecMode() {
        return this.recMode;
    }

    public final String getSummary() {
        return this.summary;
    }

    public final String getSummaryErrorTip() {
        return this.summaryErrorTip;
    }

    public final int getTimeZone() {
        return this.timeZone;
    }

    public final int getTimezoneMin() {
        return this.timezoneMin;
    }

    public final List<FlutterTranscriptionData> getTranscription() {
        return this.transcription;
    }

    public final String getTranscriptionErrorTip() {
        return this.transcriptionErrorTip;
    }

    public final int getTranscriptionState() {
        return this.transcriptionState;
    }

    public int hashCode() {
        long j10 = this.createTime;
        int a10 = b.a(this.noteTitle, b.a(this.from, ((this.keyId.hashCode() * 31) + ((int) (j10 ^ (j10 >>> 32)))) * 31, 31), 31);
        long j11 = this.audioDuration;
        long j12 = this.audioFileSize;
        int a11 = b.a(this.audioFilePath, b.a(this.audioFileMD5, b.a(this.audioFullName, (((a10 + ((int) (j11 ^ (j11 >>> 32)))) * 31) + ((int) (j12 ^ (j12 >>> 32)))) * 31, 31), 31), 31);
        boolean z10 = this.localAudioFileComplete;
        boolean z11 = true;
        if (z10) {
            z10 = true;
        }
        int a12 = (a.a(this.keywords, a.a(this.folderIdList, b.a(this.summaryErrorTip, b.a(this.transcriptionErrorTip, (((((b.a(this.cloudId, (a11 + (z10 ? 1 : 0)) * 31, 31) + this.timeZone) * 31) + this.timezoneMin) * 31) + this.transcriptionState) * 31, 31), 31), 31), 31) + this.recMode) * 31;
        boolean z12 = this.isNew;
        if (z12) {
            z12 = true;
        }
        int i10 = (((a12 + (z12 ? 1 : 0)) * 31) + this.deleteState) * 31;
        boolean z13 = this.hasEdit;
        if (!z13) {
            z11 = z13;
        }
        long j13 = this.lastEditTime;
        long j14 = this.cloudVersion;
        return this.audioWaveList.hashCode() + a.a(this.transcription, b.a(this.summary, (((((i10 + (z11 ? 1 : 0)) * 31) + ((int) (j13 ^ (j13 >>> 32)))) * 31) + ((int) (j14 ^ (j14 >>> 32)))) * 31, 31), 31);
    }

    public final boolean isNew() {
        return this.isNew;
    }

    public String toString() {
        String str = this.keyId;
        long j10 = this.createTime;
        String str2 = this.from;
        String str3 = this.noteTitle;
        long j11 = this.audioDuration;
        long j12 = this.audioFileSize;
        String str4 = this.audioFullName;
        String str5 = this.audioFileMD5;
        String str6 = this.audioFilePath;
        boolean z10 = this.localAudioFileComplete;
        String str7 = this.cloudId;
        int i10 = this.timeZone;
        int i11 = this.timezoneMin;
        int i12 = this.transcriptionState;
        String str8 = this.transcriptionErrorTip;
        String str9 = this.summaryErrorTip;
        List<String> list = this.folderIdList;
        List<String> list2 = this.keywords;
        int i13 = this.recMode;
        boolean z11 = this.isNew;
        int i14 = this.deleteState;
        String str10 = str7;
        boolean z12 = this.hasEdit;
        long j13 = this.lastEditTime;
        long j14 = this.cloudVersion;
        String str11 = this.summary;
        List<FlutterTranscriptionData> list3 = this.transcription;
        List<Double> list4 = this.audioWaveList;
        return "NativeNote(keyId=" + str + ", createTime=" + j10 + ", from=" + str2 + ", noteTitle=" + str3 + ", audioDuration=" + j11 + ", audioFileSize=" + j12 + ", audioFullName=" + str4 + ", audioFileMD5=" + str5 + ", audioFilePath=" + str6 + ", localAudioFileComplete=" + z10 + ", cloudId=" + str10 + ", timeZone=" + i10 + ", timezoneMin=" + i11 + ", transcriptionState=" + i12 + ", transcriptionErrorTip=" + str8 + ", summaryErrorTip=" + str9 + ", folderIdList=" + list + ", keywords=" + list2 + ", recMode=" + i13 + ", isNew=" + z11 + ", deleteState=" + i14 + ", hasEdit=" + z12 + ", lastEditTime=" + j13 + ", cloudVersion=" + j14 + ", summary=" + str11 + ", transcription=" + list3 + ", audioWaveList=" + list4 + ")";
    }
}
