package ai.plaud.android.plaud.anew.flutter.data;

/* compiled from: FlutterDatabaseManager.kt */
public final class FlutterSwitchConfig {
    private final boolean cloudSyncSwitch;
    private final boolean onlyWifiSyncSwitch;
    private final boolean optimizeStorage;

    public FlutterSwitchConfig(boolean z10, boolean z11, boolean z12) {
        this.cloudSyncSwitch = z10;
        this.onlyWifiSyncSwitch = z11;
        this.optimizeStorage = z12;
    }

    public static /* synthetic */ FlutterSwitchConfig copy$default(FlutterSwitchConfig flutterSwitchConfig, boolean z10, boolean z11, boolean z12, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            z10 = flutterSwitchConfig.cloudSyncSwitch;
        }
        if ((i10 & 2) != 0) {
            z11 = flutterSwitchConfig.onlyWifiSyncSwitch;
        }
        if ((i10 & 4) != 0) {
            z12 = flutterSwitchConfig.optimizeStorage;
        }
        return flutterSwitchConfig.copy(z10, z11, z12);
    }

    public final boolean component1() {
        return this.cloudSyncSwitch;
    }

    public final boolean component2() {
        return this.onlyWifiSyncSwitch;
    }

    public final boolean component3() {
        return this.optimizeStorage;
    }

    public final FlutterSwitchConfig copy(boolean z10, boolean z11, boolean z12) {
        return new FlutterSwitchConfig(z10, z11, z12);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FlutterSwitchConfig)) {
            return false;
        }
        FlutterSwitchConfig flutterSwitchConfig = (FlutterSwitchConfig) obj;
        return this.cloudSyncSwitch == flutterSwitchConfig.cloudSyncSwitch && this.onlyWifiSyncSwitch == flutterSwitchConfig.onlyWifiSyncSwitch && this.optimizeStorage == flutterSwitchConfig.optimizeStorage;
    }

    public final boolean getCloudSyncSwitch() {
        return this.cloudSyncSwitch;
    }

    public final boolean getOnlyWifiSyncSwitch() {
        return this.onlyWifiSyncSwitch;
    }

    public final boolean getOptimizeStorage() {
        return this.optimizeStorage;
    }

    public int hashCode() {
        boolean z10 = this.cloudSyncSwitch;
        boolean z11 = true;
        if (z10) {
            z10 = true;
        }
        int i10 = (z10 ? 1 : 0) * true;
        boolean z12 = this.onlyWifiSyncSwitch;
        if (z12) {
            z12 = true;
        }
        int i11 = (i10 + (z12 ? 1 : 0)) * 31;
        boolean z13 = this.optimizeStorage;
        if (!z13) {
            z11 = z13;
        }
        return i11 + (z11 ? 1 : 0);
    }

    public String toString() {
        boolean z10 = this.cloudSyncSwitch;
        boolean z11 = this.onlyWifiSyncSwitch;
        boolean z12 = this.optimizeStorage;
        return "FlutterSwitchConfig(cloudSyncSwitch=" + z10 + ", onlyWifiSyncSwitch=" + z11 + ", optimizeStorage=" + z12 + ")";
    }
}
