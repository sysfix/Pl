package ai.plaud.android.plaud.anew.flutter.data;

import c.b;
import c.d;
import c.e;
import rg.d0;

/* compiled from: FlutterDatabaseManager.kt */
public final class NativeTranscriptionTaskConfig {
    private final String keyId;
    private final boolean reTrans;
    private final String summaryFileId;
    private final String summaryPostId;
    private final String summaryType;
    private final String transFileId;
    private final String transLan;

    public NativeTranscriptionTaskConfig(String str, String str2, boolean z10, String str3, String str4, String str5, String str6) {
        d0.g(str, "keyId");
        d0.g(str2, "transLan");
        d0.g(str3, "summaryType");
        d0.g(str4, "summaryPostId");
        d0.g(str5, "transFileId");
        d0.g(str6, "summaryFileId");
        this.keyId = str;
        this.transLan = str2;
        this.reTrans = z10;
        this.summaryType = str3;
        this.summaryPostId = str4;
        this.transFileId = str5;
        this.summaryFileId = str6;
    }

    public static /* synthetic */ NativeTranscriptionTaskConfig copy$default(NativeTranscriptionTaskConfig nativeTranscriptionTaskConfig, String str, String str2, boolean z10, String str3, String str4, String str5, String str6, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = nativeTranscriptionTaskConfig.keyId;
        }
        if ((i10 & 2) != 0) {
            str2 = nativeTranscriptionTaskConfig.transLan;
        }
        String str7 = str2;
        if ((i10 & 4) != 0) {
            z10 = nativeTranscriptionTaskConfig.reTrans;
        }
        boolean z11 = z10;
        if ((i10 & 8) != 0) {
            str3 = nativeTranscriptionTaskConfig.summaryType;
        }
        String str8 = str3;
        if ((i10 & 16) != 0) {
            str4 = nativeTranscriptionTaskConfig.summaryPostId;
        }
        String str9 = str4;
        if ((i10 & 32) != 0) {
            str5 = nativeTranscriptionTaskConfig.transFileId;
        }
        String str10 = str5;
        if ((i10 & 64) != 0) {
            str6 = nativeTranscriptionTaskConfig.summaryFileId;
        }
        return nativeTranscriptionTaskConfig.copy(str, str7, z11, str8, str9, str10, str6);
    }

    public final String component1() {
        return this.keyId;
    }

    public final String component2() {
        return this.transLan;
    }

    public final boolean component3() {
        return this.reTrans;
    }

    public final String component4() {
        return this.summaryType;
    }

    public final String component5() {
        return this.summaryPostId;
    }

    public final String component6() {
        return this.transFileId;
    }

    public final String component7() {
        return this.summaryFileId;
    }

    public final NativeTranscriptionTaskConfig copy(String str, String str2, boolean z10, String str3, String str4, String str5, String str6) {
        d0.g(str, "keyId");
        d0.g(str2, "transLan");
        d0.g(str3, "summaryType");
        d0.g(str4, "summaryPostId");
        d0.g(str5, "transFileId");
        String str7 = str6;
        d0.g(str7, "summaryFileId");
        return new NativeTranscriptionTaskConfig(str, str2, z10, str3, str4, str5, str7);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof NativeTranscriptionTaskConfig)) {
            return false;
        }
        NativeTranscriptionTaskConfig nativeTranscriptionTaskConfig = (NativeTranscriptionTaskConfig) obj;
        return d0.b(this.keyId, nativeTranscriptionTaskConfig.keyId) && d0.b(this.transLan, nativeTranscriptionTaskConfig.transLan) && this.reTrans == nativeTranscriptionTaskConfig.reTrans && d0.b(this.summaryType, nativeTranscriptionTaskConfig.summaryType) && d0.b(this.summaryPostId, nativeTranscriptionTaskConfig.summaryPostId) && d0.b(this.transFileId, nativeTranscriptionTaskConfig.transFileId) && d0.b(this.summaryFileId, nativeTranscriptionTaskConfig.summaryFileId);
    }

    public final String getKeyId() {
        return this.keyId;
    }

    public final boolean getReTrans() {
        return this.reTrans;
    }

    public final String getSummaryFileId() {
        return this.summaryFileId;
    }

    public final String getSummaryPostId() {
        return this.summaryPostId;
    }

    public final String getSummaryType() {
        return this.summaryType;
    }

    public final String getTransFileId() {
        return this.transFileId;
    }

    public final String getTransLan() {
        return this.transLan;
    }

    public int hashCode() {
        int a10 = b.a(this.transLan, this.keyId.hashCode() * 31, 31);
        boolean z10 = this.reTrans;
        if (z10) {
            z10 = true;
        }
        return this.summaryFileId.hashCode() + b.a(this.transFileId, b.a(this.summaryPostId, b.a(this.summaryType, (a10 + (z10 ? 1 : 0)) * 31, 31), 31), 31);
    }

    public String toString() {
        String str = this.keyId;
        String str2 = this.transLan;
        boolean z10 = this.reTrans;
        String str3 = this.summaryType;
        String str4 = this.summaryPostId;
        String str5 = this.transFileId;
        String str6 = this.summaryFileId;
        StringBuilder a10 = e.a("NativeTranscriptionTaskConfig(keyId=", str, ", transLan=", str2, ", reTrans=");
        a10.append(z10);
        a10.append(", summaryType=");
        a10.append(str3);
        a10.append(", summaryPostId=");
        a10.append(str4);
        a10.append(", transFileId=");
        a10.append(str5);
        a10.append(", summaryFileId=");
        return d.a(a10, str6, ")");
    }
}
