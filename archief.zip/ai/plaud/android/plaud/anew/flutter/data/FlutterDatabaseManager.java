package ai.plaud.android.plaud.anew.flutter.data;

import ag.c;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import b.b;
import ci.a;
import com.google.android.gms.internal.measurement.n8;
import kotlinx.coroutines.CoroutineStart;
import re.i;
import re.j;
import rg.d0;
import rg.l0;
import rg.s0;

/* compiled from: FlutterDatabaseManager.kt */
public final class FlutterDatabaseManager {
    private static final String CHANNEL = "plaud.flutter/dbSync";
    public static final FlutterDatabaseManager INSTANCE = new FlutterDatabaseManager();
    private static j methodChannel;

    private FlutterDatabaseManager() {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-0  reason: not valid java name */
    public static final void m7configMethodChannel$lambda0(i iVar, j.d dVar) {
        d0.g(iVar, "call");
        d0.g(dVar, "result");
        a.C0057a aVar = a.f4931a;
        aVar.a(b.a("setMethodCallHandler:[", iVar.f16444a, "]"), new Object[0]);
        String str = iVar.f16444a;
        if (str != null) {
            switch (str.hashCode()) {
                case -1832848399:
                    if (str.equals("action/allTranscriptionTaskConfig")) {
                        n8.f(s0.f16640p, l0.f16620c, (CoroutineStart) null, new FlutterDatabaseManager$configMethodChannel$1$1(dVar, (c<? super FlutterDatabaseManager$configMethodChannel$1$1>) null), 2, (Object) null);
                        return;
                    }
                    return;
                case -1129464046:
                    if (str.equals("action/getNoteFromKeyIds")) {
                        n8.f(s0.f16640p, l0.f16620c, (CoroutineStart) null, new FlutterDatabaseManager$configMethodChannel$1$3(iVar, dVar, (c<? super FlutterDatabaseManager$configMethodChannel$1$3>) null), 2, (Object) null);
                        return;
                    }
                    return;
                case -184861997:
                    if (str.equals("action/allNoteKeyIds")) {
                        n8.f(s0.f16640p, l0.f16620c, (CoroutineStart) null, new FlutterDatabaseManager$configMethodChannel$1$2(iVar, dVar, (c<? super FlutterDatabaseManager$configMethodChannel$1$2>) null), 2, (Object) null);
                        return;
                    }
                    return;
                case 92377139:
                    if (str.equals("action/getSwitchConfig")) {
                        PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
                        FlutterSwitchConfig flutterSwitchConfig = new FlutterSwitchConfig(PreferencesUtil.d().a("cloud_sync_switch"), PreferencesUtil.d().a("sync_wifi_only_switch"), PreferencesUtil.d().a("OPTIMIZE_PLAUD_APP_STORAGE"));
                        aVar.a("getSwitchConfig [" + flutterSwitchConfig + "]", new Object[0]);
                        dVar.a(q.a.a(flutterSwitchConfig));
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }

    public final void configMethodChannel(io.flutter.embedding.engine.a aVar) {
        d0.g(aVar, "flutterEngine");
        j jVar = new j(aVar.f12224c.f12051s, CHANNEL);
        methodChannel = jVar;
        jVar.b(b.f909a);
    }
}
