package ai.plaud.android.plaud.anew.flutter.data;

import ag.c;
import gg.p;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.i;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.data.FlutterDatabaseManager$configMethodChannel$1$3", f = "FlutterDatabaseManager.kt", l = {136, 186}, m = "invokeSuspend")
/* compiled from: FlutterDatabaseManager.kt */
public final class FlutterDatabaseManager$configMethodChannel$1$3 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ i $call;
    public final /* synthetic */ j.d $result;
    public Object L$0;
    public Object L$1;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterDatabaseManager$configMethodChannel$1$3(i iVar, j.d dVar, c<? super FlutterDatabaseManager$configMethodChannel$1$3> cVar) {
        super(2, cVar);
        this.$call = iVar;
        this.$result = dVar;
    }

    private static final int invokeSuspend$getFlutterTransState(int i10) {
        switch (i10) {
            case -6:
            case -1:
                return -1;
            case -5:
            case -4:
                return -4;
            case -3:
                return -3;
            case -2:
                return -2;
            case 1:
                return 1;
            case 3:
                return 2;
            case 4:
                return 4;
            case 5:
            case 6:
            case 7:
                return 3;
            case 8:
                return 5;
            case 9:
                return 6;
            case 10:
                return 7;
            default:
                return 0;
        }
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterDatabaseManager$configMethodChannel$1$3(this.$call, this.$result, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterDatabaseManager$configMethodChannel$1$3) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0096  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r42) {
        /*
            r41 = this;
            r0 = r41
            kotlin.coroutines.intrinsics.CoroutineSingletons r1 = kotlin.coroutines.intrinsics.CoroutineSingletons.COROUTINE_SUSPENDED
            int r2 = r0.label
            java.lang.String r3 = "]"
            r4 = 2
            r5 = 0
            r6 = 1
            r7 = 0
            if (r2 == 0) goto L_0x002e
            if (r2 == r6) goto L_0x001f
            if (r2 != r4) goto L_0x0017
            com.google.android.gms.internal.play_billing.x2.s(r42)
            goto L_0x0192
        L_0x0017:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
            r1.<init>(r2)
            throw r1
        L_0x001f:
            java.lang.Object r2 = r0.L$1
            java.util.Iterator r2 = (java.util.Iterator) r2
            java.lang.Object r4 = r0.L$0
            java.util.List r4 = (java.util.List) r4
            com.google.android.gms.internal.play_billing.x2.s(r42)
            r8 = r42
            r7 = r0
            goto L_0x008d
        L_0x002e:
            com.google.android.gms.internal.play_billing.x2.s(r42)
            re.i r2 = r0.$call
            java.lang.String r4 = "keyIds"
            java.lang.Object r2 = r2.a(r4)
            java.util.List r2 = (java.util.List) r2
            ci.a$a r4 = ci.a.f4931a
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r9 = "getNoteFromKeyIds keyList:["
            r8.append(r9)
            r8.append(r2)
            r8.append(r3)
            java.lang.String r8 = r8.toString()
            java.lang.Object[] r9 = new java.lang.Object[r5]
            r4.a(r8, r9)
            if (r2 != 0) goto L_0x0064
            re.j$d r1 = r0.$result
            java.lang.String r2 = "-1"
            java.lang.String r3 = "keyList is null"
            r1.b(r2, r3, r7)
            xf.g r1 = xf.g.f19030a
            return r1
        L_0x0064:
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.Iterator r2 = r2.iterator()
            r7 = r0
        L_0x006e:
            boolean r8 = r2.hasNext()
            if (r8 == 0) goto L_0x0166
            java.lang.Object r8 = r2.next()
            java.lang.String r8 = (java.lang.String) r8
            ai.plaud.android.plaud.anew.database.recordfile.RecordFilesRepository$Companion r9 = ai.plaud.android.plaud.anew.database.recordfile.RecordFilesRepository.Companion
            ai.plaud.android.plaud.anew.database.recordfile.RecordFilesRepository r9 = r9.getINSTANCE()
            r7.L$0 = r4
            r7.L$1 = r2
            r7.label = r6
            java.lang.Object r8 = r9.getFileByKey(r8, r7)
            if (r8 != r1) goto L_0x008d
            return r1
        L_0x008d:
            java.util.List r8 = (java.util.List) r8
            boolean r9 = r8.isEmpty()
            r6 = r6 ^ r9
            if (r6 == 0) goto L_0x0160
            java.lang.Object r5 = r8.get(r5)
            ai.plaud.android.plaud.anew.database.recordfile.RecordFileEntity r5 = (ai.plaud.android.plaud.anew.database.recordfile.RecordFileEntity) r5
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            java.util.List r8 = r5.getTranscription()
            java.util.Iterator r8 = r8.iterator()
        L_0x00a9:
            boolean r9 = r8.hasNext()
            if (r9 == 0) goto L_0x00cb
            java.lang.Object r9 = r8.next()
            ai.plaud.android.plaud.anew.api.bean.TranscriptionData r9 = (ai.plaud.android.plaud.anew.api.bean.TranscriptionData) r9
            java.lang.String r11 = r9.getContent()
            long r14 = r9.getStart_time()
            long r12 = r9.getEnd_time()
            ai.plaud.android.plaud.anew.flutter.data.FlutterTranscriptionData r9 = new ai.plaud.android.plaud.anew.flutter.data.FlutterTranscriptionData
            r10 = r9
            r10.<init>(r11, r12, r14)
            r6.add(r9)
            goto L_0x00a9
        L_0x00cb:
            ai.plaud.android.plaud.anew.flutter.data.NativeNote r14 = new ai.plaud.android.plaud.anew.flutter.data.NativeNote
            r8 = r14
            long r9 = r5.getSessionId()
            r11 = 1000(0x3e8, float:1.401E-42)
            long r11 = (long) r11
            long r9 = r9 * r11
            java.lang.String r13 = r5.getSn()
            java.lang.StringBuilder r15 = new java.lang.StringBuilder
            r15.<init>()
            r15.append(r9)
            r15.append(r13)
            java.lang.String r9 = r15.toString()
            long r15 = r5.getSessionId()
            long r10 = r15 * r11
            java.lang.String r12 = r5.getSn()
            java.lang.String r13 = r5.getFileName()
            long r15 = r5.getDuration()
            r0 = r14
            r14 = r15
            long r16 = r5.getFileSize()
            java.lang.String r18 = r5.getFullName()
            java.lang.String r19 = r5.getFileMD5()
            java.lang.String r20 = r5.getFilePath()
            boolean r21 = r5.isExisting()
            java.lang.String r22 = r5.getCloudId()
            int r23 = r5.getTimeZone()
            int r24 = r5.getTimezoneMin()
            int r25 = r5.getTranscriptionState()
            int r25 = invokeSuspend$getFlutterTransState(r25)
            java.lang.String r26 = r5.getTranscriptionErrorTip()
            java.lang.String r27 = r5.getSummaryErrorTip()
            java.util.List r28 = r5.getTagIdList()
            java.util.List r29 = r5.getKeywords()
            int r30 = r5.getScene()
            boolean r31 = r5.isNew()
            int r32 = r5.getDeleteState()
            boolean r33 = r5.getHasEdit()
            long r34 = r5.getLastEditTime()
            long r36 = r5.getVersion()
            java.lang.String r38 = r5.getSummary()
            java.util.ArrayList r5 = new java.util.ArrayList
            r40 = r5
            r5.<init>()
            r39 = r6
            r8.<init>(r9, r10, r12, r13, r14, r16, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r36, r38, r39, r40)
            r4.add(r0)
        L_0x0160:
            r5 = 0
            r6 = 1
            r0 = r41
            goto L_0x006e
        L_0x0166:
            ci.a$a r0 = ci.a.f4931a
            int r2 = r4.size()
            java.lang.String r5 = "getNoteFromKeyIds resultList:["
            java.lang.String r2 = ai.plaud.android.plaud.anew.flutter.audio.f.a(r5, r2, r3)
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r0.a(r2, r3)
            rg.l0 r0 = rg.l0.f16618a
            rg.g1 r0 = wg.q.f18099a
            ai.plaud.android.plaud.anew.flutter.data.FlutterDatabaseManager$configMethodChannel$1$3$1 r2 = new ai.plaud.android.plaud.anew.flutter.data.FlutterDatabaseManager$configMethodChannel$1$3$1
            re.j$d r3 = r7.$result
            r5 = 0
            r2.<init>(r3, r4, r5)
            r7.L$0 = r5
            r7.L$1 = r5
            r3 = 2
            r7.label = r3
            java.lang.Object r0 = com.google.android.gms.internal.measurement.n8.v(r0, r2, r7)
            if (r0 != r1) goto L_0x0192
            return r1
        L_0x0192:
            xf.g r0 = xf.g.f19030a
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.flutter.data.FlutterDatabaseManager$configMethodChannel$1$3.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
