package ai.plaud.android.plaud.anew.flutter.data;

import c.a;
import rg.d0;

/* compiled from: FlutterDataManager.kt */
public final class FlutterUserInfo {
    private final String token;
    private final String userId;

    public FlutterUserInfo(String str, String str2) {
        d0.g(str, "userId");
        d0.g(str2, "token");
        this.userId = str;
        this.token = str2;
    }

    public static /* synthetic */ FlutterUserInfo copy$default(FlutterUserInfo flutterUserInfo, String str, String str2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = flutterUserInfo.userId;
        }
        if ((i10 & 2) != 0) {
            str2 = flutterUserInfo.token;
        }
        return flutterUserInfo.copy(str, str2);
    }

    public final String component1() {
        return this.userId;
    }

    public final String component2() {
        return this.token;
    }

    public final FlutterUserInfo copy(String str, String str2) {
        d0.g(str, "userId");
        d0.g(str2, "token");
        return new FlutterUserInfo(str, str2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FlutterUserInfo)) {
            return false;
        }
        FlutterUserInfo flutterUserInfo = (FlutterUserInfo) obj;
        return d0.b(this.userId, flutterUserInfo.userId) && d0.b(this.token, flutterUserInfo.token);
    }

    public final String getToken() {
        return this.token;
    }

    public final String getUserId() {
        return this.userId;
    }

    public int hashCode() {
        return this.token.hashCode() + (this.userId.hashCode() * 31);
    }

    public String toString() {
        return a.a("FlutterUserInfo(userId=", this.userId, ", token=", this.token, ")");
    }
}
