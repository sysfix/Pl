package ai.plaud.android.plaud.anew.flutter.data;

import ag.c;
import ai.plaud.android.plaud.NiceBuildApplication;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import ai.plaud.android.plaud.landing.LandingActivity;
import android.content.Intent;
import android.os.Build;
import b.b;
import ci.a;
import com.google.android.gms.internal.measurement.n8;
import java.util.ArrayList;
import java.util.Objects;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.text.Regex;
import kotlinx.coroutines.CoroutineStart;
import re.i;
import re.j;
import rg.d0;
import rg.l0;
import rg.s0;
import wg.q;
import zendesk.android.Zendesk;

/* compiled from: FlutterDataManager.kt */
public final class FlutterDataManager {
    private static final String CHANNEL = "plaud.flutter/dataManager";
    public static final FlutterDataManager INSTANCE = new FlutterDataManager();
    /* access modifiers changed from: private */
    public static j methodChannel;

    private FlutterDataManager() {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-1  reason: not valid java name */
    public static final void m6configMethodChannel$lambda1(i iVar, j.d dVar) {
        d0.g(iVar, "call");
        d0.g(dVar, "result");
        a.f4931a.a(b.a("setMethodCallHandler:[", iVar.f16444a, "]"), new Object[0]);
        String str = iVar.f16444a;
        if (d0.b(str, "action/logout")) {
            PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
            PreferencesUtil d10 = PreferencesUtil.d();
            Objects.requireNonNull(d10);
            d10.f1010a.removeValuesForKeys(new String[]{"user_id_key", "accessToken_key"});
            Intent intent = new Intent(AppProvider.a(), LandingActivity.class);
            intent.setFlags(268468224);
            com.blankj.utilcode.util.a.b(intent);
            dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
        } else if (!d0.b(str, "action/openZendesk")) {
        } else {
            if (NiceBuildApplication.f892s) {
                ArrayList arrayList = new ArrayList();
                PreferencesUtil preferencesUtil2 = PreferencesUtil.f1008b;
                arrayList.add(PreferencesUtil.d().b("nickname_key"));
                arrayList.add(PreferencesUtil.d().b("email_key"));
                arrayList.add(PreferencesUtil.d().b("username_key"));
                String str2 = Build.MODEL;
                d0.f(str2, "MODEL");
                String replace = new Regex("\\s").replace((CharSequence) str2, "_");
                arrayList.add("Model:" + replace);
                String str3 = Build.BRAND;
                d0.f(str3, "BRAND");
                String replace2 = new Regex("\\s").replace((CharSequence) str3, "_");
                arrayList.add("Brand:" + replace2);
                String str4 = Build.VERSION.RELEASE;
                d0.f(str4, "RELEASE");
                String replace3 = new Regex("\\s").replace((CharSequence) str4, "_");
                arrayList.add("android_version:" + replace3);
                String replace4 = new Regex("\\s").replace((CharSequence) "2.0.3", "_");
                arrayList.add("app_version:" + replace4);
                Zendesk.Companion companion = Zendesk.f19438e;
                companion.a().f19443a.setConversationTags(arrayList);
                companion.a().f19443a.showMessaging(AppProvider.a(), 268435456);
                dVar.a(ai.plaud.android.plaud.anew.flutter.audio.i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                return;
            }
            dVar.b("-1", "zendesk is not init", (Object) null);
        }
    }

    public final void configMethodChannel(io.flutter.embedding.engine.a aVar) {
        d0.g(aVar, "flutterEngine");
        j jVar = new j(aVar.f12224c.f12051s, CHANNEL);
        methodChannel = jVar;
        jVar.b(a.f908a);
    }

    public final void sendUserInfo(String str, String str2) {
        d0.g(str, "userId");
        d0.g(str2, "token");
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterDataManager$sendUserInfo$1(str, str2, (c<? super FlutterDataManager$sendUserInfo$1>) null), 2, (Object) null);
    }
}
