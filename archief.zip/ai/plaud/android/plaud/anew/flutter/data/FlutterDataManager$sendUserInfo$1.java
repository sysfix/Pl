package ai.plaud.android.plaud.anew.flutter.data;

import ag.c;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.data.FlutterDataManager$sendUserInfo$1", f = "FlutterDataManager.kt", l = {}, m = "invokeSuspend")
/* compiled from: FlutterDataManager.kt */
public final class FlutterDataManager$sendUserInfo$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ String $token;
    public final /* synthetic */ String $userId;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterDataManager$sendUserInfo$1(String str, String str2, c<? super FlutterDataManager$sendUserInfo$1> cVar) {
        super(2, cVar);
        this.$userId = str;
        this.$token = str2;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterDataManager$sendUserInfo$1(this.$userId, this.$token, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterDataManager$sendUserInfo$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            j access$getMethodChannel$p = FlutterDataManager.methodChannel;
            if (access$getMethodChannel$p != null) {
                access$getMethodChannel$p.a("listener/onUserLogin", q.a.a(new FlutterUserInfo(this.$userId, this.$token)), (j.d) null);
            }
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
