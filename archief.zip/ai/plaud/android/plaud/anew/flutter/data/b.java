package ai.plaud.android.plaud.anew.flutter.data;

import re.i;
import re.j;

public final /* synthetic */ class b implements j.c {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ b f909a = new b();

    public final void g(i iVar, j.d dVar) {
        FlutterDatabaseManager.m7configMethodChannel$lambda0(iVar, dVar);
    }
}
