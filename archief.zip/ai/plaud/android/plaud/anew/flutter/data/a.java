package ai.plaud.android.plaud.anew.flutter.data;

import re.i;
import re.j;

public final /* synthetic */ class a implements j.c {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ a f908a = new a();

    public final void g(i iVar, j.d dVar) {
        FlutterDataManager.m6configMethodChannel$lambda1(iVar, dVar);
    }
}
