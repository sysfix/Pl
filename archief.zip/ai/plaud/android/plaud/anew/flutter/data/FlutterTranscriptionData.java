package ai.plaud.android.plaud.anew.flutter.data;

import rg.d0;

/* compiled from: FlutterDatabaseManager.kt */
public final class FlutterTranscriptionData {
    private String content;
    private final long endTime;
    private final long startTime;

    public FlutterTranscriptionData(String str, long j10, long j11) {
        d0.g(str, "content");
        this.content = str;
        this.endTime = j10;
        this.startTime = j11;
    }

    public static /* synthetic */ FlutterTranscriptionData copy$default(FlutterTranscriptionData flutterTranscriptionData, String str, long j10, long j11, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = flutterTranscriptionData.content;
        }
        if ((i10 & 2) != 0) {
            j10 = flutterTranscriptionData.endTime;
        }
        long j12 = j10;
        if ((i10 & 4) != 0) {
            j11 = flutterTranscriptionData.startTime;
        }
        return flutterTranscriptionData.copy(str, j12, j11);
    }

    public final String component1() {
        return this.content;
    }

    public final long component2() {
        return this.endTime;
    }

    public final long component3() {
        return this.startTime;
    }

    public final FlutterTranscriptionData copy(String str, long j10, long j11) {
        d0.g(str, "content");
        return new FlutterTranscriptionData(str, j10, j11);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FlutterTranscriptionData)) {
            return false;
        }
        FlutterTranscriptionData flutterTranscriptionData = (FlutterTranscriptionData) obj;
        return d0.b(this.content, flutterTranscriptionData.content) && this.endTime == flutterTranscriptionData.endTime && this.startTime == flutterTranscriptionData.startTime;
    }

    public final String getContent() {
        return this.content;
    }

    public final long getEndTime() {
        return this.endTime;
    }

    public final long getStartTime() {
        return this.startTime;
    }

    public int hashCode() {
        long j10 = this.endTime;
        long j11 = this.startTime;
        return (((this.content.hashCode() * 31) + ((int) (j10 ^ (j10 >>> 32)))) * 31) + ((int) (j11 ^ (j11 >>> 32)));
    }

    public final void setContent(String str) {
        d0.g(str, "<set-?>");
        this.content = str;
    }

    public String toString() {
        String str = this.content;
        long j10 = this.endTime;
        long j11 = this.startTime;
        return "FlutterTranscriptionData(content=" + str + ", endTime=" + j10 + ", startTime=" + j11 + ")";
    }
}
