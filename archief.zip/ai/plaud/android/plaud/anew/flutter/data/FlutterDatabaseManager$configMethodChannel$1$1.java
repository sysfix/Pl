package ai.plaud.android.plaud.anew.flutter.data;

import ag.c;
import ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionDataRepository;
import ai.plaud.android.plaud.anew.database.transcriptiondata.TranscriptionStateData;
import ai.plaud.android.plaud.anew.flutter.audio.f;
import com.google.android.gms.internal.measurement.n8;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import java.util.ArrayList;
import java.util.List;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import rg.g1;
import rg.l0;
import wg.q;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.data.FlutterDatabaseManager$configMethodChannel$1$1", f = "FlutterDatabaseManager.kt", l = {55, 73}, m = "invokeSuspend")
/* compiled from: FlutterDatabaseManager.kt */
public final class FlutterDatabaseManager$configMethodChannel$1$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ j.d $result;
    public int label;

    @a(c = "ai.plaud.android.plaud.anew.flutter.data.FlutterDatabaseManager$configMethodChannel$1$1$1", f = "FlutterDatabaseManager.kt", l = {}, m = "invokeSuspend")
    /* renamed from: ai.plaud.android.plaud.anew.flutter.data.FlutterDatabaseManager$configMethodChannel$1$1$1  reason: invalid class name */
    /* compiled from: FlutterDatabaseManager.kt */
    public static final class AnonymousClass1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
        public int label;

        public final c<g> create(Object obj, c<?> cVar) {
            return new AnonymousClass1(dVar, arrayList, cVar);
        }

        public final Object invoke(c0 c0Var, c<? super g> cVar) {
            return ((AnonymousClass1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
        }

        public final Object invokeSuspend(Object obj) {
            if (this.label == 0) {
                x2.s(obj);
                dVar.a(q.a.a(arrayList));
                return g.f19030a;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterDatabaseManager$configMethodChannel$1$1(j.d dVar, c<? super FlutterDatabaseManager$configMethodChannel$1$1> cVar) {
        super(2, cVar);
        this.$result = dVar;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterDatabaseManager$configMethodChannel$1$1(this.$result, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterDatabaseManager$configMethodChannel$1$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        Object obj2;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            TranscriptionDataRepository instance = TranscriptionDataRepository.Companion.getINSTANCE();
            this.label = 1;
            obj2 = instance.getAll(this);
            if (obj2 == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
            obj2 = obj;
        } else if (i10 == 2) {
            x2.s(obj);
            return g.f19030a;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        List<TranscriptionStateData> list = (List) obj2;
        ci.a.f4931a.a(f.a("allTranscriptionTaskConfig dataList:[", list.size(), "]"), new Object[0]);
        final ArrayList arrayList = new ArrayList();
        for (TranscriptionStateData transcriptionStateData : list) {
            arrayList.add(new NativeTranscriptionTaskConfig(transcriptionStateData.getKey(), transcriptionStateData.getTransLan(), transcriptionStateData.getNeedReTrans(), transcriptionStateData.getTransSummaryType(), String.valueOf(transcriptionStateData.getSummaryPostId()), transcriptionStateData.getTransFileId(), transcriptionStateData.getSummaryFileId()));
        }
        ci.a.f4931a.a(f.a("allTranscriptionTaskConfig resultList:[", list.size(), "]"), new Object[0]);
        l0 l0Var = l0.f16618a;
        g1 g1Var = q.f18099a;
        final j.d dVar = this.$result;
        AnonymousClass1 r52 = new AnonymousClass1((c<? super AnonymousClass1>) null);
        this.label = 2;
        if (n8.v(g1Var, r52, this) == coroutineSingletons) {
            return coroutineSingletons;
        }
        return g.f19030a;
    }
}
