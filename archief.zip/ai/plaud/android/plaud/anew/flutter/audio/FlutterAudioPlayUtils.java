package ai.plaud.android.plaud.anew.flutter.audio;

import a.d;
import ai.plaud.android.plaud.NiceBuildApplication;
import ai.plaud.android.plaud.anew.flutter.bean.FlutterAudioData;
import ai.plaud.android.plaud.anew.player.PlayAudioService;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.soundplus.LibSoundPlus;
import android.content.Intent;
import android.os.Build;
import android.os.Process;
import ci.a;
import com.blankj.utilcode.util.e;
import com.google.android.gms.internal.play_billing.zzip;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.Thread;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import kotlin.jvm.internal.DefaultConstructorMarker;
import l.a;
import me.rosuh.libmpg123.MPG123;
import rg.d0;
import x.b;
import x.q;
import yf.f;
import yf.l;

/* compiled from: FlutterAudioPlayUtils.kt */
public final class FlutterAudioPlayUtils {
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);
    /* access modifiers changed from: private */
    public static float curSpeed = 1.0f;
    /* access modifiers changed from: private */
    public static int openSoundPlus = 20;
    private final FlutterAudioData audioData;
    private a audioPlayTask;
    private MPG123 decoder;
    private ThreadPoolExecutor playAudioRun;
    private PlayListener playListener;
    private long playPosition;
    private float playSpeed;
    private long skipPosition;
    private final String tag;

    /* compiled from: FlutterAudioPlayUtils.kt */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public static /* synthetic */ FlutterAudioPlayUtils get$default(Companion companion, FlutterAudioData flutterAudioData, PlayListener playListener, int i10, Object obj) {
            if ((i10 & 2) != 0) {
                playListener = null;
            }
            return companion.get(flutterAudioData, playListener);
        }

        public final FlutterAudioPlayUtils get(FlutterAudioData flutterAudioData, PlayListener playListener) {
            d0.g(flutterAudioData, "audioData");
            return new FlutterAudioPlayUtils(flutterAudioData, playListener, (DefaultConstructorMarker) null);
        }

        public final float getCurSpeed() {
            return FlutterAudioPlayUtils.curSpeed;
        }

        public final int getOpenSoundPlus() {
            return FlutterAudioPlayUtils.openSoundPlus;
        }

        public final void setCurSpeed(float f10) {
            FlutterAudioPlayUtils.curSpeed = f10;
        }

        public final void setOpenSoundPlus(int i10) {
            FlutterAudioPlayUtils.openSoundPlus = i10;
        }
    }

    /* compiled from: FlutterAudioPlayUtils.kt */
    public interface PlayListener {
        void playProgress(FlutterAudioData flutterAudioData, long j10);

        void stopPlay(FlutterAudioData flutterAudioData);
    }

    private FlutterAudioPlayUtils(FlutterAudioData flutterAudioData, PlayListener playListener2) {
        this.audioData = flutterAudioData;
        this.playListener = playListener2;
        this.tag = "FlutterAudioPlayUtils";
        this.skipPosition = -1;
        this.playSpeed = -1.0f;
    }

    public /* synthetic */ FlutterAudioPlayUtils(FlutterAudioData flutterAudioData, PlayListener playListener2, DefaultConstructorMarker defaultConstructorMarker) {
        this(flutterAudioData, playListener2);
    }

    /* access modifiers changed from: private */
    /* renamed from: play$lambda-0  reason: not valid java name */
    public static final void m0play$lambda0(FlutterAudioPlayUtils flutterAudioPlayUtils) {
        d0.g(flutterAudioPlayUtils, "this$0");
        Process.setThreadPriority(-19);
        try {
            String audioType = flutterAudioPlayUtils.audioData.getAudioType();
            if (d0.b(audioType, FlutterPlayAudioManager.AUDIO_TYPE_OPUS)) {
                flutterAudioPlayUtils.playOpusFile(flutterAudioPlayUtils.audioData.getAudioPath());
            } else if (d0.b(audioType, FlutterPlayAudioManager.AUDIO_TYPE_MP3)) {
                flutterAudioPlayUtils.playMp3File(flutterAudioPlayUtils.audioData.getAudioPath());
            } else {
                ci.a.f4931a.a("audioType error", new Object[0]);
            }
        } catch (Exception e10) {
            a.C0057a aVar = ci.a.f4931a;
            aVar.a("AudioPlayUtils Exception:[" + e10 + "]", new Object[0]);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:33:0x00ca, code lost:
        if (r9 != 3) goto L_0x00cf;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void playMp3File(java.lang.String r14) {
        /*
            r13 = this;
            java.io.File r0 = new java.io.File
            r0.<init>(r14)
            boolean r1 = r0.exists()
            if (r1 == 0) goto L_0x020c
            long r1 = r0.length()
            r3 = 0
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 <= 0) goto L_0x020c
            ci.a$a r1 = ci.a.f4931a
            r2 = 0
            java.lang.Object[] r5 = new java.lang.Object[r2]
            java.lang.String r6 = "init MPG123"
            r1.a(r6, r5)
            me.rosuh.libmpg123.MPG123 r1 = r13.decoder
            r5 = 0
            if (r1 == 0) goto L_0x0031
            long r6 = r1.f14453a
            int r8 = (r6 > r3 ? 1 : (r6 == r3 ? 0 : -1))
            if (r8 == 0) goto L_0x002d
            me.rosuh.libmpg123.MPG123.delete(r6)
        L_0x002d:
            r1.f14453a = r3
            r13.decoder = r5
        L_0x0031:
            me.rosuh.libmpg123.MPG123 r1 = new me.rosuh.libmpg123.MPG123
            r1.<init>(r14)
            r13.decoder = r1
            long r6 = r1.f14453a
            int r14 = (r6 > r3 ? 1 : (r6 == r3 ? 0 : -1))
            if (r14 != 0) goto L_0x0040
            r13.decoder = r5
        L_0x0040:
            java.util.ArrayList r14 = new java.util.ArrayList
            r14.<init>()
            r1 = r2
        L_0x0046:
            me.rosuh.libmpg123.MPG123 r6 = r13.decoder
            r7 = 1
            if (r6 == 0) goto L_0x01c4
            java.util.concurrent.ThreadPoolExecutor r6 = r13.playAudioRun
            if (r6 == 0) goto L_0x01bb
            boolean r6 = r6.isShutdown()
            if (r6 == 0) goto L_0x0057
            goto L_0x01bb
        L_0x0057:
            me.rosuh.libmpg123.MPG123 r6 = r13.decoder
            rg.d0.d(r6)
            long r8 = r6.f14453a
            short[] r6 = me.rosuh.libmpg123.MPG123.readFrame(r8)
            int r1 = r1 + 1
            if (r6 == 0) goto L_0x01c4
            int r8 = r6.length
            if (r8 != 0) goto L_0x006b
            r8 = r7
            goto L_0x006c
        L_0x006b:
            r8 = r2
        L_0x006c:
            if (r8 == 0) goto L_0x0070
            goto L_0x01c4
        L_0x0070:
            long r8 = r13.skipPosition
            int r3 = (r8 > r3 ? 1 : (r8 == r3 ? 0 : -1))
            r4 = 1000(0x3e8, float:1.401E-42)
            if (r3 < 0) goto L_0x0105
            ci.a$a r3 = ci.a.f4931a
            me.rosuh.libmpg123.MPG123 r8 = r13.decoder
            rg.d0.d(r8)
            float r8 = r8.a()
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            java.lang.String r10 = "before current pos = "
            r9.append(r10)
            r9.append(r8)
            java.lang.String r8 = r9.toString()
            java.lang.Object[] r9 = new java.lang.Object[r2]
            r3.a(r8, r9)
            me.rosuh.libmpg123.MPG123 r8 = r13.decoder
            rg.d0.d(r8)
            long r9 = r13.skipPosition
            long r11 = (long) r4
            long r9 = r9 / r11
            float r4 = (float) r9
            me.rosuh.libmpg123.MPG123 r9 = r13.decoder
            rg.d0.d(r9)
            float r9 = r9.a()
            float r4 = r4 - r9
            double r9 = (double) r4
            long r11 = r8.f14453a
            long r8 = me.rosuh.libmpg123.MPG123.getTimeFrame(r11, r9)
            me.rosuh.libmpg123.MPG123 r4 = r13.decoder
            rg.d0.d(r4)
            float r8 = (float) r8
            me.rosuh.libmpg123.SeekMode r9 = me.rosuh.libmpg123.SeekMode.SEEK_SET
            int[] r10 = me.rosuh.libmpg123.MPG123.a.f14454a
            int r9 = r9.ordinal()
            r9 = r10[r9]
            r10 = 2
            if (r9 == r7) goto L_0x00cf
            if (r9 == r10) goto L_0x00cd
            r11 = 3
            if (r9 == r11) goto L_0x00d0
            goto L_0x00cf
        L_0x00cd:
            r10 = r7
            goto L_0x00d0
        L_0x00cf:
            r10 = r2
        L_0x00d0:
            long r11 = r4.f14453a
            long r8 = me.rosuh.libmpg123.MPG123.seekFrame(r11, r8, r10)
            long r10 = r13.skipPosition
            r13.playPosition = r10
            r10 = -1
            r13.skipPosition = r10
            me.rosuh.libmpg123.MPG123 r4 = r13.decoder
            rg.d0.d(r4)
            float r4 = r4.a()
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            java.lang.String r11 = "seek sec ==>> "
            r10.append(r11)
            r10.append(r8)
            java.lang.String r8 = ", current pos = "
            r10.append(r8)
            r10.append(r4)
            java.lang.String r4 = r10.toString()
            java.lang.Object[] r8 = new java.lang.Object[r2]
            r3.a(r4, r8)
        L_0x0105:
            l.a r3 = r13.audioPlayTask     // Catch:{ IOException -> 0x017f }
            if (r3 != 0) goto L_0x0119
            l.a r3 = new l.a     // Catch:{ IOException -> 0x017f }
            android.content.Context r4 = ai.plaud.android.plaud.common.util.AppProvider.a()     // Catch:{ IOException -> 0x017f }
            r8 = 16000(0x3e80, float:2.2421E-41)
            r3.<init>(r4, r7, r8)     // Catch:{ IOException -> 0x017f }
            r13.audioPlayTask = r3     // Catch:{ IOException -> 0x017f }
            r3.run()     // Catch:{ IOException -> 0x017f }
        L_0x0119:
            float r3 = r13.playSpeed     // Catch:{ IOException -> 0x017f }
            r4 = 0
            int r4 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r4 <= 0) goto L_0x012b
            l.a r4 = r13.audioPlayTask     // Catch:{ IOException -> 0x017f }
            if (r4 == 0) goto L_0x0127
            r4.a(r3)     // Catch:{ IOException -> 0x017f }
        L_0x0127:
            r3 = -1082130432(0xffffffffbf800000, float:-1.0)
            r13.playSpeed = r3     // Catch:{ IOException -> 0x017f }
        L_0x012b:
            int r3 = openSoundPlus     // Catch:{ IOException -> 0x017f }
            if (r3 <= 0) goto L_0x0177
            java.util.List r3 = yf.f.P(r6)     // Catch:{ IOException -> 0x017f }
            r14.addAll(r3)     // Catch:{ IOException -> 0x017f }
        L_0x0136:
            int r3 = r14.size()     // Catch:{ IOException -> 0x017f }
            r4 = 256(0x100, float:3.59E-43)
            if (r3 < r4) goto L_0x0197
            java.util.List r3 = r14.subList(r2, r4)     // Catch:{ IOException -> 0x017f }
            java.util.List r3 = yf.l.q0(r3)     // Catch:{ IOException -> 0x017f }
            x.b r6 = x.b.f18243a     // Catch:{ IOException -> 0x017f }
            short[] r3 = yf.l.v0(r3)     // Catch:{ IOException -> 0x017f }
            float[] r3 = x.b.b(r3)     // Catch:{ IOException -> 0x017f }
            ai.plaud.android.plaud.soundplus.LibSoundPlus r6 = ai.plaud.android.plaud.soundplus.LibSoundPlus.f1056a     // Catch:{ IOException -> 0x017f }
            int r7 = openSoundPlus     // Catch:{ IOException -> 0x017f }
            boolean r8 = ai.plaud.android.plaud.soundplus.LibSoundPlus.f1057b     // Catch:{ IOException -> 0x017f }
            if (r8 == 0) goto L_0x0164
            r8 = 1065353216(0x3f800000, float:1.0)
            r6.setSoundPlusDrcPregain(r8)     // Catch:{ IOException -> 0x017f }
            r6.setSoundPlusNoiseFloor(r7)     // Catch:{ IOException -> 0x017f }
            float[] r3 = r6.soundplusProcess(r3)     // Catch:{ IOException -> 0x017f }
        L_0x0164:
            short[] r3 = x.b.a(r3)     // Catch:{ IOException -> 0x017f }
            l.a r6 = r13.audioPlayTask     // Catch:{ IOException -> 0x017f }
            if (r6 == 0) goto L_0x016f
            r6.c(r3)     // Catch:{ IOException -> 0x017f }
        L_0x016f:
            java.util.List r3 = r14.subList(r2, r4)     // Catch:{ IOException -> 0x017f }
            r3.clear()     // Catch:{ IOException -> 0x017f }
            goto L_0x0136
        L_0x0177:
            l.a r3 = r13.audioPlayTask     // Catch:{ IOException -> 0x017f }
            if (r3 == 0) goto L_0x0197
            r3.c(r6)     // Catch:{ IOException -> 0x017f }
            goto L_0x0197
        L_0x017f:
            r3 = move-exception
            r3.printStackTrace()
            r13.playListener = r5
            java.util.concurrent.ThreadPoolExecutor r3 = r13.playAudioRun
            if (r3 == 0) goto L_0x018c
            r3.shutdownNow()
        L_0x018c:
            l.a r3 = r13.audioPlayTask
            if (r3 == 0) goto L_0x0193
            r3.b()
        L_0x0193:
            r13.audioPlayTask = r5
            r13.playAudioRun = r5
        L_0x0197:
            me.rosuh.libmpg123.MPG123 r3 = r13.decoder
            rg.d0.d(r3)
            float r3 = r3.a()
            r4 = 1000(0x3e8, float:1.401E-42)
            float r4 = (float) r4
            float r3 = r3 * r4
            long r3 = (long) r3
            r13.playPosition = r3
            long r6 = r13.skipPosition
            r8 = 0
            int r6 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r6 >= 0) goto L_0x01b8
            ai.plaud.android.plaud.anew.flutter.audio.FlutterAudioPlayUtils$PlayListener r6 = r13.playListener
            if (r6 == 0) goto L_0x01b8
            ai.plaud.android.plaud.anew.flutter.bean.FlutterAudioData r7 = r13.audioData
            r6.playProgress(r7, r3)
        L_0x01b8:
            r3 = r8
            goto L_0x0046
        L_0x01bb:
            ci.a$a r14 = ci.a.f4931a
            java.lang.Object[] r3 = new java.lang.Object[r2]
            java.lang.String r4 = "break playAudioRun == null || playAudioRun!!.isShutdown"
            r14.a(r4, r3)
        L_0x01c4:
            r3 = 160(0xa0, double:7.9E-322)
            java.lang.Thread.sleep(r3)
            l.a r14 = r13.audioPlayTask
            if (r14 == 0) goto L_0x01da
            boolean r3 = r14.f14007r
            if (r3 != r7) goto L_0x01d2
            goto L_0x01d3
        L_0x01d2:
            r7 = r2
        L_0x01d3:
            if (r7 == 0) goto L_0x01da
            r14.b()
            r13.audioPlayTask = r5
        L_0x01da:
            ci.a$a r14 = ci.a.f4931a
            long r3 = r0.length()
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r5 = "stopPlay fileSize:["
            r0.append(r5)
            r0.append(r3)
            java.lang.String r3 = "]  count:["
            r0.append(r3)
            r0.append(r1)
            java.lang.String r1 = "]"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.Object[] r1 = new java.lang.Object[r2]
            r14.a(r0, r1)
            ai.plaud.android.plaud.anew.flutter.audio.FlutterAudioPlayUtils$PlayListener r14 = r13.playListener
            if (r14 == 0) goto L_0x020c
            ai.plaud.android.plaud.anew.flutter.bean.FlutterAudioData r0 = r13.audioData
            r14.stopPlay(r0)
        L_0x020c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.flutter.audio.FlutterAudioPlayUtils.playMp3File(java.lang.String):void");
    }

    private final void playOpusFile(String str) {
        PlayListener playListener2;
        int i10 = 0;
        ci.a.f4931a.a("播放opus文件", new Object[0]);
        File file = new File(str);
        ArrayList arrayList = new ArrayList();
        kd.a aVar = new kd.a(1);
        aVar.f13835q = new b(this, (List) arrayList);
        aVar.f13836r = new b(this, str);
        int i11 = 320;
        byte[] bArr = new byte[320];
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
        long j10 = 0;
        this.playPosition = 0;
        while (true) {
            ThreadPoolExecutor threadPoolExecutor = this.playAudioRun;
            if (threadPoolExecutor == null) {
                break;
            } else if (threadPoolExecutor.isShutdown()) {
                break;
            } else {
                long j11 = this.skipPosition;
                if (j11 >= j10) {
                    b bVar = b.f18243a;
                    randomAccessFile.seek((j11 / 20) * 80);
                    this.playPosition = this.skipPosition;
                    this.skipPosition = -1;
                }
                int read = randomAccessFile.read(bArr);
                if (read <= 0) {
                    break;
                }
                if (read == i11) {
                    try {
                        aVar.d(bArr, this.playPosition);
                    } catch (Exception e10) {
                        a.C0057a aVar2 = ci.a.f4931a;
                        aVar2.b("receiveVoiceData " + e10, new Object[0]);
                    }
                } else {
                    byte[] bArr2 = new byte[read];
                    System.arraycopy(bArr, i10, bArr2, i10, read);
                    aVar.d(bArr2, this.playPosition);
                }
                try {
                    long j12 = this.playPosition;
                    b bVar2 = b.f18243a;
                    long j13 = ((long) read) / (((long) 1) * 80);
                    Long.signum(j13);
                    long j14 = j12 + (j13 * 20);
                    this.playPosition = j14;
                    j10 = 0;
                    if (this.skipPosition < 0 && (playListener2 = this.playListener) != null) {
                        playListener2.playProgress(this.audioData, j14);
                    }
                    i11 = 320;
                    i10 = 0;
                } catch (Throwable th2) {
                    zzip.a(randomAccessFile, th);
                    throw th2;
                }
            }
        }
        zzip.a(randomAccessFile, (Throwable) null);
        Thread.sleep(160);
        aVar.a(1);
    }

    /* access modifiers changed from: private */
    /* renamed from: playOpusFile$lambda-1  reason: not valid java name */
    public static final void m1playOpusFile$lambda1(FlutterAudioPlayUtils flutterAudioPlayUtils, List list, short[] sArr, long j10) {
        d0.g(flutterAudioPlayUtils, "this$0");
        d0.g(list, "$soundTempArray");
        ThreadPoolExecutor threadPoolExecutor = flutterAudioPlayUtils.playAudioRun;
        if (threadPoolExecutor != null && !threadPoolExecutor.isShutdown()) {
            try {
                if (flutterAudioPlayUtils.audioPlayTask == null) {
                    l.a aVar = new l.a(AppProvider.a(), 1, 16000);
                    flutterAudioPlayUtils.audioPlayTask = aVar;
                    aVar.run();
                }
                float f10 = flutterAudioPlayUtils.playSpeed;
                if (f10 > 0.0f) {
                    l.a aVar2 = flutterAudioPlayUtils.audioPlayTask;
                    if (aVar2 != null) {
                        aVar2.a(f10);
                    }
                    flutterAudioPlayUtils.playSpeed = -1.0f;
                }
                if (openSoundPlus > 0) {
                    d0.f(sArr, "data");
                    list.addAll(f.P(sArr));
                    while (list.size() >= 256) {
                        List q02 = l.q0(list.subList(0, 256));
                        b bVar = b.f18243a;
                        float[] b10 = b.b(l.v0(q02));
                        LibSoundPlus libSoundPlus = LibSoundPlus.f1056a;
                        int i10 = openSoundPlus;
                        if (LibSoundPlus.f1057b) {
                            libSoundPlus.setSoundPlusDrcPregain(1.0f);
                            libSoundPlus.setSoundPlusNoiseFloor(i10);
                            b10 = libSoundPlus.soundplusProcess(b10);
                        }
                        short[] a10 = b.a(b10);
                        l.a aVar3 = flutterAudioPlayUtils.audioPlayTask;
                        if (aVar3 != null) {
                            aVar3.c(a10);
                        }
                        list.subList(0, 256).clear();
                    }
                    return;
                }
                l.a aVar4 = flutterAudioPlayUtils.audioPlayTask;
                if (aVar4 != null) {
                    d0.f(sArr, "data");
                    aVar4.c(sArr);
                }
            } catch (IOException e10) {
                e10.printStackTrace();
                flutterAudioPlayUtils.playListener = null;
                ThreadPoolExecutor threadPoolExecutor2 = flutterAudioPlayUtils.playAudioRun;
                if (threadPoolExecutor2 != null) {
                    threadPoolExecutor2.shutdownNow();
                }
                l.a aVar5 = flutterAudioPlayUtils.audioPlayTask;
                if (aVar5 != null) {
                    aVar5.b();
                }
                flutterAudioPlayUtils.audioPlayTask = null;
                flutterAudioPlayUtils.playAudioRun = null;
            }
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: playOpusFile$lambda-2  reason: not valid java name */
    public static final void m2playOpusFile$lambda2(FlutterAudioPlayUtils flutterAudioPlayUtils, String str, int i10) {
        long j10;
        d0.g(flutterAudioPlayUtils, "this$0");
        d0.g(str, "$audioPath");
        l.a aVar = flutterAudioPlayUtils.audioPlayTask;
        boolean z10 = true;
        if (aVar != null) {
            if (aVar.f14007r) {
                aVar.b();
                flutterAudioPlayUtils.audioPlayTask = null;
            }
        }
        a.C0057a aVar2 = ci.a.f4931a;
        File b10 = e.b(str);
        if (b10 == null) {
            j10 = 0;
        } else if (b10.isDirectory()) {
            j10 = e.a(b10);
        } else {
            if (!b10.exists() || !b10.isFile()) {
                z10 = false;
            }
            if (!z10) {
                j10 = -1;
            } else {
                j10 = b10.length();
            }
        }
        aVar2.a("stopPlay fileSize:[" + j10 + "]", new Object[0]);
        PlayListener playListener2 = flutterAudioPlayUtils.playListener;
        if (playListener2 != null) {
            playListener2.stopPlay(flutterAudioPlayUtils.audioData);
        }
    }

    public final void pause() {
        ThreadPoolExecutor threadPoolExecutor = this.playAudioRun;
        if (threadPoolExecutor != null) {
            threadPoolExecutor.shutdownNow();
        }
        this.playAudioRun = null;
        this.skipPosition = this.playPosition;
    }

    public final void play() {
        if (!PlayAudioService.f975p && !NiceBuildApplication.f891r) {
            Intent intent = new Intent(AppProvider.a(), PlayAudioService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                AppProvider.a().startForegroundService(intent);
            } else {
                AppProvider.a().startService(intent);
            }
        }
        a aVar = new a(this);
        q qVar = q.f18274a;
        String str = this.tag + "play-" + aVar.hashCode();
        d0.g(str, "threadName");
        ci.a.f4931a.d(d.a(str, "-threadName"), new Object[0]);
        String str2 = "tnt-" + str + "-" + System.currentTimeMillis() + "-%d";
        String.format(Locale.ROOT, str2, new Object[]{0});
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS, new LinkedBlockingQueue(1), new a9.b(Executors.defaultThreadFactory(), str2, str2 != null ? new AtomicLong(0) : null, (Boolean) null, (Integer) null, (Thread.UncaughtExceptionHandler) null), new ThreadPoolExecutor.AbortPolicy());
        this.playAudioRun = threadPoolExecutor;
        d0.d(threadPoolExecutor);
        threadPoolExecutor.execute(aVar);
    }

    public final void seek(long j10) {
        a.C0057a aVar = ci.a.f4931a;
        aVar.a("seek msTime -> [" + j10 + "]", new Object[0]);
        this.skipPosition = j10;
    }

    public final void setPlaySpeed(float f10) {
        curSpeed = f10;
        this.playSpeed = f10;
    }

    public final void stop() {
        this.playListener = null;
        l.a aVar = this.audioPlayTask;
        if (aVar != null) {
            aVar.b();
        }
        this.audioPlayTask = null;
        ThreadPoolExecutor threadPoolExecutor = this.playAudioRun;
        if (threadPoolExecutor != null) {
            threadPoolExecutor.shutdownNow();
        }
        this.playAudioRun = null;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ FlutterAudioPlayUtils(FlutterAudioData flutterAudioData, PlayListener playListener2, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(flutterAudioData, (i10 & 2) != 0 ? null : playListener2);
    }
}
