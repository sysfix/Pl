package ai.plaud.android.plaud.anew.flutter.audio;

import jd.a;
import jd.d;
import re.j;

public final /* synthetic */ class h implements d, a {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ Object f907p;

    public /* synthetic */ h(String str) {
        this.f907p = str;
    }

    public /* synthetic */ h(j.d dVar) {
        this.f907p = dVar;
    }

    public void a(int i10) {
        FlutterPlayAudioManager$convertOpus2Pcm$1.m5invokeSuspend$lambda3$lambda2((j.d) this.f907p, i10);
    }

    public void d(Object obj, long j10) {
        FlutterPlayAudioManager$convertOpus2Pcm$1.m4invokeSuspend$lambda3$lambda1((String) this.f907p, (short[]) obj, j10);
    }
}
