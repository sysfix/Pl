package ai.plaud.android.plaud.anew.flutter.audio;

import ag.c;
import ai.plaud.android.plaud.anew.flutter.audio.FlutterPlayAudioManager;
import ai.plaud.android.plaud.anew.flutter.bean.FlutterAudioData;
import ai.plaud.android.plaud.anew.player.PlayState;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.audio.FlutterPlayAudioManager$notifyPlayState$1", f = "FlutterPlayAudioManager.kt", l = {}, m = "invokeSuspend")
/* compiled from: FlutterPlayAudioManager.kt */
public final class FlutterPlayAudioManager$notifyPlayState$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ FlutterAudioData $audioData;
    public final /* synthetic */ Float $speed;
    public final /* synthetic */ PlayState $state;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterPlayAudioManager$notifyPlayState$1(FlutterAudioData flutterAudioData, PlayState playState, Float f10, c<? super FlutterPlayAudioManager$notifyPlayState$1> cVar) {
        super(2, cVar);
        this.$audioData = flutterAudioData;
        this.$state = playState;
        this.$speed = f10;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterPlayAudioManager$notifyPlayState$1(this.$audioData, this.$state, this.$speed, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterPlayAudioManager$notifyPlayState$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            j access$getMethodChannel$p = FlutterPlayAudioManager.methodChannel;
            if (access$getMethodChannel$p != null) {
                String fileKey = this.$audioData.getFileKey();
                int type = this.$state.getType();
                Float f10 = this.$speed;
                access$getMethodChannel$p.a("listener/onPlayState", q.a.a(new FlutterPlayAudioManager.PlayStateData(fileKey, type, f10 != null ? f10.floatValue() : 1.0f)), (j.d) null);
            }
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
