package ai.plaud.android.plaud.anew.flutter.audio;

import ag.c;
import ai.plaud.android.plaud.anew.flutter.audio.FlutterPlayAudioManager;
import ai.plaud.android.plaud.anew.flutter.bean.FlutterAudioData;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.audio.FlutterPlayAudioManager$notifyPlayProgress$1", f = "FlutterPlayAudioManager.kt", l = {}, m = "invokeSuspend")
/* compiled from: FlutterPlayAudioManager.kt */
public final class FlutterPlayAudioManager$notifyPlayProgress$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ FlutterAudioData $audioData;
    public final /* synthetic */ int $cur;
    public final /* synthetic */ int $total;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterPlayAudioManager$notifyPlayProgress$1(FlutterAudioData flutterAudioData, int i10, int i11, c<? super FlutterPlayAudioManager$notifyPlayProgress$1> cVar) {
        super(2, cVar);
        this.$audioData = flutterAudioData;
        this.$total = i10;
        this.$cur = i11;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterPlayAudioManager$notifyPlayProgress$1(this.$audioData, this.$total, this.$cur, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterPlayAudioManager$notifyPlayProgress$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            j access$getMethodChannel$p = FlutterPlayAudioManager.methodChannel;
            if (access$getMethodChannel$p != null) {
                access$getMethodChannel$p.a("listener/onProgress", q.a.a(new FlutterPlayAudioManager.PlayProgressData(this.$audioData.getFileKey(), this.$total, this.$cur)), (j.d) null);
            }
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
