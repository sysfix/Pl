package ai.plaud.android.plaud.anew.flutter.audio;

public final /* synthetic */ class e {
    public static String a(String str, int i10) {
        return str + i10;
    }
}
