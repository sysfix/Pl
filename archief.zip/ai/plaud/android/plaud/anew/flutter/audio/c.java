package ai.plaud.android.plaud.anew.flutter.audio;

public final /* synthetic */ class c {
    public static String a(String str, int i10, String str2, int i11) {
        return str + i10 + str2 + i11;
    }
}
