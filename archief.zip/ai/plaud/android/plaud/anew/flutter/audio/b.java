package ai.plaud.android.plaud.anew.flutter.audio;

import ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordFragment;
import ai.plaud.android.plaud.anew.pages.login.LoginFragment;
import ai.plaud.android.plaud.anew.pages.register.RegisterFragment;
import ai.plaud.android.plaud.component.CtaButton;
import android.view.inputmethod.InputMethodManager;
import androidx.arch.core.util.Function;
import b8.g;
import com.android.billingclient.api.m;
import com.android.billingclient.api.q;
import com.blankj.utilcode.util.i;
import com.google.android.datatransport.runtime.firebase.transport.LogEventDropped;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigFetchThrottledException;
import com.google.firebase.remoteconfig.internal.ConfigFetchHandler;
import com.google.firebase.remoteconfig.internal.c;
import com.tinnotech.penblesdk.Constants$OtaPushError;
import com.tinnotech.penblesdk.utils.TntBleCommUtils;
import ga.a;
import gd.q;
import gd.s;
import i.h;
import i9.p;
import id.k;
import io.flutter.plugins.inapppurchase.Messages;
import j.j;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.Thread;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import jd.a;
import jd.d;
import k.f;
import m2.b;
import ma.z;
import okhttp3.HttpUrl;
import q6.a;
import rg.d0;
import u.e;
import u.f;

public final /* synthetic */ class b implements d, a, jf.b, Function, a.C0223a, a.C0134a, b8.a, q {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f903p = 1;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Object f904q;

    /* renamed from: r  reason: collision with root package name */
    public final /* synthetic */ Object f905r;

    public /* synthetic */ b(FlutterAudioPlayUtils flutterAudioPlayUtils, String str) {
        this.f904q = flutterAudioPlayUtils;
        this.f905r = str;
    }

    public /* synthetic */ b(FlutterAudioPlayUtils flutterAudioPlayUtils, List list) {
        this.f904q = flutterAudioPlayUtils;
        this.f905r = list;
    }

    public /* synthetic */ b(ConfigFetchHandler configFetchHandler, Date date) {
        this.f904q = configFetchHandler;
        this.f905r = date;
    }

    public /* synthetic */ b(ConfigFetchHandler configFetchHandler, Map map) {
        this.f904q = configFetchHandler;
        this.f905r = map;
    }

    public /* synthetic */ b(c cVar, g gVar) {
        this.f904q = cVar;
        this.f905r = gVar;
    }

    public /* synthetic */ b(a.C0134a aVar, a.C0134a aVar2) {
        this.f904q = aVar;
        this.f905r = aVar2;
    }

    public /* synthetic */ b(id.g gVar, s sVar) {
        this.f904q = gVar;
        this.f905r = sVar;
    }

    public /* synthetic */ b(io.flutter.plugins.inapppurchase.c cVar, Messages.c cVar2) {
        this.f904q = cVar;
        this.f905r = cVar2;
    }

    public /* synthetic */ b(io.flutter.plugins.inapppurchase.g gVar, Messages.v vVar) {
        this.f904q = gVar;
        this.f905r = vVar;
    }

    public /* synthetic */ b(z zVar, String str) {
        this.f904q = zVar;
        this.f905r = str;
    }

    public /* synthetic */ b(o6.g gVar, Iterable iterable) {
        this.f904q = gVar;
        this.f905r = iterable;
    }

    public /* synthetic */ b(o6.g gVar, Map map) {
        this.f904q = gVar;
        this.f905r = map;
    }

    public /* synthetic */ b(u.c cVar, ForgetPasswordFragment forgetPasswordFragment) {
        this.f904q = cVar;
        this.f905r = forgetPasswordFragment;
    }

    public /* synthetic */ b(e eVar, LoginFragment loginFragment) {
        this.f904q = eVar;
        this.f905r = loginFragment;
    }

    public /* synthetic */ b(f fVar, RegisterFragment registerFragment) {
        this.f904q = fVar;
        this.f905r = registerFragment;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x009b, code lost:
        r7 = e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x00d6, code lost:
        r7 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00d8, code lost:
        r7 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00db, code lost:
        java.util.Objects.requireNonNull((j7.d) r13.f9145n);
        r13.m(new java.util.Date(java.lang.System.currentTimeMillis()));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x0107, code lost:
        r3 = r13.g(r0.getErrorStream());
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00d6  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00d8  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x00db  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x0107  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x013d  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x013f  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x0142  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x015d  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x0184  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final java.lang.Object f(b8.g r13) {
        /*
            r12 = this;
            java.lang.Object r13 = r12.f904q
            com.google.firebase.remoteconfig.internal.c r13 = (com.google.firebase.remoteconfig.internal.c) r13
            java.lang.Object r0 = r12.f905r
            b8.g r0 = (b8.g) r0
            int[] r1 = com.google.firebase.remoteconfig.internal.c.f9130p
            java.util.Objects.requireNonNull(r13)
            r1 = 403(0x193, float:5.65E-43)
            r2 = 0
            r3 = 200(0xc8, float:2.8E-43)
            r4 = 1
            r5 = 0
            boolean r6 = r0.m()     // Catch:{ IOException -> 0x00b8, all -> 0x00b2 }
            if (r6 == 0) goto L_0x00a8
            r13.j(r4)     // Catch:{ IOException -> 0x00b8, all -> 0x00b2 }
            java.lang.Object r0 = r0.i()     // Catch:{ IOException -> 0x00b8, all -> 0x00b2 }
            java.net.HttpURLConnection r0 = (java.net.HttpURLConnection) r0     // Catch:{ IOException -> 0x00b8, all -> 0x00b2 }
            int r6 = r0.getResponseCode()     // Catch:{ IOException -> 0x00a4, all -> 0x009d }
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ IOException -> 0x00a4, all -> 0x009d }
            int r7 = r6.intValue()     // Catch:{ IOException -> 0x009b }
            if (r7 != r3) goto L_0x0049
            monitor-enter(r13)     // Catch:{ IOException -> 0x009b }
            r7 = 8
            r13.f9134c = r7     // Catch:{ all -> 0x0046 }
            monitor-exit(r13)     // Catch:{ IOException -> 0x009b }
            com.google.firebase.remoteconfig.internal.b r7 = r13.f9146o     // Catch:{ IOException -> 0x009b }
            java.util.Date r8 = com.google.firebase.remoteconfig.internal.b.f9121f     // Catch:{ IOException -> 0x009b }
            r7.d(r5, r8)     // Catch:{ IOException -> 0x009b }
            com.google.firebase.remoteconfig.internal.a r7 = r13.l(r0)     // Catch:{ IOException -> 0x009b }
            r7.c()     // Catch:{ IOException -> 0x009b }
            goto L_0x0049
        L_0x0046:
            r7 = move-exception
            monitor-exit(r13)     // Catch:{ IOException -> 0x009b }
            throw r7     // Catch:{ IOException -> 0x009b }
        L_0x0049:
            r13.b(r0)
            r13.j(r5)
            int r7 = r6.intValue()
            boolean r7 = r13.e(r7)
            if (r7 == 0) goto L_0x006c
            java.util.Date r8 = new java.util.Date
            j7.c r9 = r13.f9145n
            j7.d r9 = (j7.d) r9
            java.util.Objects.requireNonNull(r9)
            long r9 = java.lang.System.currentTimeMillis()
            r8.<init>(r9)
            r13.m(r8)
        L_0x006c:
            if (r7 != 0) goto L_0x011e
            int r7 = r6.intValue()
            if (r7 != r3) goto L_0x0076
            goto L_0x011e
        L_0x0076:
            java.lang.String r3 = "Unable to connect to the server. Try again in a few minutes. HTTP status code: %d"
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r4[r5] = r6
            java.lang.String r3 = java.lang.String.format(r3, r4)
            int r4 = r6.intValue()
            if (r4 != r1) goto L_0x008e
            java.io.InputStream r0 = r0.getErrorStream()
            java.lang.String r3 = r13.g(r0)
        L_0x008e:
            com.google.firebase.remoteconfig.FirebaseRemoteConfigServerException r0 = new com.google.firebase.remoteconfig.FirebaseRemoteConfigServerException
            int r1 = r6.intValue()
            com.google.firebase.remoteconfig.FirebaseRemoteConfigException$Code r4 = com.google.firebase.remoteconfig.FirebaseRemoteConfigException.Code.CONFIG_UPDATE_STREAM_ERROR
            r0.<init>((int) r1, (java.lang.String) r3, (com.google.firebase.remoteconfig.FirebaseRemoteConfigException.Code) r4)
            goto L_0x011a
        L_0x009b:
            r7 = move-exception
            goto L_0x00bc
        L_0x009d:
            r6 = move-exception
            r11 = r2
            r2 = r0
            r0 = r6
            r6 = r11
            goto L_0x012a
        L_0x00a4:
            r6 = move-exception
            r7 = r6
            r6 = r2
            goto L_0x00bc
        L_0x00a8:
            java.io.IOException r6 = new java.io.IOException     // Catch:{ IOException -> 0x00b8, all -> 0x00b2 }
            java.lang.Exception r0 = r0.h()     // Catch:{ IOException -> 0x00b8, all -> 0x00b2 }
            r6.<init>(r0)     // Catch:{ IOException -> 0x00b8, all -> 0x00b2 }
            throw r6     // Catch:{ IOException -> 0x00b8, all -> 0x00b2 }
        L_0x00b2:
            r0 = move-exception
            r6 = r0
            r0 = r6
            r6 = r2
            goto L_0x012a
        L_0x00b8:
            r0 = move-exception
            r7 = r0
            r0 = r2
            r6 = r0
        L_0x00bc:
            java.lang.String r8 = "FirebaseRemoteConfig"
            java.lang.String r9 = "Exception connecting to real-time RC backend. Retrying the connection..."
            android.util.Log.d(r8, r9, r7)     // Catch:{ all -> 0x0126 }
            r13.b(r0)
            r13.j(r5)
            if (r6 == 0) goto L_0x00d8
            int r7 = r6.intValue()
            boolean r7 = r13.e(r7)
            if (r7 == 0) goto L_0x00d6
            goto L_0x00d8
        L_0x00d6:
            r7 = r5
            goto L_0x00d9
        L_0x00d8:
            r7 = r4
        L_0x00d9:
            if (r7 == 0) goto L_0x00ee
            java.util.Date r8 = new java.util.Date
            j7.c r9 = r13.f9145n
            j7.d r9 = (j7.d) r9
            java.util.Objects.requireNonNull(r9)
            long r9 = java.lang.System.currentTimeMillis()
            r8.<init>(r9)
            r13.m(r8)
        L_0x00ee:
            if (r7 != 0) goto L_0x011e
            int r7 = r6.intValue()
            if (r7 != r3) goto L_0x00f7
            goto L_0x011e
        L_0x00f7:
            java.lang.String r3 = "Unable to connect to the server. Try again in a few minutes. HTTP status code: %d"
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r4[r5] = r6
            java.lang.String r3 = java.lang.String.format(r3, r4)
            int r4 = r6.intValue()
            if (r4 != r1) goto L_0x010f
            java.io.InputStream r0 = r0.getErrorStream()
            java.lang.String r3 = r13.g(r0)
        L_0x010f:
            com.google.firebase.remoteconfig.FirebaseRemoteConfigServerException r0 = new com.google.firebase.remoteconfig.FirebaseRemoteConfigServerException
            int r1 = r6.intValue()
            com.google.firebase.remoteconfig.FirebaseRemoteConfigException$Code r4 = com.google.firebase.remoteconfig.FirebaseRemoteConfigException.Code.CONFIG_UPDATE_STREAM_ERROR
            r0.<init>((int) r1, (java.lang.String) r3, (com.google.firebase.remoteconfig.FirebaseRemoteConfigException.Code) r4)
        L_0x011a:
            r13.h(r0)
            goto L_0x0121
        L_0x011e:
            r13.i()
        L_0x0121:
            b8.g r13 = b8.j.e(r2)
            return r13
        L_0x0126:
            r2 = move-exception
            r11 = r2
            r2 = r0
            r0 = r11
        L_0x012a:
            r13.b(r2)
            r13.j(r5)
            if (r6 == 0) goto L_0x013f
            int r7 = r6.intValue()
            boolean r7 = r13.e(r7)
            if (r7 == 0) goto L_0x013d
            goto L_0x013f
        L_0x013d:
            r7 = r5
            goto L_0x0140
        L_0x013f:
            r7 = r4
        L_0x0140:
            if (r7 == 0) goto L_0x0155
            java.util.Date r8 = new java.util.Date
            j7.c r9 = r13.f9145n
            j7.d r9 = (j7.d) r9
            java.util.Objects.requireNonNull(r9)
            long r9 = java.lang.System.currentTimeMillis()
            r8.<init>(r9)
            r13.m(r8)
        L_0x0155:
            if (r7 != 0) goto L_0x0184
            int r7 = r6.intValue()
            if (r7 == r3) goto L_0x0184
            java.lang.String r3 = "Unable to connect to the server. Try again in a few minutes. HTTP status code: %d"
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r4[r5] = r6
            java.lang.String r3 = java.lang.String.format(r3, r4)
            int r4 = r6.intValue()
            if (r4 != r1) goto L_0x0175
            java.io.InputStream r1 = r2.getErrorStream()
            java.lang.String r3 = r13.g(r1)
        L_0x0175:
            com.google.firebase.remoteconfig.FirebaseRemoteConfigServerException r1 = new com.google.firebase.remoteconfig.FirebaseRemoteConfigServerException
            int r2 = r6.intValue()
            com.google.firebase.remoteconfig.FirebaseRemoteConfigException$Code r4 = com.google.firebase.remoteconfig.FirebaseRemoteConfigException.Code.CONFIG_UPDATE_STREAM_ERROR
            r1.<init>((int) r2, (java.lang.String) r3, (com.google.firebase.remoteconfig.FirebaseRemoteConfigException.Code) r4)
            r13.h(r1)
            goto L_0x0187
        L_0x0184:
            r13.i()
        L_0x0187:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.flutter.audio.b.f(b8.g):java.lang.Object");
    }

    public void a(int i10) {
        FlutterAudioPlayUtils.m2playOpusFile$lambda2((FlutterAudioPlayUtils) this.f904q, (String) this.f905r, i10);
    }

    public void accept(Object obj) {
        switch (this.f903p) {
            case 2:
                u.c cVar = (u.c) this.f904q;
                ForgetPasswordFragment forgetPasswordFragment = (ForgetPasswordFragment) this.f905r;
                xf.g gVar = (xf.g) obj;
                int i10 = ForgetPasswordFragment.H;
                d0.g(cVar, "$this_apply");
                d0.g(forgetPasswordFragment, "this$0");
                if (cVar.f17137e.isSelected()) {
                    forgetPasswordFragment.i().e(h.f.f11776a);
                    return;
                }
                return;
            case 3:
                e eVar = (e) this.f904q;
                LoginFragment loginFragment = (LoginFragment) this.f905r;
                xf.g gVar2 = (xf.g) obj;
                int i11 = LoginFragment.G;
                d0.g(eVar, "$this_apply");
                d0.g(loginFragment, "this$0");
                CtaButton ctaButton = eVar.f17152f;
                InputMethodManager inputMethodManager = (InputMethodManager) i.a().getSystemService("input_method");
                if (inputMethodManager != null) {
                    inputMethodManager.hideSoftInputFromWindow(ctaButton.getWindowToken(), 0);
                }
                loginFragment.h().e(j.c.f13047a);
                return;
            default:
                f fVar = (f) this.f904q;
                RegisterFragment registerFragment = (RegisterFragment) this.f905r;
                xf.g gVar3 = (xf.g) obj;
                int i12 = RegisterFragment.H;
                d0.g(fVar, "$this_apply");
                d0.g(registerFragment, "this$0");
                if (fVar.f17159d.isSelected()) {
                    registerFragment.h().e(f.C0172f.f13480a);
                    return;
                }
                return;
        }
    }

    public Object apply(Object obj) {
        switch (this.f903p) {
            case 5:
                ((q2.a) obj).Q0((String) this.f904q, (Object[]) this.f905r);
                return null;
            default:
                b.C0190b bVar = (b.C0190b) this.f904q;
                Function function = (Function) this.f905r;
                q2.e V = ((q2.a) obj).V(bVar.f14155p);
                int i10 = 0;
                while (i10 < bVar.f14156q.size()) {
                    int i11 = i10 + 1;
                    Object obj2 = bVar.f14156q.get(i10);
                    if (obj2 == null) {
                        V.Z(i11);
                    } else if (obj2 instanceof Long) {
                        V.L0(i11, ((Long) obj2).longValue());
                    } else if (obj2 instanceof Double) {
                        V.d0(i11, ((Double) obj2).doubleValue());
                    } else if (obj2 instanceof String) {
                        V.J(i11, (String) obj2);
                    } else if (obj2 instanceof byte[]) {
                        V.V0(i11, (byte[]) obj2);
                    }
                    i10 = i11;
                }
                return function.apply(V);
        }
    }

    public void b(byte[] bArr) {
        int i10;
        dd.c cVar;
        boolean z10;
        byte[] bArr2 = bArr;
        id.g gVar = (id.g) this.f904q;
        s sVar = (s) this.f905r;
        Objects.requireNonNull(gVar);
        int readInt = (int) TntBleCommUtils.a().readInt(8, bArr2, 0);
        if (readInt != 1) {
            k.g("OtaPushHelper", c.a("portType miss match ", readInt, "!=local:", 1), new Object[0]);
            return;
        }
        switch ((int) TntBleCommUtils.a().readInt(16, bArr2, 1)) {
            case 50:
                try {
                    dd.e eVar = new dd.e(bArr2);
                    if (eVar.f10038b == gVar.f12009a && (i10 = eVar.f10039c) != 0) {
                        gVar.f12017i = false;
                        RandomAccessFile randomAccessFile = gVar.f12015g;
                        if (randomAccessFile != null) {
                            try {
                                randomAccessFile.close();
                            } catch (IOException unused) {
                            }
                            gVar.f12015g = null;
                        }
                        ExecutorService executorService = gVar.f12027s;
                        if (executorService != null && !executorService.isShutdown()) {
                            gVar.f12027s.shutdown();
                        }
                        gVar.f12027s = null;
                        gVar.b(i10);
                        return;
                    }
                    return;
                } catch (Exception e10) {
                    e10.printStackTrace();
                    return;
                }
            case 51:
                try {
                    cVar = new dd.c(bArr2);
                } catch (Exception e11) {
                    e11.printStackTrace();
                    cVar = null;
                }
                if (cVar != null && cVar.f10027b == gVar.f12009a && !gVar.f12018j) {
                    int i11 = cVar.f10028c;
                    if (i11 != 2) {
                        gVar.f12017i = false;
                        RandomAccessFile randomAccessFile2 = gVar.f12015g;
                        if (randomAccessFile2 != null) {
                            try {
                                randomAccessFile2.close();
                            } catch (IOException unused2) {
                            }
                            gVar.f12015g = null;
                        }
                        k.e("OtaPushHelper", "removeResponse OtaPushCallback", new Object[0]);
                        sVar.o(52);
                        if (i11 == 0) {
                            ad.a aVar = gVar.f12014f;
                            if (aVar != null) {
                                aVar.otaPushFinish();
                                return;
                            }
                            return;
                        }
                        gVar.b(i11);
                        return;
                    }
                    k.e("OtaPushHelper", "status=2 waiting call message", new Object[0]);
                    return;
                }
                return;
            case 52:
                try {
                    dd.d dVar = new dd.d(bArr2);
                    if (dVar.f10029b != gVar.f12009a) {
                        StringBuilder a10 = f.a.a("uid miss match ");
                        a10.append(dVar.f10029b);
                        a10.append("!=local:");
                        a10.append(gVar.f12009a);
                        k.g("OtaPushHelper", a10.toString(), new Object[0]);
                        return;
                    }
                    long j10 = dVar.f10030c;
                    long j11 = dVar.f10031d;
                    if (j11 > gVar.f12016h) {
                        j11 = 0;
                    }
                    ExecutorService executorService2 = gVar.f12027s;
                    if (executorService2 == null || executorService2.isShutdown() || gVar.f12015g == null) {
                        k.b("OtaPushHelper", "StartSendFile.....", new Object[0]);
                        if (!gVar.f12017i || !(z10 = gVar.f12018j)) {
                            gVar.f12019k = j10;
                            gVar.f12020l = j11;
                            String.format(Locale.ROOT, "tnt-ble-fota-push-loops-pool-%d", new Object[]{0});
                            ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS, new LinkedBlockingQueue(1), new a9.b(Executors.defaultThreadFactory(), "tnt-ble-fota-push-loops-pool-%d", new AtomicLong(0), (Boolean) null, (Integer) null, (Thread.UncaughtExceptionHandler) null), new ThreadPoolExecutor.AbortPolicy());
                            gVar.f12027s = threadPoolExecutor;
                            threadPoolExecutor.execute(new id.f(gVar));
                            return;
                        }
                        gVar.d(z10 ? 1 : 0);
                        gVar.c(Constants$OtaPushError.OTA_PUSH_ERROR_USER_INTERRUPT);
                        return;
                    }
                    gVar.f12021m = j10;
                    gVar.f12022n = j11;
                    return;
                } catch (Exception e12) {
                    e12.printStackTrace();
                    return;
                }
            default:
                return;
        }
    }

    public void c(ga.b bVar) {
        a.C0134a<Object> aVar = p.f11968c;
        ((a.C0134a) this.f904q).c(bVar);
        ((a.C0134a) this.f905r).c(bVar);
    }

    public void d(Object obj, long j10) {
        FlutterAudioPlayUtils.m1playOpusFile$lambda1((FlutterAudioPlayUtils) this.f904q, (List) this.f905r, (short[]) obj, j10);
    }

    public void e(com.android.billingclient.api.j jVar, List list) {
        Messages.i iVar;
        Messages.j jVar2;
        String str;
        String str2;
        Messages.PlatformProductType platformProductType;
        String str3;
        String str4;
        Messages.j jVar3;
        ArrayList arrayList;
        Messages.v vVar;
        Iterator it;
        ArrayList arrayList2;
        Messages.PlatformRecurrenceMode platformRecurrenceMode;
        io.flutter.plugins.inapppurchase.g gVar = (io.flutter.plugins.inapppurchase.g) this.f904q;
        Messages.v vVar2 = (Messages.v) this.f905r;
        Objects.requireNonNull(gVar);
        Iterator it2 = list.iterator();
        while (it2.hasNext()) {
            m mVar = (m) it2.next();
            gVar.f12794u.put(mVar.f5472c, mVar);
        }
        Messages.i a10 = io.flutter.plugins.inapppurchase.i.a(jVar);
        ArrayList arrayList3 = new ArrayList();
        Iterator it3 = list.iterator();
        while (it3.hasNext()) {
            m mVar2 = (m) it3.next();
            String str5 = mVar2.f5474e;
            String str6 = mVar2.f5476g;
            String str7 = mVar2.f5472c;
            Messages.PlatformProductType c10 = io.flutter.plugins.inapppurchase.i.c(mVar2.f5473d);
            String str8 = mVar2.f5475f;
            m.a a11 = mVar2.a();
            if (a11 == null) {
                iVar = a10;
                jVar2 = null;
            } else {
                iVar = a10;
                Long valueOf = Long.valueOf(a11.f5482b);
                String str9 = a11.f5483c;
                String str10 = a11.f5481a;
                jVar2 = new Messages.j();
                if (valueOf != null) {
                    jVar2.f12708a = valueOf;
                    if (str10 != null) {
                        jVar2.f12709b = str10;
                        if (str9 != null) {
                            jVar2.f12710c = str9;
                        } else {
                            throw new IllegalStateException("Nonnull field \"priceCurrencyCode\" is null.");
                        }
                    } else {
                        throw new IllegalStateException("Nonnull field \"formattedPrice\" is null.");
                    }
                } else {
                    throw new IllegalStateException("Nonnull field \"priceAmountMicros\" is null.");
                }
            }
            List list2 = mVar2.f5479j;
            if (list2 == null) {
                vVar = vVar2;
                arrayList = arrayList3;
                it = it3;
                str4 = str5;
                str = str6;
                str3 = str7;
                platformProductType = c10;
                str2 = str8;
                jVar3 = jVar2;
                arrayList2 = null;
            } else {
                ArrayList arrayList4 = new ArrayList();
                Iterator it4 = list2.iterator();
                while (it4.hasNext()) {
                    m.d dVar = (m.d) it4.next();
                    String str11 = dVar.f5493b;
                    Iterator it5 = it4;
                    String str12 = dVar.f5492a;
                    Iterator it6 = it3;
                    List<String> list3 = dVar.f5496e;
                    Messages.v vVar3 = vVar2;
                    String str13 = dVar.f5494c;
                    m.c cVar = dVar.f5495d;
                    ArrayList arrayList5 = arrayList3;
                    ArrayList arrayList6 = new ArrayList();
                    Iterator it7 = cVar.f5491a.iterator();
                    while (it7.hasNext()) {
                        Iterator it8 = it7;
                        m.b bVar = (m.b) it7.next();
                        Messages.j jVar4 = jVar2;
                        String str14 = bVar.f5485a;
                        String str15 = str5;
                        String str16 = bVar.f5487c;
                        String str17 = str7;
                        Messages.PlatformProductType platformProductType2 = c10;
                        Long valueOf2 = Long.valueOf(bVar.f5486b);
                        String str18 = str8;
                        Long valueOf3 = Long.valueOf((long) bVar.f5489e);
                        String str19 = bVar.f5488d;
                        int i10 = bVar.f5490f;
                        String str20 = str6;
                        if (i10 == 1) {
                            platformRecurrenceMode = Messages.PlatformRecurrenceMode.INFINITE_RECURRING;
                        } else if (i10 == 2) {
                            platformRecurrenceMode = Messages.PlatformRecurrenceMode.FINITE_RECURRING;
                        } else if (i10 != 3) {
                            platformRecurrenceMode = Messages.PlatformRecurrenceMode.NON_RECURRING;
                        } else {
                            platformRecurrenceMode = Messages.PlatformRecurrenceMode.NON_RECURRING;
                        }
                        Messages.k kVar = new Messages.k();
                        if (valueOf3 != null) {
                            kVar.f12711a = valueOf3;
                            if (platformRecurrenceMode != null) {
                                kVar.f12712b = platformRecurrenceMode;
                                if (valueOf2 != null) {
                                    kVar.f12713c = valueOf2;
                                    if (str19 != null) {
                                        kVar.f12714d = str19;
                                        if (str14 != null) {
                                            kVar.f12715e = str14;
                                            if (str16 != null) {
                                                kVar.f12716f = str16;
                                                arrayList6.add(kVar);
                                                jVar2 = jVar4;
                                                it7 = it8;
                                                str5 = str15;
                                                str7 = str17;
                                                c10 = platformProductType2;
                                                str8 = str18;
                                                str6 = str20;
                                            } else {
                                                throw new IllegalStateException("Nonnull field \"priceCurrencyCode\" is null.");
                                            }
                                        } else {
                                            throw new IllegalStateException("Nonnull field \"formattedPrice\" is null.");
                                        }
                                    } else {
                                        throw new IllegalStateException("Nonnull field \"billingPeriod\" is null.");
                                    }
                                } else {
                                    throw new IllegalStateException("Nonnull field \"priceAmountMicros\" is null.");
                                }
                            } else {
                                throw new IllegalStateException("Nonnull field \"recurrenceMode\" is null.");
                            }
                        } else {
                            throw new IllegalStateException("Nonnull field \"billingCycleCount\" is null.");
                        }
                    }
                    String str21 = str5;
                    String str22 = str6;
                    String str23 = str7;
                    Messages.PlatformProductType platformProductType3 = c10;
                    String str24 = str8;
                    Messages.j jVar5 = jVar2;
                    Messages.s sVar = new Messages.s();
                    if (str12 != null) {
                        sVar.f12752a = str12;
                        sVar.f12753b = str11;
                        if (str13 != null) {
                            sVar.f12754c = str13;
                            if (list3 != null) {
                                sVar.f12755d = list3;
                                sVar.f12756e = arrayList6;
                                arrayList4.add(sVar);
                                it4 = it5;
                                it3 = it6;
                                vVar2 = vVar3;
                                arrayList3 = arrayList5;
                                jVar2 = jVar5;
                                str5 = str21;
                                str7 = str23;
                                c10 = platformProductType3;
                                str8 = str24;
                                str6 = str22;
                            } else {
                                throw new IllegalStateException("Nonnull field \"offerTags\" is null.");
                            }
                        } else {
                            throw new IllegalStateException("Nonnull field \"offerToken\" is null.");
                        }
                    } else {
                        throw new IllegalStateException("Nonnull field \"basePlanId\" is null.");
                    }
                }
                vVar = vVar2;
                arrayList = arrayList3;
                it = it3;
                str4 = str5;
                str = str6;
                str3 = str7;
                platformProductType = c10;
                str2 = str8;
                jVar3 = jVar2;
                arrayList2 = arrayList4;
            }
            Messages.l lVar = new Messages.l();
            if (str != null) {
                lVar.f12717a = str;
                if (str2 != null) {
                    lVar.f12718b = str2;
                    if (str3 != null) {
                        lVar.f12719c = str3;
                        if (platformProductType != null) {
                            lVar.f12720d = platformProductType;
                            if (str4 != null) {
                                lVar.f12721e = str4;
                                lVar.f12722f = jVar3;
                                lVar.f12723g = arrayList2;
                                ArrayList arrayList7 = arrayList;
                                arrayList7.add(lVar);
                                arrayList3 = arrayList7;
                                it3 = it;
                                vVar2 = vVar;
                                a10 = iVar;
                            } else {
                                throw new IllegalStateException("Nonnull field \"title\" is null.");
                            }
                        } else {
                            throw new IllegalStateException("Nonnull field \"productType\" is null.");
                        }
                    } else {
                        throw new IllegalStateException("Nonnull field \"productId\" is null.");
                    }
                } else {
                    throw new IllegalStateException("Nonnull field \"name\" is null.");
                }
            } else {
                throw new IllegalStateException("Nonnull field \"description\" is null.");
            }
        }
        Messages.m mVar3 = new Messages.m();
        mVar3.f12724a = a10;
        mVar3.f12725b = arrayList3;
        vVar2.a(mVar3);
    }

    public Object execute() {
        switch (this.f903p) {
            case 7:
                ((o6.g) this.f904q).f15087c.x((Iterable) this.f905r);
                return null;
            default:
                o6.g gVar = (o6.g) this.f904q;
                Objects.requireNonNull(gVar);
                for (Map.Entry entry : ((Map) this.f905r).entrySet()) {
                    gVar.f15093i.b((long) ((Integer) entry.getValue()).intValue(), LogEventDropped.Reason.INVALID_PAYLOD, (String) entry.getKey());
                }
                return null;
        }
    }

    public void g(com.android.billingclient.api.q qVar) {
        List<Messages.u> list;
        io.flutter.plugins.inapppurchase.c cVar = (io.flutter.plugins.inapppurchase.c) this.f904q;
        Messages.c cVar2 = (Messages.c) this.f905r;
        Objects.requireNonNull(cVar);
        String w10 = qVar.f5505a.w("externalTransactionToken", HttpUrl.FRAGMENT_ENCODE_SET);
        String w11 = qVar.f5505a.w("originalExternalTransactionId", HttpUrl.FRAGMENT_ENCODE_SET);
        if (w11.isEmpty()) {
            w11 = null;
        }
        List<q.a> list2 = qVar.f5506b;
        if (list2.isEmpty()) {
            list = Collections.emptyList();
        } else {
            ArrayList arrayList = new ArrayList();
            for (q.a aVar : list2) {
                String str = aVar.f5507a;
                String str2 = aVar.f5509c;
                Messages.PlatformProductType c10 = io.flutter.plugins.inapppurchase.i.c(aVar.f5508b);
                Messages.u uVar = new Messages.u();
                if (str != null) {
                    uVar.f12760a = str;
                    uVar.f12761b = str2;
                    if (c10 != null) {
                        uVar.f12762c = c10;
                        arrayList.add(uVar);
                    } else {
                        throw new IllegalStateException("Nonnull field \"type\" is null.");
                    }
                } else {
                    throw new IllegalStateException("Nonnull field \"id\" is null.");
                }
            }
            list = arrayList;
        }
        Messages.t tVar = new Messages.t();
        tVar.f12757a = w11;
        if (w10 != null) {
            tVar.f12758b = w10;
            if (list != null) {
                tVar.f12759c = list;
                new re.a(cVar2.f12691a, "dev.flutter.pigeon.in_app_purchase_android.InAppPurchaseCallbackApi.userSelectedalternativeBilling", Messages.d.f12692d).a(new ArrayList(Collections.singletonList(tVar)), new ze.b(new io.flutter.plugins.inapppurchase.b(cVar), 2));
                return;
            }
            throw new IllegalStateException("Nonnull field \"products\" is null.");
        }
        throw new IllegalStateException("Nonnull field \"externalTransactionToken\" is null.");
    }

    public Object k(g gVar) {
        switch (this.f903p) {
            case 10:
                z zVar = (z) this.f904q;
                String str = (String) this.f905r;
                synchronized (zVar) {
                    zVar.f14442b.remove(str);
                }
                return gVar;
            case 11:
                int[] iArr = ConfigFetchHandler.f9089j;
                return ((ConfigFetchHandler) this.f904q).b(gVar, 0, (Map) this.f905r);
            case 12:
                ConfigFetchHandler configFetchHandler = (ConfigFetchHandler) this.f904q;
                Date date = (Date) this.f905r;
                int[] iArr2 = ConfigFetchHandler.f9089j;
                Objects.requireNonNull(configFetchHandler);
                if (gVar.m()) {
                    com.google.firebase.remoteconfig.internal.b bVar = configFetchHandler.f9096g;
                    synchronized (bVar.f9123b) {
                        bVar.f9122a.edit().putInt("last_fetch_status", -1).putLong("last_fetch_time_in_millis", date.getTime()).apply();
                    }
                } else {
                    Exception h10 = gVar.h();
                    if (h10 != null) {
                        if (h10 instanceof FirebaseRemoteConfigFetchThrottledException) {
                            com.google.firebase.remoteconfig.internal.b bVar2 = configFetchHandler.f9096g;
                            synchronized (bVar2.f9123b) {
                                bVar2.f9122a.edit().putInt("last_fetch_status", 2).apply();
                            }
                        } else {
                            com.google.firebase.remoteconfig.internal.b bVar3 = configFetchHandler.f9096g;
                            synchronized (bVar3.f9123b) {
                                bVar3.f9122a.edit().putInt("last_fetch_status", 1).apply();
                            }
                        }
                    }
                }
                return gVar;
            default:
                return f(gVar);
        }
    }
}
