package ai.plaud.android.plaud.anew.flutter.audio;

import ag.c;
import ai.plaud.android.plaud.anew.database.recordfile.b;
import ai.plaud.android.plaud.anew.flutter.audio.FlutterAudioPlayUtils;
import ai.plaud.android.plaud.anew.flutter.bean.FlutterAudioData;
import ai.plaud.android.plaud.anew.player.PlayState;
import ai.plaud.android.plaud.util.audioFocus.AudioFocusManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.os.Build;
import c.e;
import ci.a;
import com.google.android.gms.internal.measurement.n8;
import java.util.Objects;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.coroutines.CoroutineStart;
import re.i;
import re.j;
import rg.d0;
import rg.l0;
import rg.s0;
import wg.q;

/* compiled from: FlutterPlayAudioManager.kt */
public final class FlutterPlayAudioManager {
    public static final String AUDIO_TYPE_MP3 = "mp3";
    public static final String AUDIO_TYPE_OPUS = "opus";
    private static final String CHANNEL = "plaud.flutter/audioManager";
    public static final FlutterPlayAudioManager INSTANCE = new FlutterPlayAudioManager();
    private static final FlutterPlayAudioManager$audioFocusResultListener$1 audioFocusResultListener;
    /* access modifiers changed from: private */
    public static FlutterAudioData curAudioData = null;
    /* access modifiers changed from: private */
    public static long curTime = 0;
    private static long duration = 0;
    /* access modifiers changed from: private */
    public static j methodChannel = null;
    /* access modifiers changed from: private */
    public static boolean needNotifyProgress = false;
    private static FlutterAudioPlayUtils playUtils = null;
    private static final long skipPosition = 15000;

    /* compiled from: FlutterPlayAudioManager.kt */
    public static final class PlayProgressData {
        private final int cur;
        private final String fileKey;
        private final int total;

        public PlayProgressData(String str, int i10, int i11) {
            d0.g(str, "fileKey");
            this.fileKey = str;
            this.total = i10;
            this.cur = i11;
        }

        public static /* synthetic */ PlayProgressData copy$default(PlayProgressData playProgressData, String str, int i10, int i11, int i12, Object obj) {
            if ((i12 & 1) != 0) {
                str = playProgressData.fileKey;
            }
            if ((i12 & 2) != 0) {
                i10 = playProgressData.total;
            }
            if ((i12 & 4) != 0) {
                i11 = playProgressData.cur;
            }
            return playProgressData.copy(str, i10, i11);
        }

        public final String component1() {
            return this.fileKey;
        }

        public final int component2() {
            return this.total;
        }

        public final int component3() {
            return this.cur;
        }

        public final PlayProgressData copy(String str, int i10, int i11) {
            d0.g(str, "fileKey");
            return new PlayProgressData(str, i10, i11);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof PlayProgressData)) {
                return false;
            }
            PlayProgressData playProgressData = (PlayProgressData) obj;
            return d0.b(this.fileKey, playProgressData.fileKey) && this.total == playProgressData.total && this.cur == playProgressData.cur;
        }

        public final int getCur() {
            return this.cur;
        }

        public final String getFileKey() {
            return this.fileKey;
        }

        public final int getTotal() {
            return this.total;
        }

        public int hashCode() {
            return (((this.fileKey.hashCode() * 31) + this.total) * 31) + this.cur;
        }

        public String toString() {
            String str = this.fileKey;
            int i10 = this.total;
            int i11 = this.cur;
            StringBuilder sb2 = new StringBuilder();
            sb2.append("PlayProgressData(fileKey=");
            sb2.append(str);
            sb2.append(", total=");
            sb2.append(i10);
            sb2.append(", cur=");
            return b.a(sb2, i11, ")");
        }
    }

    /* compiled from: FlutterPlayAudioManager.kt */
    public static final class PlayStateData {
        private final String fileKey;
        private final float speed;
        private final int state;

        public PlayStateData(String str, int i10, float f10) {
            d0.g(str, "fileKey");
            this.fileKey = str;
            this.state = i10;
            this.speed = f10;
        }

        public static /* synthetic */ PlayStateData copy$default(PlayStateData playStateData, String str, int i10, float f10, int i11, Object obj) {
            if ((i11 & 1) != 0) {
                str = playStateData.fileKey;
            }
            if ((i11 & 2) != 0) {
                i10 = playStateData.state;
            }
            if ((i11 & 4) != 0) {
                f10 = playStateData.speed;
            }
            return playStateData.copy(str, i10, f10);
        }

        public final String component1() {
            return this.fileKey;
        }

        public final int component2() {
            return this.state;
        }

        public final float component3() {
            return this.speed;
        }

        public final PlayStateData copy(String str, int i10, float f10) {
            d0.g(str, "fileKey");
            return new PlayStateData(str, i10, f10);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof PlayStateData)) {
                return false;
            }
            PlayStateData playStateData = (PlayStateData) obj;
            return d0.b(this.fileKey, playStateData.fileKey) && this.state == playStateData.state && d0.b(Float.valueOf(this.speed), Float.valueOf(playStateData.speed));
        }

        public final String getFileKey() {
            return this.fileKey;
        }

        public final float getSpeed() {
            return this.speed;
        }

        public final int getState() {
            return this.state;
        }

        public int hashCode() {
            return Float.floatToIntBits(this.speed) + (((this.fileKey.hashCode() * 31) + this.state) * 31);
        }

        public String toString() {
            String str = this.fileKey;
            int i10 = this.state;
            float f10 = this.speed;
            return "PlayStateData(fileKey=" + str + ", state=" + i10 + ", speed=" + f10 + ")";
        }
    }

    static {
        FlutterPlayAudioManager$audioFocusResultListener$1 flutterPlayAudioManager$audioFocusResultListener$1 = new FlutterPlayAudioManager$audioFocusResultListener$1();
        audioFocusResultListener = flutterPlayAudioManager$audioFocusResultListener$1;
        AudioFocusManager audioFocusManager = AudioFocusManager.f1059d;
        AudioFocusManager value = AudioFocusManager.f1060e.getValue();
        Objects.requireNonNull(value);
        if (!value.f1063c.contains(flutterPlayAudioManager$audioFocusResultListener$1)) {
            value.f1063c.add(flutterPlayAudioManager$audioFocusResultListener$1);
        }
    }

    private FlutterPlayAudioManager() {
    }

    /* access modifiers changed from: private */
    /* renamed from: configMethodChannel$lambda-0  reason: not valid java name */
    public static final void m3configMethodChannel$lambda0(i iVar, j.d dVar) {
        d0.g(iVar, "call");
        d0.g(dVar, "result");
        a.f4931a.a(b.b.a("setMethodCallHandler:[", iVar.f16444a, "]"), new Object[0]);
        String str = iVar.f16444a;
        if (str != null) {
            switch (str.hashCode()) {
                case -1133407638:
                    if (str.equals("action/setPlaySpeed")) {
                        INSTANCE.setPlaySpeed(iVar, dVar);
                        return;
                    }
                    return;
                case -1090451638:
                    if (str.equals("action/forwardAudio")) {
                        INSTANCE.forwardAudio(dVar);
                        return;
                    }
                    return;
                case -1071642942:
                    if (str.equals("action/setAudioNC")) {
                        INSTANCE.setAudioNC(iVar, dVar);
                        return;
                    }
                    return;
                case -461434623:
                    if (str.equals("action/convertOpus2Pcm")) {
                        INSTANCE.convertOpus2Pcm(iVar, dVar);
                        return;
                    }
                    return;
                case -307835813:
                    if (str.equals("action/stopAudio")) {
                        INSTANCE.stopAudio(dVar);
                        return;
                    }
                    return;
                case 479492201:
                    if (str.equals("action/playAudio")) {
                        INSTANCE.playAudio(dVar);
                        return;
                    }
                    return;
                case 638515198:
                    if (str.equals("action/seekProgress")) {
                        INSTANCE.seekProgress(iVar, dVar);
                        return;
                    }
                    return;
                case 836060409:
                    if (str.equals("action/pauseAudio")) {
                        INSTANCE.pauseAudio(dVar);
                        return;
                    }
                    return;
                case 847000962:
                    if (str.equals("action/rewindAudio")) {
                        INSTANCE.rewindAudio(dVar);
                        return;
                    }
                    return;
                case 943018391:
                    if (str.equals("action/setAudioData")) {
                        INSTANCE.setAudioData(iVar, dVar);
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }

    private final void convertOpus2Pcm(i iVar, j.d dVar) {
        n8.f(s0.f16640p, l0.f16620c, (CoroutineStart) null, new FlutterPlayAudioManager$convertOpus2Pcm$1(iVar, dVar, (c<? super FlutterPlayAudioManager$convertOpus2Pcm$1>) null), 2, (Object) null);
    }

    private final void forwardAudio(j.d dVar) {
        if (curAudioData == null) {
            dVar.b("-1", "curAudioData is null", (Object) null);
            return;
        }
        onSeek(curTime + skipPosition);
        dVar.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    /* access modifiers changed from: private */
    public final void notifyPlayProgress(FlutterAudioData flutterAudioData, int i10, int i11) {
        if (flutterAudioData == null) {
            a.f4931a.a("notifyPlayState error audioData is null", new Object[0]);
            return;
        }
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterPlayAudioManager$notifyPlayProgress$1(flutterAudioData, i10, i11, (c<? super FlutterPlayAudioManager$notifyPlayProgress$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    public final void notifyPlayState(FlutterAudioData flutterAudioData, PlayState playState, Float f10) {
        if (flutterAudioData == null) {
            a.f4931a.a("notifyPlayState error audioData is null", new Object[0]);
            return;
        }
        a.C0057a aVar = a.f4931a;
        String fileKey = flutterAudioData.getFileKey();
        aVar.a("notifyPlayState --> [" + fileKey + "] [" + playState + "] [" + f10 + "]", new Object[0]);
        s0 s0Var = s0.f16640p;
        l0 l0Var = l0.f16618a;
        n8.f(s0Var, q.f18099a, (CoroutineStart) null, new FlutterPlayAudioManager$notifyPlayState$1(flutterAudioData, playState, f10, (c<? super FlutterPlayAudioManager$notifyPlayState$1>) null), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    public final void onPauseAudio() {
        FlutterAudioPlayUtils flutterAudioPlayUtils = playUtils;
        if (flutterAudioPlayUtils != null) {
            flutterAudioPlayUtils.pause();
        }
        notifyPlayState(curAudioData, PlayState.PAUSE, Float.valueOf(FlutterAudioPlayUtils.Companion.getCurSpeed()));
    }

    /* access modifiers changed from: private */
    public final void onPlayAudio() {
        FlutterAudioPlayUtils.Companion companion = FlutterAudioPlayUtils.Companion;
        float curSpeed = companion.getCurSpeed();
        a.C0057a aVar = a.f4931a;
        float curSpeed2 = companion.getCurSpeed();
        aVar.a("AudioPlayUtils.curSpeed:[" + curSpeed2 + "]", new Object[0]);
        FlutterAudioPlayUtils flutterAudioPlayUtils = playUtils;
        if (flutterAudioPlayUtils != null) {
            flutterAudioPlayUtils.setPlaySpeed(curSpeed);
        }
        FlutterAudioPlayUtils flutterAudioPlayUtils2 = playUtils;
        if (flutterAudioPlayUtils2 != null) {
            flutterAudioPlayUtils2.play();
        }
        needNotifyProgress = true;
        notifyPlayState(curAudioData, PlayState.PLAY, Float.valueOf(companion.getCurSpeed()));
    }

    private final void onSeek(long j10) {
        long j11 = duration;
        if (j10 <= j11) {
            j11 = j10;
        }
        if (j10 < 0) {
            j11 = 0;
        }
        FlutterAudioPlayUtils flutterAudioPlayUtils = playUtils;
        if (flutterAudioPlayUtils != null) {
            flutterAudioPlayUtils.seek(j11);
        }
        FlutterAudioData flutterAudioData = curAudioData;
        if (flutterAudioData != null) {
            FlutterPlayAudioManager flutterPlayAudioManager = INSTANCE;
            curTime = j10;
            flutterPlayAudioManager.notifyPlayProgress(flutterAudioData, flutterAudioData.getDuration(), (int) j10);
        }
    }

    private final void pauseAudio(j.d dVar) {
        if (curAudioData == null) {
            dVar.b("-1", "curAudioData is null", (Object) null);
            return;
        }
        onPauseAudio();
        dVar.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    private final void playAudio(j.d dVar) {
        if (curAudioData == null) {
            dVar.b("-1", "curAudioData is null", (Object) null);
            return;
        }
        onPlayAudio();
        AudioFocusManager audioFocusManager = AudioFocusManager.f1059d;
        AudioFocusManager value = AudioFocusManager.f1060e.getValue();
        Objects.requireNonNull(value);
        if (Build.VERSION.SDK_INT >= 26) {
            AudioFocusRequest build = new AudioFocusRequest.Builder(1).setAudioAttributes(new AudioAttributes.Builder().setUsage(14).setContentType(2).build()).setAcceptsDelayedFocusGain(true).setOnAudioFocusChangeListener(value.f1062b).build();
            d0.f(build, "Builder(AudioManager.AUD…\n                .build()");
            a.f4931a.a(e.a("请求音频焦点结果 ", value.f1061a.requestAudioFocus(build)), new Object[0]);
        } else {
            a.f4931a.a(e.a("请求音频焦点结果 ", value.f1061a.requestAudioFocus(value.f1062b, 3, 1)), new Object[0]);
        }
        dVar.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    private final void rewindAudio(j.d dVar) {
        if (curAudioData == null) {
            dVar.b("-1", "curAudioData is null", (Object) null);
            return;
        }
        onSeek(curTime - skipPosition);
        dVar.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    private final void seekProgress(i iVar, j.d dVar) {
        if (curAudioData == null) {
            dVar.b("-1", "curAudioData is null", (Object) null);
            return;
        }
        Integer num = (Integer) iVar.a("progress");
        if (num == null) {
            dVar.b("-2", "millSecond is null", (Object) null);
            return;
        }
        a.C0057a aVar = a.f4931a;
        aVar.a("seekMillSecond --> " + num, new Object[0]);
        onSeek((long) num.intValue());
        dVar.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    private final void setAudioData(i iVar, j.d dVar) {
        String str;
        i iVar2 = iVar;
        j.d dVar2 = dVar;
        String str2 = (String) iVar2.a("fileKey");
        String str3 = (String) iVar2.a("audioPath");
        String str4 = (String) iVar2.a("audioType");
        Integer num = (Integer) iVar2.a("duration");
        int i10 = 1;
        String str5 = null;
        if (!(str2 == null || str2.length() == 0)) {
            if (!(str3 == null || str3.length() == 0)) {
                if (!(str4 == null || str4.length() == 0) && num != null && num.intValue() > 0) {
                    FlutterAudioData flutterAudioData = curAudioData;
                    if (flutterAudioData != null) {
                        if (d0.b(flutterAudioData != null ? flutterAudioData.getFileKey() : null, str2)) {
                            dVar2.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                            return;
                        }
                    }
                    FlutterAudioData flutterAudioData2 = curAudioData;
                    if (flutterAudioData2 != null) {
                        str5 = flutterAudioData2.getFileKey();
                    }
                    if (!d0.b(str5, str2)) {
                        FlutterAudioPlayUtils flutterAudioPlayUtils = playUtils;
                        if (flutterAudioPlayUtils != null) {
                            flutterAudioPlayUtils.stop();
                        }
                        needNotifyProgress = false;
                    }
                    FlutterAudioPlayUtils.Companion companion = FlutterAudioPlayUtils.Companion;
                    companion.setOpenSoundPlus(20);
                    companion.setCurSpeed(1.0f);
                    curTime = 0;
                    FlutterAudioData flutterAudioData3 = curAudioData;
                    if (flutterAudioData3 != null) {
                        i10 = flutterAudioData3.getDuration();
                    }
                    notifyPlayProgress(flutterAudioData3, i10, 0);
                    curAudioData = new FlutterAudioData(str2, str3, str4, num.intValue());
                    duration = (long) num.intValue();
                    a.C0057a aVar = a.f4931a;
                    long j10 = duration;
                    long j11 = (long) 3600000;
                    long j12 = (j10 % ((long) 86400000)) / j11;
                    long j13 = (long) 60000;
                    long j14 = (j10 % j11) / j13;
                    FlutterAudioPlayUtils.Companion companion2 = companion;
                    long j15 = (j10 % j13) / ((long) 1000);
                    long j16 = 10;
                    if (j12 != 0 || j14 >= 10) {
                        str = String.valueOf((j12 * ((long) 60)) + j14);
                        j16 = 10;
                    } else {
                        str = g.a("0", j14);
                    }
                    String a10 = b.b.a(str, ":", j15 < j16 ? g.a("0", j15) : String.valueOf(j15));
                    aVar.a("总时间的时间戳: " + j10 + "  格式化后的时间 " + a10, new Object[0]);
                    FlutterAudioData flutterAudioData4 = curAudioData;
                    d0.d(flutterAudioData4);
                    FlutterAudioPlayUtils.Companion companion3 = companion2;
                    playUtils = companion3.get(flutterAudioData4, new FlutterPlayAudioManager$setAudioData$1());
                    notifyPlayState(curAudioData, PlayState.IDLE, Float.valueOf(companion3.getCurSpeed()));
                    dVar2.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
                    return;
                }
            }
        }
        StringBuilder a11 = e.a("wrong params [", str2, "] [", str3, "] [");
        a11.append(str4);
        a11.append("] [");
        a11.append(num);
        a11.append("]");
        dVar2.b("-1", a11.toString(), (Object) null);
    }

    private final void setAudioNC(i iVar, j.d dVar) {
        Integer num = (Integer) iVar.a("AINCType");
        if (num == null) {
            dVar.b("-1", "AINCType is null", (Object) null);
            return;
        }
        FlutterAudioPlayUtils.Companion companion = FlutterAudioPlayUtils.Companion;
        companion.setOpenSoundPlus(num.intValue());
        a.f4931a.a(f.a("setAudioNC:[", companion.getOpenSoundPlus(), "]"), new Object[0]);
        dVar.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    private final void setPlaySpeed(i iVar, j.d dVar) {
        Double d10 = (Double) iVar.a("speed");
        if (d10 == null) {
            dVar.b("-1", "speed is null", (Object) null);
            return;
        }
        FlutterAudioPlayUtils flutterAudioPlayUtils = playUtils;
        if (flutterAudioPlayUtils != null) {
            flutterAudioPlayUtils.setPlaySpeed((float) d10.doubleValue());
        }
        dVar.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
    }

    private final void stopAudio(j.d dVar) {
        if (curAudioData == null) {
            dVar.b("-1", "curAudioData is null", (Object) null);
            return;
        }
        FlutterAudioPlayUtils flutterAudioPlayUtils = playUtils;
        if (flutterAudioPlayUtils != null) {
            flutterAudioPlayUtils.stop();
        }
        needNotifyProgress = false;
        notifyPlayState(curAudioData, PlayState.IDLE, Float.valueOf(FlutterAudioPlayUtils.Companion.getCurSpeed()));
        curAudioData = null;
    }

    public final void configMethodChannel(io.flutter.embedding.engine.a aVar) {
        d0.g(aVar, "flutterEngine");
        j jVar = new j(aVar.f12224c.f12051s, CHANNEL);
        methodChannel = jVar;
        jVar.b(d.f906a);
    }
}
