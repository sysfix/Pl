package ai.plaud.android.plaud.anew.flutter.audio;

import ag.c;
import com.google.android.gms.internal.play_billing.x2;
import gg.p;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import kotlin.jvm.internal.DefaultConstructorMarker;
import re.j;
import rg.c0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.flutter.audio.FlutterPlayAudioManager$convertOpus2Pcm$1$pcmProcess$1$2$1", f = "FlutterPlayAudioManager.kt", l = {}, m = "invokeSuspend")
/* compiled from: FlutterPlayAudioManager.kt */
public final class FlutterPlayAudioManager$convertOpus2Pcm$1$pcmProcess$1$2$1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
    public final /* synthetic */ j.d $result;
    public int label;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FlutterPlayAudioManager$convertOpus2Pcm$1$pcmProcess$1$2$1(j.d dVar, c<? super FlutterPlayAudioManager$convertOpus2Pcm$1$pcmProcess$1$2$1> cVar) {
        super(2, cVar);
        this.$result = dVar;
    }

    public final c<g> create(Object obj, c<?> cVar) {
        return new FlutterPlayAudioManager$convertOpus2Pcm$1$pcmProcess$1$2$1(this.$result, cVar);
    }

    public final Object invoke(c0 c0Var, c<? super g> cVar) {
        return ((FlutterPlayAudioManager$convertOpus2Pcm$1$pcmProcess$1$2$1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        if (this.label == 0) {
            x2.s(obj);
            this.$result.a(i.a(0, (String) null, (Object) null, 7, (DefaultConstructorMarker) null));
            return g.f19030a;
        }
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
}
