package ai.plaud.android.plaud.anew.flutter.audio;

import a1.f;
import android.app.Activity;
import android.app.Application;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.activity.e;
import androidx.lifecycle.ProcessLifecycleOwner;
import androidx.room.d;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.a0;
import com.airbnb.lottie.b0;
import com.airbnb.lottie.n;
import com.airbnb.lottie.w;
import com.google.firebase.perf.v1.NetworkRequestMetric;
import com.tinnotech.penblesdk.entity.BluetoothStatus;
import gd.k;
import io.flutter.plugin.platform.m;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import ke.c;
import ma.k0;
import o6.i;
import okhttp3.internal.ws.WebSocketProtocol;
import rg.d0;
import s4.h;
import w2.d;
import zd.b;
import zendesk.messaging.android.internal.conversationscreen.messagelog.MessageLogView;
import zendesk.messaging.android.internal.conversationslistscreen.list.ConversationsListView;
import zendesk.ui.android.common.button.ButtonView;
import zendesk.ui.android.conversation.receipt.MessageReceiptView;

public final /* synthetic */ class a implements Runnable {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f901p = 0;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Object f902q;

    public /* synthetic */ a(FlutterAudioPlayUtils flutterAudioPlayUtils) {
        this.f902q = flutterAudioPlayUtils;
    }

    public /* synthetic */ a(Activity activity) {
        this.f902q = activity;
    }

    public /* synthetic */ a(ImageView imageView) {
        this.f902q = imageView;
    }

    public /* synthetic */ a(TextView textView) {
        this.f902q = textView;
    }

    public /* synthetic */ a(ComponentActivity.f fVar) {
        this.f902q = fVar;
    }

    public /* synthetic */ a(ComponentActivity componentActivity) {
        this.f902q = componentActivity;
    }

    public /* synthetic */ a(e eVar) {
        this.f902q = eVar;
    }

    public /* synthetic */ a(ProcessLifecycleOwner processLifecycleOwner) {
        this.f902q = processLifecycleOwner;
    }

    public /* synthetic */ a(LottieDrawable lottieDrawable) {
        this.f902q = lottieDrawable;
    }

    public /* synthetic */ a(b0 b0Var) {
        this.f902q = b0Var;
    }

    public /* synthetic */ a(com.google.firebase.installations.a aVar) {
        this.f902q = aVar;
    }

    public /* synthetic */ a(k kVar) {
        this.f902q = kVar;
    }

    public /* synthetic */ a(m mVar) {
        this.f902q = mVar;
    }

    public /* synthetic */ a(InputStream inputStream) {
        this.f902q = inputStream;
    }

    public /* synthetic */ a(c cVar) {
        this.f902q = cVar;
    }

    public /* synthetic */ a(ma.b0 b0Var) {
        this.f902q = b0Var;
    }

    public /* synthetic */ a(k0.a aVar) {
        this.f902q = aVar;
    }

    public /* synthetic */ a(i iVar) {
        this.f902q = iVar;
    }

    public /* synthetic */ a(vc.e eVar) {
        this.f902q = eVar;
    }

    public /* synthetic */ a(d dVar) {
        this.f902q = dVar;
    }

    public /* synthetic */ a(yc.a aVar) {
        this.f902q = aVar;
    }

    public /* synthetic */ a(b bVar) {
        this.f902q = bVar;
    }

    public /* synthetic */ a(MessageLogView messageLogView) {
        this.f902q = messageLogView;
    }

    public /* synthetic */ a(ConversationsListView conversationsListView) {
        this.f902q = conversationsListView;
    }

    public /* synthetic */ a(ButtonView buttonView) {
        this.f902q = buttonView;
    }

    private final void a() {
        ma.b0 b0Var = (ma.b0) this.f902q;
        synchronized (b0Var.f14342d) {
            SharedPreferences.Editor edit = b0Var.f14339a.edit();
            String str = b0Var.f14340b;
            StringBuilder sb2 = new StringBuilder();
            Iterator<String> it = b0Var.f14342d.iterator();
            while (it.hasNext()) {
                sb2.append(it.next());
                sb2.append(b0Var.f14341c);
            }
            edit.putString(str, sb2.toString()).commit();
        }
    }

    public final void run() {
        Application application;
        f.a aVar;
        boolean z10 = true;
        switch (this.f901p) {
            case 0:
                FlutterAudioPlayUtils.m0play$lambda0((FlutterAudioPlayUtils) this.f902q);
                return;
            case 1:
                ((ComponentActivity) this.f902q).invalidateMenu();
                return;
            case 2:
                ComponentActivity.f fVar = (ComponentActivity.f) this.f902q;
                Runnable runnable = fVar.f1173q;
                if (runnable != null) {
                    runnable.run();
                    fVar.f1173q = null;
                    return;
                }
                return;
            case 3:
                e.onBackPressedDispatcher$lambda$1((e) this.f902q);
                return;
            case 6:
                Activity activity = (Activity) this.f902q;
                int i10 = a1.a.f661c;
                if (!activity.isFinishing()) {
                    Class<?> cls = f.f670a;
                    if (Build.VERSION.SDK_INT >= 28) {
                        activity.recreate();
                    } else {
                        if ((!f.a() || f.f675f != null) && !(f.f674e == null && f.f673d == null)) {
                            try {
                                Object obj = f.f672c.get(activity);
                                if (obj != null) {
                                    Object obj2 = f.f671b.get(activity);
                                    if (obj2 != null) {
                                        application = activity.getApplication();
                                        aVar = new f.a(activity);
                                        application.registerActivityLifecycleCallbacks(aVar);
                                        Handler handler = f.f676g;
                                        handler.post(new a1.c(aVar, obj));
                                        if (f.a()) {
                                            Method method = f.f675f;
                                            Boolean bool = Boolean.FALSE;
                                            method.invoke(obj2, new Object[]{obj, null, null, 0, bool, null, null, bool, bool});
                                        } else {
                                            activity.recreate();
                                        }
                                        handler.post(new a1.d(application, aVar));
                                    }
                                }
                            } catch (Throwable unused) {
                            }
                        }
                        z10 = false;
                    }
                    if (!z10) {
                        activity.recreate();
                        return;
                    }
                    return;
                }
                return;
            case 7:
                ProcessLifecycleOwner.delayedPauseRunnable$lambda$0((ProcessLifecycleOwner) this.f902q);
                return;
            case 8:
                androidx.room.d dVar = (androidx.room.d) this.f902q;
                synchronized (dVar) {
                    dVar.f3807f = false;
                    d.b bVar = dVar.f3809h;
                    synchronized (bVar) {
                        Arrays.fill(bVar.f3817b, false);
                        bVar.f3819d = true;
                    }
                }
                return;
            case 9:
                Map<String, b0<com.airbnb.lottie.i>> map = n.f5284a;
                h.b((InputStream) this.f902q);
                return;
            case 10:
                LottieDrawable lottieDrawable = (LottieDrawable) this.f902q;
                com.airbnb.lottie.model.layer.b bVar2 = lottieDrawable.F;
                if (bVar2 != null) {
                    try {
                        lottieDrawable.Z.acquire();
                        bVar2.u(lottieDrawable.f5097q.d());
                    } catch (InterruptedException unused2) {
                    } catch (Throwable th2) {
                        lottieDrawable.Z.release();
                        throw th2;
                    }
                    lottieDrawable.Z.release();
                    return;
                }
                return;
            case 11:
                b0 b0Var = (b0) this.f902q;
                a0<T> a0Var = b0Var.f5116d;
                if (a0Var != null) {
                    V v10 = a0Var.f5110a;
                    if (v10 != null) {
                        synchronized (b0Var) {
                            Iterator it = new ArrayList(b0Var.f5113a).iterator();
                            while (it.hasNext()) {
                                ((w) it.next()).a(v10);
                            }
                        }
                        return;
                    }
                    Throwable th3 = a0Var.f5111b;
                    synchronized (b0Var) {
                        ArrayList arrayList = new ArrayList(b0Var.f5114b);
                        if (arrayList.isEmpty()) {
                            s4.c.b("Lottie encountered an error but no failure listener was added:", th3);
                            return;
                        }
                        Iterator it2 = arrayList.iterator();
                        while (it2.hasNext()) {
                            ((w) it2.next()).a(th3);
                        }
                        return;
                    }
                }
                return;
            case 12:
                i iVar = (i) this.f902q;
                iVar.f15106d.e(new i.d(iVar));
                return;
            case NetworkRequestMetric.PERF_SESSIONS_FIELD_NUMBER /*13*/:
                Object obj3 = com.google.firebase.installations.a.f8908m;
                ((com.google.firebase.installations.a) this.f902q).b(false);
                return;
            case AndroidVersion.ANDROID_4_0 /*14*/:
                a();
                return;
            case WebSocketProtocol.B0_MASK_OPCODE /*15*/:
                k0.a aVar2 = (k0.a) this.f902q;
                Objects.requireNonNull(aVar2);
                Log.w("FirebaseMessaging", "Service took too long to process intent: " + aVar2.f14409a.getAction() + " finishing.");
                aVar2.a();
                return;
            case 16:
                vc.e eVar = (vc.e) this.f902q;
                while (!eVar.f17716f.isEmpty() && eVar.f17722l == null) {
                    eVar.f17716f.get(0).f19000a.run();
                    eVar.f17716f.remove(0);
                }
                return;
            case AndroidVersion.ANDROID_4_2 /*17*/:
                Objects.requireNonNull((yc.a) this.f902q);
                Objects.requireNonNull(id.d.a());
                return;
            case AndroidVersion.ANDROID_4_3 /*18*/:
                k kVar = (k) this.f902q;
                Objects.requireNonNull(kVar);
                try {
                    kVar.f11027t.btStatusChange(kVar.t(), BluetoothStatus.CONNECTED);
                    return;
                } catch (Exception e10) {
                    id.k.h("BleAgentImpl", e10, "syncTime-" + kVar.f11031x, new Object[0]);
                    return;
                }
            case AndroidVersion.ANDROID_4_4 /*19*/:
                b bVar3 = (b) this.f902q;
                bVar3.f19425c.a(bVar3.f19424b.a());
                return;
            case 20:
                ((c) this.f902q).f13850q.f13855e.prefetchDefaultFontManager();
                return;
            case AndroidVersion.ANDROID_5 /*21*/:
                Class[] clsArr = m.f12527w;
                ((m) this.f902q).g(false);
                return;
            case AndroidVersion.ANDROID_5_1 /*22*/:
                MessageLogView.render$lambda$4$lambda$3((MessageLogView) this.f902q);
                return;
            case AndroidVersion.ANDROID_6 /*23*/:
                ConversationsListView.render$lambda$0((ConversationsListView) this.f902q);
                return;
            case AndroidVersion.ANDROID_7 /*24*/:
                ButtonView buttonView = (ButtonView) this.f902q;
                d0.g(buttonView, "this$0");
                w2.d dVar2 = buttonView.H;
                if (dVar2 != null) {
                    dVar2.start();
                    return;
                }
                return;
            case AndroidVersion.ANDROID_7_1 /*25*/:
                ImageView imageView = (ImageView) this.f902q;
                int i11 = MessageReceiptView.f521t;
                d0.g(imageView, "$this_apply");
                imageView.animate().alpha(1.0f).setStartDelay(100).setDuration(200).setInterpolator(new LinearInterpolator()).start();
                return;
            case AndroidVersion.ANDROID_8 /*26*/:
                TextView textView = (TextView) this.f902q;
                int i12 = MessageReceiptView.f521t;
                d0.g(textView, "$this_apply");
                textView.setVisibility(0);
                return;
            default:
                ((w2.d) this.f902q).start();
                return;
        }
    }
}
