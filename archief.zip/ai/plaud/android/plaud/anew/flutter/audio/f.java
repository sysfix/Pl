package ai.plaud.android.plaud.anew.flutter.audio;

public final /* synthetic */ class f {
    public static String a(String str, int i10, String str2) {
        return str + i10 + str2;
    }
}
