package ai.plaud.android.plaud.anew.flutter.audio;

import ci.a;
import y.b;

/* compiled from: FlutterPlayAudioManager.kt */
public final class FlutterPlayAudioManager$audioFocusResultListener$1 extends b {
    public void pause() {
        a.f4931a.a("audioFocusResultListener 暂停播放", new Object[0]);
        FlutterPlayAudioManager.INSTANCE.onPauseAudio();
    }

    public void resume() {
        a.f4931a.a("audioFocusResultListener 恢复播放", new Object[0]);
        FlutterPlayAudioManager.INSTANCE.onPlayAudio();
    }
}
