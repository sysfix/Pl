package ai.plaud.android.plaud.anew.flutter.audio;

import ai.plaud.android.plaud.anew.flutter.bean.FlutterResultData;
import kotlin.jvm.internal.DefaultConstructorMarker;
import q.a;

public final /* synthetic */ class i {
    public static String a(int i10, String str, Object obj, int i11, DefaultConstructorMarker defaultConstructorMarker) {
        return a.a(new FlutterResultData(i10, str, obj, i11, defaultConstructorMarker));
    }
}
