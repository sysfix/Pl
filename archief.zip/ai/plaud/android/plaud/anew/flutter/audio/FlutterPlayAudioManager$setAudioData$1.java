package ai.plaud.android.plaud.anew.flutter.audio;

import ai.plaud.android.plaud.anew.flutter.audio.FlutterAudioPlayUtils;
import ai.plaud.android.plaud.anew.flutter.bean.FlutterAudioData;
import ai.plaud.android.plaud.anew.player.PlayState;
import rg.d0;

/* compiled from: FlutterPlayAudioManager.kt */
public final class FlutterPlayAudioManager$setAudioData$1 implements FlutterAudioPlayUtils.PlayListener {
    public void playProgress(FlutterAudioData flutterAudioData, long j10) {
        d0.g(flutterAudioData, "audioData");
        if (FlutterPlayAudioManager.needNotifyProgress) {
            FlutterPlayAudioManager flutterPlayAudioManager = FlutterPlayAudioManager.INSTANCE;
            FlutterPlayAudioManager.curTime = j10;
            FlutterAudioData access$getCurAudioData$p = FlutterPlayAudioManager.curAudioData;
            FlutterAudioData access$getCurAudioData$p2 = FlutterPlayAudioManager.curAudioData;
            flutterPlayAudioManager.notifyPlayProgress(access$getCurAudioData$p, access$getCurAudioData$p2 != null ? access$getCurAudioData$p2.getDuration() : 1, (int) j10);
        }
    }

    public void stopPlay(FlutterAudioData flutterAudioData) {
        d0.g(flutterAudioData, "audioData");
        FlutterPlayAudioManager.INSTANCE.notifyPlayState(FlutterPlayAudioManager.curAudioData, PlayState.END, Float.valueOf(FlutterAudioPlayUtils.Companion.getCurSpeed()));
    }
}
