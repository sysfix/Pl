package ai.plaud.android.plaud.anew.flutter.audio;

import re.i;
import re.j;

public final /* synthetic */ class d implements j.c {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ d f906a = new d();

    public final void g(i iVar, j.d dVar) {
        FlutterPlayAudioManager.m3configMethodChannel$lambda0(iVar, dVar);
    }
}
