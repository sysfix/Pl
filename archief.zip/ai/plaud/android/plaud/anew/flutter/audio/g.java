package ai.plaud.android.plaud.anew.flutter.audio;

public final /* synthetic */ class g {
    public static String a(String str, long j10) {
        return str + j10;
    }
}
