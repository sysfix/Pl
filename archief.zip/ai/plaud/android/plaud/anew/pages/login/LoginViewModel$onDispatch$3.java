package ai.plaud.android.plaud.anew.pages.login;

import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.bean.AuthBean;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository$login$2;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import ai.plaud.android.plaud.util.MVIExtKt;
import ci.a;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import j.k;
import java.util.Objects;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import okhttp3.HttpUrl;
import rg.d0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.pages.login.LoginViewModel$onDispatch$3", f = "LoginViewModel.kt", l = {128}, m = "invokeSuspend")
/* compiled from: LoginViewModel.kt */
public final class LoginViewModel$onDispatch$3 extends SuspendLambda implements l<c<? super g>, Object> {
    public int label;
    public final /* synthetic */ LoginViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginViewModel$onDispatch$3(LoginViewModel loginViewModel, c<? super LoginViewModel$onDispatch$3> cVar) {
        super(1, cVar);
        this.this$0 = loginViewModel;
    }

    public final c<g> create(c<?> cVar) {
        return new LoginViewModel$onDispatch$3(this.this$0, cVar);
    }

    public final Object invoke(c<? super g> cVar) {
        return ((LoginViewModel$onDispatch$3) create(cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        Integer status;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            MVIExtKt.d(this.this$0.f955t, AnonymousClass1.INSTANCE);
            LoginViewModel loginViewModel = this.this$0;
            AuthRepository authRepository = loginViewModel.f953r;
            String str = loginViewModel.f959x;
            String str2 = loginViewModel.f960y;
            this.label = 1;
            Objects.requireNonNull(authRepository);
            obj = authRepository.a(new AuthRepository$login$2(authRepository, str, str2, (c<? super AuthRepository$login$2>) null), this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ApiResponse apiResponse = (ApiResponse) obj;
        a.C0057a aVar = ci.a.f4931a;
        aVar.a("login " + apiResponse, new Object[0]);
        if (!apiResponse.isSuccess() || !(apiResponse instanceof AuthBean.AccessTokenRsq)) {
            MVIExtKt.d(this.this$0.f955t, AnonymousClass2.INSTANCE);
            Integer status2 = apiResponse.getStatus();
            if ((status2 != null && status2.intValue() == -2) || ((status = apiResponse.getStatus()) != null && status.intValue() == -1)) {
                x.l<k> lVar = this.this$0.f957v;
                String string = AppProvider.a().getResources().getString(R.string.login_WrongAccountOrPasswordPleaseReEnter);
                d0.f(string, "get().resources.getStrin…tOrPasswordPleaseReEnter)");
                MVIExtKt.c(lVar, new k.b(string));
            } else {
                x.l<k> lVar2 = this.this$0.f957v;
                String msg = apiResponse.getMsg();
                if (msg == null) {
                    msg = HttpUrl.FRAGMENT_ENCODE_SET;
                }
                MVIExtKt.c(lVar2, new k.b(msg));
            }
        } else {
            PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
            PreferencesUtil.d().c("accessToken_key", ((AuthBean.AccessTokenRsq) apiResponse).getAccess_token());
            PreferencesUtil.d().c("email_key", this.this$0.f959x);
            LoginViewModel loginViewModel2 = this.this$0;
            Objects.requireNonNull(loginViewModel2);
            loginViewModel2.c(new LoginViewModel$onFetchUserInformation$1(loginViewModel2, (c<? super LoginViewModel$onFetchUserInformation$1>) null));
        }
        return g.f19030a;
    }
}
