package ai.plaud.android.plaud.anew.pages.login;

import androidx.fragment.app.Fragment;
import gg.a;
import kotlin.jvm.internal.Lambda;

/* compiled from: FragmentViewModelLazy.kt */
public final class LoginFragment$special$$inlined$viewModels$default$1 extends Lambda implements a<Fragment> {
    public final /* synthetic */ Fragment $this_viewModels;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginFragment$special$$inlined$viewModels$default$1(Fragment fragment) {
        super(0);
        this.$this_viewModels = fragment;
    }

    public final Fragment invoke() {
        return this.$this_viewModels;
    }
}
