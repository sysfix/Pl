package ai.plaud.android.plaud.anew.pages.login;

import j.m;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: LoginFragment.kt */
public /* synthetic */ class LoginFragment$onViewCreated$4$7 extends PropertyReference1Impl {
    public static final LoginFragment$onViewCreated$4$7 INSTANCE = new LoginFragment$onViewCreated$4$7();

    public LoginFragment$onViewCreated$4$7() {
        super(m.class, "isLoginButtonState", "isLoginButtonState()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((m) obj).f13054e);
    }
}
