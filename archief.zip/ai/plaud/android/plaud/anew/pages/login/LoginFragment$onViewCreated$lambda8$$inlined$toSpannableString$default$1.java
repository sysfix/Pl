package ai.plaud.android.plaud.anew.pages.login;

import androidx.navigation.NavController;
import gg.a;
import i.m;
import j.d;
import java.util.Map;
import kotlin.jvm.internal.Lambda;
import okhttp3.HttpUrl;
import rg.d0;
import xf.g;

/* renamed from: ai.plaud.android.plaud.anew.pages.login.LoginFragment$onViewCreated$lambda-8$$inlined$toSpannableString$default$1  reason: invalid class name */
/* compiled from: Extension.kt */
public final class LoginFragment$onViewCreated$lambda8$$inlined$toSpannableString$default$1 extends Lambda implements a<g> {
    public final /* synthetic */ Map.Entry $kv;
    public final /* synthetic */ LoginFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginFragment$onViewCreated$lambda8$$inlined$toSpannableString$default$1(Map.Entry entry, LoginFragment loginFragment) {
        super(0);
        this.$kv = entry;
        this.this$0 = loginFragment;
    }

    public final void invoke() {
        Object key = this.$kv.getKey();
        d0.f(key, "kv.key");
        String str = (String) key;
        boolean b10 = d0.b(str, "user");
        String str2 = HttpUrl.FRAGMENT_ENCODE_SET;
        if (b10) {
            NavController f10 = m.f(this.this$0);
            if (!true || !true) {
                str2 = null;
            }
            d0.g("https://note.plaud.ai/user-service-agreement", "url");
            d0.g(str2, "webTitle");
            f10.k(new d("https://note.plaud.ai/user-service-agreement", str2));
        } else if (d0.b(str, "privacy")) {
            NavController f11 = m.f(this.this$0);
            if (!true || !true) {
                str2 = null;
            }
            d0.g("https://note.plaud.ai/privacy", "url");
            d0.g(str2, "webTitle");
            f11.k(new d("https://note.plaud.ai/privacy", str2));
        }
    }
}
