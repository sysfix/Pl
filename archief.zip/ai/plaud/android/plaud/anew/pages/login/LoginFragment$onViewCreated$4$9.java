package ai.plaud.android.plaud.anew.pages.login;

import j.m;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: LoginFragment.kt */
public /* synthetic */ class LoginFragment$onViewCreated$4$9 extends PropertyReference1Impl {
    public static final LoginFragment$onViewCreated$4$9 INSTANCE = new LoginFragment$onViewCreated$4$9();

    public LoginFragment$onViewCreated$4$9() {
        super(m.class, "isLoginSuccess", "isLoginSuccess()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((m) obj).f13055f);
    }
}
