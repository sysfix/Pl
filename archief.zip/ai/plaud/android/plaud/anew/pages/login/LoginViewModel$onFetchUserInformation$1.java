package ai.plaud.android.plaud.anew.pages.login;

import a.d;
import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.bean.UserBean;
import ai.plaud.android.plaud.anew.api.repository.UserRepository$getUser$2;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import ai.plaud.android.plaud.util.MVIExtKt;
import ci.a;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import j.k;
import java.util.Objects;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import xf.g;
import zendesk.core.AnonymousIdentity;
import zendesk.core.Identity;
import zendesk.core.Zendesk;

@a(c = "ai.plaud.android.plaud.anew.pages.login.LoginViewModel$onFetchUserInformation$1", f = "LoginViewModel.kt", l = {163}, m = "invokeSuspend")
/* compiled from: LoginViewModel.kt */
public final class LoginViewModel$onFetchUserInformation$1 extends SuspendLambda implements l<c<? super g>, Object> {
    public int label;
    public final /* synthetic */ LoginViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginViewModel$onFetchUserInformation$1(LoginViewModel loginViewModel, c<? super LoginViewModel$onFetchUserInformation$1> cVar) {
        super(1, cVar);
        this.this$0 = loginViewModel;
    }

    public final c<g> create(c<?> cVar) {
        return new LoginViewModel$onFetchUserInformation$1(this.this$0, cVar);
    }

    public final Object invoke(c<? super g> cVar) {
        return ((LoginViewModel$onFetchUserInformation$1) create(cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            g.a aVar = this.this$0.f954s;
            this.label = 1;
            Objects.requireNonNull(aVar);
            obj = aVar.a(new UserRepository$getUser$2(aVar, (c<? super UserRepository$getUser$2>) null), this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ApiResponse apiResponse = (ApiResponse) obj;
        a.C0057a aVar2 = ci.a.f4931a;
        aVar2.a("用户信息 [" + apiResponse + "]", new Object[0]);
        if (apiResponse instanceof UserBean.GetUserRsp) {
            UserBean.GetUserRsp getUserRsp = (UserBean.GetUserRsp) apiResponse;
            if (getUserRsp.getData_user() != null) {
                UserBean.UserInfo data_user = getUserRsp.getData_user();
                LoginViewModel loginViewModel = this.this$0;
                PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
                PreferencesUtil.d().c("user_id_key", data_user.getId());
                PreferencesUtil.d().c("username_key", data_user.getId());
                PreferencesUtil.d().c("nickname_key", data_user.getNickname());
                PreferencesUtil.d().c("email_key", data_user.getEmail());
                MVIExtKt.d(loginViewModel.f955t, LoginViewModel$onFetchUserInformation$1$1$1.INSTANCE);
                Identity build = new AnonymousIdentity.Builder().withNameIdentifier(PreferencesUtil.d().b("nickname_key")).withEmailIdentifier(PreferencesUtil.d().b("email_key")).build();
                aVar2.a("Zendesk.INSTANCE.init: [" + build + "]", new Object[0]);
                Zendesk.INSTANCE.setIdentity(build);
                return g.f19030a;
            }
        }
        aVar2.b("获取用户信息失败", new Object[0]);
        MVIExtKt.d(this.this$0.f955t, AnonymousClass2.INSTANCE);
        MVIExtKt.c(this.this$0.f957v, new k.b(d.a(AppProvider.a().getString(R.string.network_badNetwork), ":-1")));
        return g.f19030a;
    }
}
