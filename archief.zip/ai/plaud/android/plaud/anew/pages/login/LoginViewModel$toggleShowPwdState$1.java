package ai.plaud.android.plaud.anew.pages.login;

import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: LoginViewModel.kt */
public final class LoginViewModel$toggleShowPwdState$1 extends Lambda implements l<Boolean, Boolean> {
    public final /* synthetic */ LoginViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginViewModel$toggleShowPwdState$1(LoginViewModel loginViewModel) {
        super(1);
        this.this$0 = loginViewModel;
    }

    public final Boolean invoke(Boolean bool) {
        return Boolean.valueOf(d0.b(this.this$0.B.getValue(), Boolean.FALSE));
    }
}
