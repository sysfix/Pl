package ai.plaud.android.plaud.anew.pages.login;

import gg.l;
import j.m;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: LoginViewModel.kt */
public final class LoginViewModel$onFetchUserInformation$1$1$1 extends Lambda implements l<m, m> {
    public static final LoginViewModel$onFetchUserInformation$1$1$1 INSTANCE = new LoginViewModel$onFetchUserInformation$1$1$1();

    public LoginViewModel$onFetchUserInformation$1$1$1() {
        super(1);
    }

    public final m invoke(m mVar) {
        d0.g(mVar, "$this$postState");
        return m.a(mVar, false, false, false, false, false, true, 30);
    }
}
