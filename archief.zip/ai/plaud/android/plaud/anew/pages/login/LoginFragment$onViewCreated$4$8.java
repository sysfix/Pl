package ai.plaud.android.plaud.anew.pages.login;

import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import u.e;
import xf.g;

/* compiled from: LoginFragment.kt */
public final class LoginFragment$onViewCreated$4$8 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ LoginFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginFragment$onViewCreated$4$8(LoginFragment loginFragment) {
        super(1);
        this.this$0 = loginFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        LoginFragment loginFragment = this.this$0;
        int i10 = LoginFragment.G;
        if (z10) {
            VB vb2 = loginFragment.f14772x;
            d0.d(vb2);
            ((e) vb2).f17152f.j();
            return;
        }
        VB vb3 = loginFragment.f14772x;
        d0.d(vb3);
        ((e) vb3).f17152f.i();
    }
}
