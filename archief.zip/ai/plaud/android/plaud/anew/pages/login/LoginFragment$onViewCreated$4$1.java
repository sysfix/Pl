package ai.plaud.android.plaud.anew.pages.login;

import j.m;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: LoginFragment.kt */
public /* synthetic */ class LoginFragment$onViewCreated$4$1 extends PropertyReference1Impl {
    public static final LoginFragment$onViewCreated$4$1 INSTANCE = new LoginFragment$onViewCreated$4$1();

    public LoginFragment$onViewCreated$4$1() {
        super(m.class, "loading", "getLoading()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((m) obj).f13050a);
    }
}
