package ai.plaud.android.plaud.anew.pages.login;

import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import ai.plaud.android.plaud.base.ui.BaseViewModel;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.util.MVIExtKt;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.util.Patterns;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import g.a;
import j.j;
import j.k;
import j.m;
import okhttp3.HttpUrl;
import rg.d0;
import x.l;

/* compiled from: LoginViewModel.kt */
public final class LoginViewModel extends BaseViewModel {
    public boolean A;
    public final MutableLiveData<Boolean> B;
    public final LiveData<Boolean> C;

    /* renamed from: r  reason: collision with root package name */
    public final AuthRepository f953r;

    /* renamed from: s  reason: collision with root package name */
    public final a f954s;

    /* renamed from: t  reason: collision with root package name */
    public final MutableLiveData<m> f955t;

    /* renamed from: u  reason: collision with root package name */
    public final LiveData<m> f956u;

    /* renamed from: v  reason: collision with root package name */
    public final l<k> f957v;

    /* renamed from: w  reason: collision with root package name */
    public final LiveData<k> f958w;

    /* renamed from: x  reason: collision with root package name */
    public String f959x = HttpUrl.FRAGMENT_ENCODE_SET;

    /* renamed from: y  reason: collision with root package name */
    public String f960y = HttpUrl.FRAGMENT_ENCODE_SET;

    /* renamed from: z  reason: collision with root package name */
    public boolean f961z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginViewModel(n.a aVar, AuthRepository authRepository, a aVar2) {
        super(aVar);
        d0.g(aVar, "mCoroutineDispatchers");
        d0.g(authRepository, "authRepository");
        d0.g(aVar2, "userRepository");
        this.f953r = authRepository;
        this.f954s = aVar2;
        MutableLiveData<m> mutableLiveData = new MutableLiveData<>(new m(false, false, false, false, false, false, 63));
        this.f955t = mutableLiveData;
        d0.g(mutableLiveData, "<this>");
        this.f956u = mutableLiveData;
        l<k> lVar = new l<>();
        this.f957v = lVar;
        d0.g(lVar, "<this>");
        this.f958w = lVar;
        MutableLiveData<Boolean> mutableLiveData2 = new MutableLiveData<>(Boolean.FALSE);
        this.B = mutableLiveData2;
        d0.g(mutableLiveData2, "<this>");
        this.C = mutableLiveData2;
    }

    public static final boolean d(LoginViewModel loginViewModel) {
        if (loginViewModel.f959x.length() > 0) {
            if (loginViewModel.f960y.length() > 0) {
                return true;
            }
        }
        return false;
    }

    public final void e(j jVar) {
        if (jVar instanceof j.a) {
            String str = ((j.a) jVar).f13045a;
            this.f959x = str;
            d0.g(str, "input");
            this.f961z = Patterns.EMAIL_ADDRESS.matcher(str).matches();
            MVIExtKt.d(this.f955t, new LoginViewModel$onDispatch$1(this));
            return;
        }
        boolean z10 = true;
        if (jVar instanceof j.b) {
            String str2 = ((j.b) jVar).f13046a;
            this.f960y = str2;
            int a10 = i.j.a(str2, "input", str2);
            if (6 > a10 || a10 >= 17) {
                z10 = false;
            }
            this.A = z10;
            MVIExtKt.d(this.f955t, new LoginViewModel$onDispatch$2(this));
        } else if (d0.b(jVar, j.c.f13047a)) {
            Object systemService = AppProvider.a().getApplicationContext().getSystemService("wifi");
            d0.e(systemService, "null cannot be cast to non-null type android.net.wifi.WifiManager");
            if (!((WifiManager) systemService).isWifiEnabled()) {
                Object systemService2 = AppProvider.a().getSystemService("connectivity");
                d0.e(systemService2, "null cannot be cast to non-null type android.net.ConnectivityManager");
                NetworkInfo activeNetworkInfo = ((ConnectivityManager) systemService2).getActiveNetworkInfo();
                if (activeNetworkInfo == null || !activeNetworkInfo.isAvailable() || activeNetworkInfo.getType() != 0) {
                    z10 = false;
                }
                if (!z10) {
                    l<k> lVar = this.f957v;
                    String string = AppProvider.a().getString(R.string.network_badNetwork);
                    d0.f(string, "get().getString(R.string.network_badNetwork)");
                    MVIExtKt.e(lVar, new k.b(string));
                    return;
                }
            }
            if (!this.f961z) {
                l<k> lVar2 = this.f957v;
                String string2 = AppProvider.a().getString(R.string.register_PleaseEnterCorrectEmail);
                d0.f(string2, "get().getString(R.string…_PleaseEnterCorrectEmail)");
                MVIExtKt.e(lVar2, new k.a(string2));
            } else if (!this.A) {
                l<k> lVar3 = this.f957v;
                String string3 = AppProvider.a().getString(R.string.register_PasswordLengthErrorReminder);
                d0.f(string3, "get().getString(R.string…swordLengthErrorReminder)");
                MVIExtKt.e(lVar3, new k.b(string3));
            } else {
                c(new LoginViewModel$onDispatch$3(this, (c<? super LoginViewModel$onDispatch$3>) null));
            }
        }
    }
}
