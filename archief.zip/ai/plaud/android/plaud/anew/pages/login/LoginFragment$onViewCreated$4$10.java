package ai.plaud.android.plaud.anew.pages.login;

import ai.plaud.android.plaud.anew.flutter.device.f;
import android.content.Intent;
import ci.a;
import gg.l;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.android.FlutterActivityLaunchConfigs;
import java.util.Objects;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: LoginFragment.kt */
public final class LoginFragment$onViewCreated$4$10 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ LoginFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginFragment$onViewCreated$4$10(LoginFragment loginFragment) {
        super(1);
        this.this$0 = loginFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        a.f4931a.a(f.a("登录 ", z10), new Object[0]);
        if (z10) {
            LoginFragment loginFragment = this.this$0;
            int i10 = LoginFragment.G;
            Objects.requireNonNull(loginFragment);
            int i11 = FlutterActivity.f12131t;
            Intent putExtra = new Intent(loginFragment.requireActivity(), FlutterActivity.class).putExtra("cached_engine_id", "plaud_flutter_engine_id").putExtra("destroy_engine_with_activity", false).putExtra("background_mode", FlutterActivityLaunchConfigs.f12137a);
            putExtra.setFlags(268468224);
            loginFragment.startActivity(putExtra);
        }
    }
}
