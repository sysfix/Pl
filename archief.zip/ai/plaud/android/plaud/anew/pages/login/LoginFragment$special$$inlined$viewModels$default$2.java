package ai.plaud.android.plaud.anew.pages.login;

import androidx.lifecycle.ViewModelStoreOwner;
import gg.a;
import kotlin.jvm.internal.Lambda;

/* compiled from: FragmentViewModelLazy.kt */
public final class LoginFragment$special$$inlined$viewModels$default$2 extends Lambda implements a<ViewModelStoreOwner> {
    public final /* synthetic */ a $ownerProducer;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginFragment$special$$inlined$viewModels$default$2(a aVar) {
        super(0);
        this.$ownerProducer = aVar;
    }

    public final ViewModelStoreOwner invoke() {
        return (ViewModelStoreOwner) this.$ownerProducer.invoke();
    }
}
