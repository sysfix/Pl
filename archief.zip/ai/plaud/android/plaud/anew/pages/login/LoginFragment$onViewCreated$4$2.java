package ai.plaud.android.plaud.anew.pages.login;

import ai.plaud.android.plaud.anew.flutter.device.f;
import ci.a;
import gg.l;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: LoginFragment.kt */
public final class LoginFragment$onViewCreated$4$2 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ LoginFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginFragment$onViewCreated$4$2(LoginFragment loginFragment) {
        super(1);
        this.this$0 = loginFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        a.f4931a.a(f.a("loading ", z10), new Object[0]);
        if (z10) {
            this.this$0.e();
        } else {
            this.this$0.d();
        }
    }
}
