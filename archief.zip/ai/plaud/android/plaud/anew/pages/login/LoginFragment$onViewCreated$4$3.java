package ai.plaud.android.plaud.anew.pages.login;

import j.m;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: LoginFragment.kt */
public /* synthetic */ class LoginFragment$onViewCreated$4$3 extends PropertyReference1Impl {
    public static final LoginFragment$onViewCreated$4$3 INSTANCE = new LoginFragment$onViewCreated$4$3();

    public LoginFragment$onViewCreated$4$3() {
        super(m.class, "isEmailValid", "isEmailValid()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((m) obj).f13051b);
    }
}
