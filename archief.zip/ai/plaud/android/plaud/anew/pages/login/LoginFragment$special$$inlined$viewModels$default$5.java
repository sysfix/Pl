package ai.plaud.android.plaud.anew.pages.login;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.g0;
import androidx.lifecycle.HasDefaultViewModelProviderFactory;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import gg.a;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import xf.d;

/* compiled from: FragmentViewModelLazy.kt */
public final class LoginFragment$special$$inlined$viewModels$default$5 extends Lambda implements a<ViewModelProvider.Factory> {
    public final /* synthetic */ d $owner$delegate;
    public final /* synthetic */ Fragment $this_viewModels;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginFragment$special$$inlined$viewModels$default$5(Fragment fragment, d dVar) {
        super(0);
        this.$this_viewModels = fragment;
        this.$owner$delegate = dVar;
    }

    public final ViewModelProvider.Factory invoke() {
        ViewModelProvider.Factory factory;
        ViewModelStoreOwner a10 = g0.a(this.$owner$delegate);
        HasDefaultViewModelProviderFactory hasDefaultViewModelProviderFactory = a10 instanceof HasDefaultViewModelProviderFactory ? (HasDefaultViewModelProviderFactory) a10 : null;
        if (hasDefaultViewModelProviderFactory == null || (factory = hasDefaultViewModelProviderFactory.getDefaultViewModelProviderFactory()) == null) {
            factory = this.$this_viewModels.getDefaultViewModelProviderFactory();
        }
        d0.f(factory, "(owner as? HasDefaultVie…tViewModelProviderFactory");
        return factory;
    }
}
