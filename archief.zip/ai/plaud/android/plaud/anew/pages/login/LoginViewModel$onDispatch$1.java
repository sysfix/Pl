package ai.plaud.android.plaud.anew.pages.login;

import gg.l;
import j.m;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: LoginViewModel.kt */
public final class LoginViewModel$onDispatch$1 extends Lambda implements l<m, m> {
    public final /* synthetic */ LoginViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LoginViewModel$onDispatch$1(LoginViewModel loginViewModel) {
        super(1);
        this.this$0 = loginViewModel;
    }

    public final m invoke(m mVar) {
        d0.g(mVar, "$this$postState");
        LoginViewModel loginViewModel = this.this$0;
        return m.a(mVar, false, loginViewModel.f961z, false, false, LoginViewModel.d(loginViewModel), false, 45);
    }
}
