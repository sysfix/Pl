package ai.plaud.android.plaud.anew.pages.login;

import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import ai.plaud.android.plaud.component.CtaButton;
import ai.plaud.android.plaud.util.MVIExtKt;
import android.content.Context;
import android.os.Bundle;
import android.text.Annotation;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.g0;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import b1.a;
import hg.h;
import j.c;
import j.j;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import kotlin.LazyThreadSafetyMode;
import okhttp3.HttpUrl;
import pg.k;
import rg.d0;
import u.e;
import x.m;
import xf.d;

/* compiled from: LoginFragment.kt */
public final class LoginFragment extends j.a<e> {
    public static final /* synthetic */ int G = 0;
    public final d F;

    /* compiled from: Extension.kt */
    public static final class a implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ LoginFragment f951p;

        public a(LoginFragment loginFragment) {
            this.f951p = loginFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            LoginFragment loginFragment = this.f951p;
            int i13 = LoginFragment.G;
            loginFragment.h().e(new j.a(obj));
        }
    }

    /* compiled from: Extension.kt */
    public static final class b implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ LoginFragment f952p;

        public b(LoginFragment loginFragment) {
            this.f952p = loginFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            LoginFragment loginFragment = this.f952p;
            int i13 = LoginFragment.G;
            loginFragment.h().e(new j.b(obj));
        }
    }

    public LoginFragment() {
        super(AnonymousClass1.INSTANCE);
        d b10 = xf.e.b(LazyThreadSafetyMode.NONE, new LoginFragment$special$$inlined$viewModels$default$2(new LoginFragment$special$$inlined$viewModels$default$1(this)));
        this.F = g0.b(this, h.a(LoginViewModel.class), new LoginFragment$special$$inlined$viewModels$default$3(b10), new LoginFragment$special$$inlined$viewModels$default$4((gg.a) null, b10), new LoginFragment$special$$inlined$viewModels$default$5(this, b10));
    }

    public final LoginViewModel h() {
        return (LoginViewModel) this.F.getValue();
    }

    public final void i(String str) {
        boolean z10 = false;
        ci.a.f4931a.a(a.d.a("errorMsg ", str), new Object[0]);
        VB vb2 = this.f14772x;
        d0.d(vb2);
        ((e) vb2).f17148b.setVisibility(0);
        VB vb3 = this.f14772x;
        d0.d(vb3);
        AppCompatTextView appCompatTextView = ((e) vb3).f17148b;
        if (str.length() == 0) {
            z10 = true;
        }
        if (z10) {
            str = AppProvider.a().getString(R.string.network_badNetwork);
            d0.f(str, "get().getString(R.string.network_badNetwork)");
        }
        appCompatTextView.setText(str);
    }

    public void onResume() {
        super.onResume();
        if (k.b.f13468a) {
            PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
            String b10 = PreferencesUtil.d().b("email_key");
            VB vb2 = this.f14772x;
            d0.d(vb2);
            ((e) vb2).f17150d.setText(b10);
        }
    }

    public void onViewCreated(View view, Bundle bundle) {
        d0.g(view, "view");
        super.onViewCreated(view, bundle);
        LoginViewModel h10 = h();
        d0.g(h10, "<this>");
        getLifecycle().addObserver(h10);
        VB vb2 = this.f14772x;
        d0.d(vb2);
        e eVar = (e) vb2;
        AppCompatTextView appCompatTextView = eVar.f17149c;
        d0.f(appCompatTextView, "forgotPassword");
        p.a.a(new sb.a(appCompatTextView).b(c()).c(new i.d(this)), this.f994q);
        AppCompatTextView appCompatTextView2 = eVar.f17153g;
        d0.f(appCompatTextView2, "privacyText");
        SpannableString spannableString = new SpannableString(appCompatTextView2.getText());
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        Object[] spans = spannableString.getSpans(0, spannableString.length(), Annotation.class);
        d0.f(spans, "getSpans(start, end, T::class.java)");
        for (Object obj : spans) {
            Annotation annotation = (Annotation) obj;
            String key = annotation.getKey();
            d0.f(key, "an.key");
            linkedHashMap.put(key, new x.e(Integer.valueOf(spannableString.getSpanStart(annotation)), Integer.valueOf(spannableString.getSpanEnd(annotation))));
        }
        Set<Map.Entry> entrySet = linkedHashMap.entrySet();
        d0.f(entrySet, "linkedHashMap.entries");
        for (Map.Entry entry : entrySet) {
            spannableString.setSpan(new m(false, new LoginFragment$onViewCreated$lambda8$$inlined$toSpannableString$default$1(entry, this)), ((Number) ((x.e) entry.getValue()).f18249a).intValue(), ((Number) ((x.e) entry.getValue()).f18250b).intValue(), 33);
            Context context = appCompatTextView2.getContext();
            Object obj2 = b1.a.f4191a;
            spannableString.setSpan(new ForegroundColorSpan(a.d.a(context, R.color.ck_1f1f1f)), ((Number) ((x.e) entry.getValue()).f18249a).intValue(), ((Number) ((x.e) entry.getValue()).f18250b).intValue(), 33);
            spannableString.setSpan(new StyleSpan(1), ((Number) ((x.e) entry.getValue()).f18249a).intValue(), ((Number) ((x.e) entry.getValue()).f18250b).intValue(), 33);
        }
        appCompatTextView2.setMovementMethod(LinkMovementMethod.getInstance());
        appCompatTextView2.setText(spannableString);
        Context context2 = appCompatTextView2.getContext();
        Object obj3 = b1.a.f4191a;
        appCompatTextView2.setHighlightColor(a.d.a(context2, R.color.transparent));
        eVar.f17154h.setOnClickListener(new j.b(this, 0));
        AppCompatEditText appCompatEditText = eVar.f17150d;
        d0.f(appCompatEditText, "inputEmail");
        appCompatEditText.addTextChangedListener(new a(this));
        AppCompatEditText appCompatEditText2 = eVar.f17151e;
        d0.f(appCompatEditText2, "inputPassword");
        appCompatEditText2.addTextChangedListener(new b(this));
        eVar.f17155i.setOnClickListener(new j.b(this, 1));
        CtaButton ctaButton = eVar.f17152f;
        d0.f(ctaButton, "loginBtn");
        p.a.a(new sb.a(ctaButton).b(c()).c(new ai.plaud.android.plaud.anew.flutter.audio.b(eVar, this)), this.f994q);
        PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
        String b10 = PreferencesUtil.d().b("email_key");
        VB vb3 = this.f14772x;
        d0.d(vb3);
        ((e) vb3).f17150d.setText(b10);
        h().C.observe(getViewLifecycleOwner(), new c(this, 0));
        LiveData<j.m> liveData = h().f956u;
        LifecycleOwner viewLifecycleOwner = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner, LoginFragment$onViewCreated$4$1.INSTANCE, new LoginFragment$onViewCreated$4$2(this));
        LifecycleOwner viewLifecycleOwner2 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner2, "viewLifecycleOwner");
        MVIExtKt.b(liveData, viewLifecycleOwner2, LoginFragment$onViewCreated$4$3.INSTANCE, new LoginFragment$onViewCreated$4$4(this));
        LifecycleOwner viewLifecycleOwner3 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner3, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner3, LoginFragment$onViewCreated$4$5.INSTANCE, new LoginFragment$onViewCreated$4$6(this));
        LifecycleOwner viewLifecycleOwner4 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner4, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner4, LoginFragment$onViewCreated$4$7.INSTANCE, new LoginFragment$onViewCreated$4$8(this));
        LifecycleOwner viewLifecycleOwner5 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner5, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner5, LoginFragment$onViewCreated$4$9.INSTANCE, new LoginFragment$onViewCreated$4$10(this));
        h().f958w.observe(getViewLifecycleOwner(), new c(this, 1));
    }
}
