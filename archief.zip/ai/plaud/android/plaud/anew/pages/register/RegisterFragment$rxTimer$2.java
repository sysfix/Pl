package ai.plaud.android.plaud.anew.pages.register;

import gg.a;
import kotlin.jvm.internal.Lambda;
import x.h;

/* compiled from: RegisterFragment.kt */
public final class RegisterFragment$rxTimer$2 extends Lambda implements a<h> {
    public static final RegisterFragment$rxTimer$2 INSTANCE = new RegisterFragment$rxTimer$2();

    public RegisterFragment$rxTimer$2() {
        super(0);
    }

    public final h invoke() {
        return new h();
    }
}
