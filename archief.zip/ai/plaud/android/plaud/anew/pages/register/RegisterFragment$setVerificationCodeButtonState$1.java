package ai.plaud.android.plaud.anew.pages.register;

import ci.a;
import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import u.f;
import xf.g;

/* compiled from: RegisterFragment.kt */
public final class RegisterFragment$setVerificationCodeButtonState$1 extends Lambda implements l<Long, g> {
    public final /* synthetic */ RegisterFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterFragment$setVerificationCodeButtonState$1(RegisterFragment registerFragment) {
        super(1);
        this.this$0 = registerFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Number) obj).longValue());
        return g.f19030a;
    }

    public final void invoke(long j10) {
        a.f4931a.d(ai.plaud.android.plaud.anew.flutter.audio.g.a("s ", j10), new Object[0]);
        VB vb2 = this.this$0.f14772x;
        d0.d(vb2);
        ((f) vb2).f17159d.c((int) j10);
    }
}
