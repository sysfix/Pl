package ai.plaud.android.plaud.anew.pages.register;

import k.j;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: RegisterFragment.kt */
public /* synthetic */ class RegisterFragment$onViewCreated$2$5 extends PropertyReference1Impl {
    public static final RegisterFragment$onViewCreated$2$5 INSTANCE = new RegisterFragment$onViewCreated$2$5();

    public RegisterFragment$onViewCreated$2$5() {
        super(j.class, "isVerificationCode", "isVerificationCode()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((j) obj).f13484c);
    }
}
