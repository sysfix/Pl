package ai.plaud.android.plaud.anew.pages.register;

import gg.a;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: RegisterFragment.kt */
public final class RegisterFragment$setVerificationCodeButtonState$2 extends Lambda implements a<g> {
    public final /* synthetic */ RegisterFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterFragment$setVerificationCodeButtonState$2(RegisterFragment registerFragment) {
        super(0);
        this.this$0 = registerFragment;
    }

    public final void invoke() {
        ci.a.f4931a.d("已经完成", new Object[0]);
        RegisterFragment registerFragment = this.this$0;
        int i10 = RegisterFragment.H;
        registerFragment.j(true, false);
    }
}
