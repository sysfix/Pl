package ai.plaud.android.plaud.anew.pages.register;

import k.j;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: RegisterFragment.kt */
public /* synthetic */ class RegisterFragment$onViewCreated$2$3 extends PropertyReference1Impl {
    public static final RegisterFragment$onViewCreated$2$3 INSTANCE = new RegisterFragment$onViewCreated$2$3();

    public RegisterFragment$onViewCreated$2$3() {
        super(j.class, "isEmailValid", "isEmailValid()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((j) obj).f13483b);
    }
}
