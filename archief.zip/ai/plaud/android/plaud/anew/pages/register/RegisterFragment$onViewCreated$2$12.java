package ai.plaud.android.plaud.anew.pages.register;

import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.flutter.device.f;
import android.widget.Toast;
import androidx.lifecycle.LifecycleCoroutineScope;
import androidx.lifecycle.LifecycleOwnerKt;
import ci.a;
import com.google.android.gms.internal.measurement.n8;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import gg.p;
import i.m;
import java.util.Objects;
import k.b;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.CoroutineStart;
import rg.c0;
import rg.d0;
import rg.l0;
import wg.q;
import xf.g;

/* compiled from: RegisterFragment.kt */
public final class RegisterFragment$onViewCreated$2$12 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ RegisterFragment this$0;

    @kotlin.coroutines.jvm.internal.a(c = "ai.plaud.android.plaud.anew.pages.register.RegisterFragment$onViewCreated$2$12$1", f = "RegisterFragment.kt", l = {}, m = "invokeSuspend")
    /* renamed from: ai.plaud.android.plaud.anew.pages.register.RegisterFragment$onViewCreated$2$12$1  reason: invalid class name */
    /* compiled from: RegisterFragment.kt */
    public static final class AnonymousClass1 extends SuspendLambda implements p<c0, c<? super g>, Object> {
        public int label;

        public final c<g> create(Object obj, c<?> cVar) {
            return new AnonymousClass1(cVar);
        }

        public final Object invoke(c0 c0Var, c<? super g> cVar) {
            return ((AnonymousClass1) create(c0Var, cVar)).invokeSuspend(g.f19030a);
        }

        public final Object invokeSuspend(Object obj) {
            if (this.label == 0) {
                x2.s(obj);
                b.f13468a = true;
                return g.f19030a;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterFragment$onViewCreated$2$12(RegisterFragment registerFragment) {
        super(1);
        this.this$0 = registerFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        a.f4931a.a(f.a("注册 ", z10), new Object[0]);
        if (z10) {
            RegisterFragment registerFragment = this.this$0;
            String string = registerFragment.requireContext().getString(R.string.register_RegisteredSuccessfully);
            d0.f(string, "requireContext().getStri…r_RegisteredSuccessfully)");
            Objects.requireNonNull(registerFragment);
            d0.g(string, "message");
            Toast toast = registerFragment.f998u;
            if (toast != null) {
                toast.cancel();
            }
            Toast makeText = Toast.makeText(registerFragment.requireContext(), string, 0);
            registerFragment.f998u = makeText;
            d0.d(makeText);
            makeText.show();
            LifecycleCoroutineScope lifecycleScope = LifecycleOwnerKt.getLifecycleScope(this.this$0);
            l0 l0Var = l0.f16618a;
            n8.f(lifecycleScope, q.f18099a, (CoroutineStart) null, new AnonymousClass1((c<? super AnonymousClass1>) null), 2, (Object) null);
            RegisterFragment registerFragment2 = this.this$0;
            Objects.requireNonNull(registerFragment2);
            m.f(registerFragment2).m(R.id.loginFragment, false);
        }
    }
}
