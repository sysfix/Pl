package ai.plaud.android.plaud.anew.pages.register;

import gg.l;
import k.j;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: RegisterViewModel.kt */
public final class RegisterViewModel$onDispatch$4 extends Lambda implements l<j, j> {
    public final /* synthetic */ RegisterViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterViewModel$onDispatch$4(RegisterViewModel registerViewModel) {
        super(1);
        this.this$0 = registerViewModel;
    }

    public final j invoke(j jVar) {
        d0.g(jVar, "$this$postState");
        return j.a(jVar, false, this.this$0.B, false, false, RegisterViewModel.d(this.this$0), false, false, 109);
    }
}
