package ai.plaud.android.plaud.anew.pages.register;

import k.j;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: RegisterFragment.kt */
public /* synthetic */ class RegisterFragment$onViewCreated$2$1 extends PropertyReference1Impl {
    public static final RegisterFragment$onViewCreated$2$1 INSTANCE = new RegisterFragment$onViewCreated$2$1();

    public RegisterFragment$onViewCreated$2$1() {
        super(j.class, "loading", "getLoading()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((j) obj).f13482a);
    }
}
