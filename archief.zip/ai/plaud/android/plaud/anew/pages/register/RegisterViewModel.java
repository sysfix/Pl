package ai.plaud.android.plaud.anew.pages.register;

import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import ai.plaud.android.plaud.base.ui.BaseViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import k.g;
import k.j;
import n.a;
import okhttp3.HttpUrl;
import rg.d0;
import x.l;

/* compiled from: RegisterViewModel.kt */
public final class RegisterViewModel extends BaseViewModel {
    public String A = HttpUrl.FRAGMENT_ENCODE_SET;
    public boolean B;
    public boolean C;
    public boolean D;
    public boolean E;

    /* renamed from: r  reason: collision with root package name */
    public final AuthRepository f966r;

    /* renamed from: s  reason: collision with root package name */
    public final MutableLiveData<j> f967s;

    /* renamed from: t  reason: collision with root package name */
    public final LiveData<j> f968t;

    /* renamed from: u  reason: collision with root package name */
    public final l<g> f969u;

    /* renamed from: v  reason: collision with root package name */
    public final LiveData<g> f970v;

    /* renamed from: w  reason: collision with root package name */
    public String f971w = HttpUrl.FRAGMENT_ENCODE_SET;

    /* renamed from: x  reason: collision with root package name */
    public String f972x = HttpUrl.FRAGMENT_ENCODE_SET;

    /* renamed from: y  reason: collision with root package name */
    public String f973y = HttpUrl.FRAGMENT_ENCODE_SET;

    /* renamed from: z  reason: collision with root package name */
    public String f974z = HttpUrl.FRAGMENT_ENCODE_SET;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterViewModel(a aVar, AuthRepository authRepository) {
        super(aVar);
        d0.g(aVar, "coroutineDispatchers");
        d0.g(authRepository, "authRepository");
        this.f966r = authRepository;
        MutableLiveData<j> mutableLiveData = new MutableLiveData<>(new j(false, false, false, false, false, false, false, 127));
        this.f967s = mutableLiveData;
        d0.g(mutableLiveData, "<this>");
        this.f968t = mutableLiveData;
        l<g> lVar = new l<>();
        this.f969u = lVar;
        d0.g(lVar, "<this>");
        this.f970v = lVar;
    }

    public static final boolean d(RegisterViewModel registerViewModel) {
        if (registerViewModel.f971w.length() > 0) {
            if (registerViewModel.f972x.length() > 0) {
                if (registerViewModel.f973y.length() > 0) {
                    if (registerViewModel.f974z.length() > 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x00b0, code lost:
        if ((6 <= r14 && r14 < 17) != false) goto L_0x00bd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x00bb, code lost:
        if (r14 < 17) goto L_0x00bd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00ec, code lost:
        if ((6 <= r14 && r14 < 17) != false) goto L_0x00f9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x00f7, code lost:
        if (r14 < 17) goto L_0x00f9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x0168, code lost:
        if ((6 <= r14 && r14 < 17) != false) goto L_0x0175;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0173, code lost:
        if (r14 < 17) goto L_0x0175;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x01a4, code lost:
        if ((6 <= r14 && r14 < 17) != false) goto L_0x01b1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x01af, code lost:
        if (r14 < 17) goto L_0x01b1;
     */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00ca  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00cc  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00cf  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00ef  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x0182  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x0184  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x0187  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x01a7  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void e(k.f r14) {
        /*
            r13 = this;
            boolean r0 = r14 instanceof k.f.b
            java.lang.String r1 = "input"
            if (r0 == 0) goto L_0x0027
            k.f$b r14 = (k.f.b) r14
            java.lang.String r14 = r14.f13476a
            r13.f971w = r14
            rg.d0.g(r14, r1)
            java.util.regex.Pattern r0 = android.util.Patterns.EMAIL_ADDRESS
            java.util.regex.Matcher r14 = r0.matcher(r14)
            boolean r14 = r14.matches()
            r13.B = r14
            androidx.lifecycle.MutableLiveData<k.j> r14 = r13.f967s
            ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$1 r0 = new ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$1
            r0.<init>(r13)
            ai.plaud.android.plaud.util.MVIExtKt.d(r14, r0)
            goto L_0x0306
        L_0x0027:
            boolean r0 = r14 instanceof k.f.d
            r2 = 0
            if (r0 == 0) goto L_0x005e
            k.f$d r14 = (k.f.d) r14
            java.lang.String r0 = r14.f13478a
            r13.f972x = r0
            int r0 = i.j.a(r0, r1, r0)
            if (r0 != 0) goto L_0x003a
            r0 = 1
            goto L_0x003b
        L_0x003a:
            r0 = r2
        L_0x003b:
            if (r0 != 0) goto L_0x0050
            java.lang.String r14 = r14.f13478a
            rg.d0.g(r14, r1)
            kotlin.text.Regex r0 = new kotlin.text.Regex
            java.lang.String r1 = "[-+]?\\d+(\\.\\d+)?"
            r0.<init>((java.lang.String) r1)
            boolean r14 = r0.matches(r14)
            if (r14 == 0) goto L_0x0050
            r2 = 1
        L_0x0050:
            r13.C = r2
            androidx.lifecycle.MutableLiveData<k.j> r14 = r13.f967s
            ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$2 r0 = new ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$2
            r0.<init>(r13)
            ai.plaud.android.plaud.util.MVIExtKt.d(r14, r0)
            goto L_0x0306
        L_0x005e:
            boolean r0 = r14 instanceof k.f.c
            java.lang.String r3 = " mIsComfiredPassword:"
            java.lang.String r4 = " mIsPassword:"
            java.lang.String r5 = " mIsVerificationCode:"
            java.lang.String r6 = "有效 mIsEmailInValid："
            java.lang.String r7 = "confirmNewPassword"
            java.lang.String r8 = "newPassword"
            r9 = 17
            r10 = 6
            if (r0 == 0) goto L_0x0136
            ci.a$a r0 = ci.a.f4931a
            k.f$c r14 = (k.f.c) r14
            java.lang.String r11 = r14.f13477a
            java.lang.String r12 = "当前密码 "
            java.lang.String r11 = a.d.a(r12, r11)
            java.lang.Object[] r12 = new java.lang.Object[r2]
            r0.a(r11, r12)
            java.lang.String r14 = r14.f13477a
            r13.f973y = r14
            java.lang.String r14 = r13.f974z
            int r14 = r14.length()
            if (r14 <= 0) goto L_0x0090
            r14 = 1
            goto L_0x0091
        L_0x0090:
            r14 = r2
        L_0x0091:
            if (r14 == 0) goto L_0x00b3
            java.lang.String r14 = r13.f973y
            java.lang.String r11 = r13.f974z
            rg.d0.g(r14, r8)
            rg.d0.g(r11, r7)
            boolean r14 = rg.d0.b(r14, r11)
            if (r14 == 0) goto L_0x00bf
            java.lang.String r14 = r13.f973y
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x00af
            if (r14 >= r9) goto L_0x00af
            r14 = 1
            goto L_0x00b0
        L_0x00af:
            r14 = r2
        L_0x00b0:
            if (r14 == 0) goto L_0x00bf
            goto L_0x00bd
        L_0x00b3:
            java.lang.String r14 = r13.f973y
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x00bf
            if (r14 >= r9) goto L_0x00bf
        L_0x00bd:
            r14 = 1
            goto L_0x00c0
        L_0x00bf:
            r14 = r2
        L_0x00c0:
            r13.D = r14
            java.lang.String r14 = r13.f973y
            int r14 = r14.length()
            if (r14 <= 0) goto L_0x00cc
            r14 = 1
            goto L_0x00cd
        L_0x00cc:
            r14 = r2
        L_0x00cd:
            if (r14 == 0) goto L_0x00ef
            java.lang.String r14 = r13.f973y
            java.lang.String r11 = r13.f974z
            rg.d0.g(r14, r8)
            rg.d0.g(r11, r7)
            boolean r14 = rg.d0.b(r14, r11)
            if (r14 == 0) goto L_0x00fb
            java.lang.String r14 = r13.f974z
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x00eb
            if (r14 >= r9) goto L_0x00eb
            r14 = 1
            goto L_0x00ec
        L_0x00eb:
            r14 = r2
        L_0x00ec:
            if (r14 == 0) goto L_0x00fb
            goto L_0x00f9
        L_0x00ef:
            java.lang.String r14 = r13.f974z
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x00fb
            if (r14 >= r9) goto L_0x00fb
        L_0x00f9:
            r14 = 1
            goto L_0x00fc
        L_0x00fb:
            r14 = r2
        L_0x00fc:
            r13.E = r14
            boolean r1 = r13.B
            boolean r7 = r13.C
            boolean r8 = r13.D
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            r9.append(r6)
            r9.append(r1)
            r9.append(r5)
            r9.append(r7)
            r9.append(r4)
            r9.append(r8)
            r9.append(r3)
            r9.append(r14)
            java.lang.String r14 = r9.toString()
            java.lang.Object[] r1 = new java.lang.Object[r2]
            r0.a(r14, r1)
            androidx.lifecycle.MutableLiveData<k.j> r14 = r13.f967s
            ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$3 r0 = new ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$3
            r0.<init>(r13)
            ai.plaud.android.plaud.util.MVIExtKt.d(r14, r0)
            goto L_0x0306
        L_0x0136:
            boolean r0 = r14 instanceof k.f.a
            if (r0 == 0) goto L_0x01f0
            k.f$a r14 = (k.f.a) r14
            java.lang.String r14 = r14.f13475a
            r13.f974z = r14
            int r14 = r14.length()
            if (r14 <= 0) goto L_0x0148
            r14 = 1
            goto L_0x0149
        L_0x0148:
            r14 = r2
        L_0x0149:
            if (r14 == 0) goto L_0x016b
            java.lang.String r14 = r13.f973y
            java.lang.String r0 = r13.f974z
            rg.d0.g(r14, r8)
            rg.d0.g(r0, r7)
            boolean r14 = rg.d0.b(r14, r0)
            if (r14 == 0) goto L_0x0177
            java.lang.String r14 = r13.f973y
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x0167
            if (r14 >= r9) goto L_0x0167
            r14 = 1
            goto L_0x0168
        L_0x0167:
            r14 = r2
        L_0x0168:
            if (r14 == 0) goto L_0x0177
            goto L_0x0175
        L_0x016b:
            java.lang.String r14 = r13.f973y
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x0177
            if (r14 >= r9) goto L_0x0177
        L_0x0175:
            r14 = 1
            goto L_0x0178
        L_0x0177:
            r14 = r2
        L_0x0178:
            r13.D = r14
            java.lang.String r14 = r13.f973y
            int r14 = r14.length()
            if (r14 <= 0) goto L_0x0184
            r14 = 1
            goto L_0x0185
        L_0x0184:
            r14 = r2
        L_0x0185:
            if (r14 == 0) goto L_0x01a7
            java.lang.String r14 = r13.f973y
            java.lang.String r0 = r13.f974z
            rg.d0.g(r14, r8)
            rg.d0.g(r0, r7)
            boolean r14 = rg.d0.b(r14, r0)
            if (r14 == 0) goto L_0x01b3
            java.lang.String r14 = r13.f974z
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x01a3
            if (r14 >= r9) goto L_0x01a3
            r14 = 1
            goto L_0x01a4
        L_0x01a3:
            r14 = r2
        L_0x01a4:
            if (r14 == 0) goto L_0x01b3
            goto L_0x01b1
        L_0x01a7:
            java.lang.String r14 = r13.f974z
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x01b3
            if (r14 >= r9) goto L_0x01b3
        L_0x01b1:
            r14 = 1
            goto L_0x01b4
        L_0x01b3:
            r14 = r2
        L_0x01b4:
            r13.E = r14
            ci.a$a r0 = ci.a.f4931a
            boolean r1 = r13.B
            boolean r7 = r13.C
            boolean r8 = r13.D
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            r9.append(r6)
            r9.append(r1)
            r9.append(r5)
            r9.append(r7)
            r9.append(r4)
            r9.append(r8)
            r9.append(r3)
            r9.append(r14)
            java.lang.String r14 = r9.toString()
            java.lang.Object[] r1 = new java.lang.Object[r2]
            r0.a(r14, r1)
            androidx.lifecycle.MutableLiveData<k.j> r14 = r13.f967s
            ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$4 r0 = new ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$4
            r0.<init>(r13)
            ai.plaud.android.plaud.util.MVIExtKt.d(r14, r0)
            goto L_0x0306
        L_0x01f0:
            k.f$f r0 = k.f.C0172f.f13480a
            boolean r0 = rg.d0.b(r14, r0)
            r3 = 0
            if (r0 == 0) goto L_0x0203
            ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$5 r14 = new ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$5
            r14.<init>(r13, r3)
            r13.c(r14)
            goto L_0x0306
        L_0x0203:
            k.f$e r0 = k.f.e.f13479a
            boolean r14 = rg.d0.b(r14, r0)
            if (r14 == 0) goto L_0x0306
            boolean r14 = r13.D
            if (r14 == 0) goto L_0x02e8
            boolean r14 = r13.E
            if (r14 != 0) goto L_0x0215
            goto L_0x02e8
        L_0x0215:
            android.content.Context r14 = ai.plaud.android.plaud.common.util.AppProvider.a()
            android.content.Context r14 = r14.getApplicationContext()
            java.lang.String r0 = "wifi"
            java.lang.Object r14 = r14.getSystemService(r0)
            java.lang.String r0 = "null cannot be cast to non-null type android.net.wifi.WifiManager"
            rg.d0.e(r14, r0)
            android.net.wifi.WifiManager r14 = (android.net.wifi.WifiManager) r14
            boolean r14 = r14.isWifiEnabled()
            if (r14 != 0) goto L_0x0273
            android.content.Context r14 = ai.plaud.android.plaud.common.util.AppProvider.a()
            java.lang.String r0 = "connectivity"
            java.lang.Object r14 = r14.getSystemService(r0)
            java.lang.String r0 = "null cannot be cast to non-null type android.net.ConnectivityManager"
            rg.d0.e(r14, r0)
            android.net.ConnectivityManager r14 = (android.net.ConnectivityManager) r14
            android.net.NetworkInfo r14 = r14.getActiveNetworkInfo()
            if (r14 == 0) goto L_0x0255
            boolean r0 = r14.isAvailable()
            if (r0 == 0) goto L_0x0255
            int r14 = r14.getType()
            if (r14 != 0) goto L_0x0255
            r14 = 1
            goto L_0x0256
        L_0x0255:
            r14 = r2
        L_0x0256:
            if (r14 != 0) goto L_0x0273
            x.l<k.g> r14 = r13.f969u
            k.g$a r0 = new k.g$a
            android.content.Context r1 = ai.plaud.android.plaud.common.util.AppProvider.a()
            r2 = 2131886323(0x7f1200f3, float:1.9407222E38)
            java.lang.String r1 = r1.getString(r2)
            java.lang.String r2 = "get().getString(R.string.network_badNetwork)"
            rg.d0.f(r1, r2)
            r0.<init>(r1)
            ai.plaud.android.plaud.util.MVIExtKt.e(r14, r0)
            return
        L_0x0273:
            boolean r14 = r13.B
            if (r14 != 0) goto L_0x0292
            x.l<k.g> r14 = r13.f969u
            k.g$a r0 = new k.g$a
            android.content.Context r1 = ai.plaud.android.plaud.common.util.AppProvider.a()
            r2 = 2131886343(0x7f120107, float:1.9407262E38)
            java.lang.String r1 = r1.getString(r2)
            java.lang.String r2 = "get().getString(R.string…_PleaseEnterCorrectEmail)"
            rg.d0.f(r1, r2)
            r0.<init>(r1)
            ai.plaud.android.plaud.util.MVIExtKt.e(r14, r0)
            return
        L_0x0292:
            java.lang.String r14 = r13.f973y
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x029e
            if (r14 >= r9) goto L_0x029e
            r14 = 1
            goto L_0x029f
        L_0x029e:
            r14 = r2
        L_0x029f:
            java.lang.String r0 = "get()\n                  …swordLengthErrorReminder)"
            r4 = 2131886341(0x7f120105, float:1.9407258E38)
            if (r14 != 0) goto L_0x02bc
            x.l<k.g> r14 = r13.f969u
            k.g$a r1 = new k.g$a
            android.content.Context r2 = ai.plaud.android.plaud.common.util.AppProvider.a()
            java.lang.String r2 = r2.getString(r4)
            rg.d0.f(r2, r0)
            r1.<init>(r2)
            ai.plaud.android.plaud.util.MVIExtKt.e(r14, r1)
            return
        L_0x02bc:
            java.lang.String r14 = r13.f974z
            int r14 = i.j.a(r14, r1, r14)
            if (r10 > r14) goto L_0x02c7
            if (r14 >= r9) goto L_0x02c7
            r2 = 1
        L_0x02c7:
            if (r2 != 0) goto L_0x02df
            x.l<k.g> r14 = r13.f969u
            k.g$a r1 = new k.g$a
            android.content.Context r2 = ai.plaud.android.plaud.common.util.AppProvider.a()
            java.lang.String r2 = r2.getString(r4)
            rg.d0.f(r2, r0)
            r1.<init>(r2)
            ai.plaud.android.plaud.util.MVIExtKt.e(r14, r1)
            return
        L_0x02df:
            ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$6 r14 = new ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$6
            r14.<init>(r13, r3)
            r13.c(r14)
            goto L_0x0306
        L_0x02e8:
            x.l<k.g> r14 = r13.f969u
            k.g$a r0 = new k.g$a
            android.content.Context r1 = ai.plaud.android.plaud.common.util.AppProvider.a()
            android.content.res.Resources r1 = r1.getResources()
            r2 = 2131886350(0x7f12010e, float:1.9407276E38)
            java.lang.String r1 = r1.getString(r2)
            java.lang.String r2 = "get().resources.getStrin…tDoesNotMatchPleaseCheck)"
            rg.d0.f(r1, r2)
            r0.<init>(r1)
            r14.postValue(r0)
        L_0x0306:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.pages.register.RegisterViewModel.e(k.f):void");
    }
}
