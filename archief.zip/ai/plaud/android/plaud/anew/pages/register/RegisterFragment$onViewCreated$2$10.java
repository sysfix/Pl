package ai.plaud.android.plaud.anew.pages.register;

import ai.plaud.android.plaud.anew.flutter.device.f;
import ci.a;
import gg.l;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: RegisterFragment.kt */
public final class RegisterFragment$onViewCreated$2$10 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ RegisterFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterFragment$onViewCreated$2$10(RegisterFragment registerFragment) {
        super(1);
        this.this$0 = registerFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        a.f4931a.a(f.a("发送是否成功 ", z10), new Object[0]);
        if (z10) {
            RegisterFragment registerFragment = this.this$0;
            int i10 = RegisterFragment.H;
            registerFragment.j(true, true);
        }
    }
}
