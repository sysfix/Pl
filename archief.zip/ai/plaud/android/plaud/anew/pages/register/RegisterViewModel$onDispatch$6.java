package ai.plaud.android.plaud.anew.pages.register;

import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.common.util.PreferencesUtil;
import ai.plaud.android.plaud.util.MVIExtKt;
import b.b;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import k.g;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import okhttp3.HttpUrl;
import rg.d0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$6", f = "RegisterViewModel.kt", l = {225}, m = "invokeSuspend")
/* compiled from: RegisterViewModel.kt */
public final class RegisterViewModel$onDispatch$6 extends SuspendLambda implements l<c<? super g>, Object> {
    public int label;
    public final /* synthetic */ RegisterViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterViewModel$onDispatch$6(RegisterViewModel registerViewModel, c<? super RegisterViewModel$onDispatch$6> cVar) {
        super(1, cVar);
        this.this$0 = registerViewModel;
    }

    public final c<g> create(c<?> cVar) {
        return new RegisterViewModel$onDispatch$6(this.this$0, cVar);
    }

    public final Object invoke(c<? super g> cVar) {
        return ((RegisterViewModel$onDispatch$6) create(cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            MVIExtKt.d(this.this$0.f967s, AnonymousClass1.INSTANCE);
            RegisterViewModel registerViewModel = this.this$0;
            AuthRepository authRepository = registerViewModel.f966r;
            long parseLong = Long.parseLong(registerViewModel.f972x);
            RegisterViewModel registerViewModel2 = this.this$0;
            String str = registerViewModel2.A;
            String str2 = registerViewModel2.f973y;
            this.label = 1;
            obj = authRepository.b(parseLong, str, str2, this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ApiResponse apiResponse = (ApiResponse) obj;
        ci.a.f4931a.a(b.a("verifyCode:[", apiResponse.getMsg(), "]"), new Object[0]);
        if (apiResponse.isSuccess()) {
            PreferencesUtil preferencesUtil = PreferencesUtil.f1008b;
            PreferencesUtil.d().c("email_key", this.this$0.f971w);
            MVIExtKt.d(this.this$0.f967s, AnonymousClass2.INSTANCE);
        } else {
            MVIExtKt.d(this.this$0.f967s, AnonymousClass3.INSTANCE);
            Integer status = apiResponse.getStatus();
            if (status != null && status.intValue() == -2) {
                x.l<k.g> lVar = this.this$0.f969u;
                String string = AppProvider.a().getResources().getString(R.string.register_TheVerificationCodeIsWrongOrInvalid);
                d0.f(string, "get().resources.getStrin…tionCodeIsWrongOrInvalid)");
                MVIExtKt.c(lVar, new g.a(string));
            } else {
                x.l<k.g> lVar2 = this.this$0.f969u;
                String msg = apiResponse.getMsg();
                if (msg == null) {
                    msg = HttpUrl.FRAGMENT_ENCODE_SET;
                }
                MVIExtKt.c(lVar2, new g.a(msg));
            }
        }
        return xf.g.f19030a;
    }
}
