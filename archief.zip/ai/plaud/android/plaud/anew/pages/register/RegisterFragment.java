package ai.plaud.android.plaud.anew.pages.register;

import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.component.CtaButton;
import ai.plaud.android.plaud.component.VerificationCodeImageButton;
import ai.plaud.android.plaud.util.MVIExtKt;
import android.content.Context;
import android.os.Bundle;
import android.text.Annotation;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.g0;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import b1.a;
import hg.h;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import k.f;
import k.j;
import kotlin.LazyThreadSafetyMode;
import okhttp3.HttpUrl;
import pg.k;
import rg.d0;
import u.f;
import x.m;
import xf.e;

/* compiled from: RegisterFragment.kt */
public final class RegisterFragment extends k.a<f> {
    public static final /* synthetic */ int H = 0;
    public final xf.d F;
    public final xf.d G = e.a(RegisterFragment$rxTimer$2.INSTANCE);

    /* compiled from: Extension.kt */
    public static final class a implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ RegisterFragment f962p;

        public a(RegisterFragment registerFragment) {
            this.f962p = registerFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            RegisterFragment registerFragment = this.f962p;
            int i13 = RegisterFragment.H;
            registerFragment.h().e(new f.b(obj));
        }
    }

    /* compiled from: Extension.kt */
    public static final class b implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ RegisterFragment f963p;

        public b(RegisterFragment registerFragment) {
            this.f963p = registerFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            RegisterFragment registerFragment = this.f963p;
            int i13 = RegisterFragment.H;
            registerFragment.h().e(new f.d(obj));
        }
    }

    /* compiled from: Extension.kt */
    public static final class c implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ RegisterFragment f964p;

        public c(RegisterFragment registerFragment) {
            this.f964p = registerFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            RegisterFragment registerFragment = this.f964p;
            int i13 = RegisterFragment.H;
            registerFragment.h().e(new f.c(obj));
            this.f964p.i(HttpUrl.FRAGMENT_ENCODE_SET);
        }
    }

    /* compiled from: Extension.kt */
    public static final class d implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ RegisterFragment f965p;

        public d(RegisterFragment registerFragment) {
            this.f965p = registerFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            RegisterFragment registerFragment = this.f965p;
            int i13 = RegisterFragment.H;
            registerFragment.h().e(new f.a(obj));
            this.f965p.i(HttpUrl.FRAGMENT_ENCODE_SET);
        }
    }

    public RegisterFragment() {
        super(AnonymousClass1.INSTANCE);
        xf.d b10 = e.b(LazyThreadSafetyMode.NONE, new RegisterFragment$special$$inlined$viewModels$default$2(new RegisterFragment$special$$inlined$viewModels$default$1(this)));
        this.F = g0.b(this, h.a(RegisterViewModel.class), new RegisterFragment$special$$inlined$viewModels$default$3(b10), new RegisterFragment$special$$inlined$viewModels$default$4((gg.a) null, b10), new RegisterFragment$special$$inlined$viewModels$default$5(this, b10));
    }

    public final RegisterViewModel h() {
        return (RegisterViewModel) this.F.getValue();
    }

    public final void i(String str) {
        ci.a.f4931a.a(b.b.a("hideErrorMsg:[", str, "]"), new Object[0]);
        VB vb2 = this.f14772x;
        d0.d(vb2);
        ((u.f) vb2).f17158c.setVisibility(8);
    }

    public final void j(boolean z10, boolean z11) {
        if (z10) {
            VB vb2 = this.f14772x;
            d0.d(vb2);
            ((u.f) vb2).f17159d.b();
        } else {
            VB vb3 = this.f14772x;
            d0.d(vb3);
            ((u.f) vb3).f17159d.a();
        }
        if (z11) {
            ((x.h) this.G.getValue()).b(60, true, new RegisterFragment$setVerificationCodeButtonState$1(this), new RegisterFragment$setVerificationCodeButtonState$2(this));
        }
    }

    public void onDestroy() {
        super.onDestroy();
        ((x.h) this.G.getValue()).a();
    }

    public void onViewCreated(View view, Bundle bundle) {
        d0.g(view, "view");
        super.onViewCreated(view, bundle);
        VB vb2 = this.f14772x;
        d0.d(vb2);
        u.f fVar = (u.f) vb2;
        fVar.f17157b.setOnClickListener(new i.a(this));
        AppCompatEditText appCompatEditText = fVar.f17161f;
        d0.f(appCompatEditText, "inputEmail");
        appCompatEditText.addTextChangedListener(new a(this));
        VerificationCodeImageButton verificationCodeImageButton = fVar.f17159d;
        d0.f(verificationCodeImageButton, "getCodeBtn");
        p.a.a(new sb.a(verificationCodeImageButton).b(c()).c(new ai.plaud.android.plaud.anew.flutter.audio.b(fVar, this)), this.f994q);
        AppCompatEditText appCompatEditText2 = fVar.f17163h;
        d0.f(appCompatEditText2, "inputVerificationCode");
        appCompatEditText2.addTextChangedListener(new b(this));
        AppCompatEditText appCompatEditText3 = fVar.f17162g;
        d0.f(appCompatEditText3, "inputPwd");
        appCompatEditText3.addTextChangedListener(new c(this));
        AppCompatEditText appCompatEditText4 = fVar.f17160e;
        d0.f(appCompatEditText4, "inputConfirmPassword");
        appCompatEditText4.addTextChangedListener(new d(this));
        CtaButton ctaButton = fVar.f17165j;
        d0.f(ctaButton, "registerBtn");
        p.a.a(new sb.a(ctaButton).b(c()).c(new i.d(this)), this.f994q);
        AppCompatTextView appCompatTextView = fVar.f17164i;
        d0.f(appCompatTextView, "privacyText");
        SpannableString spannableString = new SpannableString(appCompatTextView.getText());
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        Object[] spans = spannableString.getSpans(0, spannableString.length(), Annotation.class);
        d0.f(spans, "getSpans(start, end, T::class.java)");
        for (Object obj : spans) {
            Annotation annotation = (Annotation) obj;
            String key = annotation.getKey();
            d0.f(key, "an.key");
            linkedHashMap.put(key, new x.e(Integer.valueOf(spannableString.getSpanStart(annotation)), Integer.valueOf(spannableString.getSpanEnd(annotation))));
        }
        Set<Map.Entry> entrySet = linkedHashMap.entrySet();
        d0.f(entrySet, "linkedHashMap.entries");
        for (Map.Entry entry : entrySet) {
            spannableString.setSpan(new m(false, new RegisterFragment$onViewCreated$lambda12$$inlined$toSpannableString$default$1(entry, this)), ((Number) ((x.e) entry.getValue()).f18249a).intValue(), ((Number) ((x.e) entry.getValue()).f18250b).intValue(), 33);
            Context context = appCompatTextView.getContext();
            Object obj2 = b1.a.f4191a;
            spannableString.setSpan(new ForegroundColorSpan(a.d.a(context, R.color.ck_1f1f1f)), ((Number) ((x.e) entry.getValue()).f18249a).intValue(), ((Number) ((x.e) entry.getValue()).f18250b).intValue(), 33);
            spannableString.setSpan(new StyleSpan(1), ((Number) ((x.e) entry.getValue()).f18249a).intValue(), ((Number) ((x.e) entry.getValue()).f18250b).intValue(), 33);
        }
        appCompatTextView.setMovementMethod(LinkMovementMethod.getInstance());
        appCompatTextView.setText(spannableString);
        Context context2 = appCompatTextView.getContext();
        Object obj3 = b1.a.f4191a;
        appCompatTextView.setHighlightColor(a.d.a(context2, R.color.transparent));
        fVar.f17167l.setOnClickListener(new k.c(fVar, this, 0));
        fVar.f17166k.setOnClickListener(new k.c(fVar, this, 1));
        LiveData<j> liveData = h().f968t;
        LifecycleOwner viewLifecycleOwner = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner, RegisterFragment$onViewCreated$2$1.INSTANCE, new RegisterFragment$onViewCreated$2$2(this));
        LifecycleOwner viewLifecycleOwner2 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner2, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner2, RegisterFragment$onViewCreated$2$3.INSTANCE, new RegisterFragment$onViewCreated$2$4(this));
        LifecycleOwner viewLifecycleOwner3 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner3, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner3, RegisterFragment$onViewCreated$2$5.INSTANCE, new RegisterFragment$onViewCreated$2$6(this));
        LifecycleOwner viewLifecycleOwner4 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner4, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner4, RegisterFragment$onViewCreated$2$7.INSTANCE, new RegisterFragment$onViewCreated$2$8(this));
        LifecycleOwner viewLifecycleOwner5 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner5, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner5, RegisterFragment$onViewCreated$2$9.INSTANCE, new RegisterFragment$onViewCreated$2$10(this));
        LifecycleOwner viewLifecycleOwner6 = getViewLifecycleOwner();
        d0.f(viewLifecycleOwner6, "viewLifecycleOwner");
        MVIExtKt.a(liveData, viewLifecycleOwner6, RegisterFragment$onViewCreated$2$11.INSTANCE, new RegisterFragment$onViewCreated$2$12(this));
        h().f970v.observe(getViewLifecycleOwner(), new i.c(this));
    }
}
