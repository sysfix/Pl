package ai.plaud.android.plaud.anew.pages.register;

import androidx.fragment.app.g0;
import androidx.lifecycle.HasDefaultViewModelProviderFactory;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.viewmodel.CreationExtras;
import gg.a;
import kotlin.jvm.internal.Lambda;
import xf.d;

/* compiled from: FragmentViewModelLazy.kt */
public final class RegisterFragment$special$$inlined$viewModels$default$4 extends Lambda implements a<CreationExtras> {
    public final /* synthetic */ a $extrasProducer;
    public final /* synthetic */ d $owner$delegate;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterFragment$special$$inlined$viewModels$default$4(a aVar, d dVar) {
        super(0);
        this.$extrasProducer = aVar;
        this.$owner$delegate = dVar;
    }

    public final CreationExtras invoke() {
        CreationExtras creationExtras;
        a aVar = this.$extrasProducer;
        if (aVar != null && (creationExtras = (CreationExtras) aVar.invoke()) != null) {
            return creationExtras;
        }
        ViewModelStoreOwner a10 = g0.a(this.$owner$delegate);
        HasDefaultViewModelProviderFactory hasDefaultViewModelProviderFactory = a10 instanceof HasDefaultViewModelProviderFactory ? (HasDefaultViewModelProviderFactory) a10 : null;
        CreationExtras defaultViewModelCreationExtras = hasDefaultViewModelProviderFactory != null ? hasDefaultViewModelProviderFactory.getDefaultViewModelCreationExtras() : null;
        return defaultViewModelCreationExtras == null ? CreationExtras.Empty.INSTANCE : defaultViewModelCreationExtras;
    }
}
