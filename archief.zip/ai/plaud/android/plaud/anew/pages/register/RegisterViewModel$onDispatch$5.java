package ai.plaud.android.plaud.anew.pages.register;

import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.bean.AuthBean;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository$sendCode$2;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.util.MVIExtKt;
import b.b;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import java.util.Objects;
import k.g;
import k.j;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import rg.d0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.pages.register.RegisterViewModel$onDispatch$5", f = "RegisterViewModel.kt", l = {153}, m = "invokeSuspend")
/* compiled from: RegisterViewModel.kt */
public final class RegisterViewModel$onDispatch$5 extends SuspendLambda implements l<c<? super g>, Object> {
    public int label;
    public final /* synthetic */ RegisterViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public RegisterViewModel$onDispatch$5(RegisterViewModel registerViewModel, c<? super RegisterViewModel$onDispatch$5> cVar) {
        super(1, cVar);
        this.this$0 = registerViewModel;
    }

    public final c<g> create(c<?> cVar) {
        return new RegisterViewModel$onDispatch$5(this.this$0, cVar);
    }

    public final Object invoke(c<? super g> cVar) {
        return ((RegisterViewModel$onDispatch$5) create(cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            RegisterViewModel registerViewModel = this.this$0;
            if (!registerViewModel.B) {
                x.l<k.g> lVar = registerViewModel.f969u;
                String string = AppProvider.a().getString(R.string.register_PleaseEnterCorrectEmail);
                d0.f(string, "get()\n                  …_PleaseEnterCorrectEmail)");
                MVIExtKt.c(lVar, new g.a(string));
                return xf.g.f19030a;
            }
            MVIExtKt.d(registerViewModel.f967s, AnonymousClass1.INSTANCE);
            RegisterViewModel registerViewModel2 = this.this$0;
            AuthRepository authRepository = registerViewModel2.f966r;
            String str = registerViewModel2.f971w;
            this.label = 1;
            Objects.requireNonNull(authRepository);
            obj = authRepository.a(new AuthRepository$sendCode$2(authRepository, str, "signup", (c<? super AuthRepository$sendCode$2>) null), this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        final ApiResponse apiResponse = (ApiResponse) obj;
        ci.a.f4931a.a(b.a("sendCode:[", apiResponse.getMsg(), "]"), new Object[0]);
        if (!apiResponse.isSuccess() || !(apiResponse instanceof AuthBean.SendCodeRsp)) {
            Integer status = apiResponse.getStatus();
            if (status != null && status.intValue() == -2) {
                x.l<k.g> lVar2 = this.this$0.f969u;
                String string2 = AppProvider.a().getResources().getString(R.string.register_AccountAlreadyExistsPleaseLoginDirectly);
                d0.f(string2, "get().resources.getStrin…xistsPleaseLoginDirectly)");
                MVIExtKt.c(lVar2, new g.a(string2));
            } else {
                x.l<k.g> lVar3 = this.this$0.f969u;
                String msg = apiResponse.getMsg();
                if (msg == null) {
                    msg = AppProvider.a().getResources().getString(R.string.network_badNetwork);
                    d0.f(msg, "get().resources.getStrin…tring.network_badNetwork)");
                }
                MVIExtKt.c(lVar3, new g.a(msg));
            }
        } else {
            this.this$0.A = ((AuthBean.SendCodeRsp) apiResponse).getToken();
        }
        MVIExtKt.d(this.this$0.f967s, new l<j, j>() {
            public final j invoke(j jVar) {
                d0.g(jVar, "$this$postState");
                return j.a(jVar, false, false, false, apiResponse.isSuccess(), false, false, false, 118);
            }
        });
        return xf.g.f19030a;
    }
}
