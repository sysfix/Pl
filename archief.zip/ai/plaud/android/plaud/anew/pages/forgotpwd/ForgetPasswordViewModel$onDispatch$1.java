package ai.plaud.android.plaud.anew.pages.forgotpwd;

import gg.l;
import i.n;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: ForgetPasswordViewModel.kt */
public final class ForgetPasswordViewModel$onDispatch$1 extends Lambda implements l<n, n> {
    public final /* synthetic */ ForgetPasswordViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordViewModel$onDispatch$1(ForgetPasswordViewModel forgetPasswordViewModel) {
        super(1);
        this.this$0 = forgetPasswordViewModel;
    }

    public final n invoke(n nVar) {
        d0.g(nVar, "$this$postState");
        return n.a(nVar, false, this.this$0.f947w.length() > 0, false, false, false, false, ForgetPasswordViewModel.d(this.this$0), false, 189);
    }
}
