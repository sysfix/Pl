package ai.plaud.android.plaud.anew.pages.forgotpwd;

import gg.l;
import i.n;
import kotlin.jvm.internal.Lambda;
import rg.d0;

/* compiled from: ForgetPasswordViewModel.kt */
public final class ForgetPasswordViewModel$onDispatch$3 extends Lambda implements l<n, n> {
    public final /* synthetic */ ForgetPasswordViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordViewModel$onDispatch$3(ForgetPasswordViewModel forgetPasswordViewModel) {
        super(1);
        this.this$0 = forgetPasswordViewModel;
    }

    public final n invoke(n nVar) {
        d0.g(nVar, "$this$postState");
        ForgetPasswordViewModel forgetPasswordViewModel = this.this$0;
        return n.a(nVar, false, false, false, forgetPasswordViewModel.E, forgetPasswordViewModel.F, false, ForgetPasswordViewModel.d(forgetPasswordViewModel), false, 167);
    }
}
