package ai.plaud.android.plaud.anew.pages.forgotpwd;

import i.n;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: ForgetPasswordFragment.kt */
public /* synthetic */ class ForgetPasswordFragment$onViewCreated$2$1 extends PropertyReference1Impl {
    public static final ForgetPasswordFragment$onViewCreated$2$1 INSTANCE = new ForgetPasswordFragment$onViewCreated$2$1();

    public ForgetPasswordFragment$onViewCreated$2$1() {
        super(n.class, "loading", "getLoading()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((n) obj).f11778a);
    }
}
