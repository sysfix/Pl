package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.R;
import android.text.Editable;
import ci.a;
import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import u.c;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$onViewCreated$2$8 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$onViewCreated$2$8(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        a.C0057a aVar = a.f4931a;
        boolean z11 = !z10;
        VB vb2 = this.this$0.f14772x;
        d0.d(vb2);
        Editable text = ((c) vb2).f17140h.getText();
        d0.d(text);
        boolean z12 = true;
        boolean z13 = text.length() > 0;
        VB vb3 = this.this$0.f14772x;
        d0.d(vb3);
        Editable text2 = ((c) vb3).f17138f.getText();
        d0.d(text2);
        aVar.a("是否有效 isPasswordValid：" + z11 + " etPassword:" + z13 + " etConfirmPassword:" + (text2.length() > 0), new Object[0]);
        if (!z10) {
            VB vb4 = this.this$0.f14772x;
            d0.d(vb4);
            Editable text3 = ((c) vb4).f17140h.getText();
            d0.d(text3);
            if (text3.length() > 0) {
                VB vb5 = this.this$0.f14772x;
                d0.d(vb5);
                Editable text4 = ((c) vb5).f17138f.getText();
                d0.d(text4);
                if (text4.length() <= 0) {
                    z12 = false;
                }
                if (z12) {
                    ForgetPasswordFragment forgetPasswordFragment = this.this$0;
                    String string = forgetPasswordFragment.getString(R.string.register_TwoTimesThePasswordInputDoesNotMatchPleaseCheck);
                    d0.f(string, "getString(R.string.regis…tDoesNotMatchPleaseCheck)");
                    int i10 = ForgetPasswordFragment.H;
                    forgetPasswordFragment.j(string);
                    return;
                }
            }
        }
        ForgetPasswordFragment.h(this.this$0);
    }
}
