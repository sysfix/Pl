package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.anew.flutter.device.f;
import ci.a;
import gg.l;
import java.util.Objects;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$onViewCreated$2$2 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$onViewCreated$2$2(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        ForgetPasswordFragment forgetPasswordFragment = this.this$0;
        int i10 = ForgetPasswordFragment.H;
        Objects.requireNonNull(forgetPasswordFragment);
        a.f4931a.a(f.a("loading ", z10), new Object[0]);
        if (z10) {
            forgetPasswordFragment.e();
        } else {
            forgetPasswordFragment.d();
        }
    }
}
