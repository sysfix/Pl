package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.anew.flutter.device.f;
import ci.a;
import gg.l;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$onViewCreated$2$14 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$onViewCreated$2$14(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        a.f4931a.a(f.a("发送是否成功 ", z10), new Object[0]);
        if (z10) {
            ForgetPasswordFragment forgetPasswordFragment = this.this$0;
            int i10 = ForgetPasswordFragment.H;
            forgetPasswordFragment.k(true, true);
        }
    }
}
