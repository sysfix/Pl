package ai.plaud.android.plaud.anew.pages.forgotpwd;

import gg.a;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$setVerificationCodeButtonState$2 extends Lambda implements a<g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$setVerificationCodeButtonState$2(ForgetPasswordFragment forgetPasswordFragment) {
        super(0);
        this.this$0 = forgetPasswordFragment;
    }

    public final void invoke() {
        ci.a.f4931a.d("已经完成", new Object[0]);
        ForgetPasswordFragment forgetPasswordFragment = this.this$0;
        int i10 = ForgetPasswordFragment.H;
        forgetPasswordFragment.k(true, false);
    }
}
