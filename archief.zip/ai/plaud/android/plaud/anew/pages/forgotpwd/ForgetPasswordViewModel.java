package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import ai.plaud.android.plaud.base.ui.BaseViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import i.i;
import i.n;
import n.a;
import okhttp3.HttpUrl;
import rg.d0;
import x.l;

/* compiled from: ForgetPasswordViewModel.kt */
public final class ForgetPasswordViewModel extends BaseViewModel {
    public String A = HttpUrl.FRAGMENT_ENCODE_SET;
    public boolean B;
    public boolean C;
    public boolean D;
    public boolean E;
    public boolean F;

    /* renamed from: r  reason: collision with root package name */
    public final AuthRepository f942r;

    /* renamed from: s  reason: collision with root package name */
    public final MutableLiveData<n> f943s;

    /* renamed from: t  reason: collision with root package name */
    public final LiveData<n> f944t;

    /* renamed from: u  reason: collision with root package name */
    public final l<i> f945u;

    /* renamed from: v  reason: collision with root package name */
    public final LiveData<i> f946v;

    /* renamed from: w  reason: collision with root package name */
    public String f947w = HttpUrl.FRAGMENT_ENCODE_SET;

    /* renamed from: x  reason: collision with root package name */
    public String f948x = HttpUrl.FRAGMENT_ENCODE_SET;

    /* renamed from: y  reason: collision with root package name */
    public String f949y = HttpUrl.FRAGMENT_ENCODE_SET;

    /* renamed from: z  reason: collision with root package name */
    public String f950z = HttpUrl.FRAGMENT_ENCODE_SET;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordViewModel(a aVar, AuthRepository authRepository) {
        super(aVar);
        d0.g(aVar, "coroutineDispatchers");
        d0.g(authRepository, "authRepository");
        this.f942r = authRepository;
        MutableLiveData<n> mutableLiveData = new MutableLiveData<>(new n(false, false, false, false, false, false, false, false, 255));
        this.f943s = mutableLiveData;
        d0.g(mutableLiveData, "<this>");
        this.f944t = mutableLiveData;
        l<i> lVar = new l<>();
        this.f945u = lVar;
        d0.g(lVar, "<this>");
        this.f946v = lVar;
    }

    public static final boolean d(ForgetPasswordViewModel forgetPasswordViewModel) {
        if (forgetPasswordViewModel.f947w.length() > 0) {
            if (forgetPasswordViewModel.f948x.length() > 0) {
                if (forgetPasswordViewModel.f949y.length() > 0) {
                    if (forgetPasswordViewModel.f950z.length() > 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x004e, code lost:
        if (new kotlin.text.Regex("[-+]?\\d+(\\.\\d+)?").matches(r10) != false) goto L_0x0052;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x009b, code lost:
        if ((6 <= r10 && r10 < 17) != false) goto L_0x00a8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x00a6, code lost:
        if (r10 < 17) goto L_0x00a8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00d7, code lost:
        if ((6 <= r10 && r10 < 17) != false) goto L_0x00e6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x00e2, code lost:
        if (r10 < 17) goto L_0x00e6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x0126, code lost:
        if ((6 <= r0 && r0 < 17) != false) goto L_0x0135;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x0131, code lost:
        if (r0 < 17) goto L_0x0135;
     */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00b5  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00b7  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00ba  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00da  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void e(i.h r10) {
        /*
            r9 = this;
            boolean r0 = r10 instanceof i.h.b
            java.lang.String r1 = "input"
            if (r0 == 0) goto L_0x0027
            i.h$b r10 = (i.h.b) r10
            java.lang.String r10 = r10.f11772a
            r9.f947w = r10
            rg.d0.g(r10, r1)
            java.util.regex.Pattern r0 = android.util.Patterns.EMAIL_ADDRESS
            java.util.regex.Matcher r10 = r0.matcher(r10)
            boolean r10 = r10.matches()
            r9.C = r10
            androidx.lifecycle.MutableLiveData<i.n> r10 = r9.f943s
            ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$1 r0 = new ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$1
            r0.<init>(r9)
            ai.plaud.android.plaud.util.MVIExtKt.d(r10, r0)
            goto L_0x0174
        L_0x0027:
            boolean r0 = r10 instanceof i.h.d
            r2 = 1
            r3 = 0
            if (r0 == 0) goto L_0x0060
            i.h$d r10 = (i.h.d) r10
            java.lang.String r0 = r10.f11774a
            r9.f948x = r0
            int r0 = i.j.a(r0, r1, r0)
            if (r0 != 0) goto L_0x003b
            r0 = r2
            goto L_0x003c
        L_0x003b:
            r0 = r3
        L_0x003c:
            if (r0 != 0) goto L_0x0051
            java.lang.String r10 = r10.f11774a
            rg.d0.g(r10, r1)
            kotlin.text.Regex r0 = new kotlin.text.Regex
            java.lang.String r1 = "[-+]?\\d+(\\.\\d+)?"
            r0.<init>((java.lang.String) r1)
            boolean r10 = r0.matches(r10)
            if (r10 == 0) goto L_0x0051
            goto L_0x0052
        L_0x0051:
            r2 = r3
        L_0x0052:
            r9.D = r2
            androidx.lifecycle.MutableLiveData<i.n> r10 = r9.f943s
            ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$2 r0 = new ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$2
            r0.<init>(r9)
            ai.plaud.android.plaud.util.MVIExtKt.d(r10, r0)
            goto L_0x0174
        L_0x0060:
            boolean r0 = r10 instanceof i.h.c
            java.lang.String r4 = "confirmNewPassword"
            java.lang.String r5 = "newPassword"
            r6 = 17
            r7 = 6
            if (r0 == 0) goto L_0x00f4
            i.h$c r10 = (i.h.c) r10
            java.lang.String r0 = r10.f11773a
            r9.f949y = r0
            java.lang.String r0 = r9.f950z
            int r0 = r0.length()
            if (r0 <= 0) goto L_0x007b
            r0 = r2
            goto L_0x007c
        L_0x007b:
            r0 = r3
        L_0x007c:
            if (r0 == 0) goto L_0x009e
            java.lang.String r0 = r9.f949y
            java.lang.String r8 = r9.f950z
            rg.d0.g(r0, r5)
            rg.d0.g(r8, r4)
            boolean r0 = rg.d0.b(r0, r8)
            if (r0 == 0) goto L_0x00aa
            java.lang.String r10 = r10.f11773a
            int r10 = i.j.a(r10, r1, r10)
            if (r7 > r10) goto L_0x009a
            if (r10 >= r6) goto L_0x009a
            r10 = r2
            goto L_0x009b
        L_0x009a:
            r10 = r3
        L_0x009b:
            if (r10 == 0) goto L_0x00aa
            goto L_0x00a8
        L_0x009e:
            java.lang.String r10 = r10.f11773a
            int r10 = i.j.a(r10, r1, r10)
            if (r7 > r10) goto L_0x00aa
            if (r10 >= r6) goto L_0x00aa
        L_0x00a8:
            r10 = r2
            goto L_0x00ab
        L_0x00aa:
            r10 = r3
        L_0x00ab:
            r9.E = r10
            java.lang.String r10 = r9.f949y
            int r10 = r10.length()
            if (r10 <= 0) goto L_0x00b7
            r10 = r2
            goto L_0x00b8
        L_0x00b7:
            r10 = r3
        L_0x00b8:
            if (r10 == 0) goto L_0x00da
            java.lang.String r10 = r9.f949y
            java.lang.String r0 = r9.f950z
            rg.d0.g(r10, r5)
            rg.d0.g(r0, r4)
            boolean r10 = rg.d0.b(r10, r0)
            if (r10 == 0) goto L_0x00e5
            java.lang.String r10 = r9.f950z
            int r10 = i.j.a(r10, r1, r10)
            if (r7 > r10) goto L_0x00d6
            if (r10 >= r6) goto L_0x00d6
            r10 = r2
            goto L_0x00d7
        L_0x00d6:
            r10 = r3
        L_0x00d7:
            if (r10 == 0) goto L_0x00e5
            goto L_0x00e6
        L_0x00da:
            java.lang.String r10 = r9.f950z
            int r10 = i.j.a(r10, r1, r10)
            if (r7 > r10) goto L_0x00e5
            if (r10 >= r6) goto L_0x00e5
            goto L_0x00e6
        L_0x00e5:
            r2 = r3
        L_0x00e6:
            r9.F = r2
            androidx.lifecycle.MutableLiveData<i.n> r10 = r9.f943s
            ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$3 r0 = new ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$3
            r0.<init>(r9)
            ai.plaud.android.plaud.util.MVIExtKt.d(r10, r0)
            goto L_0x0174
        L_0x00f4:
            boolean r0 = r10 instanceof i.h.a
            if (r0 == 0) goto L_0x0152
            i.h$a r10 = (i.h.a) r10
            java.lang.String r0 = r10.f11771a
            r9.f950z = r0
            int r0 = r0.length()
            if (r0 <= 0) goto L_0x0106
            r0 = r2
            goto L_0x0107
        L_0x0106:
            r0 = r3
        L_0x0107:
            if (r0 == 0) goto L_0x0129
            java.lang.String r0 = r9.f949y
            java.lang.String r8 = r9.f950z
            rg.d0.g(r0, r5)
            rg.d0.g(r8, r4)
            boolean r0 = rg.d0.b(r0, r8)
            if (r0 == 0) goto L_0x0134
            java.lang.String r0 = r9.f949y
            int r0 = i.j.a(r0, r1, r0)
            if (r7 > r0) goto L_0x0125
            if (r0 >= r6) goto L_0x0125
            r0 = r2
            goto L_0x0126
        L_0x0125:
            r0 = r3
        L_0x0126:
            if (r0 == 0) goto L_0x0134
            goto L_0x0135
        L_0x0129:
            java.lang.String r0 = r9.f949y
            int r0 = i.j.a(r0, r1, r0)
            if (r7 > r0) goto L_0x0134
            if (r0 >= r6) goto L_0x0134
            goto L_0x0135
        L_0x0134:
            r2 = r3
        L_0x0135:
            r9.E = r2
            java.lang.String r0 = r9.f949y
            java.lang.String r10 = r10.f11771a
            rg.d0.g(r0, r5)
            rg.d0.g(r10, r4)
            boolean r10 = rg.d0.b(r0, r10)
            r9.F = r10
            androidx.lifecycle.MutableLiveData<i.n> r10 = r9.f943s
            ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$4 r0 = new ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$4
            r0.<init>(r9)
            ai.plaud.android.plaud.util.MVIExtKt.d(r10, r0)
            goto L_0x0174
        L_0x0152:
            i.h$f r0 = i.h.f.f11776a
            boolean r0 = rg.d0.b(r10, r0)
            r1 = 0
            if (r0 == 0) goto L_0x0164
            ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$5 r10 = new ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$5
            r10.<init>(r9, r1)
            r9.c(r10)
            goto L_0x0174
        L_0x0164:
            i.h$e r0 = i.h.e.f11775a
            boolean r10 = rg.d0.b(r10, r0)
            if (r10 == 0) goto L_0x0174
            ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$6 r10 = new ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$6
            r10.<init>(r9, r1)
            r9.c(r10)
        L_0x0174:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel.e(i.h):void");
    }
}
