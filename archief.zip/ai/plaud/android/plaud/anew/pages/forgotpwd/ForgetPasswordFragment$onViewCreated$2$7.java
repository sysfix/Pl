package ai.plaud.android.plaud.anew.pages.forgotpwd;

import i.n;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: ForgetPasswordFragment.kt */
public /* synthetic */ class ForgetPasswordFragment$onViewCreated$2$7 extends PropertyReference1Impl {
    public static final ForgetPasswordFragment$onViewCreated$2$7 INSTANCE = new ForgetPasswordFragment$onViewCreated$2$7();

    public ForgetPasswordFragment$onViewCreated$2$7() {
        super(n.class, "isPasswordValid", "isPasswordValid()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((n) obj).f11781d);
    }
}
