package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.flutter.device.f;
import ci.a;
import gg.l;
import i.m;
import java.util.Objects;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$onViewCreated$2$16 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$onViewCreated$2$16(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        a.f4931a.a(f.a("忘记密码 ", z10), new Object[0]);
        if (z10) {
            ForgetPasswordFragment forgetPasswordFragment = this.this$0;
            int i10 = ForgetPasswordFragment.H;
            Objects.requireNonNull(forgetPasswordFragment);
            m.f(forgetPasswordFragment).k(new h2.a(R.id.action_forgetPasswordFragment_to_forgetPasswordSuccessFragment));
        }
    }
}
