package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.anew.flutter.device.f;
import ci.a;
import gg.l;
import java.util.Objects;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import u.c;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$onViewCreated$2$12 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$onViewCreated$2$12(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        ForgetPasswordFragment forgetPasswordFragment = this.this$0;
        int i10 = ForgetPasswordFragment.H;
        Objects.requireNonNull(forgetPasswordFragment);
        a.f4931a.a(f.a("注册按钮是否可点击 ", z10), new Object[0]);
        if (z10) {
            VB vb2 = forgetPasswordFragment.f14772x;
            d0.d(vb2);
            ((c) vb2).f17135c.j();
            return;
        }
        VB vb3 = forgetPasswordFragment.f14772x;
        d0.d(vb3);
        ((c) vb3).f17135c.i();
    }
}
