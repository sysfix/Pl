package ai.plaud.android.plaud.anew.pages.forgotpwd;

import gg.l;
import kotlin.jvm.internal.Lambda;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$onViewCreated$2$6 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$onViewCreated$2$6(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        ForgetPasswordFragment.h(this.this$0);
    }
}
