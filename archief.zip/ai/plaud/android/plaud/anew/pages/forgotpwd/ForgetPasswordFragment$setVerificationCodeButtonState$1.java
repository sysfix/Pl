package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ci.a;
import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import u.c;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$setVerificationCodeButtonState$1 extends Lambda implements l<Long, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$setVerificationCodeButtonState$1(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Number) obj).longValue());
        return g.f19030a;
    }

    public final void invoke(long j10) {
        a.f4931a.d(ai.plaud.android.plaud.anew.flutter.audio.g.a("s ", j10), new Object[0]);
        VB vb2 = this.this$0.f14772x;
        d0.d(vb2);
        ((c) vb2).f17137e.c((int) j10);
    }
}
