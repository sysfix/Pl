package ai.plaud.android.plaud.anew.pages.forgotpwd;

import gg.a;
import kotlin.jvm.internal.Lambda;
import x.h;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$rxTimer$2 extends Lambda implements a<h> {
    public static final ForgetPasswordFragment$rxTimer$2 INSTANCE = new ForgetPasswordFragment$rxTimer$2();

    public ForgetPasswordFragment$rxTimer$2() {
        super(0);
    }

    public final h invoke() {
        return new h();
    }
}
