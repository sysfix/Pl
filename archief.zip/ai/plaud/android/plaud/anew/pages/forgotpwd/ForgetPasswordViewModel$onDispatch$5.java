package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.bean.AuthBean;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository$sendCode$2;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.util.MVIExtKt;
import b.b;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import i.i;
import i.n;
import java.util.Objects;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import rg.d0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$5", f = "ForgetPasswordViewModel.kt", l = {147}, m = "invokeSuspend")
/* compiled from: ForgetPasswordViewModel.kt */
public final class ForgetPasswordViewModel$onDispatch$5 extends SuspendLambda implements l<c<? super g>, Object> {
    public int label;
    public final /* synthetic */ ForgetPasswordViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordViewModel$onDispatch$5(ForgetPasswordViewModel forgetPasswordViewModel, c<? super ForgetPasswordViewModel$onDispatch$5> cVar) {
        super(1, cVar);
        this.this$0 = forgetPasswordViewModel;
    }

    public final c<g> create(c<?> cVar) {
        return new ForgetPasswordViewModel$onDispatch$5(this.this$0, cVar);
    }

    public final Object invoke(c<? super g> cVar) {
        return ((ForgetPasswordViewModel$onDispatch$5) create(cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            ForgetPasswordViewModel forgetPasswordViewModel = this.this$0;
            if (!forgetPasswordViewModel.C) {
                x.l<i> lVar = forgetPasswordViewModel.f945u;
                String string = AppProvider.a().getString(R.string.register_PleaseEnterCorrectEmail);
                d0.f(string, "get()\n                  …_PleaseEnterCorrectEmail)");
                MVIExtKt.c(lVar, new i.a(string));
                return g.f19030a;
            }
            MVIExtKt.d(forgetPasswordViewModel.f943s, AnonymousClass1.INSTANCE);
            ForgetPasswordViewModel forgetPasswordViewModel2 = this.this$0;
            forgetPasswordViewModel2.B = false;
            AuthRepository authRepository = forgetPasswordViewModel2.f942r;
            String str = forgetPasswordViewModel2.f947w;
            this.label = 1;
            Objects.requireNonNull(authRepository);
            obj = authRepository.a(new AuthRepository$sendCode$2(authRepository, str, "reset", (c<? super AuthRepository$sendCode$2>) null), this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        final ApiResponse apiResponse = (ApiResponse) obj;
        ci.a.f4931a.a(b.a("sendCode:[", apiResponse.getMsg(), "]"), new Object[0]);
        if (!apiResponse.isSuccess()) {
            Integer status = apiResponse.getStatus();
            if (status != null && status.intValue() == -2) {
                x.l<i> lVar2 = this.this$0.f945u;
                String string2 = AppProvider.a().getResources().getString(R.string.register_PleaseEnterCorrectEmail);
                d0.f(string2, "get().resources.getStrin…_PleaseEnterCorrectEmail)");
                MVIExtKt.c(lVar2, new i.a(string2));
            } else {
                x.l<i> lVar3 = this.this$0.f945u;
                String msg = apiResponse.getMsg();
                if (msg == null) {
                    msg = "Network Error";
                }
                MVIExtKt.c(lVar3, new i.a(msg));
            }
        } else if (apiResponse instanceof AuthBean.SendCodeRsp) {
            ForgetPasswordViewModel forgetPasswordViewModel3 = this.this$0;
            forgetPasswordViewModel3.B = true;
            forgetPasswordViewModel3.A = ((AuthBean.SendCodeRsp) apiResponse).getToken();
        }
        MVIExtKt.d(this.this$0.f943s, new l<n, n>() {
            public final n invoke(n nVar) {
                d0.g(nVar, "$this$postState");
                return n.a(nVar, false, false, false, false, false, apiResponse.isSuccess(), false, false, 222);
            }
        });
        return g.f19030a;
    }
}
