package ai.plaud.android.plaud.anew.pages.forgotpwd;

import androidx.fragment.app.g0;
import androidx.lifecycle.ViewModelStore;
import gg.a;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import xf.d;

/* compiled from: FragmentViewModelLazy.kt */
public final class ForgetPasswordFragment$special$$inlined$viewModels$default$3 extends Lambda implements a<ViewModelStore> {
    public final /* synthetic */ d $owner$delegate;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$special$$inlined$viewModels$default$3(d dVar) {
        super(0);
        this.$owner$delegate = dVar;
    }

    public final ViewModelStore invoke() {
        ViewModelStore viewModelStore = g0.a(this.$owner$delegate).getViewModelStore();
        d0.f(viewModelStore, "owner.viewModelStore");
        return viewModelStore;
    }
}
