package ai.plaud.android.plaud.anew.pages.forgotpwd;

import i.n;
import kotlin.jvm.internal.PropertyReference1Impl;

/* compiled from: ForgetPasswordFragment.kt */
public /* synthetic */ class ForgetPasswordFragment$onViewCreated$2$5 extends PropertyReference1Impl {
    public static final ForgetPasswordFragment$onViewCreated$2$5 INSTANCE = new ForgetPasswordFragment$onViewCreated$2$5();

    public ForgetPasswordFragment$onViewCreated$2$5() {
        super(n.class, "isVerificationCode", "isVerificationCode()Z", 0);
    }

    public Object get(Object obj) {
        return Boolean.valueOf(((n) obj).f11780c);
    }
}
