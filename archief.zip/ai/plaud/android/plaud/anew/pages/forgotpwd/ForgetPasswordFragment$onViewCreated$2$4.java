package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.anew.flutter.device.f;
import ci.a;
import gg.l;
import kotlin.jvm.internal.Lambda;
import rg.d0;
import u.c;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$onViewCreated$2$4 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$onViewCreated$2$4(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        a.f4931a.a(f.a("邮箱是否正确 ", z10), new Object[0]);
        ForgetPasswordFragment forgetPasswordFragment = this.this$0;
        int i10 = ForgetPasswordFragment.H;
        forgetPasswordFragment.k(z10, false);
        if (z10) {
            ForgetPasswordFragment.h(this.this$0);
            return;
        }
        VB vb2 = this.this$0.f14772x;
        d0.d(vb2);
        ((c) vb2).f17136d.setVisibility(0);
    }
}
