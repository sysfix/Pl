package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ag.c;
import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.anew.api.ApiResponse;
import ai.plaud.android.plaud.anew.api.repository.AuthRepository;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.util.MVIExtKt;
import b.b;
import ci.a;
import com.google.android.gms.internal.play_billing.x2;
import gg.l;
import i.i;
import i.j;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.coroutines.jvm.internal.a;
import okhttp3.HttpUrl;
import rg.d0;
import xf.g;

@a(c = "ai.plaud.android.plaud.anew.pages.forgotpwd.ForgetPasswordViewModel$onDispatch$6", f = "ForgetPasswordViewModel.kt", l = {209}, m = "invokeSuspend")
/* compiled from: ForgetPasswordViewModel.kt */
public final class ForgetPasswordViewModel$onDispatch$6 extends SuspendLambda implements l<c<? super g>, Object> {
    public int label;
    public final /* synthetic */ ForgetPasswordViewModel this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordViewModel$onDispatch$6(ForgetPasswordViewModel forgetPasswordViewModel, c<? super ForgetPasswordViewModel$onDispatch$6> cVar) {
        super(1, cVar);
        this.this$0 = forgetPasswordViewModel;
    }

    public final c<g> create(c<?> cVar) {
        return new ForgetPasswordViewModel$onDispatch$6(this.this$0, cVar);
    }

    public final Object invoke(c<? super g> cVar) {
        return ((ForgetPasswordViewModel$onDispatch$6) create(cVar)).invokeSuspend(g.f19030a);
    }

    public final Object invokeSuspend(Object obj) {
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        int i10 = this.label;
        if (i10 == 0) {
            x2.s(obj);
            ForgetPasswordViewModel forgetPasswordViewModel = this.this$0;
            if (!forgetPasswordViewModel.C) {
                x.l<i> lVar = forgetPasswordViewModel.f945u;
                String string = AppProvider.a().getString(R.string.register_PleaseEnterCorrectEmail);
                d0.f(string, "get()\n                  …_PleaseEnterCorrectEmail)");
                MVIExtKt.c(lVar, new i.a(string));
                return g.f19030a;
            }
            String str = forgetPasswordViewModel.f949y;
            int a10 = j.a(str, "input", str);
            if (!(6 <= a10 && a10 < 17)) {
                x.l<i> lVar2 = this.this$0.f945u;
                String string2 = AppProvider.a().getString(R.string.register_PasswordLengthErrorReminder);
                d0.f(string2, "get()\n                  …swordLengthErrorReminder)");
                MVIExtKt.c(lVar2, new i.a(string2));
                return g.f19030a;
            }
            String str2 = this.this$0.f950z;
            int a11 = j.a(str2, "input", str2);
            if (!(6 <= a11 && a11 < 17)) {
                x.l<i> lVar3 = this.this$0.f945u;
                String string3 = AppProvider.a().getString(R.string.register_PasswordLengthErrorReminder);
                d0.f(string3, "get()\n                  …swordLengthErrorReminder)");
                MVIExtKt.c(lVar3, new i.a(string3));
                return g.f19030a;
            }
            MVIExtKt.d(this.this$0.f943s, AnonymousClass1.INSTANCE);
            ForgetPasswordViewModel forgetPasswordViewModel2 = this.this$0;
            AuthRepository authRepository = forgetPasswordViewModel2.f942r;
            long parseLong = Long.parseLong(forgetPasswordViewModel2.f948x);
            ForgetPasswordViewModel forgetPasswordViewModel3 = this.this$0;
            String str3 = forgetPasswordViewModel3.A;
            String str4 = forgetPasswordViewModel3.f949y;
            this.label = 1;
            obj = authRepository.b(parseLong, str3, str4, this);
            if (obj == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else if (i10 == 1) {
            x2.s(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ApiResponse apiResponse = (ApiResponse) obj;
        a.C0057a aVar = ci.a.f4931a;
        aVar.a("forgetPassword " + apiResponse, new Object[0]);
        aVar.a(b.a("verifyCode:[", apiResponse.getMsg(), "]"), new Object[0]);
        if (apiResponse.isSuccess()) {
            MVIExtKt.d(this.this$0.f943s, AnonymousClass2.INSTANCE);
        } else {
            MVIExtKt.d(this.this$0.f943s, AnonymousClass3.INSTANCE);
            Integer status = apiResponse.getStatus();
            if (status != null && status.intValue() == -2) {
                x.l<i> lVar4 = this.this$0.f945u;
                String string4 = AppProvider.a().getResources().getString(R.string.register_TheVerificationCodeIsWrongOrInvalid);
                d0.f(string4, "get().resources.getStrin…tionCodeIsWrongOrInvalid)");
                MVIExtKt.c(lVar4, new i.a(string4));
            } else {
                x.l<i> lVar5 = this.this$0.f945u;
                String msg = apiResponse.getMsg();
                if (msg == null) {
                    msg = HttpUrl.FRAGMENT_ENCODE_SET;
                }
                MVIExtKt.c(lVar5, new i.a(msg));
            }
        }
        return g.f19030a;
    }
}
