package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.R;
import android.text.Editable;
import gg.l;
import kotlin.jvm.internal.Lambda;
import pg.j;
import rg.d0;
import u.c;
import xf.g;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment$onViewCreated$2$10 extends Lambda implements l<Boolean, g> {
    public final /* synthetic */ ForgetPasswordFragment this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ForgetPasswordFragment$onViewCreated$2$10(ForgetPasswordFragment forgetPasswordFragment) {
        super(1);
        this.this$0 = forgetPasswordFragment;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Boolean) obj).booleanValue());
        return g.f19030a;
    }

    public final void invoke(boolean z10) {
        if (!z10) {
            VB vb2 = this.this$0.f14772x;
            d0.d(vb2);
            Editable text = ((c) vb2).f17138f.getText();
            d0.d(text);
            if (text.length() > 0) {
                VB vb3 = this.this$0.f14772x;
                d0.d(vb3);
                Editable text2 = ((c) vb3).f17140h.getText();
                d0.d(text2);
                String obj = text2.toString();
                VB vb4 = this.this$0.f14772x;
                d0.d(vb4);
                Editable text3 = ((c) vb4).f17138f.getText();
                d0.d(text3);
                String obj2 = text3.toString();
                d0.g(obj, "newPassword");
                d0.g(obj2, "confirmNewPassword");
                if (!j.w(obj, obj2, false, 2)) {
                    ForgetPasswordFragment forgetPasswordFragment = this.this$0;
                    String string = forgetPasswordFragment.getString(R.string.register_TwoTimesThePasswordInputDoesNotMatchPleaseCheck);
                    d0.f(string, "getString(R.string.regis…tDoesNotMatchPleaseCheck)");
                    int i10 = ForgetPasswordFragment.H;
                    forgetPasswordFragment.j(string);
                    return;
                }
            }
        }
        ForgetPasswordFragment forgetPasswordFragment2 = this.this$0;
        int i11 = ForgetPasswordFragment.H;
        if (forgetPasswordFragment2.i().B) {
            ForgetPasswordFragment.h(this.this$0);
        }
    }
}
