package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.R;
import android.os.Bundle;
import android.view.View;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.g;
import com.google.android.material.button.MaterialButton;
import i.m;
import i.p;
import java.util.Objects;
import rg.d0;
import u.d;

/* compiled from: ForgetPasswordSuccessFragment.kt */
public final class ForgetPasswordSuccessFragment extends p<d> {
    public static final /* synthetic */ int F = 0;

    /* compiled from: ForgetPasswordSuccessFragment.kt */
    public static final class a extends g {

        /* renamed from: d  reason: collision with root package name */
        public final /* synthetic */ ForgetPasswordSuccessFragment f941d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(ForgetPasswordSuccessFragment forgetPasswordSuccessFragment) {
            super(true);
            this.f941d = forgetPasswordSuccessFragment;
        }

        public void a() {
            ForgetPasswordSuccessFragment forgetPasswordSuccessFragment = this.f941d;
            int i10 = ForgetPasswordSuccessFragment.F;
            forgetPasswordSuccessFragment.h();
        }
    }

    public ForgetPasswordSuccessFragment() {
        super(AnonymousClass1.INSTANCE);
    }

    public final void h() {
        m.f(this).m(R.id.loginFragment, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        d0.g(view, "view");
        super.onViewCreated(view, bundle);
        VB vb2 = this.f14772x;
        d0.d(vb2);
        d dVar = (d) vb2;
        dVar.f17145b.setOnClickListener(new i.a(this));
        MaterialButton materialButton = dVar.f17146c;
        d0.f(materialButton, "goLoginBtn");
        d0.h(materialButton, "$this$clicks");
        p.a.a(new sb.a(materialButton).b(c()).c(new i.d(this)), this.f994q);
        OnBackPressedDispatcher onBackPressedDispatcher = requireActivity().getOnBackPressedDispatcher();
        a aVar = new a(this);
        Objects.requireNonNull(onBackPressedDispatcher);
        d0.g(aVar, "onBackPressedCallback");
        onBackPressedDispatcher.b(aVar);
    }
}
