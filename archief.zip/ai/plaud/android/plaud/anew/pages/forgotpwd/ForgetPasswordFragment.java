package ai.plaud.android.plaud.anew.pages.forgotpwd;

import ai.plaud.android.plaud.R;
import ai.plaud.android.plaud.common.util.AppProvider;
import ai.plaud.android.plaud.component.CtaButton;
import ai.plaud.android.plaud.component.VerificationCodeImageButton;
import ai.plaud.android.plaud.util.MVIExtKt;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.g0;
import androidx.lifecycle.LiveData;
import i.h;
import i.n;
import i.o;
import kotlin.LazyThreadSafetyMode;
import okhttp3.HttpUrl;
import pg.k;
import rg.d0;
import xf.e;

/* compiled from: ForgetPasswordFragment.kt */
public final class ForgetPasswordFragment extends o<u.c> {
    public static final /* synthetic */ int H = 0;
    public final xf.d F;
    public final xf.d G = e.a(ForgetPasswordFragment$rxTimer$2.INSTANCE);

    /* compiled from: Extension.kt */
    public static final class a implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ ForgetPasswordFragment f937p;

        public a(ForgetPasswordFragment forgetPasswordFragment) {
            this.f937p = forgetPasswordFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            ForgetPasswordFragment forgetPasswordFragment = this.f937p;
            int i13 = ForgetPasswordFragment.H;
            forgetPasswordFragment.i().e(new h.b(obj));
        }
    }

    /* compiled from: Extension.kt */
    public static final class b implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ ForgetPasswordFragment f938p;

        public b(ForgetPasswordFragment forgetPasswordFragment) {
            this.f938p = forgetPasswordFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            ForgetPasswordFragment forgetPasswordFragment = this.f938p;
            int i13 = ForgetPasswordFragment.H;
            forgetPasswordFragment.i().e(new h.d(obj));
        }
    }

    /* compiled from: Extension.kt */
    public static final class c implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ ForgetPasswordFragment f939p;

        public c(ForgetPasswordFragment forgetPasswordFragment) {
            this.f939p = forgetPasswordFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            ForgetPasswordFragment forgetPasswordFragment = this.f939p;
            int i13 = ForgetPasswordFragment.H;
            forgetPasswordFragment.i().e(new h.c(obj));
        }
    }

    /* compiled from: Extension.kt */
    public static final class d implements TextWatcher {

        /* renamed from: p  reason: collision with root package name */
        public final /* synthetic */ ForgetPasswordFragment f940p;

        public d(ForgetPasswordFragment forgetPasswordFragment) {
            this.f940p = forgetPasswordFragment;
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        }

        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            String str;
            if (charSequence == null || (str = charSequence.toString()) == null) {
                str = HttpUrl.FRAGMENT_ENCODE_SET;
            }
            String obj = k.b0(str).toString();
            ForgetPasswordFragment forgetPasswordFragment = this.f940p;
            int i13 = ForgetPasswordFragment.H;
            forgetPasswordFragment.i().e(new h.a(obj));
        }
    }

    public ForgetPasswordFragment() {
        super(AnonymousClass1.INSTANCE);
        xf.d b10 = e.b(LazyThreadSafetyMode.NONE, new ForgetPasswordFragment$special$$inlined$viewModels$default$2(new ForgetPasswordFragment$special$$inlined$viewModels$default$1(this)));
        this.F = g0.b(this, hg.h.a(ForgetPasswordViewModel.class), new ForgetPasswordFragment$special$$inlined$viewModels$default$3(b10), new ForgetPasswordFragment$special$$inlined$viewModels$default$4((gg.a) null, b10), new ForgetPasswordFragment$special$$inlined$viewModels$default$5(this, b10));
    }

    public static final void h(ForgetPasswordFragment forgetPasswordFragment) {
        VB vb2 = forgetPasswordFragment.f14772x;
        d0.d(vb2);
        ((u.c) vb2).f17136d.setVisibility(8);
    }

    public final ForgetPasswordViewModel i() {
        return (ForgetPasswordViewModel) this.F.getValue();
    }

    public final void j(String str) {
        boolean z10 = false;
        ci.a.f4931a.a(a.d.a("errorMsg ", str), new Object[0]);
        VB vb2 = this.f14772x;
        d0.d(vb2);
        ((u.c) vb2).f17136d.setVisibility(0);
        VB vb3 = this.f14772x;
        d0.d(vb3);
        AppCompatTextView appCompatTextView = ((u.c) vb3).f17136d;
        if (str.length() == 0) {
            z10 = true;
        }
        if (z10) {
            str = AppProvider.a().getString(R.string.network_badNetwork);
            d0.f(str, "get().getString(R.string.network_badNetwork)");
        }
        appCompatTextView.setText(str);
    }

    public final void k(boolean z10, boolean z11) {
        if (z10) {
            VB vb2 = this.f14772x;
            d0.d(vb2);
            ((u.c) vb2).f17137e.b();
        } else {
            VB vb3 = this.f14772x;
            d0.d(vb3);
            ((u.c) vb3).f17137e.a();
        }
        if (z11) {
            ((x.h) this.G.getValue()).b(60, true, new ForgetPasswordFragment$setVerificationCodeButtonState$1(this), new ForgetPasswordFragment$setVerificationCodeButtonState$2(this));
        }
    }

    public void onDestroy() {
        super.onDestroy();
        ((x.h) this.G.getValue()).a();
    }

    public void onViewCreated(View view, Bundle bundle) {
        d0.g(view, "view");
        super.onViewCreated(view, bundle);
        VB vb2 = this.f14772x;
        d0.d(vb2);
        u.c cVar = (u.c) vb2;
        cVar.f17134b.setOnClickListener(new i.a(this));
        AppCompatEditText appCompatEditText = cVar.f17139g;
        d0.f(appCompatEditText, "inputEmail");
        appCompatEditText.addTextChangedListener(new a(this));
        VerificationCodeImageButton verificationCodeImageButton = cVar.f17137e;
        d0.f(verificationCodeImageButton, "getCodeBtn");
        p.a.a(new sb.a(verificationCodeImageButton).b(c()).c(new ai.plaud.android.plaud.anew.flutter.audio.b(cVar, this)), this.f994q);
        AppCompatEditText appCompatEditText2 = cVar.f17141i;
        d0.f(appCompatEditText2, "inputVerificationCode");
        appCompatEditText2.addTextChangedListener(new b(this));
        AppCompatEditText appCompatEditText3 = cVar.f17140h;
        d0.f(appCompatEditText3, "inputPwd");
        appCompatEditText3.addTextChangedListener(new c(this));
        AppCompatEditText appCompatEditText4 = cVar.f17138f;
        d0.f(appCompatEditText4, "inputConfirmPassword");
        appCompatEditText4.addTextChangedListener(new d(this));
        CtaButton ctaButton = cVar.f17135c;
        d0.f(ctaButton, "confirmBtn");
        p.a.a(new sb.a(ctaButton).b(c()).c(new i.d(this)), this.f994q);
        cVar.f17143k.setOnClickListener(new i.b(cVar, this, 0));
        cVar.f17142j.setOnClickListener(new i.b(cVar, this, 1));
        LiveData<n> liveData = i().f944t;
        MVIExtKt.a(liveData, this, ForgetPasswordFragment$onViewCreated$2$1.INSTANCE, new ForgetPasswordFragment$onViewCreated$2$2(this));
        MVIExtKt.a(liveData, this, ForgetPasswordFragment$onViewCreated$2$3.INSTANCE, new ForgetPasswordFragment$onViewCreated$2$4(this));
        MVIExtKt.a(liveData, this, ForgetPasswordFragment$onViewCreated$2$5.INSTANCE, new ForgetPasswordFragment$onViewCreated$2$6(this));
        MVIExtKt.a(liveData, this, ForgetPasswordFragment$onViewCreated$2$7.INSTANCE, new ForgetPasswordFragment$onViewCreated$2$8(this));
        MVIExtKt.b(liveData, this, ForgetPasswordFragment$onViewCreated$2$9.INSTANCE, new ForgetPasswordFragment$onViewCreated$2$10(this));
        MVIExtKt.a(liveData, this, ForgetPasswordFragment$onViewCreated$2$11.INSTANCE, new ForgetPasswordFragment$onViewCreated$2$12(this));
        MVIExtKt.a(liveData, this, ForgetPasswordFragment$onViewCreated$2$13.INSTANCE, new ForgetPasswordFragment$onViewCreated$2$14(this));
        MVIExtKt.a(liveData, this, ForgetPasswordFragment$onViewCreated$2$15.INSTANCE, new ForgetPasswordFragment$onViewCreated$2$16(this));
        i().f946v.observe(getViewLifecycleOwner(), new i.c(this));
    }
}
