package ai.plaud.android.plaud.anew.manager;

import a.d;
import ci.a;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;
import ma.v;
import rg.d0;

/* compiled from: PlaudMessagingService.kt */
public final class PlaudMessagingService extends FirebaseMessagingService {
    public void onMessageReceived(RemoteMessage remoteMessage) {
        d0.g(remoteMessage, "message");
        super.onMessageReceived(remoteMessage);
        a.C0057a aVar = a.f4931a;
        aVar.a(d.a("From: ", remoteMessage.f8982p.getString("from")), new Object[0]);
        Map<String, String> p12 = remoteMessage.p1();
        d0.f(p12, "message.data");
        if (!p12.isEmpty()) {
            Map<String, String> p13 = remoteMessage.p1();
            aVar.a("Message data payload: " + p13, new Object[0]);
        }
        if (remoteMessage.f8984r == null && v.l(remoteMessage.f8982p)) {
            remoteMessage.f8984r = new RemoteMessage.b(new v(remoteMessage.f8982p), (RemoteMessage.a) null);
        }
        RemoteMessage.b bVar = remoteMessage.f8984r;
        if (bVar != null) {
            aVar.a(d.a("Message Notification Body: ", bVar.f8985a), new Object[0]);
        }
    }
}
