package android.support.v4.os;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.support.v4.os.ResultReceiver;
import java.util.Objects;

/* compiled from: IResultReceiver */
public interface a extends IInterface {

    /* renamed from: a  reason: collision with root package name */
    public static final String f1156a = "android$support$v4$os$IResultReceiver".replace('$', '.');

    /* renamed from: android.support.v4.os.a$a  reason: collision with other inner class name */
    /* compiled from: IResultReceiver */
    public static abstract class C0016a extends Binder implements a {

        /* renamed from: c  reason: collision with root package name */
        public static final /* synthetic */ int f1157c = 0;

        /* renamed from: android.support.v4.os.a$a$a  reason: collision with other inner class name */
        /* compiled from: IResultReceiver */
        public static class C0017a implements a {

            /* renamed from: c  reason: collision with root package name */
            public IBinder f1158c;

            public C0017a(IBinder iBinder) {
                this.f1158c = iBinder;
            }

            public IBinder asBinder() {
                return this.f1158c;
            }
        }

        public C0016a() {
            attachInterface(this, a.f1156a);
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i10, Parcel parcel, Parcel parcel2, int i11) {
            String str = a.f1156a;
            if (i10 >= 1 && i10 <= 16777215) {
                parcel.enforceInterface(str);
            }
            if (i10 == 1598968902) {
                parcel2.writeString(str);
                return true;
            } else if (i10 != 1) {
                return super.onTransact(i10, parcel, parcel2, i11);
            } else {
                int readInt = parcel.readInt();
                Object createFromParcel = parcel.readInt() != 0 ? Bundle.CREATOR.createFromParcel(parcel) : null;
                ResultReceiver.b bVar = (ResultReceiver.b) this;
                Objects.requireNonNull(ResultReceiver.this);
                ResultReceiver.this.a(readInt, (Bundle) createFromParcel);
                return true;
            }
        }
    }
}
