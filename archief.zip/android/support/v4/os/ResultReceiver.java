package android.support.v4.os;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.os.a;

@SuppressLint({"BanParcelableUsage"})
public class ResultReceiver implements Parcelable {
    public static final Parcelable.Creator<ResultReceiver> CREATOR = new a();

    /* renamed from: p  reason: collision with root package name */
    public a f1154p;

    public class a implements Parcelable.Creator<ResultReceiver> {
        public Object createFromParcel(Parcel parcel) {
            return new ResultReceiver(parcel);
        }

        public Object[] newArray(int i10) {
            return new ResultReceiver[i10];
        }
    }

    public class b extends a.C0016a {
        public b() {
        }
    }

    public ResultReceiver(Parcel parcel) {
        a aVar;
        IBinder readStrongBinder = parcel.readStrongBinder();
        int i10 = a.C0016a.f1157c;
        if (readStrongBinder == null) {
            aVar = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface(a.f1156a);
            if (queryLocalInterface == null || !(queryLocalInterface instanceof a)) {
                aVar = new a.C0016a.C0017a(readStrongBinder);
            } else {
                aVar = (a) queryLocalInterface;
            }
        }
        this.f1154p = aVar;
    }

    public void a(int i10, Bundle bundle) {
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        synchronized (this) {
            if (this.f1154p == null) {
                this.f1154p = new b();
            }
            parcel.writeStrongBinder(this.f1154p.asBinder());
        }
    }
}
