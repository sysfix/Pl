package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;

public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new a();

    /* renamed from: p  reason: collision with root package name */
    public final int f1127p;

    /* renamed from: q  reason: collision with root package name */
    public final float f1128q;

    public static class a implements Parcelable.Creator<RatingCompat> {
        public Object createFromParcel(Parcel parcel) {
            return new RatingCompat(parcel.readInt(), parcel.readFloat());
        }

        public Object[] newArray(int i10) {
            return new RatingCompat[i10];
        }
    }

    public RatingCompat(int i10, float f10) {
        this.f1127p = i10;
        this.f1128q = f10;
    }

    public int describeContents() {
        return this.f1127p;
    }

    public String toString() {
        String str;
        StringBuilder a10 = f.a.a("Rating:style=");
        a10.append(this.f1127p);
        a10.append(" rating=");
        float f10 = this.f1128q;
        if (f10 < 0.0f) {
            str = "unrated";
        } else {
            str = String.valueOf(f10);
        }
        a10.append(str);
        return a10.toString();
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f1127p);
        parcel.writeFloat(this.f1128q);
    }
}
