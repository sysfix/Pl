package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();

    /* renamed from: p  reason: collision with root package name */
    public final int f1139p;

    /* renamed from: q  reason: collision with root package name */
    public final long f1140q;

    /* renamed from: r  reason: collision with root package name */
    public final long f1141r;

    /* renamed from: s  reason: collision with root package name */
    public final float f1142s;

    /* renamed from: t  reason: collision with root package name */
    public final long f1143t;

    /* renamed from: u  reason: collision with root package name */
    public final int f1144u;

    /* renamed from: v  reason: collision with root package name */
    public final CharSequence f1145v;

    /* renamed from: w  reason: collision with root package name */
    public final long f1146w;

    /* renamed from: x  reason: collision with root package name */
    public List<CustomAction> f1147x;

    /* renamed from: y  reason: collision with root package name */
    public final long f1148y;

    /* renamed from: z  reason: collision with root package name */
    public final Bundle f1149z;

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new a();

        /* renamed from: p  reason: collision with root package name */
        public final String f1150p;

        /* renamed from: q  reason: collision with root package name */
        public final CharSequence f1151q;

        /* renamed from: r  reason: collision with root package name */
        public final int f1152r;

        /* renamed from: s  reason: collision with root package name */
        public final Bundle f1153s;

        public static class a implements Parcelable.Creator<CustomAction> {
            public Object createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            public Object[] newArray(int i10) {
                return new CustomAction[i10];
            }
        }

        public CustomAction(Parcel parcel) {
            this.f1150p = parcel.readString();
            this.f1151q = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f1152r = parcel.readInt();
            this.f1153s = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder a10 = f.a.a("Action:mName='");
            a10.append(this.f1151q);
            a10.append(", mIcon=");
            a10.append(this.f1152r);
            a10.append(", mExtras=");
            a10.append(this.f1153s);
            return a10.toString();
        }

        public void writeToParcel(Parcel parcel, int i10) {
            parcel.writeString(this.f1150p);
            TextUtils.writeToParcel(this.f1151q, parcel, i10);
            parcel.writeInt(this.f1152r);
            parcel.writeBundle(this.f1153s);
        }
    }

    public static class a implements Parcelable.Creator<PlaybackStateCompat> {
        public Object createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        public Object[] newArray(int i10) {
            return new PlaybackStateCompat[i10];
        }
    }

    public PlaybackStateCompat(Parcel parcel) {
        this.f1139p = parcel.readInt();
        this.f1140q = parcel.readLong();
        this.f1142s = parcel.readFloat();
        this.f1146w = parcel.readLong();
        this.f1141r = parcel.readLong();
        this.f1143t = parcel.readLong();
        this.f1145v = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f1147x = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f1148y = parcel.readLong();
        this.f1149z = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.f1144u = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "PlaybackState {" + "state=" + this.f1139p + ", position=" + this.f1140q + ", buffered position=" + this.f1141r + ", speed=" + this.f1142s + ", updated=" + this.f1146w + ", actions=" + this.f1143t + ", error code=" + this.f1144u + ", error message=" + this.f1145v + ", custom actions=" + this.f1147x + ", active item id=" + this.f1148y + "}";
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f1139p);
        parcel.writeLong(this.f1140q);
        parcel.writeFloat(this.f1142s);
        parcel.writeLong(this.f1146w);
        parcel.writeLong(this.f1141r);
        parcel.writeLong(this.f1143t);
        TextUtils.writeToParcel(this.f1145v, parcel, i10);
        parcel.writeTypedList(this.f1147x);
        parcel.writeLong(this.f1148y);
        parcel.writeBundle(this.f1149z);
        parcel.writeInt(this.f1144u);
    }
}
