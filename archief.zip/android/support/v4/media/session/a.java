package android.support.v4.media.session;

import android.os.IInterface;

/* compiled from: IMediaSession */
public interface a extends IInterface {
}
