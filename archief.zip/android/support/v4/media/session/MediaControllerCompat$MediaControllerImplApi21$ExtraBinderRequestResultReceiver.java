package android.support.v4.media.session;

import android.os.Bundle;
import android.os.ResultReceiver;

class MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver extends ResultReceiver {
    public void onReceiveResult(int i10, Bundle bundle) {
        throw null;
    }
}
