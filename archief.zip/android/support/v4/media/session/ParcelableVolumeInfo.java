package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new a();

    /* renamed from: p  reason: collision with root package name */
    public int f1134p;

    /* renamed from: q  reason: collision with root package name */
    public int f1135q;

    /* renamed from: r  reason: collision with root package name */
    public int f1136r;

    /* renamed from: s  reason: collision with root package name */
    public int f1137s;

    /* renamed from: t  reason: collision with root package name */
    public int f1138t;

    public static class a implements Parcelable.Creator<ParcelableVolumeInfo> {
        public Object createFromParcel(Parcel parcel) {
            return new ParcelableVolumeInfo(parcel);
        }

        public Object[] newArray(int i10) {
            return new ParcelableVolumeInfo[i10];
        }
    }

    public ParcelableVolumeInfo(Parcel parcel) {
        this.f1134p = parcel.readInt();
        this.f1136r = parcel.readInt();
        this.f1137s = parcel.readInt();
        this.f1138t = parcel.readInt();
        this.f1135q = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f1134p);
        parcel.writeInt(this.f1136r);
        parcel.writeInt(this.f1137s);
        parcel.writeInt(this.f1138t);
        parcel.writeInt(this.f1135q);
    }
}
