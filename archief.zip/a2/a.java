package a2;

/* compiled from: MetadataItem */
public final class a extends c {
}
