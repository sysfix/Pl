package a2;

import java.nio.ByteBuffer;

/* compiled from: Table */
public class c {

    /* renamed from: a  reason: collision with root package name */
    public int f771a;

    /* renamed from: b  reason: collision with root package name */
    public ByteBuffer f772b;

    /* renamed from: c  reason: collision with root package name */
    public int f773c;

    /* renamed from: d  reason: collision with root package name */
    public int f774d;

    public c() {
        if (d.f775a == null) {
            d.f775a = new d();
        }
    }

    public int a(int i10) {
        if (i10 < this.f774d) {
            return this.f772b.getShort(this.f773c + i10);
        }
        return 0;
    }

    public void b(int i10, ByteBuffer byteBuffer) {
        this.f772b = byteBuffer;
        if (byteBuffer != null) {
            this.f771a = i10;
            int i11 = i10 - byteBuffer.getInt(i10);
            this.f773c = i11;
            this.f774d = this.f772b.getShort(i11);
            return;
        }
        this.f771a = 0;
        this.f773c = 0;
        this.f774d = 0;
    }
}
