package a2;

/* compiled from: Utf8Safe */
public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static d f775a;
}
