package a2;

/* compiled from: MetadataList */
public final class b extends c {
    public int c() {
        int a10 = a(6);
        if (a10 == 0) {
            return 0;
        }
        int i10 = a10 + this.f771a;
        return this.f772b.getInt(this.f772b.getInt(i10) + i10);
    }
}
