package a1;

import android.app.Notification;
import android.os.Bundle;

/* compiled from: NotificationCompat */
public class q extends s {

    /* renamed from: b  reason: collision with root package name */
    public CharSequence f707b;

    /* compiled from: NotificationCompat */
    public static class a {
        public static Notification.BigTextStyle a(Notification.BigTextStyle bigTextStyle, CharSequence charSequence) {
            return bigTextStyle.bigText(charSequence);
        }

        public static Notification.BigTextStyle b(Notification.Builder builder) {
            return new Notification.BigTextStyle(builder);
        }

        public static Notification.BigTextStyle c(Notification.BigTextStyle bigTextStyle, CharSequence charSequence) {
            return bigTextStyle.setBigContentTitle(charSequence);
        }

        public static Notification.BigTextStyle d(Notification.BigTextStyle bigTextStyle, CharSequence charSequence) {
            return bigTextStyle.setSummaryText(charSequence);
        }
    }

    public void a(Bundle bundle) {
        bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", "androidx.core.app.NotificationCompat$BigTextStyle");
    }

    public void b(n nVar) {
        a.a(a.c(a.b(((t) nVar).f731b), (CharSequence) null), this.f707b);
    }

    public String c() {
        return "androidx.core.app.NotificationCompat$BigTextStyle";
    }
}
