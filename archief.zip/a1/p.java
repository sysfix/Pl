package a1;

import android.app.Notification;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import androidx.core.graphics.drawable.IconCompat;

/* compiled from: NotificationCompat */
public class p extends s {

    /* renamed from: b  reason: collision with root package name */
    public IconCompat f704b;

    /* renamed from: c  reason: collision with root package name */
    public IconCompat f705c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f706d;

    /* compiled from: NotificationCompat */
    public static class a {
        public static Notification.BigPictureStyle a(Notification.BigPictureStyle bigPictureStyle, Bitmap bitmap) {
            return bigPictureStyle.bigPicture(bitmap);
        }

        public static Notification.BigPictureStyle b(Notification.Builder builder) {
            return new Notification.BigPictureStyle(builder);
        }

        public static Notification.BigPictureStyle c(Notification.BigPictureStyle bigPictureStyle, CharSequence charSequence) {
            return bigPictureStyle.setBigContentTitle(charSequence);
        }

        public static void d(Notification.BigPictureStyle bigPictureStyle, Bitmap bitmap) {
            bigPictureStyle.bigLargeIcon(bitmap);
        }
    }

    /* compiled from: NotificationCompat */
    public static class b {
        public static void a(Notification.BigPictureStyle bigPictureStyle, Icon icon) {
            bigPictureStyle.bigLargeIcon(icon);
        }
    }

    /* compiled from: NotificationCompat */
    public static class c {
        public static void a(Notification.BigPictureStyle bigPictureStyle, Icon icon) {
            bigPictureStyle.bigPicture(icon);
        }

        public static void b(Notification.BigPictureStyle bigPictureStyle, CharSequence charSequence) {
            bigPictureStyle.setContentDescription(charSequence);
        }

        public static void c(Notification.BigPictureStyle bigPictureStyle, boolean z10) {
            bigPictureStyle.showBigPictureWhenCollapsed(z10);
        }
    }

    public void b(n nVar) {
        int i10 = Build.VERSION.SDK_INT;
        t tVar = (t) nVar;
        Notification.BigPictureStyle c10 = a.c(a.b(tVar.f731b), (CharSequence) null);
        IconCompat iconCompat = this.f704b;
        if (iconCompat != null) {
            if (i10 >= 31) {
                c.a(c10, IconCompat.a.f(iconCompat, tVar.f730a));
            } else if (iconCompat.e() == 1) {
                c10 = a.a(c10, this.f704b.c());
            }
        }
        if (this.f706d) {
            IconCompat iconCompat2 = this.f705c;
            if (iconCompat2 == null) {
                a.d(c10, (Bitmap) null);
            } else {
                b.a(c10, IconCompat.a.f(iconCompat2, tVar.f730a));
            }
        }
        if (i10 >= 31) {
            c.c(c10, false);
            c.b(c10, (CharSequence) null);
        }
    }

    public String c() {
        return "androidx.core.app.NotificationCompat$BigPictureStyle";
    }

    public p d(Bitmap bitmap) {
        this.f705c = null;
        this.f706d = true;
        return this;
    }

    public p e(Bitmap bitmap) {
        IconCompat iconCompat;
        if (bitmap == null) {
            iconCompat = null;
        } else {
            PorterDuff.Mode mode = IconCompat.f2617k;
            IconCompat iconCompat2 = new IconCompat(1);
            iconCompat2.f2619b = bitmap;
            iconCompat = iconCompat2;
        }
        this.f704b = iconCompat;
        return this;
    }
}
