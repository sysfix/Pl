package a1;

import android.content.res.Configuration;

/* compiled from: MultiWindowModeChangedInfo */
public final class l {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f691a;

    public l(boolean z10) {
        this.f691a = z10;
    }

    public l(boolean z10, Configuration configuration) {
        this.f691a = z10;
    }
}
