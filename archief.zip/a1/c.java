package a1;

import a1.f;

/* compiled from: ActivityRecreator */
public class c implements Runnable {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ f.a f662p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Object f663q;

    public c(f.a aVar, Object obj) {
        this.f662p = aVar;
        this.f663q = obj;
    }

    public void run() {
        this.f662p.f677p = this.f663q;
    }
}
