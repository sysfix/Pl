package a1;

/* compiled from: SharedElementCallback */
public abstract class b0 {
}
