package a1;

import android.content.res.Configuration;

/* compiled from: PictureInPictureModeChangedInfo */
public final class z {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f770a;

    public z(boolean z10) {
        this.f770a = z10;
    }

    public z(boolean z10, Configuration configuration) {
        this.f770a = z10;
    }
}
