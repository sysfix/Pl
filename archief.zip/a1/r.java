package a1;

import a1.t;
import ai.plaud.android.plaud.R;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Objects;

/* compiled from: NotificationCompat */
public class r {

    /* renamed from: a  reason: collision with root package name */
    public Context f708a;

    /* renamed from: b  reason: collision with root package name */
    public ArrayList<o> f709b = new ArrayList<>();

    /* renamed from: c  reason: collision with root package name */
    public ArrayList<y> f710c = new ArrayList<>();

    /* renamed from: d  reason: collision with root package name */
    public ArrayList<o> f711d = new ArrayList<>();

    /* renamed from: e  reason: collision with root package name */
    public CharSequence f712e;

    /* renamed from: f  reason: collision with root package name */
    public CharSequence f713f;

    /* renamed from: g  reason: collision with root package name */
    public PendingIntent f714g;

    /* renamed from: h  reason: collision with root package name */
    public Bitmap f715h;

    /* renamed from: i  reason: collision with root package name */
    public int f716i;

    /* renamed from: j  reason: collision with root package name */
    public int f717j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f718k = true;

    /* renamed from: l  reason: collision with root package name */
    public s f719l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f720m = false;

    /* renamed from: n  reason: collision with root package name */
    public String f721n;

    /* renamed from: o  reason: collision with root package name */
    public Bundle f722o;

    /* renamed from: p  reason: collision with root package name */
    public int f723p = 0;

    /* renamed from: q  reason: collision with root package name */
    public int f724q = 0;

    /* renamed from: r  reason: collision with root package name */
    public String f725r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f726s;

    /* renamed from: t  reason: collision with root package name */
    public Notification f727t;
    @Deprecated

    /* renamed from: u  reason: collision with root package name */
    public ArrayList<String> f728u;

    /* compiled from: NotificationCompat */
    public static class a {
        public static AudioAttributes a(AudioAttributes.Builder builder) {
            return builder.build();
        }

        public static AudioAttributes.Builder b() {
            return new AudioAttributes.Builder();
        }

        public static AudioAttributes.Builder c(AudioAttributes.Builder builder, int i10) {
            return builder.setContentType(i10);
        }

        public static AudioAttributes.Builder d(AudioAttributes.Builder builder, int i10) {
            return builder.setLegacyStreamType(i10);
        }

        public static AudioAttributes.Builder e(AudioAttributes.Builder builder, int i10) {
            return builder.setUsage(i10);
        }
    }

    public r(Context context, String str) {
        Notification notification = new Notification();
        this.f727t = notification;
        this.f708a = context;
        this.f725r = str;
        notification.when = System.currentTimeMillis();
        this.f727t.audioStreamType = -1;
        this.f717j = 0;
        this.f728u = new ArrayList<>();
        this.f726s = true;
    }

    public static CharSequence b(CharSequence charSequence) {
        return (charSequence != null && charSequence.length() > 5120) ? charSequence.subSequence(0, 5120) : charSequence;
    }

    public Notification a() {
        Notification notification;
        Bundle bundle;
        t tVar = new t(this);
        s sVar = tVar.f732c.f719l;
        if (sVar != null) {
            sVar.b(tVar);
        }
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 26) {
            notification = t.a.a(tVar.f731b);
        } else if (i10 >= 24) {
            notification = t.a.a(tVar.f731b);
        } else {
            t.c.a(tVar.f731b, tVar.f734e);
            notification = t.a.a(tVar.f731b);
        }
        Objects.requireNonNull(tVar.f732c);
        if (sVar != null) {
            Objects.requireNonNull(tVar.f732c.f719l);
        }
        if (!(sVar == null || (bundle = notification.extras) == null)) {
            sVar.a(bundle);
        }
        return notification;
    }

    public r c(CharSequence charSequence) {
        this.f713f = b(charSequence);
        return this;
    }

    public r d(CharSequence charSequence) {
        this.f712e = b(charSequence);
        return this;
    }

    public final void e(int i10, boolean z10) {
        if (z10) {
            Notification notification = this.f727t;
            notification.flags = i10 | notification.flags;
            return;
        }
        Notification notification2 = this.f727t;
        notification2.flags = (~i10) & notification2.flags;
    }

    public r f(Bitmap bitmap) {
        if (bitmap != null && Build.VERSION.SDK_INT < 27) {
            Resources resources = this.f708a.getResources();
            int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.compat_notification_large_icon_max_width);
            int dimensionPixelSize2 = resources.getDimensionPixelSize(R.dimen.compat_notification_large_icon_max_height);
            if (bitmap.getWidth() > dimensionPixelSize || bitmap.getHeight() > dimensionPixelSize2) {
                double min = Math.min(((double) dimensionPixelSize) / ((double) Math.max(1, bitmap.getWidth())), ((double) dimensionPixelSize2) / ((double) Math.max(1, bitmap.getHeight())));
                bitmap = Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(((double) bitmap.getWidth()) * min), (int) Math.ceil(((double) bitmap.getHeight()) * min), true);
            }
        }
        this.f715h = bitmap;
        return this;
    }

    public r g(s sVar) {
        if (this.f719l != sVar) {
            this.f719l = sVar;
            if (sVar.f729a != this) {
                sVar.f729a = this;
                g(sVar);
            }
        }
        return this;
    }
}
