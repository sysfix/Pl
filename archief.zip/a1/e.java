package a1;

import android.util.Log;
import java.lang.reflect.Method;

/* compiled from: ActivityRecreator */
public class e implements Runnable {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ Object f668p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Object f669q;

    public e(Object obj, Object obj2) {
        this.f668p = obj;
        this.f669q = obj2;
    }

    public void run() {
        try {
            Method method = f.f673d;
            if (method != null) {
                method.invoke(this.f668p, new Object[]{this.f669q, Boolean.FALSE, "AppCompat recreation"});
                return;
            }
            f.f674e.invoke(this.f668p, new Object[]{this.f669q, Boolean.FALSE});
        } catch (RuntimeException e10) {
            if (e10.getClass() == RuntimeException.class && e10.getMessage() != null && e10.getMessage().startsWith("Unable to stop")) {
                throw e10;
            }
        } catch (Throwable th2) {
            Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th2);
        }
    }
}
