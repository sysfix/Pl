package a1;

import n1.a;

/* compiled from: OnMultiWindowModeChangedProvider */
public interface w {
    void addOnMultiWindowModeChangedListener(a<l> aVar);

    void removeOnMultiWindowModeChangedListener(a<l> aVar);
}
