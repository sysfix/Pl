package a1;

import android.os.Bundle;

/* compiled from: NotificationCompatJellybean */
public class u {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f735a = new Object();

    public static Bundle[] a(a0[] a0VarArr) {
        if (a0VarArr == null) {
            return null;
        }
        Bundle[] bundleArr = new Bundle[a0VarArr.length];
        if (a0VarArr.length <= 0) {
            return bundleArr;
        }
        a0 a0Var = a0VarArr[0];
        new Bundle();
        throw null;
    }
}
