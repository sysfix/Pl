package a1;

import n1.a;

/* compiled from: OnPictureInPictureModeChangedProvider */
public interface x {
    void addOnPictureInPictureModeChangedListener(a<z> aVar);

    void removeOnPictureInPictureModeChangedListener(a<z> aVar);
}
