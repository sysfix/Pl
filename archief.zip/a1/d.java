package a1;

import a1.f;
import android.app.Application;

/* compiled from: ActivityRecreator */
public class d implements Runnable {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ Application f666p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ f.a f667q;

    public d(Application application, f.a aVar) {
        this.f666p = application;
        this.f667q = aVar;
    }

    public void run() {
        this.f666p.unregisterActivityLifecycleCallbacks(this.f667q);
    }
}
