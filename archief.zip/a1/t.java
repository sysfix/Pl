package a1;

import a1.y;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Person;
import android.app.RemoteInput;
import android.content.Context;
import android.content.LocusId;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import okhttp3.HttpUrl;

/* compiled from: NotificationCompatBuilder */
public class t implements n {

    /* renamed from: a  reason: collision with root package name */
    public final Context f730a;

    /* renamed from: b  reason: collision with root package name */
    public final Notification.Builder f731b;

    /* renamed from: c  reason: collision with root package name */
    public final r f732c;

    /* renamed from: d  reason: collision with root package name */
    public final List<Bundle> f733d = new ArrayList();

    /* renamed from: e  reason: collision with root package name */
    public final Bundle f734e = new Bundle();

    /* compiled from: NotificationCompatBuilder */
    public static class a {
        public static Notification a(Notification.Builder builder) {
            return builder.build();
        }

        public static Notification.Builder b(Notification.Builder builder, int i10) {
            return builder.setPriority(i10);
        }

        public static Notification.Builder c(Notification.Builder builder, CharSequence charSequence) {
            return builder.setSubText(charSequence);
        }

        public static Notification.Builder d(Notification.Builder builder, boolean z10) {
            return builder.setUsesChronometer(z10);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class b {
        public static Notification.Builder a(Notification.Builder builder, boolean z10) {
            return builder.setShowWhen(z10);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class c {
        public static Notification.Builder a(Notification.Builder builder, Bundle bundle) {
            return builder.setExtras(bundle);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class d {
        public static Notification.Builder a(Notification.Builder builder, Notification.Action action) {
            return builder.addAction(action);
        }

        public static Notification.Action.Builder b(Notification.Action.Builder builder, Bundle bundle) {
            return builder.addExtras(bundle);
        }

        public static Notification.Action.Builder c(Notification.Action.Builder builder, RemoteInput remoteInput) {
            return builder.addRemoteInput(remoteInput);
        }

        public static Notification.Action d(Notification.Action.Builder builder) {
            return builder.build();
        }

        public static Notification.Action.Builder e(int i10, CharSequence charSequence, PendingIntent pendingIntent) {
            return new Notification.Action.Builder(i10, charSequence, pendingIntent);
        }

        public static String f(Notification notification) {
            return notification.getGroup();
        }

        public static Notification.Builder g(Notification.Builder builder, String str) {
            return builder.setGroup(str);
        }

        public static Notification.Builder h(Notification.Builder builder, boolean z10) {
            return builder.setGroupSummary(z10);
        }

        public static Notification.Builder i(Notification.Builder builder, boolean z10) {
            return builder.setLocalOnly(z10);
        }

        public static Notification.Builder j(Notification.Builder builder, String str) {
            return builder.setSortKey(str);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class e {
        public static Notification.Builder a(Notification.Builder builder, String str) {
            return builder.addPerson(str);
        }

        public static Notification.Builder b(Notification.Builder builder, String str) {
            return builder.setCategory(str);
        }

        public static Notification.Builder c(Notification.Builder builder, int i10) {
            return builder.setColor(i10);
        }

        public static Notification.Builder d(Notification.Builder builder, Notification notification) {
            return builder.setPublicVersion(notification);
        }

        public static Notification.Builder e(Notification.Builder builder, Uri uri, Object obj) {
            return builder.setSound(uri, (AudioAttributes) obj);
        }

        public static Notification.Builder f(Notification.Builder builder, int i10) {
            return builder.setVisibility(i10);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class f {
        public static Notification.Action.Builder a(Icon icon, CharSequence charSequence, PendingIntent pendingIntent) {
            return new Notification.Action.Builder(icon, charSequence, pendingIntent);
        }

        public static Notification.Builder b(Notification.Builder builder, Object obj) {
            return builder.setSmallIcon((Icon) obj);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class g {
        public static Notification.Action.Builder a(Notification.Action.Builder builder, boolean z10) {
            return builder.setAllowGeneratedReplies(z10);
        }

        public static Notification.Builder b(Notification.Builder builder, RemoteViews remoteViews) {
            return builder.setCustomBigContentView(remoteViews);
        }

        public static Notification.Builder c(Notification.Builder builder, RemoteViews remoteViews) {
            return builder.setCustomContentView(remoteViews);
        }

        public static Notification.Builder d(Notification.Builder builder, RemoteViews remoteViews) {
            return builder.setCustomHeadsUpContentView(remoteViews);
        }

        public static Notification.Builder e(Notification.Builder builder, CharSequence[] charSequenceArr) {
            return builder.setRemoteInputHistory(charSequenceArr);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class h {
        public static Notification.Builder a(Context context, String str) {
            return new Notification.Builder(context, str);
        }

        public static Notification.Builder b(Notification.Builder builder, int i10) {
            return builder.setBadgeIconType(i10);
        }

        public static Notification.Builder c(Notification.Builder builder, boolean z10) {
            return builder.setColorized(z10);
        }

        public static Notification.Builder d(Notification.Builder builder, int i10) {
            return builder.setGroupAlertBehavior(i10);
        }

        public static Notification.Builder e(Notification.Builder builder, CharSequence charSequence) {
            return builder.setSettingsText(charSequence);
        }

        public static Notification.Builder f(Notification.Builder builder, String str) {
            return builder.setShortcutId(str);
        }

        public static Notification.Builder g(Notification.Builder builder, long j10) {
            return builder.setTimeoutAfter(j10);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class i {
        public static Notification.Builder a(Notification.Builder builder, Person person) {
            return builder.addPerson(person);
        }

        public static Notification.Action.Builder b(Notification.Action.Builder builder, int i10) {
            return builder.setSemanticAction(i10);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class j {
        public static Notification.Builder a(Notification.Builder builder, boolean z10) {
            return builder.setAllowSystemGeneratedContextualActions(z10);
        }

        public static Notification.Builder b(Notification.Builder builder, Notification.BubbleMetadata bubbleMetadata) {
            return builder.setBubbleMetadata(bubbleMetadata);
        }

        public static Notification.Action.Builder c(Notification.Action.Builder builder, boolean z10) {
            return builder.setContextual(z10);
        }

        public static Notification.Builder d(Notification.Builder builder, Object obj) {
            return builder.setLocusId((LocusId) obj);
        }
    }

    /* compiled from: NotificationCompatBuilder */
    public static class k {
        public static Notification.Action.Builder a(Notification.Action.Builder builder, boolean z10) {
            return builder.setAuthenticationRequired(z10);
        }

        public static Notification.Builder b(Notification.Builder builder, int i10) {
            return builder.setForegroundServiceBehavior(i10);
        }
    }

    public t(r rVar) {
        List<String> list;
        Bundle bundle;
        Bundle bundle2;
        r rVar2 = rVar;
        this.f732c = rVar2;
        Context context = rVar2.f708a;
        this.f730a = context;
        if (Build.VERSION.SDK_INT >= 26) {
            this.f731b = h.a(context, rVar2.f725r);
        } else {
            this.f731b = new Notification.Builder(rVar2.f708a);
        }
        Notification notification = rVar2.f727t;
        this.f731b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, (RemoteViews) null).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(rVar2.f712e).setContentText(rVar2.f713f).setContentInfo((CharSequence) null).setContentIntent(rVar2.f714g).setDeleteIntent(notification.deleteIntent).setFullScreenIntent((PendingIntent) null, (notification.flags & 128) == 0 ? false : true).setLargeIcon(rVar2.f715h).setNumber(rVar2.f716i).setProgress(0, 0, false);
        a.b(a.d(a.c(this.f731b, (CharSequence) null), false), rVar2.f717j);
        Iterator<o> it = rVar2.f709b.iterator();
        while (it.hasNext()) {
            o next = it.next();
            IconCompat a10 = next.a();
            Notification.Action.Builder a11 = f.a(a10 != null ? a10.g() : null, next.f701j, next.f702k);
            a0[] a0VarArr = next.f694c;
            if (a0VarArr != null) {
                int length = a0VarArr.length;
                RemoteInput[] remoteInputArr = new RemoteInput[length];
                if (a0VarArr.length <= 0) {
                    for (int i10 = 0; i10 < length; i10++) {
                        d.c(a11, remoteInputArr[i10]);
                    }
                } else {
                    a0 a0Var = a0VarArr[0];
                    throw null;
                }
            }
            if (next.f692a != null) {
                bundle2 = new Bundle(next.f692a);
            } else {
                bundle2 = new Bundle();
            }
            bundle2.putBoolean("android.support.allowGeneratedReplies", next.f696e);
            int i11 = Build.VERSION.SDK_INT;
            if (i11 >= 24) {
                g.a(a11, next.f696e);
            }
            bundle2.putInt("android.support.action.semanticAction", next.f698g);
            if (i11 >= 28) {
                i.b(a11, next.f698g);
            }
            if (i11 >= 29) {
                j.c(a11, next.f699h);
            }
            if (i11 >= 31) {
                k.a(a11, next.f703l);
            }
            bundle2.putBoolean("android.support.action.showsUserInterface", next.f697f);
            d.b(a11, bundle2);
            d.a(this.f731b, d.d(a11));
        }
        Bundle bundle3 = rVar2.f722o;
        if (bundle3 != null) {
            this.f734e.putAll(bundle3);
        }
        int i12 = Build.VERSION.SDK_INT;
        b.a(this.f731b, rVar2.f718k);
        d.i(this.f731b, rVar2.f720m);
        d.g(this.f731b, (String) null);
        d.j(this.f731b, (String) null);
        d.h(this.f731b, false);
        e.b(this.f731b, rVar2.f721n);
        e.c(this.f731b, rVar2.f723p);
        e.f(this.f731b, rVar2.f724q);
        e.d(this.f731b, (Notification) null);
        e.e(this.f731b, notification.sound, notification.audioAttributes);
        if (i12 < 28) {
            list = a(b(rVar2.f710c), rVar2.f728u);
        } else {
            list = rVar2.f728u;
        }
        if (list != null && !list.isEmpty()) {
            for (String a12 : list) {
                e.a(this.f731b, a12);
            }
        }
        if (rVar2.f711d.size() > 0) {
            if (rVar2.f722o == null) {
                rVar2.f722o = new Bundle();
            }
            Bundle bundle4 = rVar2.f722o.getBundle("android.car.EXTENSIONS");
            bundle4 = bundle4 == null ? new Bundle() : bundle4;
            Bundle bundle5 = new Bundle(bundle4);
            Bundle bundle6 = new Bundle();
            for (int i13 = 0; i13 < rVar2.f711d.size(); i13++) {
                String num = Integer.toString(i13);
                o oVar = rVar2.f711d.get(i13);
                Object obj = u.f735a;
                Bundle bundle7 = new Bundle();
                IconCompat a13 = oVar.a();
                bundle7.putInt("icon", a13 != null ? a13.d() : 0);
                bundle7.putCharSequence("title", oVar.f701j);
                bundle7.putParcelable("actionIntent", oVar.f702k);
                if (oVar.f692a != null) {
                    bundle = new Bundle(oVar.f692a);
                } else {
                    bundle = new Bundle();
                }
                bundle.putBoolean("android.support.allowGeneratedReplies", oVar.f696e);
                bundle7.putBundle("extras", bundle);
                bundle7.putParcelableArray("remoteInputs", u.a(oVar.f694c));
                bundle7.putBoolean("showsUserInterface", oVar.f697f);
                bundle7.putInt("semanticAction", oVar.f698g);
                bundle6.putBundle(num, bundle7);
            }
            bundle4.putBundle("invisible_actions", bundle6);
            bundle5.putBundle("invisible_actions", bundle6);
            if (rVar2.f722o == null) {
                rVar2.f722o = new Bundle();
            }
            rVar2.f722o.putBundle("android.car.EXTENSIONS", bundle4);
            this.f734e.putBundle("android.car.EXTENSIONS", bundle5);
        }
        int i14 = Build.VERSION.SDK_INT;
        if (i14 >= 24) {
            c.a(this.f731b, rVar2.f722o);
            g.e(this.f731b, (CharSequence[]) null);
        }
        if (i14 >= 26) {
            h.b(this.f731b, 0);
            h.e(this.f731b, (CharSequence) null);
            h.f(this.f731b, (String) null);
            h.g(this.f731b, 0);
            h.d(this.f731b, 0);
            if (!TextUtils.isEmpty(rVar2.f725r)) {
                this.f731b.setSound((Uri) null).setDefaults(0).setLights(0, 0, 0).setVibrate((long[]) null);
            }
        }
        if (i14 >= 28) {
            Iterator<y> it2 = rVar2.f710c.iterator();
            while (it2.hasNext()) {
                y next2 = it2.next();
                Notification.Builder builder = this.f731b;
                Objects.requireNonNull(next2);
                i.a(builder, y.a.b(next2));
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            j.a(this.f731b, rVar2.f726s);
            j.b(this.f731b, (Notification.BubbleMetadata) null);
        }
    }

    public static List<String> a(List<String> list, List<String> list2) {
        if (list == null) {
            return list2;
        }
        if (list2 == null) {
            return list;
        }
        o0.b bVar = new o0.b(list2.size() + list.size());
        bVar.addAll(list);
        bVar.addAll(list2);
        return new ArrayList(bVar);
    }

    public static List<String> b(List<y> list) {
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(list.size());
        for (y next : list) {
            String str = next.f760c;
            if (str == null) {
                if (next.f758a != null) {
                    StringBuilder a10 = f.a.a("name:");
                    a10.append(next.f758a);
                    str = a10.toString();
                } else {
                    str = HttpUrl.FRAGMENT_ENCODE_SET;
                }
            }
            arrayList.add(str);
        }
        return arrayList;
    }
}
