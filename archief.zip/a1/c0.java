package a1;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import b1.a;
import java.util.ArrayList;
import java.util.Iterator;

/* compiled from: TaskStackBuilder */
public final class c0 implements Iterable<Intent> {

    /* renamed from: p  reason: collision with root package name */
    public final ArrayList<Intent> f664p = new ArrayList<>();

    /* renamed from: q  reason: collision with root package name */
    public final Context f665q;

    /* compiled from: TaskStackBuilder */
    public interface a {
        Intent getSupportParentActivityIntent();
    }

    public c0(Context context) {
        this.f665q = context;
    }

    public c0 c(Intent intent) {
        ComponentName component = intent.getComponent();
        if (component == null) {
            component = intent.resolveActivity(this.f665q.getPackageManager());
        }
        if (component != null) {
            f(component);
        }
        this.f664p.add(intent);
        return this;
    }

    public c0 f(ComponentName componentName) {
        int size = this.f664p.size();
        try {
            Intent b10 = m.b(this.f665q, componentName);
            while (b10 != null) {
                this.f664p.add(size, b10);
                b10 = m.b(this.f665q, b10.getComponent());
            }
            return this;
        } catch (PackageManager.NameNotFoundException e10) {
            Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
            throw new IllegalArgumentException(e10);
        }
    }

    public void i() {
        if (!this.f664p.isEmpty()) {
            Intent[] intentArr = (Intent[]) this.f664p.toArray(new Intent[0]);
            intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
            Context context = this.f665q;
            Object obj = b1.a.f4191a;
            a.C0045a.a(context, intentArr, (Bundle) null);
            return;
        }
        throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
    }

    @Deprecated
    public Iterator<Intent> iterator() {
        return this.f664p.iterator();
    }
}
