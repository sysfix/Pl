package a1;

import android.app.PendingIntent;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;
import okhttp3.HttpUrl;

/* compiled from: NotificationCompat */
public class o {

    /* renamed from: a  reason: collision with root package name */
    public final Bundle f692a;

    /* renamed from: b  reason: collision with root package name */
    public IconCompat f693b;

    /* renamed from: c  reason: collision with root package name */
    public final a0[] f694c;

    /* renamed from: d  reason: collision with root package name */
    public final a0[] f695d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f696e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f697f;

    /* renamed from: g  reason: collision with root package name */
    public final int f698g;

    /* renamed from: h  reason: collision with root package name */
    public final boolean f699h;
    @Deprecated

    /* renamed from: i  reason: collision with root package name */
    public int f700i;

    /* renamed from: j  reason: collision with root package name */
    public CharSequence f701j;

    /* renamed from: k  reason: collision with root package name */
    public PendingIntent f702k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f703l;

    public o(int i10, CharSequence charSequence, PendingIntent pendingIntent) {
        IconCompat b10 = i10 == 0 ? null : IconCompat.b((Resources) null, HttpUrl.FRAGMENT_ENCODE_SET, i10);
        Bundle bundle = new Bundle();
        this.f697f = true;
        this.f693b = b10;
        if (b10 != null && b10.e() == 2) {
            this.f700i = b10.d();
        }
        this.f701j = r.b(charSequence);
        this.f702k = pendingIntent;
        this.f692a = bundle;
        this.f694c = null;
        this.f695d = null;
        this.f696e = true;
        this.f698g = 0;
        this.f697f = true;
        this.f699h = false;
        this.f703l = false;
    }

    public IconCompat a() {
        int i10;
        if (this.f693b == null && (i10 = this.f700i) != 0) {
            this.f693b = IconCompat.b((Resources) null, HttpUrl.FRAGMENT_ENCODE_SET, i10);
        }
        return this.f693b;
    }
}
