package a1;

/* compiled from: RemoteInput */
public final class a0 {
}
