package a1;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Message;
import android.os.RemoteException;
import android.provider.Settings;
import android.util.Log;
import c0.a;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* compiled from: NotificationManagerCompat */
public final class v {

    /* renamed from: c  reason: collision with root package name */
    public static final Object f736c = new Object();

    /* renamed from: d  reason: collision with root package name */
    public static String f737d;

    /* renamed from: e  reason: collision with root package name */
    public static Set<String> f738e = new HashSet();

    /* renamed from: f  reason: collision with root package name */
    public static final Object f739f = new Object();

    /* renamed from: g  reason: collision with root package name */
    public static e f740g;

    /* renamed from: a  reason: collision with root package name */
    public final Context f741a;

    /* renamed from: b  reason: collision with root package name */
    public final NotificationManager f742b;

    /* compiled from: NotificationManagerCompat */
    public static class a {
        public static boolean a(NotificationManager notificationManager) {
            return notificationManager.areNotificationsEnabled();
        }

        public static int b(NotificationManager notificationManager) {
            return notificationManager.getImportance();
        }
    }

    /* compiled from: NotificationManagerCompat */
    public static class b {
        public static void a(NotificationManager notificationManager, NotificationChannel notificationChannel) {
            notificationManager.createNotificationChannel(notificationChannel);
        }

        public static void b(NotificationManager notificationManager, NotificationChannelGroup notificationChannelGroup) {
            notificationManager.createNotificationChannelGroup(notificationChannelGroup);
        }

        public static void c(NotificationManager notificationManager, List<NotificationChannelGroup> list) {
            notificationManager.createNotificationChannelGroups(list);
        }

        public static void d(NotificationManager notificationManager, List<NotificationChannel> list) {
            notificationManager.createNotificationChannels(list);
        }

        public static void e(NotificationManager notificationManager, String str) {
            notificationManager.deleteNotificationChannel(str);
        }

        public static void f(NotificationManager notificationManager, String str) {
            notificationManager.deleteNotificationChannelGroup(str);
        }

        public static String g(NotificationChannel notificationChannel) {
            return notificationChannel.getId();
        }

        public static String h(NotificationChannelGroup notificationChannelGroup) {
            return notificationChannelGroup.getId();
        }

        public static NotificationChannel i(NotificationManager notificationManager, String str) {
            return notificationManager.getNotificationChannel(str);
        }

        public static List<NotificationChannelGroup> j(NotificationManager notificationManager) {
            return notificationManager.getNotificationChannelGroups();
        }

        public static List<NotificationChannel> k(NotificationManager notificationManager) {
            return notificationManager.getNotificationChannels();
        }
    }

    /* compiled from: NotificationManagerCompat */
    public static class c implements f {

        /* renamed from: a  reason: collision with root package name */
        public final String f743a;

        /* renamed from: b  reason: collision with root package name */
        public final int f744b;

        /* renamed from: c  reason: collision with root package name */
        public final String f745c;

        /* renamed from: d  reason: collision with root package name */
        public final Notification f746d;

        public c(String str, int i10, String str2, Notification notification) {
            this.f743a = str;
            this.f744b = i10;
            this.f745c = str2;
            this.f746d = notification;
        }

        public void a(c0.a aVar) {
            aVar.U(this.f743a, this.f744b, this.f745c, this.f746d);
        }

        public String toString() {
            StringBuilder sb2 = new StringBuilder("NotifyTask[");
            sb2.append("packageName:");
            sb2.append(this.f743a);
            sb2.append(", id:");
            sb2.append(this.f744b);
            sb2.append(", tag:");
            return c.d.a(sb2, this.f745c, "]");
        }
    }

    /* compiled from: NotificationManagerCompat */
    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public final ComponentName f747a;

        /* renamed from: b  reason: collision with root package name */
        public final IBinder f748b;

        public d(ComponentName componentName, IBinder iBinder) {
            this.f747a = componentName;
            this.f748b = iBinder;
        }
    }

    /* compiled from: NotificationManagerCompat */
    public static class e implements Handler.Callback, ServiceConnection {

        /* renamed from: a  reason: collision with root package name */
        public final Context f749a;

        /* renamed from: b  reason: collision with root package name */
        public final Handler f750b;

        /* renamed from: c  reason: collision with root package name */
        public final Map<ComponentName, a> f751c = new HashMap();

        /* renamed from: d  reason: collision with root package name */
        public Set<String> f752d = new HashSet();

        /* compiled from: NotificationManagerCompat */
        public static class a {

            /* renamed from: a  reason: collision with root package name */
            public final ComponentName f753a;

            /* renamed from: b  reason: collision with root package name */
            public boolean f754b = false;

            /* renamed from: c  reason: collision with root package name */
            public c0.a f755c;

            /* renamed from: d  reason: collision with root package name */
            public ArrayDeque<f> f756d = new ArrayDeque<>();

            /* renamed from: e  reason: collision with root package name */
            public int f757e = 0;

            public a(ComponentName componentName) {
                this.f753a = componentName;
            }
        }

        public e(Context context) {
            this.f749a = context;
            HandlerThread handlerThread = new HandlerThread("NotificationManagerCompat");
            handlerThread.start();
            this.f750b = new Handler(handlerThread.getLooper(), this);
        }

        public final void a(a aVar) {
            boolean z10;
            if (Log.isLoggable("NotifManCompat", 3)) {
                StringBuilder a10 = f.a.a("Processing component ");
                a10.append(aVar.f753a);
                a10.append(", ");
                a10.append(aVar.f756d.size());
                a10.append(" queued tasks");
                Log.d("NotifManCompat", a10.toString());
            }
            if (!aVar.f756d.isEmpty()) {
                if (aVar.f754b) {
                    z10 = true;
                } else {
                    boolean bindService = this.f749a.bindService(new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(aVar.f753a), this, 33);
                    aVar.f754b = bindService;
                    if (bindService) {
                        aVar.f757e = 0;
                    } else {
                        StringBuilder a11 = f.a.a("Unable to bind to listener ");
                        a11.append(aVar.f753a);
                        Log.w("NotifManCompat", a11.toString());
                        this.f749a.unbindService(this);
                    }
                    z10 = aVar.f754b;
                }
                if (!z10 || aVar.f755c == null) {
                    b(aVar);
                    return;
                }
                while (true) {
                    f peek = aVar.f756d.peek();
                    if (peek == null) {
                        break;
                    }
                    try {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            Log.d("NotifManCompat", "Sending task " + peek);
                        }
                        peek.a(aVar.f755c);
                        aVar.f756d.remove();
                    } catch (DeadObjectException unused) {
                        if (Log.isLoggable("NotifManCompat", 3)) {
                            StringBuilder a12 = f.a.a("Remote service has died: ");
                            a12.append(aVar.f753a);
                            Log.d("NotifManCompat", a12.toString());
                        }
                    } catch (RemoteException e10) {
                        StringBuilder a13 = f.a.a("RemoteException communicating with ");
                        a13.append(aVar.f753a);
                        Log.w("NotifManCompat", a13.toString(), e10);
                    }
                }
                if (!aVar.f756d.isEmpty()) {
                    b(aVar);
                }
            }
        }

        public final void b(a aVar) {
            if (!this.f750b.hasMessages(3, aVar.f753a)) {
                int i10 = aVar.f757e + 1;
                aVar.f757e = i10;
                if (i10 > 6) {
                    StringBuilder a10 = f.a.a("Giving up on delivering ");
                    a10.append(aVar.f756d.size());
                    a10.append(" tasks to ");
                    a10.append(aVar.f753a);
                    a10.append(" after ");
                    a10.append(aVar.f757e);
                    a10.append(" retries");
                    Log.w("NotifManCompat", a10.toString());
                    aVar.f756d.clear();
                    return;
                }
                int i11 = (1 << (i10 - 1)) * 1000;
                if (Log.isLoggable("NotifManCompat", 3)) {
                    Log.d("NotifManCompat", "Scheduling retry for " + i11 + " ms");
                }
                this.f750b.sendMessageDelayed(this.f750b.obtainMessage(3, aVar.f753a), (long) i11);
            }
        }

        public boolean handleMessage(Message message) {
            Set<String> set;
            int i10 = message.what;
            c0.a aVar = null;
            if (i10 == 0) {
                f fVar = (f) message.obj;
                String string = Settings.Secure.getString(this.f749a.getContentResolver(), "enabled_notification_listeners");
                synchronized (v.f736c) {
                    if (string != null) {
                        if (!string.equals(v.f737d)) {
                            String[] split = string.split(":", -1);
                            HashSet hashSet = new HashSet(split.length);
                            for (String unflattenFromString : split) {
                                ComponentName unflattenFromString2 = ComponentName.unflattenFromString(unflattenFromString);
                                if (unflattenFromString2 != null) {
                                    hashSet.add(unflattenFromString2.getPackageName());
                                }
                            }
                            v.f738e = hashSet;
                            v.f737d = string;
                        }
                    }
                    set = v.f738e;
                }
                if (!set.equals(this.f752d)) {
                    this.f752d = set;
                    List<ResolveInfo> queryIntentServices = this.f749a.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
                    HashSet hashSet2 = new HashSet();
                    for (ResolveInfo next : queryIntentServices) {
                        if (set.contains(next.serviceInfo.packageName)) {
                            ServiceInfo serviceInfo = next.serviceInfo;
                            ComponentName componentName = new ComponentName(serviceInfo.packageName, serviceInfo.name);
                            if (next.serviceInfo.permission != null) {
                                Log.w("NotifManCompat", "Permission present on component " + componentName + ", not adding listener record.");
                            } else {
                                hashSet2.add(componentName);
                            }
                        }
                    }
                    Iterator it = hashSet2.iterator();
                    while (it.hasNext()) {
                        ComponentName componentName2 = (ComponentName) it.next();
                        if (!this.f751c.containsKey(componentName2)) {
                            if (Log.isLoggable("NotifManCompat", 3)) {
                                Log.d("NotifManCompat", "Adding listener record for " + componentName2);
                            }
                            this.f751c.put(componentName2, new a(componentName2));
                        }
                    }
                    Iterator<Map.Entry<ComponentName, a>> it2 = this.f751c.entrySet().iterator();
                    while (it2.hasNext()) {
                        Map.Entry next2 = it2.next();
                        if (!hashSet2.contains(next2.getKey())) {
                            if (Log.isLoggable("NotifManCompat", 3)) {
                                StringBuilder a10 = f.a.a("Removing listener record for ");
                                a10.append(next2.getKey());
                                Log.d("NotifManCompat", a10.toString());
                            }
                            a aVar2 = (a) next2.getValue();
                            if (aVar2.f754b) {
                                this.f749a.unbindService(this);
                                aVar2.f754b = false;
                            }
                            aVar2.f755c = null;
                            it2.remove();
                        }
                    }
                }
                for (a next3 : this.f751c.values()) {
                    next3.f756d.add(fVar);
                    a(next3);
                }
                return true;
            } else if (i10 == 1) {
                d dVar = (d) message.obj;
                ComponentName componentName3 = dVar.f747a;
                IBinder iBinder = dVar.f748b;
                a aVar3 = this.f751c.get(componentName3);
                if (aVar3 != null) {
                    int i11 = a.C0052a.f4568c;
                    if (iBinder != null) {
                        IInterface queryLocalInterface = iBinder.queryLocalInterface(c0.a.f4567b);
                        if (queryLocalInterface == null || !(queryLocalInterface instanceof c0.a)) {
                            aVar = new a.C0052a.C0053a(iBinder);
                        } else {
                            aVar = (c0.a) queryLocalInterface;
                        }
                    }
                    aVar3.f755c = aVar;
                    aVar3.f757e = 0;
                    a(aVar3);
                }
                return true;
            } else if (i10 == 2) {
                a aVar4 = this.f751c.get((ComponentName) message.obj);
                if (aVar4 != null) {
                    if (aVar4.f754b) {
                        this.f749a.unbindService(this);
                        aVar4.f754b = false;
                    }
                    aVar4.f755c = null;
                }
                return true;
            } else if (i10 != 3) {
                return false;
            } else {
                a aVar5 = this.f751c.get((ComponentName) message.obj);
                if (aVar5 != null) {
                    a(aVar5);
                }
                return true;
            }
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Connected to service " + componentName);
            }
            this.f750b.obtainMessage(1, new d(componentName, iBinder)).sendToTarget();
        }

        public void onServiceDisconnected(ComponentName componentName) {
            if (Log.isLoggable("NotifManCompat", 3)) {
                Log.d("NotifManCompat", "Disconnected from service " + componentName);
            }
            this.f750b.obtainMessage(2, componentName).sendToTarget();
        }
    }

    /* compiled from: NotificationManagerCompat */
    public interface f {
        void a(c0.a aVar);
    }

    public v(Context context) {
        this.f741a = context;
        this.f742b = (NotificationManager) context.getSystemService("notification");
    }

    public boolean a() {
        if (Build.VERSION.SDK_INT >= 24) {
            return a.a(this.f742b);
        }
        AppOpsManager appOpsManager = (AppOpsManager) this.f741a.getSystemService("appops");
        ApplicationInfo applicationInfo = this.f741a.getApplicationInfo();
        String packageName = this.f741a.getApplicationContext().getPackageName();
        int i10 = applicationInfo.uid;
        try {
            Class<?> cls = Class.forName(AppOpsManager.class.getName());
            Class cls2 = Integer.TYPE;
            if (((Integer) cls.getMethod("checkOpNoThrow", new Class[]{cls2, cls2, String.class}).invoke(appOpsManager, new Object[]{Integer.valueOf(((Integer) cls.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue()), Integer.valueOf(i10), packageName})).intValue() == 0) {
                return true;
            }
            return false;
        } catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException | NoSuchMethodException | RuntimeException | InvocationTargetException unused) {
            return true;
        }
    }

    public void b(int i10, Notification notification) {
        Bundle bundle = notification.extras;
        if (bundle != null && bundle.getBoolean("android.support.useSideChannel")) {
            c cVar = new c(this.f741a.getPackageName(), i10, (String) null, notification);
            synchronized (f739f) {
                if (f740g == null) {
                    f740g = new e(this.f741a.getApplicationContext());
                }
                f740g.f750b.obtainMessage(0, cVar).sendToTarget();
            }
            this.f742b.cancel((String) null, i10);
            return;
        }
        this.f742b.notify((String) null, i10, notification);
    }
}
