package a1;

import android.os.Bundle;

/* compiled from: NotificationCompat */
public abstract class s {

    /* renamed from: a  reason: collision with root package name */
    public r f729a;

    public void a(Bundle bundle) {
        String c10 = c();
        if (c10 != null) {
            bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", c10);
        }
    }

    public abstract void b(n nVar);

    public abstract String c();
}
