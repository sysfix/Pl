package a1;

/* compiled from: NotificationBuilderWithBuilderAccessor */
public interface n {
}
