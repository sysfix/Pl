package a3;

/* compiled from: WebMessageCompat */
public class c {

    /* renamed from: a  reason: collision with root package name */
    public final d[] f776a;

    /* renamed from: b  reason: collision with root package name */
    public final String f777b;

    public c(String str, d[] dVarArr) {
        this.f777b = str;
        this.f776a = dVarArr;
    }
}
