package a3;

/* compiled from: WebMessagePortCompat */
public abstract class d {

    /* compiled from: WebMessagePortCompat */
    public static abstract class a {
    }
}
