package a3;

/* compiled from: SafeBrowsingResponseCompat */
public abstract class a {
}
