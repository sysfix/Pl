package a3;

/* compiled from: TracingConfig */
public class b {
}
