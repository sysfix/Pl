package a3;

import android.annotation.SuppressLint;
import android.content.pm.PackageInfo;
import android.net.Uri;
import okhttp3.HttpUrl;
import org.slf4j.Marker;

/* compiled from: WebViewCompat */
public class e {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f778a = 0;

    /* compiled from: WebViewCompat */
    public interface a {
        void onComplete(long j10);
    }

    static {
        Uri.parse(Marker.ANY_MARKER);
        Uri.parse(HttpUrl.FRAGMENT_ENCODE_SET);
    }

    @SuppressLint({"PrivateApi"})
    public static PackageInfo a() {
        return (PackageInfo) Class.forName("android.webkit.WebViewFactory").getMethod("getLoadedPackageInfo", new Class[0]).invoke((Object) null, new Object[0]);
    }
}
