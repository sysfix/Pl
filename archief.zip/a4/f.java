package a4;

import android.graphics.Bitmap;
import coil.memory.MemoryCache;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/* compiled from: WeakMemoryCache.kt */
public final class f implements h {

    /* renamed from: a  reason: collision with root package name */
    public final LinkedHashMap<MemoryCache.Key, ArrayList<a>> f791a = new LinkedHashMap<>();

    /* renamed from: b  reason: collision with root package name */
    public int f792b;

    /* compiled from: WeakMemoryCache.kt */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final int f793a;

        /* renamed from: b  reason: collision with root package name */
        public final WeakReference<Bitmap> f794b;

        /* renamed from: c  reason: collision with root package name */
        public final Map<String, Object> f795c;

        /* renamed from: d  reason: collision with root package name */
        public final int f796d;

        public a(int i10, WeakReference<Bitmap> weakReference, Map<String, ? extends Object> map, int i11) {
            this.f793a = i10;
            this.f794b = weakReference;
            this.f795c = map;
            this.f796d = i11;
        }
    }

    public synchronized void a(int i10) {
        if (i10 >= 10 && i10 != 20) {
            d();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0043, code lost:
        return r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized coil.memory.MemoryCache.b b(coil.memory.MemoryCache.Key r7) {
        /*
            r6 = this;
            monitor-enter(r6)
            java.util.LinkedHashMap<coil.memory.MemoryCache$Key, java.util.ArrayList<a4.f$a>> r0 = r6.f791a     // Catch:{ all -> 0x0044 }
            java.lang.Object r7 = r0.get(r7)     // Catch:{ all -> 0x0044 }
            java.util.ArrayList r7 = (java.util.ArrayList) r7     // Catch:{ all -> 0x0044 }
            r0 = 0
            if (r7 != 0) goto L_0x000e
            monitor-exit(r6)
            return r0
        L_0x000e:
            r1 = 0
            int r2 = r7.size()     // Catch:{ all -> 0x0044 }
        L_0x0013:
            if (r1 >= r2) goto L_0x0035
            java.lang.Object r3 = r7.get(r1)     // Catch:{ all -> 0x0044 }
            a4.f$a r3 = (a4.f.a) r3     // Catch:{ all -> 0x0044 }
            java.lang.ref.WeakReference<android.graphics.Bitmap> r4 = r3.f794b     // Catch:{ all -> 0x0044 }
            java.lang.Object r4 = r4.get()     // Catch:{ all -> 0x0044 }
            android.graphics.Bitmap r4 = (android.graphics.Bitmap) r4     // Catch:{ all -> 0x0044 }
            if (r4 == 0) goto L_0x002d
            coil.memory.MemoryCache$b r5 = new coil.memory.MemoryCache$b     // Catch:{ all -> 0x0044 }
            java.util.Map<java.lang.String, java.lang.Object> r3 = r3.f795c     // Catch:{ all -> 0x0044 }
            r5.<init>(r4, r3)     // Catch:{ all -> 0x0044 }
            goto L_0x002e
        L_0x002d:
            r5 = r0
        L_0x002e:
            if (r5 == 0) goto L_0x0032
            r0 = r5
            goto L_0x0035
        L_0x0032:
            int r1 = r1 + 1
            goto L_0x0013
        L_0x0035:
            int r7 = r6.f792b     // Catch:{ all -> 0x0044 }
            int r1 = r7 + 1
            r6.f792b = r1     // Catch:{ all -> 0x0044 }
            r1 = 10
            if (r7 < r1) goto L_0x0042
            r6.d()     // Catch:{ all -> 0x0044 }
        L_0x0042:
            monitor-exit(r6)
            return r0
        L_0x0044:
            r7 = move-exception
            monitor-exit(r6)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.f.b(coil.memory.MemoryCache$Key):coil.memory.MemoryCache$b");
    }

    public synchronized void c(MemoryCache.Key key, Bitmap bitmap, Map<String, ? extends Object> map, int i10) {
        LinkedHashMap<MemoryCache.Key, ArrayList<a>> linkedHashMap = this.f791a;
        ArrayList<a> arrayList = linkedHashMap.get(key);
        if (arrayList == null) {
            arrayList = new ArrayList<>();
            linkedHashMap.put(key, arrayList);
        }
        ArrayList arrayList2 = arrayList;
        int identityHashCode = System.identityHashCode(bitmap);
        a aVar = new a(identityHashCode, new WeakReference(bitmap), map, i10);
        int i11 = 0;
        int size = arrayList2.size();
        while (true) {
            if (i11 >= size) {
                arrayList2.add(aVar);
                break;
            }
            a aVar2 = (a) arrayList2.get(i11);
            if (i10 < aVar2.f796d) {
                i11++;
            } else if (aVar2.f793a == identityHashCode && aVar2.f794b.get() == bitmap) {
                arrayList2.set(i11, aVar);
            } else {
                arrayList2.add(i11, aVar);
            }
        }
        int i12 = this.f792b;
        this.f792b = i12 + 1;
        if (i12 >= 10) {
            d();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0028, code lost:
        r2 = r2.f794b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void d() {
        /*
            r9 = this;
            r0 = 0
            r9.f792b = r0
            java.util.LinkedHashMap<coil.memory.MemoryCache$Key, java.util.ArrayList<a4.f$a>> r1 = r9.f791a
            java.util.Collection r1 = r1.values()
            java.util.Iterator r1 = r1.iterator()
        L_0x000d:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x0069
            java.lang.Object r2 = r1.next()
            java.util.ArrayList r2 = (java.util.ArrayList) r2
            int r3 = r2.size()
            r4 = 1
            if (r3 > r4) goto L_0x003a
            java.lang.Object r2 = yf.l.c0(r2)
            a4.f$a r2 = (a4.f.a) r2
            if (r2 == 0) goto L_0x0033
            java.lang.ref.WeakReference<android.graphics.Bitmap> r2 = r2.f794b
            if (r2 == 0) goto L_0x0033
            java.lang.Object r2 = r2.get()
            android.graphics.Bitmap r2 = (android.graphics.Bitmap) r2
            goto L_0x0034
        L_0x0033:
            r2 = 0
        L_0x0034:
            if (r2 != 0) goto L_0x000d
            r1.remove()
            goto L_0x000d
        L_0x003a:
            int r3 = r2.size()
            r5 = r0
            r6 = r5
        L_0x0040:
            if (r5 >= r3) goto L_0x005f
            int r7 = r5 - r6
            java.lang.Object r8 = r2.get(r7)
            a4.f$a r8 = (a4.f.a) r8
            java.lang.ref.WeakReference<android.graphics.Bitmap> r8 = r8.f794b
            java.lang.Object r8 = r8.get()
            if (r8 != 0) goto L_0x0054
            r8 = r4
            goto L_0x0055
        L_0x0054:
            r8 = r0
        L_0x0055:
            if (r8 == 0) goto L_0x005c
            r2.remove(r7)
            int r6 = r6 + 1
        L_0x005c:
            int r5 = r5 + 1
            goto L_0x0040
        L_0x005f:
            boolean r2 = r2.isEmpty()
            if (r2 == 0) goto L_0x000d
            r1.remove()
            goto L_0x000d
        L_0x0069:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.f.d():void");
    }
}
