package a4;

import android.graphics.Bitmap;
import coil.memory.MemoryCache;
import java.util.Map;

/* compiled from: WeakMemoryCache.kt */
public final class b implements h {
    public void a(int i10) {
    }

    public MemoryCache.b b(MemoryCache.Key key) {
        return null;
    }

    public void c(MemoryCache.Key key, Bitmap bitmap, Map<String, ? extends Object> map, int i10) {
    }
}
