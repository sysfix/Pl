package a4;

import android.graphics.Bitmap;
import coil.memory.MemoryCache;
import java.util.Map;
import o0.f;

/* compiled from: StrongMemoryCache.kt */
public final class e implements g {

    /* renamed from: a  reason: collision with root package name */
    public final h f785a;

    /* renamed from: b  reason: collision with root package name */
    public final b f786b;

    /* compiled from: StrongMemoryCache.kt */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final Bitmap f787a;

        /* renamed from: b  reason: collision with root package name */
        public final Map<String, Object> f788b;

        /* renamed from: c  reason: collision with root package name */
        public final int f789c;

        public a(Bitmap bitmap, Map<String, ? extends Object> map, int i10) {
            this.f787a = bitmap;
            this.f788b = map;
            this.f789c = i10;
        }
    }

    /* compiled from: StrongMemoryCache.kt */
    public static final class b extends f<MemoryCache.Key, a> {

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ e f790i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(int i10, e eVar) {
            super(i10);
            this.f790i = eVar;
        }

        public void b(boolean z10, Object obj, Object obj2, Object obj3) {
            a aVar = (a) obj2;
            a aVar2 = (a) obj3;
            this.f790i.f785a.c((MemoryCache.Key) obj, aVar.f787a, aVar.f788b, aVar.f789c);
        }

        public int g(Object obj, Object obj2) {
            MemoryCache.Key key = (MemoryCache.Key) obj;
            return ((a) obj2).f789c;
        }
    }

    public e(int i10, h hVar) {
        this.f785a = hVar;
        this.f786b = new b(i10, this);
    }

    public void a(int i10) {
        int i11;
        if (i10 >= 40) {
            this.f786b.h(-1);
            return;
        }
        boolean z10 = false;
        if (10 <= i10 && i10 < 20) {
            z10 = true;
        }
        if (z10) {
            b bVar = this.f786b;
            synchronized (bVar) {
                i11 = bVar.f14808b;
            }
            bVar.h(i11 / 2);
        }
    }

    public MemoryCache.b b(MemoryCache.Key key) {
        a aVar = (a) this.f786b.c(key);
        if (aVar != null) {
            return new MemoryCache.b(aVar.f787a, aVar.f788b);
        }
        return null;
    }

    public void c(MemoryCache.Key key, Bitmap bitmap, Map<String, ? extends Object> map) {
        int i10;
        int j10 = l7.a.j(bitmap);
        b bVar = this.f786b;
        synchronized (bVar) {
            i10 = bVar.f14809c;
        }
        if (j10 <= i10) {
            this.f786b.d(key, new a(bitmap, map, j10));
            return;
        }
        this.f786b.e(key);
        this.f785a.c(key, bitmap, map, j10);
    }
}
