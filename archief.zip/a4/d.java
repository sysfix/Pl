package a4;

import coil.memory.MemoryCache;
import i.m;

/* compiled from: RealMemoryCache.kt */
public final class d implements MemoryCache {

    /* renamed from: a  reason: collision with root package name */
    public final g f783a;

    /* renamed from: b  reason: collision with root package name */
    public final h f784b;

    public d(g gVar, h hVar) {
        this.f783a = gVar;
        this.f784b = hVar;
    }

    public void a(int i10) {
        this.f783a.a(i10);
        this.f784b.a(i10);
    }

    public MemoryCache.b b(MemoryCache.Key key) {
        MemoryCache.b b10 = this.f783a.b(key);
        return b10 == null ? this.f784b.b(key) : b10;
    }

    public void c(MemoryCache.Key key, MemoryCache.b bVar) {
        this.f783a.c(new MemoryCache.Key(key.f5034p, m.i(key.f5035q)), bVar.f5040a, m.i(bVar.f5041b));
    }
}
