package a4;

import ai.plaud.android.plaud.anew.flutter.audio.e;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import c4.g;
import c4.l;
import c4.n;
import coil.a;
import coil.decode.DataSource;
import coil.intercept.RealInterceptorChain;
import coil.memory.MemoryCache;
import h2.k;
import h4.h;
import h4.p;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Pair;
import rg.d0;
import s3.b;
import x3.a;

/* compiled from: MemoryCacheService.kt */
public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final a f780a;

    /* renamed from: b  reason: collision with root package name */
    public final k f781b;

    /* renamed from: c  reason: collision with root package name */
    public final p f782c;

    public c(a aVar, k kVar, p pVar) {
        this.f780a = aVar;
        this.f781b = kVar;
        this.f782c = pVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:51:0x010d, code lost:
        if (java.lang.Math.abs(r9 - r2) <= 1) goto L_0x010f;
     */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x012c  */
    /* JADX WARNING: Removed duplicated region for block: B:65:0x012e  */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x01e7  */
    /* JADX WARNING: Removed duplicated region for block: B:93:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final coil.memory.MemoryCache.b a(c4.g r19, coil.memory.MemoryCache.Key r20, d4.e r21, coil.size.Scale r22) {
        /*
            r18 = this;
            r0 = r18
            r1 = r19
            r2 = r20
            r3 = r21
            r4 = r22
            coil.request.CachePolicy r5 = r1.f4694t
            boolean r5 = r5.getReadEnabled()
            r6 = 0
            if (r5 != 0) goto L_0x0014
            return r6
        L_0x0014:
            coil.a r5 = r0.f780a
            coil.memory.MemoryCache r5 = r5.a()
            if (r5 == 0) goto L_0x0021
            coil.memory.MemoryCache$b r5 = r5.b(r2)
            goto L_0x0022
        L_0x0021:
            r5 = r6
        L_0x0022:
            if (r5 == 0) goto L_0x01e9
            h2.k r7 = r0.f781b
            android.graphics.Bitmap r8 = r5.f5040a
            android.graphics.Bitmap$Config r8 = l7.a.k(r8)
            boolean r7 = r7.f(r1, r8)
            java.lang.String r8 = "MemoryCacheService"
            r9 = 3
            if (r7 != 0) goto L_0x0050
            h4.p r2 = r0.f782c
            if (r2 == 0) goto L_0x0076
            int r3 = r2.a()
            if (r3 > r9) goto L_0x0076
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.Object r1 = r1.f4676b
            java.lang.String r4 = ": Cached bitmap is hardware-backed, which is incompatible with the request."
            java.lang.String r1 = h.a.a(r3, r1, r4)
            r2.b(r8, r9, r1, r6)
            goto L_0x0076
        L_0x0050:
            boolean r7 = r0.b(r5)
            boolean r10 = k.i.d(r21)
            if (r10 == 0) goto L_0x007e
            if (r7 == 0) goto L_0x007a
            h4.p r2 = r0.f782c
            if (r2 == 0) goto L_0x0076
            int r3 = r2.a()
            if (r3 > r9) goto L_0x0076
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.Object r1 = r1.f4676b
            java.lang.String r4 = ": Requested original size, but cached image is sampled."
            java.lang.String r1 = h.a.a(r3, r1, r4)
            r2.b(r8, r9, r1, r6)
        L_0x0076:
            r17 = r5
            goto L_0x01dc
        L_0x007a:
            r17 = r5
            goto L_0x01e2
        L_0x007e:
            java.util.Map<java.lang.String, java.lang.String> r2 = r2.f5035q
            java.lang.String r9 = "coil#transformation_size"
            java.lang.Object r2 = r2.get(r9)
            java.lang.String r2 = (java.lang.String) r2
            if (r2 == 0) goto L_0x0096
            java.lang.String r1 = r21.toString()
            boolean r1 = rg.d0.b(r2, r1)
            r17 = r5
            goto L_0x01e5
        L_0x0096:
            android.graphics.Bitmap r2 = r5.f5040a
            int r2 = r2.getWidth()
            android.graphics.Bitmap r6 = r5.f5040a
            int r6 = r6.getHeight()
            d4.a r9 = r3.f9924a
            boolean r10 = r9 instanceof d4.a.C0106a
            r11 = 2147483647(0x7fffffff, float:NaN)
            if (r10 == 0) goto L_0x00b0
            d4.a$a r9 = (d4.a.C0106a) r9
            int r9 = r9.f9917a
            goto L_0x00b1
        L_0x00b0:
            r9 = r11
        L_0x00b1:
            d4.a r10 = r3.f9925b
            boolean r12 = r10 instanceof d4.a.C0106a
            if (r12 == 0) goto L_0x00bc
            d4.a$a r10 = (d4.a.C0106a) r10
            int r10 = r10.f9917a
            goto L_0x00bd
        L_0x00bc:
            r10 = r11
        L_0x00bd:
            double r12 = t3.d.a(r2, r6, r9, r10, r4)
            boolean r14 = h4.f.a(r19)
            r16 = r7
            r15 = r8
            r7 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            if (r14 == 0) goto L_0x00f7
            double r7 = yf.h.k(r12, r7)
            r17 = r5
            double r4 = (double) r9
            double r0 = (double) r2
            double r0 = r0 * r7
            double r4 = r4 - r0
            double r0 = java.lang.Math.abs(r4)
            r4 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 <= 0) goto L_0x00f3
            double r0 = (double) r10
            double r4 = (double) r6
            double r7 = r7 * r4
            double r0 = r0 - r7
            double r0 = java.lang.Math.abs(r0)
            r4 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 > 0) goto L_0x00ef
            goto L_0x00f3
        L_0x00ef:
            r0 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            r4 = 1
            goto L_0x0128
        L_0x00f3:
            r0 = r18
            goto L_0x01e1
        L_0x00f7:
            r17 = r5
            android.graphics.Bitmap$Config[] r0 = h4.h.f11463a
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r9 == r0) goto L_0x0104
            if (r9 != r11) goto L_0x0102
            goto L_0x0104
        L_0x0102:
            r1 = 0
            goto L_0x0105
        L_0x0104:
            r1 = 1
        L_0x0105:
            if (r1 != 0) goto L_0x010f
            int r9 = r9 - r2
            int r1 = java.lang.Math.abs(r9)
            r4 = 1
            if (r1 > r4) goto L_0x0126
        L_0x010f:
            if (r10 == r0) goto L_0x0116
            if (r10 != r11) goto L_0x0114
            goto L_0x0116
        L_0x0114:
            r0 = 0
            goto L_0x0117
        L_0x0116:
            r0 = 1
        L_0x0117:
            if (r0 != 0) goto L_0x00f3
            int r10 = r10 - r6
            int r0 = java.lang.Math.abs(r10)
            r1 = 1
            if (r0 > r1) goto L_0x0125
            r0 = r18
            goto L_0x01df
        L_0x0125:
            r4 = r1
        L_0x0126:
            r0 = 4607182418800017408(0x3ff0000000000000, double:1.0)
        L_0x0128:
            int r0 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r0 != 0) goto L_0x012e
            r0 = r4
            goto L_0x012f
        L_0x012e:
            r0 = 0
        L_0x012f:
            java.lang.String r1 = ")."
            java.lang.String r5 = ": Cached image's request size ("
            java.lang.String r7 = ", "
            if (r0 != 0) goto L_0x0186
            if (r14 != 0) goto L_0x0186
            r0 = r18
            h4.p r4 = r0.f782c
            if (r4 == 0) goto L_0x01db
            int r8 = r4.a()
            r9 = 3
            if (r8 > r9) goto L_0x01db
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            r9 = r19
            java.lang.Object r9 = r9.f4676b
            r8.append(r9)
            r8.append(r5)
            r8.append(r2)
            r8.append(r7)
            r8.append(r6)
            java.lang.String r2 = ") does not exactly match the requested size ("
            r8.append(r2)
            d4.a r2 = r3.f9924a
            r8.append(r2)
            r8.append(r7)
            d4.a r2 = r3.f9925b
            r8.append(r2)
            r8.append(r7)
            r10 = r22
            r8.append(r10)
            r8.append(r1)
            java.lang.String r1 = r8.toString()
            r6 = 0
            r2 = 3
            r8 = r15
            r4.b(r8, r2, r1, r6)
            goto L_0x01dc
        L_0x0186:
            r0 = r18
            r9 = r19
            r10 = r22
            r8 = r15
            r14 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r11 = (r12 > r14 ? 1 : (r12 == r14 ? 0 : -1))
            if (r11 <= 0) goto L_0x01de
            if (r16 == 0) goto L_0x01de
            h4.p r4 = r0.f782c
            if (r4 == 0) goto L_0x01db
            int r11 = r4.a()
            r12 = 3
            if (r11 > r12) goto L_0x01db
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r11.<init>()
            java.lang.Object r9 = r9.f4676b
            r11.append(r9)
            r11.append(r5)
            r11.append(r2)
            r11.append(r7)
            r11.append(r6)
            java.lang.String r2 = ") is smaller than the requested size ("
            r11.append(r2)
            d4.a r2 = r3.f9924a
            r11.append(r2)
            r11.append(r7)
            d4.a r2 = r3.f9925b
            r11.append(r2)
            r11.append(r7)
            r11.append(r10)
            r11.append(r1)
            java.lang.String r1 = r11.toString()
            r6 = 0
            r2 = 3
            r4.b(r8, r2, r1, r6)
            goto L_0x01dc
        L_0x01db:
            r6 = 0
        L_0x01dc:
            r1 = 0
            goto L_0x01e5
        L_0x01de:
            r1 = r4
        L_0x01df:
            r2 = 0
            goto L_0x01e4
        L_0x01e1:
            r6 = 0
        L_0x01e2:
            r1 = 1
            r2 = r6
        L_0x01e4:
            r6 = r2
        L_0x01e5:
            if (r1 == 0) goto L_0x01e9
            r6 = r17
        L_0x01e9:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.c.a(c4.g, coil.memory.MemoryCache$Key, d4.e, coil.size.Scale):coil.memory.MemoryCache$b");
    }

    public final boolean b(MemoryCache.b bVar) {
        Object obj = bVar.f5041b.get("coil#is_sampled");
        Boolean bool = obj instanceof Boolean ? (Boolean) obj : null;
        if (bool != null) {
            return bool.booleanValue();
        }
        return false;
    }

    public final MemoryCache.Key c(g gVar, Object obj, c4.k kVar, b bVar) {
        String str;
        Map map;
        MemoryCache.Key key = gVar.f4679e;
        if (key != null) {
            return key;
        }
        bVar.e(gVar, obj);
        List<Pair<y3.b<? extends Object>, Class<? extends Object>>> list = this.f780a.getComponents().f16701c;
        int size = list.size();
        int i10 = 0;
        while (true) {
            if (i10 >= size) {
                str = null;
                break;
            }
            Pair pair = list.get(i10);
            y3.b bVar2 = (y3.b) pair.component1();
            if (((Class) pair.component2()).isAssignableFrom(obj.getClass())) {
                d0.e(bVar2, "null cannot be cast to non-null type coil.key.Keyer<kotlin.Any>");
                str = bVar2.a(obj, kVar);
                if (str != null) {
                    break;
                }
            }
            i10++;
        }
        bVar.g(gVar, str);
        if (str == null) {
            return null;
        }
        List<f4.c> list2 = gVar.f4686l;
        l lVar = gVar.D;
        if (lVar.f4745p.isEmpty()) {
            map = yf.p.S();
        } else {
            Map<String, l.b> map2 = lVar.f4745p;
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (Map.Entry next : map2.entrySet()) {
                String str2 = ((l.b) next.getValue()).f4748b;
                if (str2 != null) {
                    linkedHashMap.put(next.getKey(), str2);
                }
            }
            map = linkedHashMap;
        }
        if (list2.isEmpty() && map.isEmpty()) {
            return new MemoryCache.Key(str, (Map) null, 2);
        }
        Map X = yf.p.X(map);
        if (!list2.isEmpty()) {
            List<f4.c> list3 = gVar.f4686l;
            int size2 = list3.size();
            for (int i11 = 0; i11 < size2; i11++) {
                X.put(e.a("coil#transformation_", i11), list3.get(i11).b());
            }
            X.put("coil#transformation_size", kVar.f4732d.toString());
        }
        return new MemoryCache.Key(str, X);
    }

    public final n d(a.C0288a aVar, g gVar, MemoryCache.Key key, MemoryCache.b bVar) {
        BitmapDrawable bitmapDrawable = new BitmapDrawable(gVar.f4675a.getResources(), bVar.f5040a);
        DataSource dataSource = DataSource.MEMORY_CACHE;
        Object obj = bVar.f5041b.get("coil#disk_cache_key");
        String str = obj instanceof String ? (String) obj : null;
        boolean b10 = b(bVar);
        Bitmap.Config[] configArr = h.f11463a;
        return new n(bitmapDrawable, gVar, dataSource, key, str, b10, (aVar instanceof RealInterceptorChain) && ((RealInterceptorChain) aVar).f5033g);
    }
}
