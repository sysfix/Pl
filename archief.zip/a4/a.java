package a4;

import android.graphics.Bitmap;
import coil.memory.MemoryCache;
import java.util.Map;

/* compiled from: StrongMemoryCache.kt */
public final class a implements g {

    /* renamed from: a  reason: collision with root package name */
    public final h f779a;

    public a(h hVar) {
        this.f779a = hVar;
    }

    public void a(int i10) {
    }

    public MemoryCache.b b(MemoryCache.Key key) {
        return null;
    }

    public void c(MemoryCache.Key key, Bitmap bitmap, Map<String, ? extends Object> map) {
        this.f779a.c(key, bitmap, map, l7.a.j(bitmap));
    }
}
