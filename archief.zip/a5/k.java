package a5;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.baseflow.geolocator.errors.ErrorCodes;
import com.baseflow.geolocator.location.LocationAccuracy;
import com.google.protobuf.GeneratedMessageLite;
import h1.b;
import h1.c;
import h1.e;
import j1.g;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Locale;
import java.util.WeakHashMap;

/* compiled from: LocationManagerClient */
public class k implements j, b {

    /* renamed from: a  reason: collision with root package name */
    public final LocationManager f825a;

    /* renamed from: b  reason: collision with root package name */
    public final q f826b;

    /* renamed from: c  reason: collision with root package name */
    public final m f827c;

    /* renamed from: d  reason: collision with root package name */
    public Context f828d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f829e = false;

    /* renamed from: f  reason: collision with root package name */
    public Location f830f;

    /* renamed from: g  reason: collision with root package name */
    public String f831g;

    /* renamed from: h  reason: collision with root package name */
    public r f832h;

    /* renamed from: i  reason: collision with root package name */
    public z4.a f833i;

    /* compiled from: LocationManagerClient */
    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f834a;

        /* JADX WARNING: Can't wrap try/catch for region: R(14:0|1|2|3|4|5|6|7|8|9|10|11|12|14) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            /*
                com.baseflow.geolocator.location.LocationAccuracy[] r0 = com.baseflow.geolocator.location.LocationAccuracy.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f834a = r0
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.lowest     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f834a     // Catch:{ NoSuchFieldError -> 0x001d }
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.low     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f834a     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.high     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f834a     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.best     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r0 = f834a     // Catch:{ NoSuchFieldError -> 0x003e }
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.bestForNavigation     // Catch:{ NoSuchFieldError -> 0x003e }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                int[] r0 = f834a     // Catch:{ NoSuchFieldError -> 0x0049 }
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.medium     // Catch:{ NoSuchFieldError -> 0x0049 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0049 }
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: a5.k.a.<clinit>():void");
        }
    }

    public k(Context context, m mVar) {
        this.f825a = (LocationManager) context.getSystemService("location");
        this.f827c = mVar;
        this.f828d = context;
        this.f826b = new q(context, mVar);
    }

    public static boolean g(Location location, Location location2) {
        if (location2 == null) {
            return true;
        }
        long time = location.getTime() - location2.getTime();
        boolean z10 = time > 120000;
        boolean z11 = time < -120000;
        boolean z12 = time > 0;
        if (z10) {
            return true;
        }
        if (z11) {
            return false;
        }
        float accuracy = (float) ((int) (location.getAccuracy() - location2.getAccuracy()));
        boolean z13 = accuracy > 0.0f;
        boolean z14 = accuracy < 0.0f;
        boolean z15 = accuracy > 200.0f;
        boolean equals = location.getProvider() != null ? location.getProvider().equals(location2.getProvider()) : false;
        if (z14) {
            return true;
        }
        if (!z12 || z13) {
            return z12 && !z15 && equals;
        }
        return true;
    }

    public boolean a(int i10, int i11) {
        return false;
    }

    public /* synthetic */ boolean b(Context context) {
        return i.a(this, context);
    }

    public void c(r rVar, z4.a aVar) {
        Location location = null;
        for (String lastKnownLocation : this.f825a.getProviders(true)) {
            Location lastKnownLocation2 = this.f825a.getLastKnownLocation(lastKnownLocation);
            if (lastKnownLocation2 != null && g(lastKnownLocation2, location)) {
                location = lastKnownLocation2;
            }
        }
        rVar.a(location);
    }

    @SuppressLint({"MissingPermission"})
    public void d(Activity activity, r rVar, z4.a aVar) {
        int i10;
        long j10;
        float f10;
        String str;
        z4.a aVar2 = aVar;
        if (!b(this.f828d)) {
            aVar2.b(ErrorCodes.locationServicesDisabled);
            return;
        }
        this.f832h = rVar;
        this.f833i = aVar2;
        LocationAccuracy locationAccuracy = LocationAccuracy.best;
        m mVar = this.f827c;
        if (mVar != null) {
            float f11 = (float) mVar.f836b;
            LocationAccuracy locationAccuracy2 = mVar.f835a;
            if (locationAccuracy2 == LocationAccuracy.lowest) {
                j10 = Long.MAX_VALUE;
            } else {
                j10 = mVar.f837c;
            }
            int i11 = a.f834a[locationAccuracy2.ordinal()];
            i10 = (i11 == 1 || i11 == 2) ? 104 : (i11 == 3 || i11 == 4 || i11 == 5) ? 100 : 102;
            LocationAccuracy locationAccuracy3 = locationAccuracy2;
            f10 = f11;
            locationAccuracy = locationAccuracy3;
        } else {
            j10 = 0;
            f10 = 0.0f;
            i10 = 102;
        }
        List<String> providers = this.f825a.getProviders(true);
        boolean z10 = false;
        if (locationAccuracy == LocationAccuracy.lowest) {
            str = "passive";
        } else {
            str = "fused";
            if (!providers.contains(str) || Build.VERSION.SDK_INT < 31) {
                str = "gps";
                if (!providers.contains(str)) {
                    str = "network";
                    if (!providers.contains(str)) {
                        str = !providers.isEmpty() ? providers.get(0) : null;
                    }
                }
            }
        }
        this.f831g = str;
        if (str == null) {
            aVar2.b(ErrorCodes.locationServicesDisabled);
            return;
        }
        e.c cVar = new e.c(j10);
        cVar.f11348c = f10;
        if (f10 < 0.0f) {
            throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%f, %f] (too low)", new Object[]{"minUpdateDistanceMeters", Float.valueOf(0.0f), Float.valueOf(Float.MAX_VALUE)}));
        } else if (f10 <= Float.MAX_VALUE) {
            cVar.f11348c = f10;
            boolean z11 = i10 == 104 || i10 == 102 || i10 == 100;
            Object[] objArr = {Integer.valueOf(i10)};
            if (z11) {
                cVar.f11347b = i10;
                if (cVar.f11346a != Long.MAX_VALUE) {
                    z10 = true;
                }
                l7.a.g(z10, "passive location requests must have an explicit minimum update interval");
                long j11 = cVar.f11346a;
                int i12 = cVar.f11347b;
                long min = Math.min(-1, j11);
                float f12 = cVar.f11348c;
                e eVar = new e(j11, i12, Long.MAX_VALUE, GeneratedMessageLite.UNINITIALIZED_SERIALIZED_SIZE, min, f12, 0);
                this.f829e = true;
                this.f826b.b();
                LocationManager locationManager = this.f825a;
                String str2 = this.f831g;
                Looper mainLooper = Looper.getMainLooper();
                WeakHashMap<Object, WeakReference<c.C0140c>> weakHashMap = c.f11326a;
                if (Build.VERSION.SDK_INT >= 31) {
                    c.b.c(locationManager, str2, e.b.a(eVar), new g(new Handler(mainLooper)), this);
                } else if (!c.a.a(locationManager, str2, eVar, this, mainLooper)) {
                    locationManager.requestLocationUpdates(str2, j11, f12, this, mainLooper);
                }
            } else {
                throw new IllegalArgumentException(String.format("quality must be a defined QUALITY constant, not %d", objArr));
            }
        } else {
            throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%f, %f] (too high)", new Object[]{"minUpdateDistanceMeters", Float.valueOf(0.0f), Float.valueOf(Float.MAX_VALUE)}));
        }
    }

    @SuppressLint({"MissingPermission"})
    public void e() {
        this.f829e = false;
        this.f826b.c();
        this.f825a.removeUpdates(this);
    }

    public void f(n nVar) {
        if (this.f825a == null) {
            ((b) nVar).b(false);
            return;
        }
        ((b) nVar).b(b(this.f828d));
    }

    public /* synthetic */ void onFlushComplete(int i10) {
        h1.a.a(this, i10);
    }

    public synchronized void onLocationChanged(Location location) {
        if (g(location, this.f830f)) {
            this.f830f = location;
            if (this.f832h != null) {
                this.f826b.a(location);
                this.f832h.a(this.f830f);
            }
        }
    }

    public /* synthetic */ void onLocationChanged(List list) {
        h1.a.b(this, list);
    }

    @SuppressLint({"MissingPermission"})
    public void onProviderDisabled(String str) {
        if (str.equals(this.f831g)) {
            if (this.f829e) {
                this.f825a.removeUpdates(this);
            }
            z4.a aVar = this.f833i;
            if (aVar != null) {
                aVar.b(ErrorCodes.locationServicesDisabled);
            }
            this.f831g = null;
        }
    }

    public void onProviderEnabled(String str) {
    }

    @TargetApi(28)
    public void onStatusChanged(String str, int i10, Bundle bundle) {
        if (i10 != 2 && i10 == 0) {
            onProviderDisabled(str);
        }
    }
}
