package a5;

import androidx.lifecycle.CoroutineLiveDataKt;
import com.baseflow.geolocator.location.LocationAccuracy;
import java.util.Map;

/* compiled from: LocationOptions */
public class m {

    /* renamed from: a  reason: collision with root package name */
    public final LocationAccuracy f835a;

    /* renamed from: b  reason: collision with root package name */
    public final long f836b;

    /* renamed from: c  reason: collision with root package name */
    public final long f837c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f838d;

    public m(LocationAccuracy locationAccuracy, long j10, long j11, boolean z10) {
        this.f835a = locationAccuracy;
        this.f836b = j10;
        this.f837c = j11;
        this.f838d = z10;
    }

    public static m a(Map<String, Object> map) {
        if (map == null) {
            return new m(LocationAccuracy.best, 0, CoroutineLiveDataKt.DEFAULT_TIMEOUT, false);
        }
        Integer num = (Integer) map.get("accuracy");
        Integer num2 = (Integer) map.get("distanceFilter");
        Integer num3 = (Integer) map.get("timeInterval");
        Boolean bool = (Boolean) map.get("useMSLAltitude");
        LocationAccuracy locationAccuracy = LocationAccuracy.best;
        boolean z10 = true;
        if (num != null) {
            int intValue = num.intValue();
            if (intValue == 0) {
                locationAccuracy = LocationAccuracy.lowest;
            } else if (intValue == 1) {
                locationAccuracy = LocationAccuracy.low;
            } else if (intValue == 2) {
                locationAccuracy = LocationAccuracy.medium;
            } else if (intValue == 3) {
                locationAccuracy = LocationAccuracy.high;
            } else if (intValue == 5) {
                locationAccuracy = LocationAccuracy.bestForNavigation;
            }
        }
        LocationAccuracy locationAccuracy2 = locationAccuracy;
        long intValue2 = num2 != null ? (long) num2.intValue() : 0;
        long intValue3 = num3 != null ? (long) num3.intValue() : CoroutineLiveDataKt.DEFAULT_TIMEOUT;
        if (bool == null || !bool.booleanValue()) {
            z10 = false;
        }
        return new m(locationAccuracy2, intValue2, intValue3, z10);
    }
}
