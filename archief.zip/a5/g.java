package a5;

import android.content.Context;
import android.content.Intent;
import com.google.android.gms.common.a;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import re.l;
import x6.c;

/* compiled from: GeolocationManager */
public class g implements l {

    /* renamed from: a  reason: collision with root package name */
    public final List<j> f824a = new CopyOnWriteArrayList();

    public boolean a(int i10, int i11, Intent intent) {
        for (j a10 : this.f824a) {
            if (a10.a(i10, i11)) {
                return true;
            }
        }
        return false;
    }

    public j b(Context context, boolean z10, m mVar) {
        if (z10) {
            return new k(context, mVar);
        }
        boolean z11 = false;
        try {
            Object obj = a.f6412c;
            if (a.f6413d.b(context, c.f18309a) == 0) {
                z11 = true;
            }
        } catch (NoClassDefFoundError unused) {
        }
        if (z11) {
            return new f(context, mVar);
        }
        return new k(context, mVar);
    }

    public void c(j jVar) {
        this.f824a.remove(jVar);
        jVar.e();
    }
}
