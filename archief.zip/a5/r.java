package a5;

import android.location.Location;

@FunctionalInterface
/* compiled from: PositionChangedCallback */
public interface r {
    void a(Location location);
}
