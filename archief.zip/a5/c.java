package a5;

import com.android.billingclient.api.a;

/* compiled from: ForegroundNotificationOptions */
public class c {

    /* renamed from: a  reason: collision with root package name */
    public final String f801a;

    /* renamed from: b  reason: collision with root package name */
    public final String f802b;

    /* renamed from: c  reason: collision with root package name */
    public final a f803c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f804d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f805e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f806f;

    public c(String str, String str2, a aVar, boolean z10, boolean z11, boolean z12) {
        this.f801a = str;
        this.f802b = str2;
        this.f803c = aVar;
        this.f804d = z10;
        this.f805e = z11;
        this.f806f = z12;
    }
}
