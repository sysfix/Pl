package a5;

import a1.r;
import a1.v;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/* compiled from: BackgroundNotification */
public class a {

    /* renamed from: a  reason: collision with root package name */
    public final Context f797a;

    /* renamed from: b  reason: collision with root package name */
    public final Integer f798b;

    /* renamed from: c  reason: collision with root package name */
    public r f799c;

    public a(Context context, String str, Integer num, c cVar) {
        this.f797a = context;
        this.f798b = num;
        r rVar = new r(context, str);
        rVar.f717j = 1;
        this.f799c = rVar;
        a(cVar, false);
    }

    public final void a(c cVar, boolean z10) {
        com.android.billingclient.api.a aVar = cVar.f803c;
        int identifier = this.f797a.getResources().getIdentifier(aVar.f5364a, aVar.f5365b, this.f797a.getPackageName());
        if (identifier == 0) {
            this.f797a.getResources().getIdentifier("ic_launcher.png", "mipmap", this.f797a.getPackageName());
        }
        r rVar = this.f799c;
        rVar.d(cVar.f801a);
        rVar.f727t.icon = identifier;
        rVar.c(cVar.f802b);
        Intent launchIntentForPackage = this.f797a.getPackageManager().getLaunchIntentForPackage(this.f797a.getPackageName());
        PendingIntent pendingIntent = null;
        if (launchIntentForPackage != null) {
            launchIntentForPackage.setPackage((String) null);
            launchIntentForPackage.setFlags(270532608);
            int i10 = 134217728;
            if (Build.VERSION.SDK_INT > 23) {
                i10 = 201326592;
            }
            pendingIntent = PendingIntent.getActivity(this.f797a, 0, launchIntentForPackage, i10);
        }
        rVar.f714g = pendingIntent;
        rVar.e(2, cVar.f806f);
        this.f799c = rVar;
        if (z10) {
            new v(this.f797a).b(this.f798b.intValue(), this.f799c.a());
        }
    }
}
