package a5;

import android.app.Activity;
import android.content.Context;
import z4.a;

/* compiled from: LocationClient */
public interface j {
    boolean a(int i10, int i11);

    boolean b(Context context);

    void c(r rVar, a aVar);

    void d(Activity activity, r rVar, a aVar);

    void e();

    void f(n nVar);
}
