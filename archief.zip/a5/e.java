package a5;

import android.app.Activity;
import android.content.ContentValues;
import android.content.IntentSender;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Base64;
import b8.d;
import b8.g;
import b8.j;
import com.baseflow.geolocator.errors.ErrorCodes;
import com.google.android.datatransport.runtime.firebase.transport.LogEventDropped;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigClientException;
import com.google.firebase.remoteconfig.internal.c;
import f6.b;
import fd.f;
import gd.k;
import gd.q;
import gd.s;
import hd.i;
import i6.i;
import i6.m;
import i6.n;
import i6.r;
import id.g;
import id.h;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ThreadPoolExecutor;
import l6.a;
import p6.n;
import q6.a;

public final /* synthetic */ class e implements d, a.C0223a, n.b, b8.a, q, hd.a {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ int f809p = 0;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ Object f810q;

    /* renamed from: r  reason: collision with root package name */
    public final /* synthetic */ Object f811r;

    /* renamed from: s  reason: collision with root package name */
    public final /* synthetic */ Object f812s;

    public /* synthetic */ e(f fVar, Activity activity, z4.a aVar) {
        this.f810q = fVar;
        this.f811r = activity;
        this.f812s = aVar;
    }

    public /* synthetic */ e(cb.d dVar, g gVar, g gVar2) {
        this.f810q = dVar;
        this.f811r = gVar;
        this.f812s = gVar2;
    }

    public /* synthetic */ e(c cVar, g gVar, g gVar2) {
        this.f810q = cVar;
        this.f811r = gVar;
        this.f812s = gVar2;
    }

    public /* synthetic */ e(k kVar, h hVar, ad.c cVar) {
        this.f810q = kVar;
        this.f811r = hVar;
        this.f812s = cVar;
    }

    public /* synthetic */ e(i iVar, h hVar, ad.d dVar) {
        this.f810q = iVar;
        this.f811r = hVar;
        this.f812s = dVar;
    }

    public /* synthetic */ e(g.a aVar, ThreadPoolExecutor threadPoolExecutor, s sVar) {
        this.f810q = aVar;
        this.f811r = threadPoolExecutor;
        this.f812s = sVar;
    }

    public /* synthetic */ e(n6.a aVar, r rVar, i6.n nVar) {
        this.f810q = aVar;
        this.f811r = rVar;
        this.f812s = nVar;
    }

    public /* synthetic */ e(n nVar, i6.n nVar2, r rVar) {
        this.f810q = nVar;
        this.f811r = nVar2;
        this.f812s = rVar;
    }

    public /* synthetic */ e(n nVar, String str, String str2) {
        this.f810q = nVar;
        this.f811r = str;
        this.f812s = str2;
    }

    public /* synthetic */ e(n nVar, List list, r rVar) {
        this.f810q = nVar;
        this.f811r = list;
        this.f812s = rVar;
    }

    public /* synthetic */ e(n nVar, Map map, a.C0184a aVar) {
        this.f810q = nVar;
        this.f811r = map;
        this.f812s = aVar;
    }

    public Object apply(Object obj) {
        Cursor rawQuery;
        long j10;
        b bVar;
        b bVar2;
        int i10 = 2;
        switch (this.f809p) {
            case 2:
                n nVar = (n) this.f810q;
                i6.n nVar2 = (i6.n) this.f811r;
                r rVar = (r) this.f812s;
                SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
                b bVar3 = n.f15429u;
                if (nVar.g().compileStatement("PRAGMA page_size").simpleQueryForLong() * nVar.g().compileStatement("PRAGMA page_count").simpleQueryForLong() >= nVar.f15433s.e()) {
                    nVar.b(1, LogEventDropped.Reason.CACHE_FULL, nVar2.h());
                    return -1L;
                }
                Long h10 = nVar.h(sQLiteDatabase, rVar);
                if (h10 != null) {
                    j10 = h10.longValue();
                } else {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("backend_name", rVar.b());
                    contentValues.put("priority", Integer.valueOf(s6.a.a(rVar.d())));
                    contentValues.put("next_request_ms", 0);
                    if (rVar.c() != null) {
                        contentValues.put("extras", Base64.encodeToString(rVar.c(), 0));
                    }
                    j10 = sQLiteDatabase.insert("transport_contexts", (String) null, contentValues);
                }
                int d10 = nVar.f15433s.d();
                byte[] bArr = nVar2.e().f11889b;
                boolean z10 = bArr.length <= d10;
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put("context_id", Long.valueOf(j10));
                contentValues2.put("transport_name", nVar2.h());
                contentValues2.put("timestamp_ms", Long.valueOf(nVar2.f()));
                contentValues2.put("uptime_ms", Long.valueOf(nVar2.i()));
                contentValues2.put("payload_encoding", nVar2.e().f11888a.f10744a);
                contentValues2.put("code", nVar2.d());
                contentValues2.put("num_attempts", 0);
                contentValues2.put("inline", Boolean.valueOf(z10));
                contentValues2.put("payload", z10 ? bArr : new byte[0]);
                long insert = sQLiteDatabase.insert("events", (String) null, contentValues2);
                if (!z10) {
                    int ceil = (int) Math.ceil(((double) bArr.length) / ((double) d10));
                    for (int i11 = 1; i11 <= ceil; i11++) {
                        byte[] copyOfRange = Arrays.copyOfRange(bArr, (i11 - 1) * d10, Math.min(i11 * d10, bArr.length));
                        ContentValues contentValues3 = new ContentValues();
                        contentValues3.put("event_id", Long.valueOf(insert));
                        contentValues3.put("sequence_num", Integer.valueOf(i11));
                        contentValues3.put("bytes", copyOfRange);
                        sQLiteDatabase.insert("event_payloads", (String) null, contentValues3);
                    }
                }
                for (Map.Entry next : Collections.unmodifiableMap(nVar2.c()).entrySet()) {
                    ContentValues contentValues4 = new ContentValues();
                    contentValues4.put("event_id", Long.valueOf(insert));
                    contentValues4.put("name", (String) next.getKey());
                    contentValues4.put("value", (String) next.getValue());
                    sQLiteDatabase.insert("event_metadata", (String) null, contentValues4);
                }
                return Long.valueOf(insert);
            case 3:
                n nVar3 = (n) this.f810q;
                SQLiteDatabase sQLiteDatabase2 = (SQLiteDatabase) obj;
                b bVar4 = n.f15429u;
                Objects.requireNonNull(nVar3);
                sQLiteDatabase2.compileStatement((String) this.f811r).execute();
                n.o(sQLiteDatabase2.rawQuery((String) this.f812s, (String[]) null), new p6.k(nVar3, 2));
                sQLiteDatabase2.compileStatement("DELETE FROM events WHERE num_attempts >= 16").execute();
                return null;
            case 4:
                n nVar4 = (n) this.f810q;
                List list = (List) this.f811r;
                r rVar2 = (r) this.f812s;
                Cursor cursor = (Cursor) obj;
                b bVar5 = n.f15429u;
                Objects.requireNonNull(nVar4);
                while (cursor.moveToNext()) {
                    long j11 = cursor.getLong(0);
                    boolean z11 = cursor.getInt(7) != 0;
                    n.a a10 = i6.n.a();
                    a10.f(cursor.getString(1));
                    a10.e(cursor.getLong(i10));
                    a10.g(cursor.getLong(3));
                    if (z11) {
                        String string = cursor.getString(4);
                        if (string == null) {
                            bVar2 = p6.n.f15429u;
                        } else {
                            bVar2 = new b(string);
                        }
                        a10.d(new m(bVar2, cursor.getBlob(5)));
                    } else {
                        String string2 = cursor.getString(4);
                        if (string2 == null) {
                            bVar = p6.n.f15429u;
                        } else {
                            bVar = new b(string2);
                        }
                        a10.d(new m(bVar, (byte[]) p6.n.o(nVar4.g().query("event_payloads", new String[]{"bytes"}, "event_id = ?", new String[]{String.valueOf(j11)}, (String) null, (String) null, "sequence_num"), a.b.D)));
                    }
                    if (!cursor.isNull(6)) {
                        ((i.b) a10).f11866b = Integer.valueOf(cursor.getInt(6));
                    }
                    list.add(new p6.b(j11, rVar2, a10.b()));
                    i10 = 2;
                }
                return null;
            default:
                p6.n nVar5 = (p6.n) this.f810q;
                Map map = (Map) this.f811r;
                a.C0184a aVar = (a.C0184a) this.f812s;
                Cursor cursor2 = (Cursor) obj;
                b bVar6 = p6.n.f15429u;
                Objects.requireNonNull(nVar5);
                while (cursor2.moveToNext()) {
                    String string3 = cursor2.getString(0);
                    int i12 = cursor2.getInt(1);
                    LogEventDropped.Reason reason = LogEventDropped.Reason.REASON_UNKNOWN;
                    if (i12 != reason.getNumber()) {
                        LogEventDropped.Reason reason2 = LogEventDropped.Reason.MESSAGE_TOO_OLD;
                        if (i12 != reason2.getNumber()) {
                            reason2 = LogEventDropped.Reason.CACHE_FULL;
                            if (i12 != reason2.getNumber()) {
                                reason2 = LogEventDropped.Reason.PAYLOAD_TOO_BIG;
                                if (i12 != reason2.getNumber()) {
                                    reason2 = LogEventDropped.Reason.MAX_RETRIES_REACHED;
                                    if (i12 != reason2.getNumber()) {
                                        reason2 = LogEventDropped.Reason.INVALID_PAYLOD;
                                        if (i12 != reason2.getNumber()) {
                                            reason2 = LogEventDropped.Reason.SERVER_ERROR;
                                            if (i12 != reason2.getNumber()) {
                                                m6.a.a("SQLiteEventStore", "%n is not valid. No matched LogEventDropped-Reason found. Treated it as REASON_UNKNOWN", Integer.valueOf(i12));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        reason = reason2;
                    }
                    long j12 = cursor2.getLong(2);
                    if (!map.containsKey(string3)) {
                        map.put(string3, new ArrayList());
                    }
                    int i13 = LogEventDropped.f6279c;
                    ((List) map.get(string3)).add(new LogEventDropped(j12, reason));
                }
                for (Map.Entry entry : map.entrySet()) {
                    int i14 = l6.c.f14074c;
                    new ArrayList();
                    aVar.f14069b.add(new l6.c((String) entry.getKey(), Collections.unmodifiableList((List) entry.getValue())));
                }
                long a11 = nVar5.f15431q.a();
                SQLiteDatabase g10 = nVar5.g();
                g10.beginTransaction();
                try {
                    rawQuery = g10.rawQuery("SELECT last_metrics_upload_ms FROM global_log_event_state LIMIT 1", new String[0]);
                    b bVar7 = p6.n.f15429u;
                    rawQuery.moveToNext();
                    long j13 = rawQuery.getLong(0);
                    int i15 = l6.e.f14080c;
                    l6.e eVar = new l6.e(j13, a11);
                    rawQuery.close();
                    l6.e eVar2 = eVar;
                    g10.setTransactionSuccessful();
                    g10.endTransaction();
                    aVar.f14068a = eVar2;
                    int i16 = l6.b.f14072b;
                    int i17 = l6.d.f14077c;
                    aVar.f14070c = new l6.b(new l6.d(nVar5.g().compileStatement("PRAGMA page_size").simpleQueryForLong() * nVar5.g().compileStatement("PRAGMA page_count").simpleQueryForLong(), ((p6.a) p6.e.f15413a).f15405b));
                    aVar.f14071d = nVar5.f15434t.get();
                    return new l6.a(aVar.f14068a, Collections.unmodifiableList(aVar.f14069b), aVar.f14070c, aVar.f14071d);
                } catch (Throwable th2) {
                    g10.endTransaction();
                    throw th2;
                }
        }
    }

    public void b(byte[] bArr) {
        dd.c cVar;
        boolean z10 = true;
        switch (this.f809p) {
            case 8:
                k kVar = (k) this.f810q;
                h hVar = (h) this.f811r;
                ad.c cVar2 = (ad.c) this.f812s;
                Objects.requireNonNull(kVar);
                try {
                    hVar.b(bArr);
                    if (cVar2 != null) {
                        dd.m mVar = hVar.f12037b;
                        if (mVar == null || mVar.f10053b != mVar.f10054c.size()) {
                            z10 = false;
                        }
                        if (z10) {
                            kVar.f11008a.o(26);
                            cVar2.f(hVar.f12037b);
                            return;
                        }
                        return;
                    }
                    return;
                } catch (Exception e10) {
                    e10.printStackTrace();
                    kVar.f11008a.o(26);
                    if (cVar2 != null) {
                        cVar2.f(null);
                        return;
                    }
                    return;
                }
            case 9:
                hd.i iVar = (hd.i) this.f810q;
                h hVar2 = (h) this.f811r;
                ad.d dVar = (ad.d) this.f812s;
                Objects.requireNonNull(iVar);
                try {
                    hVar2.c(bArr);
                    if (dVar != null) {
                        f fVar = hVar2.f12038c;
                        if (fVar == null || fVar.f10793h != fVar.f10794i.size()) {
                            z10 = false;
                        }
                        if (z10) {
                            iVar.f11644b.g(11);
                            dVar.b(hVar2.f12038c);
                            return;
                        }
                        return;
                    }
                    return;
                } catch (Exception e11) {
                    id.k.d("WifiAgentImpl", e11, "wifi getFileList Error", new Object[0]);
                    iVar.f11644b.g(11);
                    if (dVar != null) {
                        dVar.b(null);
                        return;
                    }
                    return;
                }
            default:
                g.a aVar = (g.a) this.f810q;
                ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) this.f811r;
                s sVar = (s) this.f812s;
                Objects.requireNonNull(aVar);
                if (!threadPoolExecutor.isShutdown()) {
                    threadPoolExecutor.shutdown();
                    id.k.e("OtaPushHelper", "sendFinish executorService purge isResult", new Object[0]);
                    aVar.f12028p = true;
                    try {
                        cVar = new dd.c(bArr);
                    } catch (Exception e12) {
                        e12.printStackTrace();
                        cVar = null;
                    }
                    if (cVar != null) {
                        long j10 = cVar.f10027b;
                        id.g gVar = id.g.this;
                        if (j10 == gVar.f12009a && !gVar.f12018j) {
                            int i10 = cVar.f10028c;
                            if (i10 != 2) {
                                gVar.f12017i = false;
                                RandomAccessFile randomAccessFile = gVar.f12015g;
                                if (randomAccessFile != null) {
                                    try {
                                        randomAccessFile.close();
                                    } catch (IOException unused) {
                                    }
                                    id.g.this.f12015g = null;
                                }
                                id.k.e("OtaPushHelper", "removeResponse OtaPushCallback", new Object[0]);
                                sVar.o(52);
                                if (i10 == 0) {
                                    ad.a aVar2 = id.g.this.f12014f;
                                    if (aVar2 != null) {
                                        aVar2.otaPushFinish();
                                        return;
                                    }
                                    return;
                                }
                                id.g.this.b(i10);
                                return;
                            }
                            id.k.e("OtaPushHelper", "status=2 waiting call message", new Object[0]);
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
        }
    }

    public Object execute() {
        n6.a aVar = (n6.a) this.f810q;
        r rVar = (r) this.f811r;
        aVar.f14649d.v(rVar, (i6.n) this.f812s);
        aVar.f14646a.a(rVar, 1);
        return null;
    }

    public void f(Exception exc) {
        f fVar = (f) this.f810q;
        Activity activity = (Activity) this.f811r;
        z4.a aVar = (z4.a) this.f812s;
        Objects.requireNonNull(fVar);
        if (exc instanceof ResolvableApiException) {
            if (activity == null) {
                aVar.b(ErrorCodes.locationServicesDisabled);
                return;
            }
            ResolvableApiException resolvableApiException = (ResolvableApiException) exc;
            if (resolvableApiException.getStatusCode() == 6) {
                try {
                    resolvableApiException.startResolutionForResult(activity, fVar.f817e);
                } catch (IntentSender.SendIntentException unused) {
                    aVar.b(ErrorCodes.locationServicesDisabled);
                }
            } else {
                aVar.b(ErrorCodes.locationServicesDisabled);
            }
        } else if (((ApiException) exc).getStatusCode() == 8502) {
            fVar.h(fVar.f818f);
        } else {
            aVar.b(ErrorCodes.locationServicesDisabled);
        }
    }

    public Object k(b8.g gVar) {
        switch (this.f809p) {
            case 6:
                cb.d dVar = (cb.d) this.f810q;
                b8.g gVar2 = (b8.g) this.f811r;
                b8.g gVar3 = (b8.g) this.f812s;
                Objects.requireNonNull(dVar);
                if (!gVar2.m() || gVar2.i() == null) {
                    return j.e(Boolean.FALSE);
                }
                db.c cVar = (db.c) gVar2.i();
                if (gVar3.m()) {
                    db.c cVar2 = (db.c) gVar3.i();
                    if (!(cVar2 == null || !cVar.f9994c.equals(cVar2.f9994c))) {
                        return j.e(Boolean.FALSE);
                    }
                }
                return dVar.f4860d.c(cVar).f(dVar.f4858b, new cb.c(dVar, 1));
            default:
                c cVar3 = (c) this.f810q;
                b8.g gVar4 = (b8.g) this.f811r;
                b8.g gVar5 = (b8.g) this.f812s;
                int[] iArr = c.f9130p;
                Objects.requireNonNull(cVar3);
                if (!gVar4.m()) {
                    return j.d(new FirebaseRemoteConfigClientException("Firebase Installations failed to get installation auth token for config update listener connection.", (Throwable) gVar4.h()));
                }
                if (!gVar5.m()) {
                    return j.d(new FirebaseRemoteConfigClientException("Firebase Installations failed to get installation ID for config update listener connection.", (Throwable) gVar5.h()));
                }
                try {
                    HttpURLConnection httpURLConnection = (HttpURLConnection) cVar3.d().openConnection();
                    cVar3.k(httpURLConnection, (String) gVar5.i(), ((com.google.firebase.installations.b) gVar4.i()).a());
                    return j.e(httpURLConnection);
                } catch (IOException e10) {
                    return j.d(new FirebaseRemoteConfigClientException("Failed to open HTTP stream connection", (Throwable) e10));
                }
        }
    }
}
