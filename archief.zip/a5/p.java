package a5;

import android.location.OnNmeaMessageListener;
import java.util.Calendar;
import java.util.Objects;

public final /* synthetic */ class p implements OnNmeaMessageListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f841a;

    public /* synthetic */ p(q qVar) {
        this.f841a = qVar;
    }

    public final void onNmeaMessage(String str, long j10) {
        q qVar = this.f841a;
        Objects.requireNonNull(qVar);
        if (str.startsWith("$GPGGA")) {
            qVar.f845d = str;
            qVar.f846e = Calendar.getInstance();
        }
    }
}
