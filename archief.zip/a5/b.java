package a5;

import com.baseflow.geolocator.errors.ErrorCodes;
import re.j;

/* compiled from: FlutterLocationServiceListener */
public class b implements n {

    /* renamed from: a  reason: collision with root package name */
    public j.d f800a;

    public b(j.d dVar) {
        this.f800a = dVar;
    }

    public void a(ErrorCodes errorCodes) {
        this.f800a.b(errorCodes.toString(), errorCodes.toDescription(), (Object) null);
    }

    public void b(boolean z10) {
        this.f800a.a(Boolean.valueOf(z10));
    }
}
