package a5;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import com.baseflow.geolocator.location.ServiceStatus;
import re.d;

/* compiled from: LocationServiceStatusReceiver */
public class o extends BroadcastReceiver {

    /* renamed from: a  reason: collision with root package name */
    public final d.b f839a;

    /* renamed from: b  reason: collision with root package name */
    public ServiceStatus f840b;

    public o(d.b bVar) {
        this.f839a = bVar;
    }

    public void onReceive(Context context, Intent intent) {
        if ("android.location.PROVIDERS_CHANGED".equals(intent.getAction())) {
            LocationManager locationManager = (LocationManager) context.getSystemService("location");
            boolean isProviderEnabled = locationManager.isProviderEnabled("gps");
            boolean isProviderEnabled2 = locationManager.isProviderEnabled("network");
            if (isProviderEnabled || isProviderEnabled2) {
                ServiceStatus serviceStatus = this.f840b;
                if (serviceStatus == null || serviceStatus == ServiceStatus.disabled) {
                    ServiceStatus serviceStatus2 = ServiceStatus.enabled;
                    this.f840b = serviceStatus2;
                    this.f839a.a(Integer.valueOf(serviceStatus2.ordinal()));
                    return;
                }
                return;
            }
            ServiceStatus serviceStatus3 = this.f840b;
            if (serviceStatus3 == null || serviceStatus3 == ServiceStatus.enabled) {
                ServiceStatus serviceStatus4 = ServiceStatus.disabled;
                this.f840b = serviceStatus4;
                this.f839a.a(Integer.valueOf(serviceStatus4.ordinal()));
            }
        }
    }
}
