package a5;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.WorkSource;
import b8.g;
import b8.r;
import com.baseflow.geolocator.errors.ErrorCodes;
import com.baseflow.geolocator.location.LocationAccuracy;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.internal.c;
import com.google.android.gms.common.api.internal.e;
import com.google.android.gms.internal.location.h;
import com.google.android.gms.internal.location.j;
import com.google.android.gms.internal.location.zzd;
import com.google.android.gms.internal.play_billing.zzip;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.common.collect.MapMakerInternalMap;
import com.google.protobuf.GeneratedMessageLite;
import i.d;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.Executor;
import u7.c;
import z6.a0;
import z6.b0;
import z6.c0;
import z6.d0;
import z6.i;

/* compiled from: FusedLocationClient */
public class f implements j {

    /* renamed from: a  reason: collision with root package name */
    public final Context f813a;

    /* renamed from: b  reason: collision with root package name */
    public final u7.b f814b;

    /* renamed from: c  reason: collision with root package name */
    public final u7.a f815c;

    /* renamed from: d  reason: collision with root package name */
    public final q f816d;

    /* renamed from: e  reason: collision with root package name */
    public final int f817e;

    /* renamed from: f  reason: collision with root package name */
    public final m f818f;

    /* renamed from: g  reason: collision with root package name */
    public z4.a f819g;

    /* renamed from: h  reason: collision with root package name */
    public r f820h;

    /* compiled from: FusedLocationClient */
    public class a extends u7.b {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ Context f821a;

        public a(Context context) {
            this.f821a = context;
        }

        public synchronized void a(LocationAvailability locationAvailability) {
            z4.a aVar;
            if (!locationAvailability.p1() && !f.this.b(this.f821a) && (aVar = f.this.f819g) != null) {
                aVar.b(ErrorCodes.locationServicesDisabled);
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:8:0x0025, code lost:
            return;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public synchronized void b(com.google.android.gms.location.LocationResult r2) {
            /*
                r1 = this;
                monitor-enter(r1)
                a5.f r0 = a5.f.this     // Catch:{ all -> 0x004a }
                a5.r r0 = r0.f820h     // Catch:{ all -> 0x004a }
                if (r0 != 0) goto L_0x0026
                java.lang.String r2 = "FlutterGeolocator"
                java.lang.String r0 = "LocationCallback was called with empty locationResult or no positionChangedCallback was registered."
                android.util.Log.e(r2, r0)     // Catch:{ all -> 0x004a }
                a5.f r2 = a5.f.this     // Catch:{ all -> 0x004a }
                u7.a r0 = r2.f815c     // Catch:{ all -> 0x004a }
                u7.b r2 = r2.f814b     // Catch:{ all -> 0x004a }
                com.google.android.gms.internal.location.h r0 = (com.google.android.gms.internal.location.h) r0     // Catch:{ all -> 0x004a }
                r0.d(r2)     // Catch:{ all -> 0x004a }
                a5.f r2 = a5.f.this     // Catch:{ all -> 0x004a }
                z4.a r2 = r2.f819g     // Catch:{ all -> 0x004a }
                if (r2 == 0) goto L_0x0024
                com.baseflow.geolocator.errors.ErrorCodes r0 = com.baseflow.geolocator.errors.ErrorCodes.errorWhileAcquiringPosition     // Catch:{ all -> 0x004a }
                r2.b(r0)     // Catch:{ all -> 0x004a }
            L_0x0024:
                monitor-exit(r1)
                return
            L_0x0026:
                java.util.List r0 = r2.f7437p     // Catch:{ all -> 0x004a }
                int r0 = r0.size()     // Catch:{ all -> 0x004a }
                if (r0 != 0) goto L_0x0030
                r2 = 0
                goto L_0x003a
            L_0x0030:
                java.util.List r2 = r2.f7437p     // Catch:{ all -> 0x004a }
                int r0 = r0 + -1
                java.lang.Object r2 = r2.get(r0)     // Catch:{ all -> 0x004a }
                android.location.Location r2 = (android.location.Location) r2     // Catch:{ all -> 0x004a }
            L_0x003a:
                a5.f r0 = a5.f.this     // Catch:{ all -> 0x004a }
                a5.q r0 = r0.f816d     // Catch:{ all -> 0x004a }
                r0.a(r2)     // Catch:{ all -> 0x004a }
                a5.f r0 = a5.f.this     // Catch:{ all -> 0x004a }
                a5.r r0 = r0.f820h     // Catch:{ all -> 0x004a }
                r0.a(r2)     // Catch:{ all -> 0x004a }
                monitor-exit(r1)
                return
            L_0x004a:
                r2 = move-exception
                monitor-exit(r1)
                throw r2
            */
            throw new UnsupportedOperationException("Method not decompiled: a5.f.a.b(com.google.android.gms.location.LocationResult):void");
        }
    }

    /* compiled from: FusedLocationClient */
    public static /* synthetic */ class b {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f823a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        static {
            /*
                com.baseflow.geolocator.location.LocationAccuracy[] r0 = com.baseflow.geolocator.location.LocationAccuracy.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f823a = r0
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.lowest     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f823a     // Catch:{ NoSuchFieldError -> 0x001d }
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.low     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f823a     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.baseflow.geolocator.location.LocationAccuracy r1 = com.baseflow.geolocator.location.LocationAccuracy.medium     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: a5.f.b.<clinit>():void");
        }
    }

    public f(Context context, m mVar) {
        int nextInt;
        this.f813a = context;
        int i10 = c.f17266a;
        this.f815c = new h(context);
        this.f818f = mVar;
        this.f816d = new q(context, mVar);
        synchronized (this) {
            nextInt = new SecureRandom().nextInt(MapMakerInternalMap.MAX_SEGMENTS);
        }
        this.f817e = nextInt;
        this.f814b = new a(context);
    }

    public static LocationRequest g(m mVar) {
        float f10;
        long j10;
        long j11;
        m mVar2 = mVar;
        if (Build.VERSION.SDK_INT < 33) {
            WorkSource workSource = r8;
            WorkSource workSource2 = new WorkSource();
            LocationRequest locationRequest = new LocationRequest(102, 3600000, 600000, 0, Long.MAX_VALUE, Long.MAX_VALUE, GeneratedMessageLite.UNINITIALIZED_SERIALIZED_SIZE, 0.0f, true, 3600000, 0, 0, (String) null, false, workSource, (zzd) null);
            if (mVar2 != null) {
                int i10 = i(mVar2.f835a);
                zzip.w(i10);
                locationRequest.f7425p = i10;
                long j12 = mVar2.f837c;
                com.google.android.gms.common.internal.c.b(j12 >= 0, "intervalMillis must be greater than or equal to 0");
                long j13 = locationRequest.f7427r;
                long j14 = locationRequest.f7426q;
                if (j13 == j14 / 6) {
                    locationRequest.f7427r = j12 / 6;
                }
                if (locationRequest.f7433x == j14) {
                    locationRequest.f7433x = j12;
                }
                locationRequest.f7426q = j12;
                long j15 = mVar2.f837c / 2;
                com.google.android.gms.common.internal.c.c(j15 >= 0, "illegal fastest interval: %d", Long.valueOf(j15));
                locationRequest.f7427r = j15;
                float f11 = (float) mVar2.f836b;
                if (f11 >= 0.0f) {
                    locationRequest.f7431v = f11;
                } else {
                    throw new IllegalArgumentException("invalid displacement: " + f11);
                }
            }
            return locationRequest;
        }
        com.google.android.gms.common.internal.c.b(0 >= 0, "intervalMillis must be greater than or equal to 0");
        int i11 = 102;
        if (mVar2 != null) {
            i11 = i(mVar2.f835a);
            zzip.w(i11);
            j11 = mVar2.f837c;
            com.google.android.gms.common.internal.c.b(j11 >= 0, "intervalMillis must be greater than or equal to 0");
            j10 = mVar2.f837c;
            com.google.android.gms.common.internal.c.b(j10 == -1 || j10 >= 0, "minUpdateIntervalMillis must be greater than or equal to 0, or IMPLICIT_MIN_UPDATE_INTERVAL");
            float f12 = (float) mVar2.f836b;
            com.google.android.gms.common.internal.c.b(f12 >= 0.0f, "minUpdateDistanceMeters must be greater than or equal to 0");
            f10 = f12;
        } else {
            f10 = 0.0f;
            j11 = 0;
            j10 = -1;
        }
        if (j10 == -1) {
            j10 = j11;
        } else if (i11 != 105) {
            j10 = Math.min(j10, j11);
        }
        long max = Math.max(0, j11);
        long j16 = -1 == -1 ? j11 : -1;
        WorkSource workSource3 = r4;
        WorkSource workSource4 = new WorkSource((WorkSource) null);
        return new LocationRequest(i11, j11, j10, max, Long.MAX_VALUE, Long.MAX_VALUE, GeneratedMessageLite.UNINITIALIZED_SERIALIZED_SIZE, f10, true, j16, 0, 0, (String) null, false, workSource3, (zzd) null);
    }

    public static int i(LocationAccuracy locationAccuracy) {
        int i10 = b.f823a[locationAccuracy.ordinal()];
        if (i10 == 1) {
            return 105;
        }
        if (i10 != 2) {
            return i10 != 3 ? 100 : 102;
        }
        return 104;
    }

    public boolean a(int i10, int i11) {
        if (i10 == this.f817e) {
            if (i11 == -1) {
                m mVar = this.f818f;
                if (mVar == null || this.f820h == null || this.f819g == null) {
                    return false;
                }
                h(mVar);
                return true;
            }
            z4.a aVar = this.f819g;
            if (aVar != null) {
                aVar.b(ErrorCodes.locationServicesDisabled);
            }
        }
        return false;
    }

    public /* synthetic */ boolean b(Context context) {
        return i.a(this, context);
    }

    @SuppressLint({"MissingPermission"})
    public void c(r rVar, z4.a aVar) {
        h hVar = (h) this.f815c;
        Objects.requireNonNull(hVar);
        i.a aVar2 = new i.a();
        aVar2.f19333a = com.google.android.gms.internal.location.c.f6679p;
        aVar2.f19336d = 2414;
        g c10 = hVar.c(0, aVar2.a());
        Objects.requireNonNull(rVar);
        d dVar = new d(rVar);
        r rVar2 = (r) c10;
        Objects.requireNonNull(rVar2);
        Executor executor = b8.i.f4359a;
        rVar2.e(executor, dVar);
        rVar2.d(executor, new d(aVar));
    }

    @SuppressLint({"MissingPermission"})
    public void d(Activity activity, r rVar, z4.a aVar) {
        this.f820h = rVar;
        this.f819g = aVar;
        LocationRequest g10 = g(this.f818f);
        ArrayList arrayList = new ArrayList();
        arrayList.add(g10);
        LocationSettingsRequest locationSettingsRequest = new LocationSettingsRequest(arrayList, false, false);
        Context context = this.f813a;
        int i10 = c.f17266a;
        g<u7.d> d10 = new j(context).d(locationSettingsRequest);
        d dVar = new d(this);
        r rVar2 = (r) d10;
        Objects.requireNonNull(rVar2);
        Executor executor = b8.i.f4359a;
        rVar2.e(executor, dVar);
        rVar2.d(executor, new e(this, activity, aVar));
    }

    public void e() {
        this.f816d.c();
        ((h) this.f815c).d(this.f814b);
    }

    public void f(n nVar) {
        Context context = this.f813a;
        int i10 = c.f17266a;
        new j(context).d(new LocationSettingsRequest(new ArrayList(), false, false)).b(new d(nVar));
    }

    @SuppressLint({"MissingPermission"})
    public final void h(m mVar) {
        LocationRequest g10 = g(mVar);
        this.f816d.b();
        u7.a aVar = this.f815c;
        u7.b bVar = this.f814b;
        Looper mainLooper = Looper.getMainLooper();
        h hVar = (h) aVar;
        Objects.requireNonNull(hVar);
        if (mainLooper == null) {
            mainLooper = Looper.myLooper();
            com.google.android.gms.common.internal.c.j(mainLooper, "invalid null looper");
        }
        String simpleName = u7.b.class.getSimpleName();
        com.google.android.gms.common.internal.c.j(bVar, "Listener must not be null");
        com.google.android.gms.common.internal.c.j(mainLooper, "Looper must not be null");
        com.google.android.gms.common.internal.c.j(simpleName, "Listener type must not be null");
        com.google.android.gms.common.api.internal.c cVar = new com.google.android.gms.common.api.internal.c(mainLooper, bVar, simpleName);
        com.google.android.gms.internal.location.g gVar = new com.google.android.gms.internal.location.g(hVar, cVar, com.google.android.gms.internal.location.a.f6677a);
        androidx.appcompat.widget.h hVar2 = new androidx.appcompat.widget.h(gVar, g10);
        e eVar = new e();
        eVar.f6482a = hVar2;
        eVar.f6483b = gVar;
        eVar.f6484c = cVar;
        eVar.f6485d = 2436;
        boolean z10 = true;
        com.google.android.gms.common.internal.c.b(true, "Must set register function");
        com.google.android.gms.common.internal.c.b(eVar.f6483b != null, "Must set unregister function");
        if (eVar.f6484c == null) {
            z10 = false;
        }
        com.google.android.gms.common.internal.c.b(z10, "Must set holder");
        c.a aVar2 = eVar.f6484c.f6475c;
        com.google.android.gms.common.internal.c.j(aVar2, "Key must not be null");
        com.google.android.gms.common.api.internal.c cVar2 = eVar.f6484c;
        int i10 = eVar.f6485d;
        d0 d0Var = new d0(eVar, cVar2, (Feature[]) null, true, i10);
        com.google.android.gms.common.api.internal.i iVar = new com.google.android.gms.common.api.internal.i(eVar, aVar2);
        c0 c0Var = c0.f19318p;
        com.google.android.gms.common.internal.c.j(cVar2.f6475c, "Listener has already been released.");
        com.google.android.gms.common.internal.c.j(aVar2, "Listener has already been released.");
        com.google.android.gms.common.api.internal.b bVar2 = hVar.f6436h;
        Objects.requireNonNull(bVar2);
        b8.h hVar3 = new b8.h();
        bVar2.f(hVar3, i10, hVar);
        com.google.android.gms.common.api.internal.j jVar = new com.google.android.gms.common.api.internal.j(new b0(d0Var, iVar, c0Var), hVar3);
        Handler handler = bVar2.f6471n;
        handler.sendMessage(handler.obtainMessage(8, new a0(jVar, bVar2.f6466i.get(), hVar)));
    }
}
