package a5;

/* compiled from: LocationServiceListener */
public interface n {
}
