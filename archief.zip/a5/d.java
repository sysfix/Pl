package a5;

import android.content.Intent;
import b8.c;
import b8.g;
import com.baseflow.geolocator.errors.ErrorCodes;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStates;
import io.flutter.plugins.firebase.core.GeneratedAndroidFirebaseCore;
import io.flutter.plugins.firebase.core.a;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import ma.i0;
import ma.j0;
import ma.k0;

public final /* synthetic */ class d implements c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f807a = 0;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Object f808b;

    public /* synthetic */ d(n nVar) {
        this.f808b = nVar;
    }

    public /* synthetic */ d(Intent intent) {
        this.f808b = intent;
    }

    public /* synthetic */ d(GeneratedAndroidFirebaseCore.f fVar) {
        this.f808b = fVar;
    }

    public /* synthetic */ d(ScheduledFuture scheduledFuture) {
        this.f808b = scheduledFuture;
    }

    public /* synthetic */ d(k0.a aVar) {
        this.f808b = aVar;
    }

    public final void a(g gVar) {
        boolean z10 = false;
        switch (this.f807a) {
            case 0:
                n nVar = (n) this.f808b;
                if (!gVar.m()) {
                    ((b) nVar).a(ErrorCodes.locationServicesDisabled);
                }
                u7.d dVar = (u7.d) gVar.i();
                if (dVar != null) {
                    LocationSettingsStates locationSettingsStates = ((LocationSettingsResult) dVar.f17267a).f7442q;
                    boolean z11 = locationSettingsStates != null && locationSettingsStates.f7443p;
                    boolean z12 = locationSettingsStates != null && locationSettingsStates.f7444q;
                    if (z11 || z12) {
                        z10 = true;
                    }
                    ((b) nVar).b(z10);
                    return;
                }
                ((b) nVar).a(ErrorCodes.locationServicesDisabled);
                return;
            case 1:
                i0.b((Intent) this.f808b);
                return;
            case 2:
                int i10 = j0.f14398d;
                ((k0.a) this.f808b).a();
                return;
            case 3:
                ((ScheduledFuture) this.f808b).cancel(false);
                return;
            default:
                GeneratedAndroidFirebaseCore.f fVar = (GeneratedAndroidFirebaseCore.f) this.f808b;
                Map<String, String> map = a.f12596c;
                if (gVar.m()) {
                    fVar.a(gVar.i());
                    return;
                } else {
                    fVar.b(gVar.h());
                    return;
                }
        }
    }
}
