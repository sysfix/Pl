package a5;

import android.content.Context;
import android.location.LocationManager;

/* compiled from: LocationClient */
public final /* synthetic */ class i {
    public static boolean a(j _this, Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService("location");
        return locationManager.isProviderEnabled("gps") || locationManager.isProviderEnabled("network");
    }
}
