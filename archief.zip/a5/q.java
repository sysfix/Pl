package a5;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.location.OnNmeaMessageListener;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import java.util.Calendar;

/* compiled from: NmeaClient */
public class q {

    /* renamed from: a  reason: collision with root package name */
    public final LocationManager f842a;

    /* renamed from: b  reason: collision with root package name */
    public final m f843b;
    @TargetApi(24)

    /* renamed from: c  reason: collision with root package name */
    public OnNmeaMessageListener f844c;

    /* renamed from: d  reason: collision with root package name */
    public String f845d;

    /* renamed from: e  reason: collision with root package name */
    public Calendar f846e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f847f = false;

    public q(Context context, m mVar) {
        this.f843b = mVar;
        this.f842a = (LocationManager) context.getSystemService("location");
        if (Build.VERSION.SDK_INT >= 24) {
            this.f844c = new p(this);
        }
    }

    public void a(Location location) {
        if (location != null && this.f845d != null && this.f843b != null && this.f847f) {
            Calendar instance = Calendar.getInstance();
            instance.add(13, -5);
            Calendar calendar = this.f846e;
            if ((calendar == null || !calendar.before(instance)) && this.f843b.f838d) {
                String[] split = this.f845d.split(",");
                if (split[0].startsWith("$GPGGA") && split.length > 9 && !split[9].isEmpty()) {
                    double parseDouble = Double.parseDouble(split[9]);
                    if (location.getExtras() == null) {
                        location.setExtras(Bundle.EMPTY);
                    }
                    location.getExtras().putDouble("geolocator_mslAltitude", parseDouble);
                }
            }
        }
    }

    @SuppressLint({"MissingPermission"})
    public void b() {
        m mVar;
        LocationManager locationManager;
        if (!this.f847f && (mVar = this.f843b) != null && mVar.f838d && Build.VERSION.SDK_INT >= 24 && (locationManager = this.f842a) != null) {
            locationManager.addNmeaListener(this.f844c, (Handler) null);
            this.f847f = true;
        }
    }

    public void c() {
        LocationManager locationManager;
        m mVar = this.f843b;
        if (mVar != null && mVar.f838d && Build.VERSION.SDK_INT >= 24 && (locationManager = this.f842a) != null) {
            locationManager.removeNmeaListener(this.f844c);
            this.f847f = false;
        }
    }
}
