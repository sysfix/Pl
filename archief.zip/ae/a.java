package ae;

import android.content.Context;
import android.content.pm.PackageManager;
import android.view.WindowManager;
import le.a;
import re.c;
import re.j;
import rg.d0;

/* compiled from: DeviceInfoPlusPlugin.kt */
public final class a implements le.a {

    /* renamed from: a  reason: collision with root package name */
    public j f879a;

    public void d(a.b bVar) {
        d0.g(bVar, "binding");
        c cVar = bVar.f14106b;
        d0.f(cVar, "binding.binaryMessenger");
        Context context = bVar.f14105a;
        d0.f(context, "binding.applicationContext");
        this.f879a = new j(cVar, "dev.fluttercommunity.plus/device_info");
        PackageManager packageManager = context.getPackageManager();
        d0.f(packageManager, "context.packageManager");
        Object systemService = context.getSystemService("window");
        d0.e(systemService, "null cannot be cast to non-null type android.view.WindowManager");
        b bVar2 = new b(packageManager, (WindowManager) systemService);
        j jVar = this.f879a;
        if (jVar != null) {
            jVar.b(bVar2);
        } else {
            d0.q("methodChannel");
            throw null;
        }
    }

    public void h(a.b bVar) {
        d0.g(bVar, "binding");
        j jVar = this.f879a;
        if (jVar != null) {
            jVar.b((j.c) null);
        } else {
            d0.q("methodChannel");
            throw null;
        }
    }
}
