package ae;

import android.content.pm.PackageManager;
import android.view.WindowManager;
import dev.fluttercommunity.plus.share.Share;
import java.util.Map;
import re.i;
import re.j;

/* compiled from: MethodCallHandlerImpl.kt */
public final class b implements j.c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f880a = 0;

    /* renamed from: b  reason: collision with root package name */
    public final Object f881b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f882c;

    public b(Share share, ce.b bVar) {
        this.f881b = share;
        this.f882c = bVar;
    }

    public void a(i iVar) {
        if (!(iVar.f16445b instanceof Map)) {
            throw new IllegalArgumentException("Map arguments expected".toString());
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:104:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:105:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:106:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:107:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:108:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:109:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:111:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x02ce, code lost:
        if (r1.equals("share") == false) goto L_0x039b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x02fe, code lost:
        if (r1.equals("shareFilesWithResult") == false) goto L_0x039b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0308, code lost:
        if (r1.equals("shareWithResult") == false) goto L_0x039b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x030c, code lost:
        a(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x030f, code lost:
        if (r0 == false) goto L_0x031d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0319, code lost:
        if (((ce.b) r12.f882c).c(r14) != false) goto L_0x031d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x031d, code lost:
        r2 = r13.a("text");
        rg.d0.e(r2, "null cannot be cast to non-null type kotlin.String");
        ((dev.fluttercommunity.plus.share.Share) r12.f881b).d((java.lang.String) r2, (java.lang.String) r13.a("subject"), r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:76:0x0333, code lost:
        if (r0 != false) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0335, code lost:
        if (r0 == false) goto L_0x033b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0337, code lost:
        r14.a("dev.fluttercommunity.plus/share/unavailable");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:79:0x033b, code lost:
        r14.a((java.lang.Object) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0345, code lost:
        if (r1.equals("shareFiles") == false) goto L_0x039b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x0348, code lost:
        a(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x034b, code lost:
        if (r0 == false) goto L_0x0358;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x0355, code lost:
        if (((ce.b) r12.f882c).c(r14) != false) goto L_0x0358;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:?, code lost:
        r2 = r13.a("paths");
        rg.d0.d(r2);
        ((dev.fluttercommunity.plus.share.Share) r12.f881b).e((java.util.List) r2, (java.util.List) r13.a("mimeTypes"), (java.lang.String) r13.a("text"), (java.lang.String) r13.a("subject"), r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x0384, code lost:
        if (r0 != false) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x0386, code lost:
        if (r0 == false) goto L_0x038c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:90:0x0388, code lost:
        r14.a("dev.fluttercommunity.plus/share/unavailable");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x038c, code lost:
        r14.a((java.lang.Object) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:92:0x0390, code lost:
        r13 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x0391, code lost:
        r14.b("Share failed", r13.getMessage(), (java.lang.Object) null);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void g(re.i r13, re.j.d r14) {
        /*
            r12 = this;
            int r0 = r12.f880a
            r1 = 2
            r2 = 0
            java.lang.String r3 = "result"
            java.lang.String r4 = "call"
            switch(r0) {
                case 0: goto L_0x000d;
                default: goto L_0x000b;
            }
        L_0x000b:
            goto L_0x029f
        L_0x000d:
            rg.d0.g(r13, r4)
            rg.d0.g(r14, r3)
            java.lang.String r13 = r13.f16444a
            java.lang.String r0 = "getDeviceInfo"
            boolean r13 = r13.equals(r0)
            if (r13 == 0) goto L_0x029b
            java.util.HashMap r13 = new java.util.HashMap
            r13.<init>()
            java.lang.String r0 = android.os.Build.BOARD
            java.lang.String r3 = "BOARD"
            rg.d0.f(r0, r3)
            java.lang.String r3 = "board"
            r13.put(r3, r0)
            java.lang.String r0 = android.os.Build.BOOTLOADER
            java.lang.String r3 = "BOOTLOADER"
            rg.d0.f(r0, r3)
            java.lang.String r3 = "bootloader"
            r13.put(r3, r0)
            java.lang.String r0 = android.os.Build.BRAND
            java.lang.String r3 = "BRAND"
            rg.d0.f(r0, r3)
            java.lang.String r3 = "brand"
            r13.put(r3, r0)
            java.lang.String r3 = android.os.Build.DEVICE
            java.lang.String r4 = "DEVICE"
            rg.d0.f(r3, r4)
            java.lang.String r4 = "device"
            r13.put(r4, r3)
            java.lang.String r4 = android.os.Build.DISPLAY
            java.lang.String r5 = "DISPLAY"
            rg.d0.f(r4, r5)
            java.lang.String r5 = "display"
            r13.put(r5, r4)
            java.lang.String r4 = android.os.Build.FINGERPRINT
            java.lang.String r5 = "FINGERPRINT"
            rg.d0.f(r4, r5)
            java.lang.String r5 = "fingerprint"
            r13.put(r5, r4)
            java.lang.String r5 = android.os.Build.HARDWARE
            java.lang.String r6 = "HARDWARE"
            rg.d0.f(r5, r6)
            java.lang.String r6 = "hardware"
            r13.put(r6, r5)
            java.lang.String r6 = android.os.Build.HOST
            java.lang.String r7 = "HOST"
            rg.d0.f(r6, r7)
            java.lang.String r7 = "host"
            r13.put(r7, r6)
            java.lang.String r6 = android.os.Build.ID
            java.lang.String r7 = "ID"
            rg.d0.f(r6, r7)
            java.lang.String r7 = "id"
            r13.put(r7, r6)
            java.lang.String r6 = android.os.Build.MANUFACTURER
            java.lang.String r7 = "MANUFACTURER"
            rg.d0.f(r6, r7)
            java.lang.String r7 = "manufacturer"
            r13.put(r7, r6)
            java.lang.String r7 = android.os.Build.MODEL
            java.lang.String r8 = "MODEL"
            rg.d0.f(r7, r8)
            java.lang.String r8 = "model"
            r13.put(r8, r7)
            java.lang.String r8 = android.os.Build.PRODUCT
            java.lang.String r9 = "PRODUCT"
            rg.d0.f(r8, r9)
            java.lang.String r9 = "product"
            r13.put(r9, r8)
            java.lang.String[] r9 = android.os.Build.SUPPORTED_32_BIT_ABIS
            java.lang.String r10 = "SUPPORTED_32_BIT_ABIS"
            rg.d0.f(r9, r10)
            int r10 = r9.length
            java.lang.Object[] r9 = java.util.Arrays.copyOf(r9, r10)
            java.util.List r9 = yf.h.v(r9)
            java.lang.String r10 = "supported32BitAbis"
            r13.put(r10, r9)
            java.lang.String[] r9 = android.os.Build.SUPPORTED_64_BIT_ABIS
            java.lang.String r10 = "SUPPORTED_64_BIT_ABIS"
            rg.d0.f(r9, r10)
            int r10 = r9.length
            java.lang.Object[] r9 = java.util.Arrays.copyOf(r9, r10)
            java.util.List r9 = yf.h.v(r9)
            java.lang.String r10 = "supported64BitAbis"
            r13.put(r10, r9)
            java.lang.String[] r9 = android.os.Build.SUPPORTED_ABIS
            java.lang.String r10 = "SUPPORTED_ABIS"
            rg.d0.f(r9, r10)
            int r10 = r9.length
            java.lang.Object[] r9 = java.util.Arrays.copyOf(r9, r10)
            java.util.List r9 = yf.h.v(r9)
            java.lang.String r10 = "supportedAbis"
            r13.put(r10, r9)
            java.lang.String r9 = android.os.Build.TAGS
            java.lang.String r10 = "TAGS"
            rg.d0.f(r9, r10)
            java.lang.String r10 = "tags"
            r13.put(r10, r9)
            java.lang.String r9 = android.os.Build.TYPE
            java.lang.String r10 = "TYPE"
            rg.d0.f(r9, r10)
            java.lang.String r10 = "type"
            r13.put(r10, r9)
            java.lang.String r9 = "generic"
            boolean r0 = pg.j.w(r0, r9, r2, r1)
            java.lang.String r10 = "unknown"
            r11 = 1
            if (r0 == 0) goto L_0x011a
            boolean r0 = pg.j.w(r3, r9, r2, r1)
            if (r0 != 0) goto L_0x0179
        L_0x011a:
            boolean r0 = pg.j.w(r4, r9, r2, r1)
            if (r0 != 0) goto L_0x0179
            boolean r0 = pg.j.w(r4, r10, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "goldfish"
            boolean r0 = pg.k.y(r5, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "ranchu"
            boolean r0 = pg.k.y(r5, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "google_sdk"
            boolean r0 = pg.k.y(r7, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "Emulator"
            boolean r0 = pg.k.y(r7, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "Android SDK built for x86"
            boolean r0 = pg.k.y(r7, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "Genymotion"
            boolean r0 = pg.k.y(r6, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "sdk"
            boolean r0 = pg.k.y(r8, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "vbox86p"
            boolean r0 = pg.k.y(r8, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "emulator"
            boolean r0 = pg.k.y(r8, r0, r2, r1)
            if (r0 != 0) goto L_0x0179
            java.lang.String r0 = "simulator"
            boolean r0 = pg.k.y(r8, r0, r2, r1)
            if (r0 == 0) goto L_0x0177
            goto L_0x0179
        L_0x0177:
            r0 = r2
            goto L_0x017a
        L_0x0179:
            r0 = r11
        L_0x017a:
            r0 = r0 ^ r11
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            java.lang.String r1 = "isPhysicalDevice"
            r13.put(r1, r0)
            java.lang.Object r0 = r12.f881b
            android.content.pm.PackageManager r0 = (android.content.pm.PackageManager) r0
            android.content.pm.FeatureInfo[] r0 = r0.getSystemAvailableFeatures()
            java.lang.String r1 = "packageManager.systemAvailableFeatures"
            rg.d0.f(r0, r1)
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            int r3 = r0.length
            r4 = r2
        L_0x0198:
            if (r4 >= r3) goto L_0x01ab
            r5 = r0[r4]
            java.lang.String r6 = r5.name
            if (r6 != 0) goto L_0x01a2
            r6 = r11
            goto L_0x01a3
        L_0x01a2:
            r6 = r2
        L_0x01a3:
            if (r6 != 0) goto L_0x01a8
            r1.add(r5)
        L_0x01a8:
            int r4 = r4 + 1
            goto L_0x0198
        L_0x01ab:
            java.util.ArrayList r0 = new java.util.ArrayList
            r2 = 10
            int r2 = yf.i.S(r1, r2)
            r0.<init>(r2)
            java.util.Iterator r1 = r1.iterator()
        L_0x01ba:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x01cc
            java.lang.Object r2 = r1.next()
            android.content.pm.FeatureInfo r2 = (android.content.pm.FeatureInfo) r2
            java.lang.String r2 = r2.name
            r0.add(r2)
            goto L_0x01ba
        L_0x01cc:
            java.lang.String r1 = "systemFeatures"
            r13.put(r1, r0)
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            int r1 = android.os.Build.VERSION.SDK_INT
            java.lang.String r2 = android.os.Build.VERSION.BASE_OS
            java.lang.String r3 = "BASE_OS"
            rg.d0.f(r2, r3)
            java.lang.String r3 = "baseOS"
            r0.put(r3, r2)
            int r2 = android.os.Build.VERSION.PREVIEW_SDK_INT
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            java.lang.String r3 = "previewSdkInt"
            r0.put(r3, r2)
            java.lang.String r2 = android.os.Build.VERSION.SECURITY_PATCH
            java.lang.String r3 = "SECURITY_PATCH"
            rg.d0.f(r2, r3)
            java.lang.String r3 = "securityPatch"
            r0.put(r3, r2)
            java.lang.String r2 = android.os.Build.VERSION.CODENAME
            java.lang.String r3 = "CODENAME"
            rg.d0.f(r2, r3)
            java.lang.String r3 = "codename"
            r0.put(r3, r2)
            java.lang.String r2 = android.os.Build.VERSION.INCREMENTAL
            java.lang.String r3 = "INCREMENTAL"
            rg.d0.f(r2, r3)
            java.lang.String r3 = "incremental"
            r0.put(r3, r2)
            java.lang.String r2 = android.os.Build.VERSION.RELEASE
            java.lang.String r3 = "RELEASE"
            rg.d0.f(r2, r3)
            java.lang.String r3 = "release"
            r0.put(r3, r2)
            java.lang.Integer r2 = java.lang.Integer.valueOf(r1)
            java.lang.String r3 = "sdkInt"
            r0.put(r3, r2)
            java.lang.String r2 = "version"
            r13.put(r2, r0)
            java.lang.Object r0 = r12.f882c
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            android.view.Display r0 = r0.getDefaultDisplay()
            java.lang.String r2 = "windowManager.defaultDisplay"
            rg.d0.f(r0, r2)
            android.util.DisplayMetrics r2 = new android.util.DisplayMetrics
            r2.<init>()
            r0.getRealMetrics(r2)
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            int r3 = r2.widthPixels
            double r3 = (double) r3
            java.lang.Double r3 = java.lang.Double.valueOf(r3)
            java.lang.String r4 = "widthPx"
            r0.put(r4, r3)
            int r3 = r2.heightPixels
            double r3 = (double) r3
            java.lang.Double r3 = java.lang.Double.valueOf(r3)
            java.lang.String r4 = "heightPx"
            r0.put(r4, r3)
            float r3 = r2.xdpi
            java.lang.Float r3 = java.lang.Float.valueOf(r3)
            java.lang.String r4 = "xDpi"
            r0.put(r4, r3)
            float r2 = r2.ydpi
            java.lang.Float r2 = java.lang.Float.valueOf(r2)
            java.lang.String r3 = "yDpi"
            r0.put(r3, r2)
            java.lang.String r2 = "displayMetrics"
            r13.put(r2, r0)
            r0 = 26
            java.lang.String r2 = "serialNumber"
            if (r1 < r0) goto L_0x028d
            java.lang.String r10 = android.os.Build.getSerial()     // Catch:{ SecurityException -> 0x0284 }
        L_0x0284:
            java.lang.String r0 = "try {\n                  …UNKNOWN\n                }"
            rg.d0.f(r10, r0)
            r13.put(r2, r10)
            goto L_0x0297
        L_0x028d:
            java.lang.String r0 = android.os.Build.SERIAL
            java.lang.String r1 = "SERIAL"
            rg.d0.f(r0, r1)
            r13.put(r2, r0)
        L_0x0297:
            r14.a(r13)
            goto L_0x029e
        L_0x029b:
            r14.c()
        L_0x029e:
            return
        L_0x029f:
            rg.d0.g(r13, r4)
            rg.d0.g(r14, r3)
            java.lang.String r0 = r13.f16444a
            java.lang.String r3 = "call.method"
            rg.d0.f(r0, r3)
            java.lang.String r3 = "WithResult"
            boolean r0 = pg.j.l(r0, r3, r2, r1)
            java.lang.String r1 = r13.f16444a
            if (r1 == 0) goto L_0x039b
            int r3 = r1.hashCode()
            java.lang.String r10 = "dev.fluttercommunity.plus/share/unavailable"
            java.lang.String r4 = "subject"
            java.lang.String r5 = "text"
            java.lang.String r6 = "null cannot be cast to non-null type kotlin.String"
            r11 = 0
            switch(r3) {
                case -1811378728: goto L_0x033f;
                case -1594861118: goto L_0x0302;
                case -1212337029: goto L_0x02f8;
                case -743768819: goto L_0x02d2;
                case 109400031: goto L_0x02c8;
                default: goto L_0x02c6;
            }
        L_0x02c6:
            goto L_0x039b
        L_0x02c8:
            java.lang.String r2 = "share"
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x030c
            goto L_0x039b
        L_0x02d2:
            java.lang.String r3 = "shareUri"
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x02dc
            goto L_0x039b
        L_0x02dc:
            r12.a(r13)
            java.lang.Object r1 = r12.f881b
            dev.fluttercommunity.plus.share.Share r1 = (dev.fluttercommunity.plus.share.Share) r1
            java.lang.String r3 = "uri"
            java.lang.Object r13 = r13.a(r3)
            rg.d0.e(r13, r6)
            java.lang.String r13 = (java.lang.String) r13
            r1.d(r13, r11, r2)
            if (r0 != 0) goto L_0x039e
            r14.a(r11)
            goto L_0x039e
        L_0x02f8:
            java.lang.String r2 = "shareFilesWithResult"
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x0348
            goto L_0x039b
        L_0x0302:
            java.lang.String r2 = "shareWithResult"
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x030c
            goto L_0x039b
        L_0x030c:
            r12.a(r13)
            if (r0 == 0) goto L_0x031d
            java.lang.Object r1 = r12.f882c
            ce.b r1 = (ce.b) r1
            boolean r1 = r1.c(r14)
            if (r1 != 0) goto L_0x031d
            goto L_0x039e
        L_0x031d:
            java.lang.Object r1 = r12.f881b
            dev.fluttercommunity.plus.share.Share r1 = (dev.fluttercommunity.plus.share.Share) r1
            java.lang.Object r2 = r13.a(r5)
            rg.d0.e(r2, r6)
            java.lang.String r2 = (java.lang.String) r2
            java.lang.Object r13 = r13.a(r4)
            java.lang.String r13 = (java.lang.String) r13
            r1.d(r2, r13, r0)
            if (r0 != 0) goto L_0x039e
            if (r0 == 0) goto L_0x033b
            r14.a(r10)
            goto L_0x039e
        L_0x033b:
            r14.a(r11)
            goto L_0x039e
        L_0x033f:
            java.lang.String r2 = "shareFiles"
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x0348
            goto L_0x039b
        L_0x0348:
            r12.a(r13)
            if (r0 == 0) goto L_0x0358
            java.lang.Object r1 = r12.f882c
            ce.b r1 = (ce.b) r1
            boolean r1 = r1.c(r14)
            if (r1 != 0) goto L_0x0358
            goto L_0x039e
        L_0x0358:
            java.lang.Object r1 = r12.f881b     // Catch:{ IOException -> 0x0390 }
            dev.fluttercommunity.plus.share.Share r1 = (dev.fluttercommunity.plus.share.Share) r1     // Catch:{ IOException -> 0x0390 }
            java.lang.String r2 = "paths"
            java.lang.Object r2 = r13.a(r2)     // Catch:{ IOException -> 0x0390 }
            rg.d0.d(r2)     // Catch:{ IOException -> 0x0390 }
            java.util.List r2 = (java.util.List) r2     // Catch:{ IOException -> 0x0390 }
            java.lang.String r3 = "mimeTypes"
            java.lang.Object r3 = r13.a(r3)     // Catch:{ IOException -> 0x0390 }
            r6 = r3
            java.util.List r6 = (java.util.List) r6     // Catch:{ IOException -> 0x0390 }
            java.lang.Object r3 = r13.a(r5)     // Catch:{ IOException -> 0x0390 }
            r7 = r3
            java.lang.String r7 = (java.lang.String) r7     // Catch:{ IOException -> 0x0390 }
            java.lang.Object r13 = r13.a(r4)     // Catch:{ IOException -> 0x0390 }
            r8 = r13
            java.lang.String r8 = (java.lang.String) r8     // Catch:{ IOException -> 0x0390 }
            r4 = r1
            r5 = r2
            r9 = r0
            r4.e(r5, r6, r7, r8, r9)     // Catch:{ IOException -> 0x0390 }
            if (r0 != 0) goto L_0x039e
            if (r0 == 0) goto L_0x038c
            r14.a(r10)     // Catch:{ IOException -> 0x0390 }
            goto L_0x039e
        L_0x038c:
            r14.a(r11)     // Catch:{ IOException -> 0x0390 }
            goto L_0x039e
        L_0x0390:
            r13 = move-exception
            java.lang.String r13 = r13.getMessage()
            java.lang.String r0 = "Share failed"
            r14.b(r0, r13, r11)
            goto L_0x039e
        L_0x039b:
            r14.c()
        L_0x039e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ae.b.g(re.i, re.j$d):void");
    }

    public b(PackageManager packageManager, WindowManager windowManager) {
        this.f881b = packageManager;
        this.f882c = windowManager;
    }
}
