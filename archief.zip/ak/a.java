package ak;

import android.net.Uri;
import gg.l;
import rg.d0;
import zendesk.ui.android.conversation.avatar.AvatarMask;

/* compiled from: AvatarImageRendering.kt */
public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final b f7a;

    /* renamed from: ak.a$a  reason: collision with other inner class name */
    /* compiled from: AvatarImageRendering.kt */
    public static final class C0000a {

        /* renamed from: a  reason: collision with root package name */
        public b f8a = new b((Uri) null, false, 0, (Integer) null, (AvatarMask) null, 31);

        public final C0000a a(l<? super b, b> lVar) {
            this.f8a = lVar.invoke(this.f8a);
            return this;
        }
    }

    public a(C0000a aVar) {
        this.f7a = aVar.f8a;
    }

    public final C0000a a() {
        d0.g(this, "rendering");
        C0000a aVar = new C0000a();
        aVar.f8a = this.f7a;
        return aVar;
    }

    public a() {
        this.f7a = new b((Uri) null, false, 0, (Integer) null, (AvatarMask) null, 31);
    }
}
