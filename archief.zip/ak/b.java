package ak;

import ai.plaud.android.plaud.R;
import android.net.Uri;
import f.a;
import java.util.Objects;
import rg.d0;
import zendesk.ui.android.conversation.avatar.AvatarMask;

/* compiled from: AvatarImageState.kt */
public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final Uri f9a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f10b;

    /* renamed from: c  reason: collision with root package name */
    public final int f11c;

    /* renamed from: d  reason: collision with root package name */
    public final Integer f12d;

    /* renamed from: e  reason: collision with root package name */
    public final AvatarMask f13e;

    public b() {
        this((Uri) null, false, 0, (Integer) null, (AvatarMask) null, 31);
    }

    public b(Uri uri, boolean z10, int i10, Integer num, AvatarMask avatarMask) {
        this.f9a = uri;
        this.f10b = z10;
        this.f11c = i10;
        this.f12d = num;
        this.f13e = avatarMask;
    }

    public static b a(b bVar, Uri uri, boolean z10, int i10, Integer num, AvatarMask avatarMask, int i11) {
        if ((i11 & 1) != 0) {
            uri = bVar.f9a;
        }
        Uri uri2 = uri;
        if ((i11 & 2) != 0) {
            z10 = bVar.f10b;
        }
        boolean z11 = z10;
        if ((i11 & 4) != 0) {
            i10 = bVar.f11c;
        }
        int i12 = i10;
        if ((i11 & 8) != 0) {
            num = bVar.f12d;
        }
        Integer num2 = num;
        if ((i11 & 16) != 0) {
            avatarMask = bVar.f13e;
        }
        AvatarMask avatarMask2 = avatarMask;
        Objects.requireNonNull(bVar);
        d0.g(avatarMask2, "mask");
        return new b(uri2, z11, i12, num2, avatarMask2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return d0.b(this.f9a, bVar.f9a) && this.f10b == bVar.f10b && this.f11c == bVar.f11c && d0.b(this.f12d, bVar.f12d) && this.f13e == bVar.f13e;
    }

    public int hashCode() {
        Uri uri = this.f9a;
        int i10 = 0;
        int hashCode = (uri == null ? 0 : uri.hashCode()) * 31;
        boolean z10 = this.f10b;
        if (z10) {
            z10 = true;
        }
        int i11 = (((hashCode + (z10 ? 1 : 0)) * 31) + this.f11c) * 31;
        Integer num = this.f12d;
        if (num != null) {
            i10 = num.hashCode();
        }
        return this.f13e.hashCode() + ((i11 + i10) * 31);
    }

    public String toString() {
        StringBuilder a10 = a.a("AvatarImageState(uri=");
        a10.append(this.f9a);
        a10.append(", shouldAnimate=");
        a10.append(this.f10b);
        a10.append(", avatarSize=");
        a10.append(this.f11c);
        a10.append(", backgroundColor=");
        a10.append(this.f12d);
        a10.append(", mask=");
        a10.append(this.f13e);
        a10.append(')');
        return a10.toString();
    }

    public b(Uri uri, boolean z10, int i10, Integer num, AvatarMask avatarMask, int i11) {
        z10 = (i11 & 2) != 0 ? true : z10;
        i10 = (i11 & 4) != 0 ? R.dimen.zuia_avatar_image_size : i10;
        AvatarMask avatarMask2 = (i11 & 16) != 0 ? AvatarMask.NONE : null;
        d0.g(avatarMask2, "mask");
        this.f9a = null;
        this.f10b = z10;
        this.f11c = i10;
        this.f12d = null;
        this.f13e = avatarMask2;
    }
}
